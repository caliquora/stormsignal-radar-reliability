# Open-source visual stack

The visual revision uses installed, recognized open-source packages. No third-party skill repository or unrecognized executable was installed, and no stock imagery or third-party template was copied.

| Component | Version checked | License | Use |
|---|---|---|---|
| Matplotlib | 3.10.8 | Matplotlib license, based on PSF | Seven regenerated scientific figure collections; SVG and PNG export |
| ReportLab | 4.4.9 | BSD | Research brief layout and PDF generation |
| NumPy | 2.3.5 | BSD | Reading saved arrays and unchanged summary calculations |
| pandas | 2.2.3 | BSD 3-Clause | Reading tabular outputs and original seed means |
| DejaVu Sans and Serif | Font included with Matplotlib | Bitstream Vera license with DejaVu changes in public domain | Embedded PDF and offline HTML typography; chart fonts |
| Pillow | 13.0.0 | MIT-CMU | Internal render/contact-sheet inspection only |
| Playwright | 1.62.0 | Apache-2.0 | Internal local-browser layout checks only |

License names were checked against installed package metadata and license files. Notices for the primary visual dependencies and embedded font are included in `docs/licenses/`. Dependencies are used, not vendored into this archive. The report's CSS, layout, simple radar motif, and presentation code are original to this project. No remote fonts, analytics, CDN code, or network requests are required to view the HTML.

The project's included MIT license applies to its original code. It does not relicense SEVIR data or third-party software. Existing SEVIR attribution and data-use documentation remain in `DATA_SOURCES.md` and `NOVELTY_AUDIT.md`.

## Impeccable guidance

Impeccable was not available as an installed skill. The official open-source reading material was reviewed and applied directly: [skill source](https://github.com/pbakaus/impeccable/blob/main/skill/SKILL.src.md), [audit](https://github.com/pbakaus/impeccable/blob/main/skill/reference/audit.md), [polish](https://github.com/pbakaus/impeccable/blob/main/skill/reference/polish.md), and [craft floor](https://github.com/pbakaus/impeccable/blob/main/skill/reference/craft-floor.md). Its [Apache-2.0 license](https://github.com/pbakaus/impeccable/blob/main/LICENSE), Copyright 2025 Paul Bakaus, is included in `licenses/Impeccable-LICENSE.txt`.

Applied principles include a reading-focused hierarchy, consistent spacing and type, restrained component use, visible caveats, keyboard focus, adequate touch targets, image dimensions, and local font assets. No Impeccable package, binary, plugin hook, installer, or detector ran. No external skill installation or machine-generated design score is claimed. The actual render stack remains Matplotlib, ReportLab, DejaVu and Poppler.
