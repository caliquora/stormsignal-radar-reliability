# Explore StormSignal in three minutes

## Open it

Open `explorer/index.html` in a modern browser. The experiment controls and radar maps work offline: there are no API calls, credentials, external scripts, or live weather feeds. If you serve the repository root with `python -m http.server 8000`, visit `/explorer/` so all supporting document and CSV links resolve. This local preview command does not deploy anything publicly.

## Try these three questions

1. **What changes when a feed is 30 minutes stale?** Switch between field error, probability error and high-echo overlap. A reduction in one kind of error does not guarantee improved detection.
2. **Can the same freshness badge hide different problems?** Change the simulated stale region from a front proxy to quiet sky. The age histogram stays matched while the real radar values hidden by the fault change.
3. **Why does this matter outside a notebook?** Observation time is a property of the data, not the HTTP request. Data consumers should retain observation age and evaluate faults before treating a forecast as current.

## What is real?

- All model curves and table values come from `reports/metrics.csv`. CNN rows are unweighted means of the two saved seeds. Baselines have one run.
- Paired differences and intervals come from `reports/paired_day_bootstrap.csv`; the resampling unit is the UTC day.
- Radar fields come from `studies/spatial-freshness/results/predetermined_example.npz` (case S839404), selected by the study protocol. The underlying scans are real; stale placement is simulated.
- Source SHA-256 hashes are embedded in `explorer/evidence.json` and in the standalone HTML.
- This is a replay of recorded evidence, not live inference, a weather prediction service, or a new training result.

## Rebuild and test

With the research environment installed:

```
python scripts/build_explorer.py
python scripts/model_tradeoffs.py
python -m unittest discover -s tests -p test_explorer.py -v
node tests/test_explorer_ui.cjs
```

Building the explorer requires Python and NumPy; viewing it requires only a browser. The Node test uses no npm dependencies and verifies control state changes and canvas data with a DOM stub. It does **not** measure browser layout or accessibility conformance.

## Validation on 2026-11-12

- Seven new evidence-integrity tests passed, including exact embedded-data matching and matched age histograms.
- Behavior checks passed for 12 metric/age combinations, seven model rows, three placement states, unchanged freshness badge, and changing radar pixels.
- Four existing data-integrity tests passed.
- The complete legacy test suite could not run because PyTorch is absent in the current execution environment. No model was retrained.
- Chromium visual QA was attempted, but process socket restrictions prevented browser startup. Desktop/mobile appearance remains unverified in an actual browser. Do not describe this as visually signed off.
- GitHub publication was not attempted; the earlier write approval remains a separate blocker.

## Repository build-out

`docs/MODEL_TRADEOFFS.md` and `reports/model_tradeoffs.csv` add a reproducible descriptive Pareto audit. This exposes tradeoffs across the frozen MAE, Brier and CSI means without inventing a universal winning model. It is not a new confirmatory test or a stakeholder utility model.
