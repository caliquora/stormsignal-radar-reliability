# Visual revision verification

Visual edition prepared November 11, 2026 from the saved combined StormSignal project. This is a presentation revision, not a new experiment.

## What changed

- Integrated both executed studies in an 18-page landscape brief and a portable offline HTML report. The separate spatial brief is now five pages.
- Gave the brief an editorial cover, a prominent “Why should I care?” page, larger original charts, and dedicated spatial pages for the matched design, input-information loss, same-support control, sensitivity, limitations, and novelty.
- Applied the official open-source Impeccable audit/polish reading guidance directly. Impeccable was not installed as a runnable skill. No package, binary, hook, detector or installer ran; no automated design score is claimed.
- Improved reading order, type hierarchy, spacing, contrast, navigation and restrained use of panels. Embedded DejaVu Serif and all figures so the HTML needs no CDN, font request, analytics, or JavaScript. Figure dimensions reserve layout space; navigation has keyboard focus and 48-pixel targets; narrow-screen styles and scrollable scientific graphics are present.
- Preserved the seven original regenerated Matplotlib chart collections and their model colors, marker/dash encodings, legends, and improvement directions. Embedded three spatial figure collections. Clarified the spatial chart title so differing confidence intervals do not imply a tested orientation interaction.
- Kept the original case-study PNG byte-for-byte. Its source prediction tensors are absent from the compact archive, so it was enlarged rather than reconstructed.
- Updated the novelty discussion with close Reeves and RadarFill prior art. The 20.6% versus 1.3% comparison is explicitly an input-information diagnostic. The horizontal miss increase is not represented as established across both tested orientations. First-ever novelty and operational warning benefits remain unproven.

## What stayed unchanged

SHA-256 comparison confirms 71 distinct protected scientific files remain byte-for-byte unchanged against the saved source archives. These include scientific source, weights, protocol, configuration, manifests, saved CSV/JSON/NPZ evidence, tests, and the original case-study image. The two input hash manifests are `docs/evidence_sha256.json` and `docs/combined_evidence_sha256.json`.

No source weather data were downloaded, no model was trained, and no bootstrap interval was recomputed in this design revision. Full-precision saved evidence remains authoritative. The primary calibrated-probability cutoff is still 0.5. Brier is described as overall probabilistic accuracy, not a standalone calibration metric. Historical science verification remains separate from the design checks here.

## Completed checks

- Presentation rebuild: original figure scripts, spatial figure script, both PDF builders and HTML builder completed from saved evidence.
- `python scripts/check_visuals.py`: passed. 71 protected hashes match; 11 embedded images decode; 10 SVGs parse; dimensions are present; internal anchors resolve; no duplicate IDs; all figures have alternative text; no script or remote asset is required.
- HTML parsing: no structural errors reported by lxml.
- Python source compilation: passed for source, scripts, tests and spatial code.
- Four data/manifest integrity tests: passed.
- Final 18-page combined PDF and five-page spatial PDF: all pages rendered and visually reviewed. Native text remains within the page bounds. Fonts are embedded. Revised pages were re-rendered after final wording changes. No clipped labels or overlapping report text were found.
- Scientific hashes are checked independently of updated presentation/package checksums. Repacking includes code, metrics, manifests, weights and licenses, while excluding temporary review images and caches.

## Verification limits

- PyTorch is absent from this design environment. The full scientific test suite and spatial inference protocol were not rerun here. The archive retains historical successful verification from the science/restoration run; that is not a new replication.
- Chromium launch was blocked by environment socket restrictions, including an elevated attempt in the earlier visual pass. Desktop/mobile browser runtime behavior is therefore unverified. Structural checks and responsive CSS are not substitutes for live browser QA.
- The PDF is a conventional generated document, not certified PDF/UA. No full assistive-technology audit was completed.
- No GitHub publication or remote CI was attempted. Existing publication approval remains separate.

## Rebuild

With the recorded Python dependencies and ReportLab installed, run `make visuals` and `python scripts/check_visuals.py`. Presentation rebuilding does not download data or retrain. The full original `make reproduce` workflow does and requires PyTorch.
