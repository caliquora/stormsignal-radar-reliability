# Research roadmap

The completed data ingestion is a bounded, reproducible pilot. Training outputs and recorded evaluations establish which model experiments actually ran. The extensions below are **future work**, not claims about current results or guarantees of publication novelty.

## 1. Finish the pilot without changing the question after seeing results

Freeze the manifest, model-selection rule, probability calibration procedure, fault scenarios, and primary metrics. Report all three CNN representations, both training seeds, and the classical baselines, including negative results. Distinguish source-encoded mean-field prediction from block-level high-echo classification.

Use paired comparisons on the same held-out events. Bootstrap weather groups or UTC days while retaining matched fault conditions and training seeds together. Report the number of independent groups and uncertainty, rather than treating every pixel as an independent observation. Compare model outputs before and after calibration.

The current calibration sample has 60 storm and 30 random events, whereas test data have 100 of each. Document this mismatch. Any calibration redesign inspired by pilot results should be assessed on a **new untouched test set**, not repeatedly optimized against the existing 200 test events.

## 2. Independently verify the research gap

The candidate contribution is a matched-observation comparison of blind replay, explicit missingness, and trustworthy replay provenance. CNN nowcasting, missing-frame robustness, probabilistic calibration, and weather-data-age concerns are established subjects.

Before a paper submission or a first-of-its-kind claim:

1. Search scholarly databases and preprint indexes for delayed observations, stale scans, repeated scans, persistence faults, replay faults, timestamp corruption, age of information, and forecast reliability. Include meteorological operational studies, not only machine-learning benchmarks.
2. Read the full closest papers and supplements, especially missing-frame nowcasting studies. Follow their references and later citations. A search-result abstract is insufficient to decide experimental overlap.
3. Create a comparison matrix of observed inputs, fault types, metadata assumptions, matched-information controls, targets, calibration, and holdout design.
4. Ask a meteorology or nowcasting researcher to challenge the gap and physical interpretation.
5. Revise the claim if the exact experiment already exists. A transparent replication plus a justified extension is preferable to unsupported novelty language.

See [NOVELTY_AUDIT.md](NOVELTY_AUDIT.md) for the current search scope and closest work. Search absence is not proof that a method or experiment is new.

## 3. Expand independent weather coverage before model complexity

Increase training events in stages, such as several thousand events and then all eligible training-period events, measuring learning curves, compute, and storage. Enumerate the current archive rather than assuming its historical size is its present size. Keep event manifests and content hashes, and avoid downloading unrelated modalities until they are needed.

Reserve a new holdout before inspecting its model outcomes. Possible options include untouched event groups, stricter geographically held-out regions, or later years if an accessible source actually supplies them. A single exact-source weather system must not cross partitions merely because it has multiple event IDs. Audit spatial and temporal overlap and multiday storm dependence, not just equality of catalog IDs.

Use a temporally blocked calibration set with a prespecified source composition. For operational probability claims, obtain a continuous time/place sample that includes normal dry periods; event-curated data alone cannot estimate everyday forecast reliability. Report performance by source type, season, region, and severity with subgroup sample counts.

## 4. Replace assumed faults with independently observed feed evidence

The pilot simulates terminal delays. A stronger study needs public or explicitly authorized archive/telemetry records linking measurement time, publication time, retrieval time, source sequence IDs, and independently confirmed failures. Check reuse and sharing rights for those logs before including them.

Test whole-frame delays, partial spatial failures, out-of-order arrivals, dropped scans, duplicated payloads, and timestamp errors separately. Estimate realistic frequency and duration from the logs instead of treating an arbitrary experimental mixture as an operational rate.

True observation age supplied by the simulator is an oracle when timestamps are falsely fresh. To study a deployable solution, build and separately evaluate a provenance or fault detector. Include genuinely unchanged weather as a negative control: repeated image values do not prove a broken feed. Evaluate detection latency, false alarms, and downstream forecasting consequences jointly. A model that performs well with oracle age may not perform well with noisy estimated age.

## 5. Isolate the mechanism with additional ablations

- Add clean-only training, mask-only and age-only features, and matched carry-forward versus zero-fill representations.
- Hold available source observations and forecast targets fixed across comparisons. Separate informative metadata from differences in imputation.
- Train on one delay range or fault mixture and test unseen durations or mixtures. The current use of the same prespecified delay values across training and testing does not establish unseen-fault generalization.
- Increase seeds and rerun budget-matched baselines. Tune all families under comparable validation budgets rather than maximizing one model's chance of winning.
- Compare global translation with a properly implemented dense optical-flow baseline and established probabilistic approaches where computationally feasible.
- Retain paired effect sizes and negative findings. Adding parameters is not itself evidence of a research contribution.

## 6. Add satellite information only with careful time accounting

SEVIR aligns radar with satellite and lightning modalities. A future experiment could test whether infrared history provides useful fresh information during radar delay, using a multimodal CNN or ConvLSTM. Radar/satellite fusion is already established; the research question must concern the precisely defined outage and information setting.

Align modality timestamps, spatial resolutions, and missing-value rules. Use only observations that would have been available by forecast issue time. Distinguish satellite acquisition from delivery latency, and never introduce future satellite frames into the forecast. Preserve a radar-only control, match compute budgets where possible, and state when multimodal systems receive genuinely more current observations.

## 7. Test practical value without overclaiming safety

Measure end-to-end latency, preprocessing, memory, and hardware requirements alongside forecast skill. A CPU-friendly model could be useful even when it does not lead a large-model benchmark, but that usefulness must be demonstrated rather than presumed.

If adding abstention, choose its policy on independent validation/calibration data. Report forecast coverage, high-echo coverage, missed positives among retained forecasts, and the cost or availability of fallback. Compare random rejection and a simple age-based policy. Rejecting all difficult storms is not a successful warning system.

Progress toward operational use would require external meteorological review, validation on representative real feeds, reliable provenance, monitored failure behavior, and a clearly defined human or system fallback. This repository does not establish those conditions. It must not replace official weather warnings.

## Publication-ready stopping criteria

A stronger release should include an independently reviewed novelty statement, a locked untouched holdout, documented real-data/fault provenance, appropriate group-level uncertainty, fair strong baselines, measured compute, and a reproducible artifact. Statistical or operational claims should reflect the evidence actually obtained. A clear negative result about the limits of age-aware CNNs is still a useful result.
