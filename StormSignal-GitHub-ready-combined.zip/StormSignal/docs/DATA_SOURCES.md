# Data sources, access, and attribution

Verified against the downloaded manifests on 2026-11-11. This document describes data actually ingested, not the size of an intended future experiment. Final model performance is reported separately.

## Primary dataset

This project uses the radar **vertically integrated liquid (VIL)** modality of the Storm EVent ImageRy (SEVIR) dataset. The primary references are:

- [SEVIR in the AWS Open Data Registry](https://registry.opendata.aws/sevir/): public bucket, access instructions, use terms, and recommended access-date citation.
- [Veillette, Samsi, and Mattioli, SEVIR, NeurIPS 2020](https://papers.nips.cc/paper_files/paper/2020/hash/fa78a16157fed00d7a80515818432169-Abstract.html): dataset construction and original modeling applications.
- [Dataset supplement](https://proceedings.neurips.cc/paper/2020/file/fa78a16157fed00d7a80515818432169-Supplemental.pdf): catalog fields, spatial information, and storage details.
- [Official SEVIR challenge repository](https://github.com/MIT-AI-Accelerator/sevir_challenges): usage examples, baseline context, and information about prepared subsets.

The full multimodal release is approximately one terabyte. **This experiment did not download or train on the full release.** It uses a reproducible VIL subset. Satellite imagery and lightning data were not used.

## Access actually exercised

No AWS account, private credentials, or paid data subscription was needed. The loader retrieved the [public catalog](https://sevir.s3.us-west-2.amazonaws.com/CATALOG.csv), inspected public HDF5 metadata, and requested the byte ranges containing selected events. For example, one verified source object is [the July–December 2019 storm-event VIL file](https://sevir.s3.us-west-2.amazonaws.com/data/vil/2019/SEVIR_VIL_STORMEVENTS_2019_0701_1231.h5). That link points to a large object; use the bounded loader rather than downloading it casually.

The implementation verifies that source VIL arrays are contiguous, uncompressed, and compatible with the expected layout before using offsets. It requires HTTP 206 range responses and checks response lengths. It refuses a server response that would silently download an entire object. This strategy depends on the current storage layout; it is not a general reader for arbitrarily chunked HDF5 datasets.

Successful ingestion produced:

- **1,010 distinct events**, each with 49 frames of 384 by 384 native pixels.
- **7,297,597,440 native pixel-time values** read and transformed. The source arrays are unsigned bytes, so their nominal event payload is the same number of bytes, about 7.30 GB or 6.80 GiB.
- **420,397,300 bytes of derived event files** in the recorded integrity audit, about 420 MB. Compression and retained precision determine this size.
- Zero reported cross-split documented episode overlap in the integrity audit.

The nominal event payload is not a measured total network transfer. Catalogs, metadata requests, headers, and any retries add overhead. Billions of correlated pixels do not constitute billions of independent training examples: the principal sampling units here are events and weather episodes.

## Sampling and observed coverage

The fixed sampling seed is 20261111. The catalog contains 20,393 VIL rows before this study's filtering. Selection requires catalog-reported zero missingness and a 49-frame sequence with regular five-minute increments. Related documented episodes spanning splits are excluded. Within a source and split, selection retains one event per documented storm episode, or one random event per UTC date when no episode identifier is available.

The actual selected counts and issue-time coverage are:

| Split | Events | Storm / random | First to last selected issue date |
|---|---:|---:|---|
| Training | 600 | 300 / 300 | 2017-06-13 to 2018-12-24 |
| Model selection | 120 | 60 / 60 | 2019-01-08 to 2019-04-23 |
| Calibration | 90 | 60 / 30 | 2019-05-10 to 2019-06-17 |
| Test | 200 | 100 / 100 | 2019-07-08 to 2019-11-30 |

These are the dates represented by selected events, not continuous coverage. The loader uses seven-day exclusions around split boundaries, wider than the four-hour source sequences. Consult the manifest for precise timestamps and membership.

The requested calibration allocation was 120, but only 30 eligible distinct random-event dates were retained alongside 60 storm events. The realized calibration set therefore has **a different source mixture** from the other splits. This is an explicit limitation for calibration transfer, not an unnoticed claim of balanced sampling. A larger follow-up should prespecify a matched-source calibration design or appropriate weighting and evaluate it on a new untouched holdout.

SEVIR itself is curated around weather events, with a selected random component. Even the 50:50 subsets here are not representative of all operational locations and times. Probability calibration measured here does not establish calibration on a continuous everyday weather feed.

## Transformations and meaning

The retained event arrays contain all 49 timestamps at 96 by 96 resolution. Each output cell stores the mean of its corresponding 4 by 4 native block and a separate indicator for whether any native pixel reaches encoded VIL value 133. The indicator is calculated **before** mean pooling, preserving the presence of small high-intensity cores. The threshold defines this experiment's encoded-echo event, not an official public warning threshold.

Encoded value 255 denotes missing data. The loader rejects an event if any such value is found despite the catalog quality filter. It does not reinterpret missing pixels as extreme weather or as clear sky. This quality-controlled starting point supports controlled simulated input faults; it does not validate behavior on naturally incomplete source events.

Mean encoded VIL is not mean rainfall rate or a decoded physical liquid quantity. VIL is not direct evidence of surface flooding, human impact, hail damage, or a tornado. The reduced-resolution, single-lead task differs from standard full-resolution SEVIR leaderboard tasks.

Catalog times and actual frame times are not interchangeable. The loader derives issue time from the catalog timestamp plus that event's recorded offset for frame 24; offsets are not assumed to be identical for every event. See [METHODOLOGY.md](METHODOLOGY.md) for the causal forecast and corruption definitions.

## Reproducibility records

- `data/processed/sample_manifest.csv`: source event IDs, object names, row indices, source categories, split membership, coordinates, and issue/target timestamps.
- `data/processed/source_objects.json`: verified object URLs, data offsets, array shapes, and types.
- `data/processed/event_hashes.csv` and individual event caches: recorded source-data hashes and derived-file references.
- `data/processed/data_summary.json`: selected counts and transformation settings.
- `reports/data_integrity_audit.json`: checks on the generated artifacts.

The catalog SHA-256 for this run is `3209386cde96ffa80ccec3c1919090ffc601333cc651116f9fc48f224a5c2f57`. Retain these records when sharing results. A mutable public bucket URL alone is insufficient to identify the data version.

## Rights and citation

The AWS registry states that there are **no restrictions on use of the SEVIR data**. It requests the following access-date attribution, supplied here for this run:

> Storm EVent ImageRy (SEVIR) was accessed on 2026-11-11 from https://registry.opendata.aws/sevir/.

Also cite Mark Veillette, Siddharth Samsi, and Chris Mattioli, “SEVIR: A Storm Event Imagery Dataset for Deep Learning Applications in Radar and Satellite Meteorology,” *Advances in Neural Information Processing Systems*, 2020.

The project's MIT license applies to its original code and documentation. It does not relicense external papers, figures, code, or model weights. If copying code from the MIT-licensed challenge repository, preserve its license notice. The public-release statement in the separate `eie-sevir` repository is not automatically the same software license. All project result figures should identify SEVIR as their underlying data source.
