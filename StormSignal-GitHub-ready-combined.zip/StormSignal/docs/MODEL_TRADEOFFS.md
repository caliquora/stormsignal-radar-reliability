# No single score tells the whole story

Descriptive analysis of existing held-out summary results. This does not retrain models, choose deployment thresholds, or add independent evidence. A model is Pareto-efficient here when no other method has equal or lower MAE and Brier, and equal or higher CSI, with a strict improvement in at least one.

## What the recorded means show

- **0 minutes old:** nondominated methods: advection, trusted_age.
- **5 minutes old:** nondominated methods: advection, trusted_age.
- **15 minutes old:** nondominated methods: trusted_age.
- **30 minutes old:** nondominated methods: missing_aware, replay_blind, trusted_age.

## Why this matters

If a portfolio presents only its best-looking error metric, it can hide weaker detection at the fixed probability cutoff. This audit makes the competing objectives explicit and helps a reader choose what to investigate next rather than announcing a universal winner.

## Limits

- This frontier is based on point estimates, not confidence-dominance tests. Small differences can be noisy.
- CNN summaries average two seeds; baseline rows have one saved record. Seed means do not provide independent uncertainty estimates.
- CSI uses the frozen calibrated 0.5 threshold. Baseline calibration produced no positive predictions for some methods; raw-score diagnostics are a separate analysis.
- No stakeholder cost function, operational utility, flood forecast, or public-safety benefit has been validated.
- This is an exploratory reading of an already inspected test cohort, not a newly preregistered endpoint.

Source: `reports/metrics.csv`; reproducible command: `python scripts/model_tradeoffs.py`. Full machine-readable comparison: `reports/model_tradeoffs.csv`.
