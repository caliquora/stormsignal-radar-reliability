# Novelty and related-work audit

Review date: 2026-11-11.

## Combined-study update

The spatial follow-on is executed, not proposed. Its specific contribution is a controlled SEVIR intervention preserving stale coverage, the age histogram, patch geometry and seam length while changing placement, followed by a same-support age swap and downstream frozen-CNN evaluation. Random-placement controls, two seeds and an orientation check are included. This is original exploratory work in this project; first-ever scientific novelty is not independently established.

The closest reviewed context narrows the claim:

- [Reeves et al., AMS 2017](https://ams.confex.com/ams/97Annual/webprogram/Paper306788.html) created per-pixel MRMS age mosaics and compared latency with reflectivity-change rates. Spatial freshness and storm-relative risk are not new discoveries here.
- [RadarFill, November 2026 preprint](https://arxiv.org/html/2611.04768v1) studies structured spatial missingness and downstream nowcasting. It fills gaps instead of permuting stale ages, but rules out a broad claim of pioneering spatial-data-loss stress tests.
- Missingness masks and elapsed-time representations predate this work, including GRU-D. This project does not introduce those representations.

The 20.6% versus 1.3% result measures missing input information at issue time, not forecast misses or missed warnings. Targeting a moving-front proxy makes the direction partly expected. The same-footprint age swap is the more discriminating control: the primary horizontal blind-CNN miss change is +2.89 percentage points [1.70, 4.25], while vertical sensitivity is +0.51 [-0.45, 1.58]. The miss increase was not established across both orientations. Different interval outcomes alone are not an interaction test. An MAE interval crossing zero is not equivalence.

The 200-event cohort was already inspected, the faults are synthetic, provenance is an oracle, and CNNs were trained with whole-scene delays rather than spatial faults. SEVIR random-source events are intensity-stratified, not an unbiased deployment background population. The project has not demonstrated better public warnings or safer human decisions. A new holdout and realistic age/coverage logs are needed for stronger conclusions.

## Honest contribution statement

This project investigates a focused reliability question: **when an older radar image is replayed into apparently current slots, what is the measured value of exposing its provenance, compared with blind replay and explicitly missing input, at matched observation age and compute budget?**

The contribution is an original, reproducible experiment and a careful presentation of its results. The present literature check does not establish that this is the first such experiment. It does not establish a new forecasting architecture, a state-of-the-art result, a production warning capability, or a theoretical novelty claim.

If the implemented model receives simulator-supplied true age despite falsely fresh timestamps, describe that arm as a provenance oracle. An oracle result cannot be marketed as automatic freeze detection. Research code and an informative negative result are valid portfolio outcomes.

## Established work that this project builds on

### SEVIR, CNN nowcasting, and simple baselines

Veillette, Samsi, and Mattioli's [SEVIR paper, NeurIPS 2020](https://papers.neurips.cc/paper/2020/file/fa78a16157fed00d7a80515818432169-Paper.pdf) introduces the dataset and evaluates U-Net variants against persistence and optical-flow baselines. A project that merely trains a CNN on SEVIR is therefore not new. Its encoded echo thresholds and contingency metrics also predate this project.

The custom 96-by-96, single-target, block-level exceedance experiment here changes the task and cannot be compared directly with that paper's full-resolution, multi-lead scores.

### Probabilistic forecasts and motion-based baselines

[Pulkkinen et al., 2019: pysteps](https://gmd.copernicus.org/articles/12/4185/2019/) provides an established open-source framework for probabilistic precipitation nowcasting, motion estimation, and verification. Motion extrapolation, ensemble forecasts, and forecast verification are existing methods, not claimed contributions here.

### Missing-frame robustness and calibrated generative nowcasts

[Schusterbauer et al., CVPR 2026: Probabilistic Precipitation Nowcasting with Rectified Flow Transformers](https://compvis.github.io/weather-rf/) explicitly reports variable input context, robustness to frame drops, and probabilistic calibration on SEVIR. Consequently, claims such as "the first uncertainty-aware SEVIR model" or "the first model that handles missing radar frames" are not supportable.

The proposed distinction is narrower: controlled comparison of replayed images without informative provenance, explicit missingness, and replay with trustworthy age, while holding observation availability and target time fixed. This distinction still needs broader literature review before any first-of-its-kind claim.

### Weather-data age and latency

[Bass, AMS 2018: Weather Product Latency Versus Data Age: Differences and Impacts on Aviation](https://ams.confex.com/ams/98Annual/webprogram/Paper327953.html) distinguishes a product's timestamp from the age of its constituent observations and discusses operational consequences. Thus the general warning that a current-looking radar product can contain old measurements is established. This experiment studies a specific machine-learning comparison rather than discovering that safety issue.

### Efficiency and uncertainty are also active research areas

[Just Weather Scoring](https://compvis.github.io/jws/) describes an efficient distributional nowcasting approach with uncertainty evaluation on SEVIR and MeteoNet. Reduced computation, calibration, and visually realistic forecasts are not novel simply because they appear together in a portfolio.

This project's modest model budget is an execution constraint and a way to study accessible reliability tools, not evidence of superiority over modern large models. Any timing comparison must use measured, comparable settings.

## What can make this experiment distinctive

1. **Matched stale-versus-missing comparison.** Use the same source windows and forecast targets, varying only the corruption representation and disclosed provenance.
2. **Clear information accounting.** Distinguish slot time, observation time, and issue time, and separate an age oracle from a deployable hidden-fault detector.
3. **High-echo-aware evaluation.** Construct the small-core classification target before spatial pooling; measure missed echoes and rejected severe cases alongside average error.
4. **Reliability without hidden leakage.** Separate training, model selection, calibration, and final evaluation; keep all versions of a storm together.
5. **Accessible replication.** Include manifests, tests, small-data smoke checks, transparent compute costs, failure examples, and complete negative results.

These are proposed strengths of the study design. They should be claimed as completed contributions only after the corresponding code, experiments, and artifacts exist.

With regular time spacing, an explicit missingness mask also reveals terminal delay. The missingness-versus-truthful-replay comparison therefore isolates representation/imputation; it does not demonstrate the value of extra information unavailable to the missingness arm. All model families should receive the same historical high-echo indicators when those indicators are computed from native-resolution imagery.

The replay-blind CNN is fault-augmented during training. Exact repeated arrays can indirectly reveal the fault and its duration. An absent or small gain from explicit provenance would not show that provenance is generally unimportant, nor would it describe a clean-trained naive forecaster. The completed comparison must be interpreted within its training protocol. Clean-trained surprise-fault evaluation is an extension, not a completed result.

Global advection and ridge/logistic references receive true age and must be called metadata-assisted. The implemented age-based retention chart filters simulated conditions using trusted age, including when the underlying forecast is blind. It is not a novel learned abstention detector.

## Search scope and unresolved questions

The targeted web review examined original SEVIR material, the official challenge repository, motion-based nowcasting, recent missing-frame and probabilistic nowcasting work, and combinations of these search concepts:

- `SEVIR nowcasting uncertainty calibration missing modality robustness`
- `SEVIR nowcasting reliability energy compute early exit risk coverage`
- `radar nowcasting frozen frames data age reliability`
- `radar nowcasting stale age machine learning`
- `precipitation nowcasting data age`
- `nowcasting radar repeated frames`
- `SEVIR abstention`
- `precipitation nowcasting selective prediction`

Searches for "frozen" also retrieve the physical frozen-flow assumption, frozen pretrained weights, and frozen precipitation. Those are different from a telemetry feed replaying an old image and must not be treated as direct matches without reading the source.

This was a targeted scan, not a systematic review or patent search. Nonappearance in these results does not establish absence from the literature. Outstanding checks include operational radar latency and stale-cache studies, age-of-information methods in geospatial inference, data-quality benchmarks, and related work using terms such as delayed observation, repeated scan, persistence fault, replay fault, and timestamp corruption.

## Claim policy

Use wording such as:

> A reproducible SEVIR stress test of replayed and explicitly missing radar observations, studying the value of trustworthy frame-age information under a fixed small-model budget.

If supported by the executed study, report numerical effects with sample counts, uncertainty intervals, the exact targets, and the tested delay scenarios.

Avoid unsupported language such as:

- "Nobody has done this before."
- "Predicts flooding" or "prevents weather-related deaths."
- "Detects radar outages" when only oracle ages or synthetic labels are available.
- "Outperforms weather forecasting systems" without a fair same-task baseline.
- "Trained on a terabyte" when only a bounded subset was downloaded and used.
- "Calibrated probabilities" based solely on normalized regression scores.
- "Statistically significant" based on treating correlated pixels as independent samples.

## Data and code attribution

The [AWS SEVIR registry](https://registry.opendata.aws/sevir/) states that the dataset has no use restrictions and provides citation guidance. Archive the access date and cite the original paper. Rights to borrowed code must be checked independently. The [SEVIR challenge repository](https://github.com/MIT-AI-Accelerator/sevir_challenges) has an explicit MIT license; preserve its notice if copying substantial code. The [eie-sevir distribution statement](https://github.com/MIT-AI-Accelerator/eie-sevir/blob/master/DISTRIBUTION_STATEMENT) is not the same license.

Original project code may use its own chosen license. That choice does not relicense source datasets, copied code, external model weights, or paper figures. Prefer newly generated figures from documented experiments and include their data provenance.
