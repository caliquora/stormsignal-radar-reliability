# How to understand and present this project

This is an AI-assisted research build. Before using it as evidence of personal skills, reproduce a small run, read the key modules, and make an independently understood extension. Honest explanation of limitations is more convincing than a claim of unprecedented model performance.

## A five-minute technical walkthrough

1. **Problem.** A forecast can receive older observations than its timestamps suggest. Holding issue time and target fixed exposes the cost of old information.
2. **Data engineering.** Read the public catalog, keep strict QC, group episodes, enforce chronology and embargoes, then use HDF5 offsets and HTTP byte ranges instead of downloading an entire terabyte archive. Record hashes and a manifest.
3. **Representation.** Pool the mean radar field, but threshold native pixels before pooling the high-core label. Explain why mean pooling followed by thresholding would erase small intense cores.
4. **Controlled learning.** Three equal-budget CNNs differ only in fault representation. All get matching historical mean and high-core fields. The architecture is a compact encoder/decoder, not an invented new CNN family.
5. **Evaluation.** Compare classical and physical-style baselines, calibrate on separate time periods, measure continuous and probabilistic error, and bootstrap weather days rather than millions of correlated pixels.
6. **Conclusion.** Use the saved metrics and intervals to explain what worked, what did not, and which unresolved assumptions limit transfer to operational weather services.

## Questions to be ready to answer

**Why not randomly split frames?**
Nearby frames and overlapping event windows can depict the same weather. A random split would let the model learn almost the same scene it later appears to forecast.

**Why is the age-aware model an oracle under hidden replay?**
The experiment knows when it injected a fault. A real feed with false timestamps may not expose that truth. Supplying it measures the value of a trusted provenance mechanism, not automatic outage detection.

**Does a missingness mask already reveal age?**
For terminal missing slots on a regular grid, yes. The explicit-missing and trusted-replay arms test different encodings of equivalent information.

**Can the blind model infer the fault anyway?**
Often, because exact repeated images are a strong clue and the model was trained with replay faults. This weakens any claim that explicit timestamps are the only source of freshness information.

**Why both MAE and Brier score?**
MAE measures average-field error. Brier measures probabilistic error for a specific block-level high-echo event. A blurry average field can have reasonable MAE while losing important small cores.

**Why not call this flood forecasting?**
VIL is a radar-derived proxy. Flood risk also depends on precipitation accumulation, terrain, drainage, soil moisture, exposure, and vulnerability. None of those is estimated here.

**Why can a baseline beat a CNN?**
Weather fields have strong persistence and motion. A small neural model and limited training sample may not justify added complexity. Reporting that outcome demonstrates good model selection rather than failure.

**What is actually novel?**
The narrow controlled empirical audit and its matched-information design are the proposed contribution. The dataset, CNNs, calibration, and concern about delayed weather information already exist. First-ever novelty remains unverified.

## Extensions that demonstrate independent skill

- Implement a timestamp-provenance validator and test it on controlled feed faults without claiming that repeated arrays prove an outage.
- Add a clean-trained CNN and quantify surprise-fault degradation on a new untouched test set.
- Replace global phase translation with a strong, documented optical-flow baseline and preserve information parity.
- Run a larger predeclared event sample with three to five seeds and bootstrap longer weather-system blocks.
- Build an interactive local explorer for fixed saved results, preserving the research-only disclaimer.
- Write a short experiment log describing your own changes, predictions before each run, results, and what you learned.
