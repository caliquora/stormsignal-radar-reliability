# Combined publication candidate

Prepared from the redesigned main project package and the separately executed spatial freshness study on November 11, 2026. The scientific outputs are unchanged. The main README now links both studies and explains why the findings matter.

- Main experiment: 1,010 sampled events, 200 original held-out events, six CNN fits, four non-CNN baselines, and 40 primary metric rows.
- Spatial follow-on: exploratory reuse of 200 previously inspected events, 42,000 sufficient-statistic rows, two patch orientations, same-support age swaps, fixed weights/calibration, and no model retuning.
- All 49 spatial artifact checksums and the frozen protocol hash were checked after recovery. All 16 original-score restoration comparisons were recalculated; maximum absolute difference was 6.998e-7.
- A fresh local run passed all 11 main-project unit tests. A separate fresh run passed the spatial protocol invariants and exactly matched its saved protocol-test result; scientific result files were not overwritten. This was code/protocol verification, not a new data download or retraining run.
- Original MIT notices, SEVIR attribution/data-use boundaries, and visualization/font license notices are retained.
- Raw weather arrays and installed dependencies are not included. No actual secret or private user data was found in the publication text scan. Incidental local execution paths were removed from the test transcript.
- A local publication candidate is not proof of a successful GitHub upload or remote CI run. Those must be verified separately.
