# Methodology: when a radar feed looks fresh but is not

## Scope and status

This is a controlled historical experiment on SEVIR radar imagery. It tests the value of truthful observation provenance when recent radar frames are unavailable and a feed repeats an older frame. It is a research portfolio, not a deployed warning system or a validated flood, rainfall-rate, lightning, or tornado predictor.

This document specifies the study design and reporting requirements. The committed run manifest and result files determine what was actually executed. A design requirement is not evidence that an experiment ran. Report downloaded bytes, unique events, windows, epochs, seeds, and evaluation counts explicitly; the size of the source archive is not the size of the completed analysis.

## Research question

At a fixed forecast issue time and with the same underlying observations available, how do three representations of a delayed feed affect a compact CNN's forecast and reliability?

1. **Blind replay:** repeat the last available radar image in newer slots, without informative provenance channels.
2. **Explicit missingness:** mark unavailable slots and fill their image values with a documented placeholder.
3. **Truthful replay provenance:** repeat the last available image, but disclose which slots are substituted and how old their source observation is.

The third arm assumes trustworthy provenance. When the fault includes falsely fresh timestamps, that information is an **oracle upper bound**, not a working hidden-fault detector. A claim about automatic freeze detection requires a separate detector evaluated on both corrupted and genuinely unchanged clean imagery.

On this regular five-minute grid, an explicit availability mask already identifies the last genuine frame and therefore reveals the delay. The second and third arms have equivalent delay information; their comparison tests representation and imputation, not access to an additional hidden fact. Blind replay is not guaranteed to hide the fault completely: exact repeated images may themselves provide a detectable cue.

All three CNNs, including blind replay, are trained with simulated faults. The blind model can learn to recognize exact repeated arrays and may infer their duration without a metadata channel. A small or absent gain from explicit age would therefore not establish that provenance is unimportant. It would describe this fault-augmented training protocol, not a clean-trained forecaster encountering an unexpected outage. Clean-only training under surprise faults remains a separate, unexecuted experiment.

The central hypothesis is that truthful provenance reduces degradation under simulated delay relative to blind replay. An improvement is not assumed. The experiment should preserve negative results and differences across metrics.

## Data and target definition

- Source: [SEVIR](https://registry.opendata.aws/sevir/) and its catalog, with the [original dataset paper](https://papers.neurips.cc/paper/2020/file/fa78a16157fed00d7a80515818432169-Paper.pdf) as the technical reference.
- Source sequences contain radar VIL imagery at five-minute spacing. Select valid windows using catalog metadata and verified file dimensions.
- Context: 12 slots from 55 minutes before issue time through issue time, inclusive.
- Target: the radar field 30 minutes after issue time.
- Reduced-resolution input and regression target: 96 by 96 cells derived from the original 384 by 384 imagery using non-overlapping 4 by 4 mean pooling, after applying the source's documented missing-value rules.
- Separate classification target: a cell is positive if **any valid original pixel** in its 4 by 4 block reaches encoded VIL value 133. Construct this label before pooling.
- Historical input: include the same native-pixel exceedance indicator for each of the 12 context slots. This ensures CNNs and baselines receive the same high-core information; providing these indicators only to persistence would create an information imbalance.

The regression task concerns the block mean of encoded VIL. The classification task concerns the presence of a high encoded echo somewhere in a block. These are distinct targets. Averaging encoded VIL is not the same as averaging a decoded physical quantity. Neither target represents rainfall in millimeters per hour, surface flooding, damage, or an official severe-weather threshold.

Raw-pixel thresholding preserves small intense cores that mean pooling can erase, but changes the spatial event definition. Scores must not be presented as equivalent to full-resolution SEVIR leaderboard results. Record the missing-value policy, valid-pixel minimum, pooling operator, threshold comparison, units, and normalization in the run configuration. Never convert an invalid pixel to a high-echo positive or silently treat it as no weather.

## Matched corruption protocol

For every selected window, retain the original target and issue time. Simulate terminal delays of 0, 5, 15, and 30 minutes. At delay `d`, the last genuine observation is at issue time minus `d`; newer slots are unavailable.

Use the same event, window, delay, target, split, and random seed across all three representations. The replay arms repeat the last genuine observation into unavailable slots. The missingness arm uses its prescribed placeholder and mask. No corruption operation reads the target or any post-issue observation.

A nominal 30-minute forecast under delays of 5, 15, and 30 minutes predicts 35, 45, and 60 minutes beyond the last real image. This difference is part of the experiment and must be shown on plots. Do not shift the target forward or backward to make a corrupted example appear easier.

Three notions of time must remain separate:

- **Slot time:** when the feed claims that a frame belongs.
- **Observation time:** when the underlying source image was measured.
- **Issue time:** when the forecast is produced.

Truthful ages use observation time. Blind replay uses no hidden ground-truth delay. A source timestamp legitimately available to an operator can support an age-aware system; a timestamp secretly supplied by the simulator cannot establish a deployable hidden-fault detector.

In the feature encoding, per-slot staleness is slot time minus source-observation time, scaled by a documented constant. It differs from source age at issue time. Historical genuine frames have zero per-slot staleness even though they precede issue time. Apply the same replay or missingness transformation to the mean-VIL and historical-exceedance channels.

These are simulated faults. Their frequencies and severities are experimental choices, not measured operational outage rates. Report every delay separately. Any mixture-average result must state its chosen weights.

## Split and leakage controls

Use chronological partitions, subject to actual catalog coverage:

- Training: 2017 and 2018.
- Model selection: January through April 2019.
- Calibration: May and June 2019.
- Final test: July through December 2019.

Apply a documented one-week embargo at temporal boundaries. The exact retained intervals, treatment of sequence durations, and event counts must be emitted by code. Exclude a whole sequence if its context or target crosses a boundary or embargo. A month without available data remains absent; do not imply that the entire named interval was observed.

All windows, augmentations, and fault versions of one event must remain in one partition. Different SEVIR IDs can still depict nearby portions of the same weather system. Audit overlapping time intervals and geographic footprints where metadata permit, as well as exact or near-duplicate source arrays. Group related episodes or remove boundary overlaps. If only event-ID separation is implemented, state that storm-system independence remains unverified.

Select events by a deterministic manifest and fixed seed, not by which events make a model look good. Preserve the catalog's storm/random distinctions in analysis. SEVIR's curated sampling is not a representative sample of every place and time, so estimated rates and calibration apply to this test distribution, not automatically to the public's daily weather exposure.

Fit normalization, feature selection, class weights, and model parameters using training data only. Use model-selection data for architecture, early stopping, and hyperparameters. Freeze these before calibration and test. Calibration labels may fit a prespecified calibrator; they must not choose a new model architecture. If many reliability thresholds are tuned, divide calibration into fitting and policy-selection subsets or disclose that the test is the only independent assessment of the resulting policy.

The recorded subset contains 600 training, 120 model-selection, 90 calibration, and 200 test events. Calibration has 60 storm-source and 30 random-source events, whereas the other partitions are evenly split by source. That source-mixture shift can affect postprocessing. Calling an output "calibrated" describes a fitted postprocessing step; reliability still needs evaluation on the held-out distribution. Do not rebalance or retune using the observed test results.

The July test differs from the original SEVIR benchmark's June 2019 test boundary. Combined with reduced resolution, a shorter context/target task, and possible subsampling, this is a custom study, not a benchmark reproduction.

## Models and fair comparison

### Required simple baselines

1. **Persistence:** retain the latest available genuine radar field and its directly derived high-echo classification. A genuinely blind pipeline may not know that this image is stale; do not give it an unreported freshness advantage.
2. **Advection:** estimate motion from available imagery and translate the last field. A global phase-correlation implementation is a useful cheap baseline, but must be named **global translation**, not dense optical flow. Log border treatment and motion failures. With known age, translate across the full interval from observation time to target time; with hidden age, report the blind assumption separately.
3. **Classical ML when run:** ridge regression for the mean field and logistic regression for high-echo classification, using causal lags, local-neighborhood summaries, trend, and known age, with documented sampling and the same targets. Label this arm metadata-assisted if it uses true age. Label it planned if not executed.

In the recorded implementation, global advection and the ridge/logistic pair intentionally use true source age. They are **metadata-assisted reference models**, not blind alternatives. Persistence uses the most recently available image; its numeric forecast is unchanged by whether the age is disclosed.

Train the three CNN arms with the same image/exceedance/mask/age channel layout, architecture, optimizer, parameter budget, minibatch policy, training examples, initialization seeds, and stopping rule. A 48-channel design contains 12 mean-VIL, 12 native-exceedance, 12 mask, and 12 age channels; blinded metadata are constants. Keep normalization of each channel type fixed and documented. Equal parameter count alone does not establish identical compute or effective information.

Report the exact loss and class weighting. When regression and classification heads share a network, log each loss separately and keep weights fixed across arms. Class weighting and synthetic fault oversampling can alter raw probability calibration.

For diagnostic extensions, add a clean-only CNN, an age-only ablation, and a mask-only ablation. These are optional experiments, not assumed results. Repeat training across multiple seeds before claiming a robust architecture advantage; otherwise label the result a single-seed pilot.

## Evaluation

Publish metrics for each model and each delay, on the same valid pixels and events:

- **Mean absolute error:** encoded VIL block means. Give the unit/scale and equal-event mean; optionally also pool all valid pixels.
- **Critical success index:** hits divided by hits plus misses plus false alarms, for the explicitly defined block-level high-echo task.
- **Probability of detection / recall:** hits divided by hits plus misses.
- **False-alarm ratio:** false alarms divided by hits plus false alarms. This is not the false-positive rate.
- **Brier score and reliability diagrams:** for a genuine probability output for the block-level high-echo target.
- **Operational cost proxy:** measured inference latency and memory on specified hardware, batch size, numerical precision, and warm-up policy. Count preprocessing and additional heads when comparing end-to-end use.

An arbitrary scaled VIL regression output is not an event probability. Do not call a heuristic score calibrated unless it was mapped to event probabilities on separate calibration data and assessed on untouched test labels. For probabilistic regression, interval coverage and width or CRPS require an actual predictive distribution; do not infer them from a point forecast alone.

Binary persistence and an interpolated/advection score are not calibrated event probabilities. Report their raw scores separately and apply the same held-out calibration opportunity to baselines and CNNs. Otherwise a Brier comparison mixes the benefit of calibration with differences in the underlying forecasts. Report raw and calibrated Brier scores for every applicable model.

A fixed probability cutoff of 0.5 is a specified decision rule, not an optimum for CSI or rare-event detection. Calibrated baseline probabilities can remain entirely below that cutoff and yield zero CSI while retaining useful probabilistic or deterministic information. Preserve the frozen primary cutoff. If adding raw deterministic baseline CSI, detection, and false-alarm diagnostics, label them as secondary and keep them distinct from calibrated-probability CSI. Do not select a new cutoff from the final test outcomes.

Aggregate CSI from summed contingency counts and also report event-level distributions when useful. Define zero-denominator cases in advance and show how many occur; avoid awarding perfect scores automatically for no-event images. Report positive-event and pixel counts, especially at high thresholds.

Use paired bootstrap intervals over independent event or storm-episode groups, retaining all matched fault conditions together in each resample. Pixels and overlapping windows are not independent replicates. Report the bootstrap unit, repetitions, seeds, and confidence level. With very few independent events, describe intervals as unstable rather than presenting many pixels as a large effective sample.

For a UTC-day bootstrap, keep storm and random-source events from the same day together. This is a pragmatic dependence control, not proof of independent days; multiday systems can remain correlated. Pair seeds across arms and average seed-level effects within an event before resampling days. Additional seeds do not create new independent weather events.

### Selective prediction / abstention

An abstention policy can flag a forecast as requiring fallback or human review. Its test-time score must use input-available features, model outputs, or calibrated uncertainty, never future forecast error or target severity.

Choose policy settings before final testing. Show risk versus retained coverage together with the fraction of high-echo cases retained, missed positives among retained cases, and the number of rejected cases. A policy that rejects all difficult storms may improve average error while providing little useful severe-weather coverage. Compare with random rejection and a simple age-based policy.

A hypothetical perfect ranking by observed test error may appear only as a clearly labeled unattainable oracle reference. Abstention does not itself make a forecast safe, and no human-response or warning benefit has been measured.

The implemented retention figure is narrower than a learned abstention system: it successively excludes the older injected-delay conditions, assuming known true age and equal weight for each of the four delays. Even the blind-forecast curve therefore uses an external trusted-age filtering policy. It is a descriptive scenario analysis, not evidence of a deployable hidden-fault detector or a calibrated event-specific rejection rule. With identical target events replicated across all delay conditions, target prevalence is unchanged by this condition-level filter.

## Figures and interpretation

Use a shared color scale and labeled time axes for input, replayed/missing slots, forecast, truth, and error. Mark simulated frames visibly. Include prespecified representative cases and failure cases, not only the most attractive successes.

Recommended figures are delay-degradation curves, paired model differences with event-bootstrap intervals, a hit/miss/false-alarm map, reliability by delay, and a risk-coverage plot with severe-echo coverage. Keep smooth-looking images separate from scientific skill: visually sharp forecasts can still be misplaced.

## Reproducibility and release checklist

- Save dataset URLs/object keys, access date, catalog version or checksum, event IDs, raw byte counts, split membership, and transformation settings.
- Save environment versions, seeds, model configs, training history, checkpoints or reproducible training instructions, and machine-readable metrics.
- Recorded prediction arrays use float16 storage for compact visualization. Rounding near the 0.5 cutoff can slightly change recomputed contingency counts. The original-precision `metrics.csv` and saved event sufficient statistics are authoritative for reported metrics and bootstrap intervals; quantized prediction files are approximate unless regenerated from the saved models at original precision.
- Include unit tests for causal indexing, matched corruption, split disjointness, embargo enforcement, invalid-value handling, pre-pooling high-echo labels, and metric edge cases.
- Provide a tiny smoke-test path separately from the real-data training/evaluation path. Never mix synthetic smoke-test scores with real observations.
- Exclude credentials, local/private paths in notebook outputs, private repository contents, and large raw archives from version control. Download data with an explicit manifest and bounded scope.
- Distinguish the code license from dataset and third-party-code rights. The [SEVIR registry](https://registry.opendata.aws/sevir/) states that the data have no use restrictions and supplies an access-date citation. Cite the dataset paper as well.
- Preserve the [MIT notice in sevir_challenges](https://github.com/MIT-AI-Accelerator/sevir_challenges/blob/main/LICENSE) if its code is reused. The separate `eie-sevir` repository's public-release statement is not interchangeable with that MIT license.
- State all incomplete checks and unexecuted extensions. A public portfolio should make it easy to reproduce an honest small result and to scale the same protocol later.

## Scientific limits

The experiment is retrospective, region- and period-specific, and possibly limited to a manageable subset. Simulated terminal delays omit many real faults such as partial-sector failures, out-of-order packets, reflectivity artifacts, variable scan intervals, missing neighboring radars, and systematic metadata errors. Trustworthy age does not restore the missing meteorological information. A compact CNN is not presumed to beat persistence or advection. These limitations are part of the result, not reasons to hide an unsuccessful comparison.

