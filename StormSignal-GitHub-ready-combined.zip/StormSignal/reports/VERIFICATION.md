# Verification of the recorded run

Completed November 11, 2026. No remote repository was modified.

## Data

- 1,010 selected event arrays passed shape, range, finiteness, binary-label, and stored source-hash checks.
- Source payload: 7,297,597,440 native uint8 pixel-time values. Derived event files: 420,397,300 bytes.
- No failed event downloads in the completed run.
- No documented storm episode crosses temporal partitions. Split windows have a seven-day exclusion buffer.
- Event source hashes, object ETags, derived-file hashes, and the sample manifest are retained. Source hashes record observed downloaded bytes; they are not a separate publisher-signed checksum guarantee.

## Modeling

- Six CNN fits completed: three encodings, seeds 17 and 29, 18 epochs each, 108 epochs total.
- Each CNN has 23,746 trainable parameters and identical channel count/optimization budget.
- Four non-CNN baselines completed: climatology, persistence, global advection, and causal ridge/logistic forecasting.
- 40 primary model/seed/delay metric rows are present.
- Continuous field targets, high-echo targets, and all causal historical channels use matched event ordering.
- The test partition contains 200 events across 113 issue-date UTC days.

## Checks

- All 11 unit/integrity tests passed.
- Python source and scripts compile successfully.
- All 40 primary MAE, Brier, and CSI rows were independently recomputed from saved full-precision event statistics and matched.
- Paired-bootstrap identity checks return exactly zero when comparing identical arrays.
- Figure generation completed; the PDF was rendered and visually checked.

## Interpretation safeguards

- Calibrated CSI uses the frozen 0.5 probability cutoff. Zero CSI for calibrated persistence/advection at that cutoff is not absence of deterministic forecast skill.
- A separately labeled raw-score diagnostic was added after the primary run. It does not change primary endpoints or select a new threshold on test data.
- Probabilities were fitted using a separate calibration period, which has a 60:30 storm/random source mixture rather than 50:50. Calibration quality and source shift must be judged, not assumed.
- Prediction/truth arrays are compressed as float16. Full-precision metrics and event statistics are authoritative. Recomputing threshold metrics from rounded visualization arrays can slightly change them (maximum CSI discrepancy observed in this audit: 0.00020318).
- Trusted source age is oracle information when a hidden feed fault falsifies timestamps. Replay-blind training includes injected faults, and repeated images can reveal delay indirectly.
- UTC-day bootstrap does not eliminate multiday meteorological dependence or fully capture training variability.
- No first-ever novelty, operational warning suitability, or real-world social benefit has been established.

## Unrun work

Full-archive training, other geographic/time holdouts, genuine outage detection, clean-trained surprise-fault evaluation, radar/satellite/lightning fusion, stronger optical-flow and ensemble models, deployment, and GitHub-hosted CI are future work. Local tests passing does not imply remote CI ran.
