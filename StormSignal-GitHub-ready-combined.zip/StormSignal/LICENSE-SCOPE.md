# License scope

The root MIT license applies to StormSignal-authored research code, subject to existing data and third-party notices. It does not relicense imported VANE code under `apps/vane/`. That source declares `UNLICENSED`; its permissions must be resolved before an open-source release. Vendored dependencies retain their original notices. See `apps/vane/README-STORMSIGNAL.md`.
