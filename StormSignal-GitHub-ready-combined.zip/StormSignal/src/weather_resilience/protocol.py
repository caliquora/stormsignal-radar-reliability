"""Fault injection, temporal provenance, and leakage-safe metrics."""
import numpy as np
DELAYS=(0,1,3,6)  # five-minute slots
ARMS=('replay_blind','missing_aware','trusted_age')

def corrupt(x, delay, arm, high=None):
    """All arms retain exactly the same genuine observations at fixed issue time.

    x: (...,12,H,W), delay: 0..6. Trusted age is oracle under hidden faults.
    Missing-aware carries an explicit availability mask but zeroes absent slots.
    Replay-blind has metadata placeholders and no access to true feed age.
    """
    if arm not in ARMS: raise ValueError(arm)
    if not 0 <= delay < x.shape[-3]: raise ValueError(delay)
    x=np.array(x,dtype=np.float32,copy=True)
    mask=np.ones_like(x); age=np.zeros_like(x)
    if delay:
        last=x.shape[-3]-delay-1
        mask[...,last+1:,:,:]=0
        for i in range(last+1,x.shape[-3]):
            x[...,i,:,:]=x[...,last,:,:] if arm!='missing_aware' else 0
            age[...,i,:,:]=(i-last)/6
    if arm=='replay_blind': mask.fill(1);age.fill(0)
    if arm=='missing_aware':age.fill(0)
    if high is not None:
        high=np.array(high,dtype=np.float32,copy=True)
        if delay:
            for i in range(last+1,high.shape[-3]):
                high[...,i,:,:]=high[...,last,:,:] if arm!='missing_aware' else 0
        return np.concatenate([x,high,mask,age],axis=-3)
    return np.concatenate([x,mask,age],axis=-3)

def score_arrays(y, high, pred, prob, cutoff=.5):
    yes=prob>=cutoff; truth=high.astype(bool)
    tp=np.sum(yes&truth);fp=np.sum(yes&~truth);fn=np.sum(~yes&truth)
    return {'mae':float(np.mean(np.abs(pred-y))*254),'rmse':float(np.sqrt(np.mean((pred-y)**2))*254),
            'brier':float(np.mean((prob-high)**2)), 'csi':float(tp/max(1,tp+fp+fn)),
            'pod':float(tp/max(1,tp+fn)), 'far':float(fp/max(1,tp+fp)),
            'forecast_positive_fraction':float(yes.mean()),'observed_positive_fraction':float(truth.mean())}

def event_stats(y, high, pred, prob, cutoff=.5):
    yes=prob>=cutoff; truth=high.astype(bool)
    dims=tuple(range(1,y.ndim))
    return np.stack([np.mean(np.abs(pred-y),axis=dims)*254,np.mean((prob-high)**2,axis=dims),
                     np.sum(yes&truth,axis=dims),np.sum(yes&~truth,axis=dims),np.sum(~yes&truth,axis=dims)],axis=1)

def paired_bootstrap(a,b,metric='brier',repeats=1000,seed=27):
    """a-b, paired event resampling, never independent pixels."""
    rng=np.random.default_rng(seed);idx=rng.integers(0,len(a),size=(repeats,len(a)))
    if metric in ['mae','brier']:
        col=0 if metric=='mae' else 1;delta=(a[idx,col]-b[idx,col]).mean(axis=1)
    else:
        aa=a[idx].sum(axis=1);bb=b[idx].sum(axis=1)
        delta=aa[:,2]/np.maximum(1,aa[:,2:5].sum(axis=1))-bb[:,2]/np.maximum(1,bb[:,2:5].sum(axis=1))
    return {'mean':float(np.mean(delta)),'low':float(np.quantile(delta,.025)),'high':float(np.quantile(delta,.975))}
