"""Original compact spatial CNN, climatology, persistence and FFT advection."""
import numpy as np
import torch
from torch import nn
from torch.nn import functional as F
from scipy.ndimage import shift

class TinyNowcaster(nn.Module):
    """Equal architecture for each provenance arm; two forecast heads."""
    def __init__(self):
        super().__init__()
        self.enc1=nn.Sequential(nn.Conv2d(48,16,3,padding=1),nn.SiLU(),nn.Conv2d(16,16,3,padding=1),nn.SiLU())
        self.enc2=nn.Sequential(nn.Conv2d(16,24,3,stride=2,padding=1),nn.SiLU(),nn.Conv2d(24,24,3,padding=1),nn.SiLU())
        self.decoder=nn.Sequential(nn.Conv2d(40,16,3,padding=1),nn.SiLU(),nn.Conv2d(16,2,1))
    def forward(self,x):
        a=self.enc1(F.avg_pool2d(x,2));b=self.enc2(a)
        out=self.decoder(torch.cat([a,F.interpolate(b,size=a.shape[-2:],mode='bilinear',align_corners=False)],dim=1))
        out=F.interpolate(out,size=x.shape[-2:],mode='bilinear',align_corners=False)
        return out[:,0].sigmoid(),out[:,1]

def motion(a,b,max_shift=8):
    """Integer phase-correlation shift between two genuine frames, in coarse pixels."""
    cross=np.fft.fft2(b)*np.conj(np.fft.fft2(a));cross/=np.maximum(abs(cross),1e-8)
    corr=np.fft.ifft2(cross).real
    y,x=np.unravel_index(np.argmax(corr),corr.shape)
    if y>len(a)//2:y-=len(a)
    if x>a.shape[1]//2:x-=a.shape[1]
    return np.clip([y,x],-max_shift,max_shift)

def advect(x,high,delay):
    last=11-delay
    delta=motion(x[last-2],x[last])/2
    horizon=6+delay
    y=shift(x[last],delta*horizon,order=1,mode='constant',cval=0,prefilter=False)
    p=shift(high[last].astype(float),delta*horizon,order=1,mode='constant',cval=0,prefilter=False)
    return y,p
