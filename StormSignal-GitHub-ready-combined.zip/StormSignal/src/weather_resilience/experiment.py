"""Run the frozen protocol, train equal-budget arms, evaluate held-out events."""
from __future__ import annotations
import json,time,random,platform,hashlib
from pathlib import Path
import numpy as np
import pandas as pd
import torch
from torch import nn
from scipy.special import expit
from sklearn.linear_model import LogisticRegression, Ridge
from scipy.ndimage import uniform_filter
from .protocol import ARMS,DELAYS,corrupt,score_arrays,event_stats,paired_bootstrap
from .models import TinyNowcaster,advect

def load_split(root,manifest,split):
    rows=manifest[manifest.split==split];xs=[];ys=[];hs=[];xh=[]
    for row in rows.itertuples():
        with np.load(root/'data/processed/events'/f'{row.id}.npz') as f:
            xs.append(f['mean'][13:25].astype(np.float32)/254);ys.append(f['mean'][30].astype(np.float32)/254)
            hs.append(f['high'][30]);xh.append(f['high'][13:25])
    return np.stack(xs),np.stack(ys),np.stack(hs),np.stack(xh)

def predict(model,x,high,delay,arm,batch=24):
    ys=[];ls=[]
    model.eval()
    with torch.no_grad():
        for i in range(0,len(x),batch):
            xx=torch.from_numpy(corrupt(x[i:i+batch],delay,arm,high[i:i+batch]))
            y,l=model(xx);ys.append(y.numpy());ls.append(l.numpy())
    return np.concatenate(ys),np.concatenate(ls)

FEATURE_NAMES=['last_mean','previous_mean','ten_minutes_back_mean','last_high','previous_high','local_mean_3x3','local_high_3x3','trend_10min','age_30min']
def features(x,high,d):
    last=11-d;a=x[:,last];b=x[:,last-1];c=x[:,last-2];h=high[:,last].astype(float);old=high[:,last-1].astype(float)
    return np.stack([a,b,c,h,old,uniform_filter(a,size=(1,3,3)),uniform_filter(h,size=(1,3,3)),a-c,np.full_like(a,d/6)],axis=-1).astype(np.float32)
def baseline(name,x,high,d,mean,prob,classifier,regressor):
    shape=x[:,0].shape
    if name=='climatology':return np.full(shape,mean),np.full(shape,prob)
    if name=='persistence':return x[:,11-d],high[:,11-d].astype(float)
    if name=='advection':
        rows=[advect(a,b,d) for a,b in zip(x,high)];return np.stack([a for a,b in rows]),np.stack([b for a,b in rows])
    f=features(x,high,d).reshape(-1,9)
    return np.clip(regressor.predict(f),0,1).reshape(shape),classifier.predict_proba(f)[:,1].reshape(shape)

def run(root,epochs=18,seeds=(17,29)):
    root=Path(root);rep=root/'reports';rep.mkdir(exist_ok=True);weights=root/'models';weights.mkdir(exist_ok=True)
    torch.set_num_threads(4);torch.set_num_interop_threads(2)
    manifest=pd.read_csv(root/'data/processed/sample_manifest.csv')
    splits={s:load_split(root,manifest,s) for s in ['train','tune','calibration','test']}
    x,y,h,xh=splits['train'];tx,ty,th,txh=splits['tune'];cx,cy,ch,cxh=splits['calibration'];ex,ey,eh,exh=splits['test']
    # Climatology fitted on training only, constant in space and feed delay.
    climatology=float(y.mean());base_probability=float(h.mean())
    results=[];histories=[];all_stats={};all_predictions={}
    start=time.time()
    protocol={'epochs':epochs,'seeds':list(seeds),'delays_minutes':[d*5 for d in DELAYS],
      'input_frames':list(range(13,25)),'target_frame':30,'horizon_minutes':30,'arms':list(ARMS),
      'selection':'lowest mean validation loss over all four delays','calibration':'logistic slope/intercept on calibration events; common across delays',
      'cutoff':0.5,'loss':'MSE normalized encoded mean VIL + 0.25 binary cross entropy for any-native-pixel>=133',
      'torch':torch.__version__,'numpy':np.__version__,'platform':platform.platform(),'threads':4}
    (rep/'run_config.json').write_text(json.dumps(protocol,indent=2))
    for seed in seeds:
      for arm in ARMS:
        torch.manual_seed(seed);np.random.seed(seed);random.seed(seed)
        model=TinyNowcaster();optimizer=torch.optim.AdamW(model.parameters(),lr=.002,weight_decay=1e-4)
        bce=nn.BCEWithLogitsLoss();rng=np.random.default_rng(seed);best=float('inf');best_state=None;epoch_times=[]
        for epoch in range(epochs):
            tic=time.time();model.train();losses=[]
            for ids in np.array_split(rng.permutation(len(x)),int(np.ceil(len(x)/24))):
                # Per-example delays; identical random stream for all equal-budget arms.
                delays=rng.choice(DELAYS,len(ids));xx=np.stack([corrupt(x[i],int(d),arm,xh[i]) for i,d in zip(ids,delays)])
                pred,logit=model(torch.from_numpy(xx));target=torch.from_numpy(y[ids]);high=torch.from_numpy(h[ids].astype(np.float32))
                loss=((pred-target)**2).mean()+.25*bce(logit,high)
                optimizer.zero_grad();loss.backward();nn.utils.clip_grad_norm_(model.parameters(),1);optimizer.step();losses.append(loss.item())
            vals=[]
            for d in DELAYS:
                yp,lp=predict(model,tx,txh,d,arm)
                ce=np.logaddexp(0,lp)-th*lp
                vals.append(float(np.mean((yp-ty)**2)+.25*ce.mean()))
            val=float(np.mean(vals));secs=time.time()-tic;epoch_times.append(secs)
            histories.append({'arm':arm,'seed':seed,'epoch':epoch+1,'train_loss':float(np.mean(losses)),'validation_loss':val,'seconds':secs})
            if val<best: best=val;best_epoch=epoch+1;best_state={k:v.clone() for k,v in model.state_dict().items()}
            print(f'{arm} seed={seed} epoch={epoch+1}/{epochs} train={np.mean(losses):.5f} val={val:.5f} secs={secs:.1f}',flush=True)
        model.load_state_dict(best_state);torch.save({'state_dict':best_state,'best_epoch':best_epoch,'config':protocol},weights/f'{arm}_{seed}.pt')
        # Equal number of calibration pixels per delay, deterministic; no test information.
        cz=[];labels=[]
        for d in DELAYS:
            _,logit=predict(model,cx,cxh,d,arm);flat=logit.ravel();idx=rng.choice(len(flat),min(100000,len(flat)),replace=False)
            cz.append(flat[idx]);labels.append(ch.ravel()[idx])
        cal=LogisticRegression(C=1000,max_iter=300).fit(np.concatenate(cz)[:,None],np.concatenate(labels))
        slope=float(cal.coef_[0,0]);intercept=float(cal.intercept_[0])
        (weights/f'{arm}_{seed}_calibration.json').write_text(json.dumps({'slope':slope,'intercept':intercept,'pixels':len(np.concatenate(cz))},indent=2))
        for d in DELAYS:
            tic=time.perf_counter();yp,lp=predict(model,ex,exh,d,arm);elapsed=time.perf_counter()-tic
            pp=expit(lp*slope+intercept)
            metrics=score_arrays(ey,eh,yp,pp);metrics.update({'model':arm,'seed':seed,'delay_minutes':d*5,'best_epoch':best_epoch,
               'parameters':sum(p.numel() for p in model.parameters()),'inference_ms_per_event':elapsed/len(ex)*1000,
               'training_seconds':sum(epoch_times),'raw_brier':float(np.mean((expit(lp)-eh)**2))})
            results.append(metrics);key=f'{arm}_{seed}_{d*5}'
            all_stats[key]=event_stats(ey,eh,yp,pp)
            # Predetermined test examples: first storm/random and maximum observed intensity are labeled in report.
            all_predictions[key]=(yp,pp)
        pd.DataFrame(results).to_csv(rep/'metrics.csv',index=False);pd.DataFrame(histories).to_csv(rep/'training_history.csv',index=False)
        np.savez_compressed(rep/'event_stats.npz',**all_stats)
        # Save separate compact prediction arrays, enable independent figure and metric regeneration.
        for key,(yp,pp) in all_predictions.items():
            np.savez_compressed(rep/f'prediction_{key}.npz',mean=yp.astype(np.float16),prob=pp.astype(np.float16))
        all_predictions={}
    # Classical causal per-pixel forecast, not merely a calibration regression.
    rng=np.random.default_rng(417);feature_rows=[];target_rows=[];high_rows=[]
    for d in DELAYS:
        f=features(x,xh,d).reshape(-1,9);idx=rng.choice(len(f),min(100000,len(f)),replace=False)
        feature_rows.append(f[idx]);target_rows.append(y.ravel()[idx]);high_rows.append(h.ravel()[idx])
    ff=np.concatenate(feature_rows);classifier=LogisticRegression(max_iter=300,C=1).fit(ff,np.concatenate(high_rows))
    regressor=Ridge(alpha=10).fit(ff,np.concatenate(target_rows))
    (weights/'classical_coefficients.json').write_text(json.dumps({'features':FEATURE_NAMES,'logistic_coef':classifier.coef_.tolist(),'logistic_intercept':classifier.intercept_.tolist(),'ridge_coef':regressor.coef_.tolist(),'ridge_intercept':float(regressor.intercept_)},indent=2))
    for name in ['climatology','persistence','advection','linear_logistic']:
        calibration_scores=[];calibration_labels=[]
        for d in DELAYS:
            _,p0=baseline(name,cx,cxh,d,climatology,base_probability,classifier,regressor)
            idx=rng.choice(p0.size,min(100000,p0.size),replace=False)
            calibration_scores.append(p0.ravel()[idx]);calibration_labels.append(ch.ravel()[idx])
        cal=LogisticRegression(C=1000,max_iter=300).fit(np.concatenate(calibration_scores)[:,None],np.concatenate(calibration_labels))
        for d in DELAYS:
            yp,p0=baseline(name,ex,exh,d,climatology,base_probability,classifier,regressor)
            pp=expit(p0*cal.coef_[0,0]+cal.intercept_[0])
            met=score_arrays(ey,eh,yp,pp);met.update({'model':name,'seed':0,'delay_minutes':d*5,'raw_brier':float(np.mean((p0-eh)**2))});results.append(met)
            all_stats[f'{name}_0_{d*5}']=event_stats(ey,eh,yp,pp)
            np.savez_compressed(rep/f'prediction_{name}_0_{d*5}.npz',mean=yp.astype(np.float16),prob=pp.astype(np.float16))
    np.savez_compressed(rep/'event_stats.npz',**all_stats)
    pd.DataFrame(results).to_csv(rep/'metrics.csv',index=False);pd.DataFrame(histories).to_csv(rep/'training_history.csv',index=False)
    np.savez_compressed(rep/'test_truth.npz',mean=ey.astype(np.float16),high=eh,history=ex.astype(np.float16))
    (rep/'runtime.json').write_text(json.dumps({'total_seconds':time.time()-start,'completed_utc':pd.Timestamp.now('UTC').isoformat()},indent=2))
    print(pd.DataFrame(results).groupby(['model','delay_minutes'])[['mae','brier','csi','pod']].mean().to_string(),flush=True)

if __name__=='__main__':
    import argparse
    p=argparse.ArgumentParser();p.add_argument('--root',default='.');p.add_argument('--epochs',type=int,default=18);p.add_argument('--seeds',nargs='+',type=int,default=[17,29]);a=p.parse_args();run(a.root,a.epochs,a.seeds)
