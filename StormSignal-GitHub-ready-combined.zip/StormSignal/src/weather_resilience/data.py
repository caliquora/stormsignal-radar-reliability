"""Reproducible SEVIR sampling and HTTP-range ingestion; no full-archive download."""
from __future__ import annotations
import io, json, hashlib, time, urllib.request
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor, as_completed
import numpy as np
import pandas as pd
import h5py
BASE = 'https://sevir.s3.us-west-2.amazonaws.com/'

class RangeFile(io.RawIOBase):
    """Small read-only metadata cache for contiguous public HDF5 datasets."""
    def __init__(self, url):
        self.url, self.pos, self.cache = url, 0, {}
        with urllib.request.urlopen(urllib.request.Request(url, method='HEAD'), timeout=60) as r:
            self.size = int(r.headers['Content-Length'])
    def readable(self): return True
    def seekable(self): return True
    def tell(self): return self.pos
    def seek(self, offset, whence=0):
        self.pos = offset if whence == 0 else self.pos + offset if whence == 1 else self.size + offset
        return self.pos
    def read(self, n=-1):
        if n < 0: n = self.size - self.pos
        out = []
        while n:
            block, off = divmod(self.pos, 262144)
            if block not in self.cache:
                lo = block * 262144
                self.cache[block] = get_range(self.url, lo, min(self.size - 1, lo + 262143))[0]
            b = self.cache[block][off:off+n]
            if not b: break
            out.append(b); self.pos += len(b); n -= len(b)
        return b''.join(out)
    def readinto(self, b):
        x = self.read(len(b)); b[:len(x)] = x; return len(x)

def get_range(url, lo, hi):
    for attempt in range(4):
        try:
            request = urllib.request.Request(url, headers={'Range': f'bytes={lo}-{hi}'})
            with urllib.request.urlopen(request, timeout=120) as r:
                if r.status != 206: raise ValueError('Server did not honor byte range; refusing whole-object download')
                data = r.read()
                if len(data) != hi-lo+1: raise ValueError('Truncated range response')
                return data, r.headers.get('ETag')
        except Exception:
            if attempt == 3: raise
            time.sleep(2 ** attempt)

def sample_catalog(path, counts=(600,120,120,200), seed=20261111):
    c = pd.read_csv(path, low_memory=False)
    c = c[(c.img_type == 'vil') & (c.pct_missing == 0)].copy()
    c['time'] = pd.to_datetime(c.time_utc)
    c['source'] = np.where(c.id.str.startswith('S'), 'storm', 'random')
    # Seven-day embargo around boundaries exceeds the 4-hour event window.
    c['split'] = ''
    ranges = [('train','2017-01-01','2018-12-25'),('tune','2019-01-08','2019-04-24'),
              ('calibration','2019-05-08','2019-06-23'),('test','2019-07-08','2020-01-01')]
    for split, start, end in ranges:
        c.loc[(c.time >= start) & (c.time < end), 'split'] = split
    c = c[c.split != ''].copy()
    # Drop any documented episode spanning splits, even beyond the embargo.
    ep = c.dropna(subset=['episode_id']).groupby('episode_id').split.nunique()
    c = c[~c.episode_id.isin(ep[ep > 1].index)]
    # Exactly regular five-minute frames only. Issue time is frame 24, not catalog center.
    c = c[c.minute_offsets.apply(lambda x: len(str(x).split(':')) == 49 and np.all(np.diff(np.array(str(x).split(':'),dtype=int)) == 5))]
    result = []
    for (split,_,_), n in zip(ranges, counts):
        s = c[c.split == split].copy()
        # Target 50/50 source composition; available dates may reduce a stratum.
        # Actual source counts are recorded and any imbalance must be disclosed.
        for source in ['storm','random']:
            p = s[s.source == source].copy()
            # One documented storm episode, or one random UTC date, per source.
            p['cluster'] = p.apply(lambda r: f'S{int(r.episode_id)}' if pd.notna(r.episode_id) else 'R'+str(r.time.date()), axis=1)
            p = p.sample(frac=1, random_state=seed).drop_duplicates('cluster')
            take = min(n // 2, len(p))
            result.append(p.sample(n=take, random_state=seed).sort_values('time'))
    out = pd.concat(result).sort_values(['split','time']).reset_index(drop=True)
    out['issue_time_utc'] = out.apply(lambda r: r.time + pd.Timedelta(minutes=int(str(r.minute_offsets).split(':')[24])),axis=1)
    out['target_time_utc'] = out.issue_time_utc + pd.Timedelta(minutes=30)
    return out

def metadata_offset(file_name):
    url = BASE+'data/'+file_name
    with RangeFile(url) as rf, h5py.File(rf,'r') as f:
        d = f['vil']
        if d.chunks is not None or d.compression is not None: raise ValueError('Expected contiguous VIL dataset')
        return {'url':url, 'offset':d.id.get_offset(), 'shape':d.shape, 'dtype':str(d.dtype)}

def ingest(root, counts=(600,120,120,200), workers=8):
    root = Path(root); raw=root/'data/raw'; processed=root/'data/processed'
    raw.mkdir(parents=True,exist_ok=True); processed.mkdir(parents=True,exist_ok=True)
    catalog=raw/'CATALOG.csv'
    if not catalog.exists(): urllib.request.urlretrieve(BASE+'CATALOG.csv',catalog)
    sample = sample_catalog(catalog, counts)
    sample.to_csv(processed/'sample_manifest.csv',index=False)
    print('Selected',sample.groupby(['split','source']).size().to_dict(),flush=True)
    offsets={}
    with ThreadPoolExecutor(max_workers=workers) as pool:
        futures={pool.submit(metadata_offset,f): f for f in sample.file_name.unique()}
        for future in as_completed(futures): offsets[futures[future]]=future.result()
    (processed/'source_objects.json').write_text(json.dumps(offsets,indent=2))
    def fetch(row):
        dest=processed/'events'/f'{row.id}.npz'; dest.parent.mkdir(exist_ok=True)
        if dest.exists():
            try:
                with np.load(dest) as cached:
                    assert cached['mean'].shape==(49,96,96)
                    assert cached['high'].shape==(49,96,96)
                    assert len(str(cached['sha256']))==64
                return row.id,'cached'
            except (ValueError, OSError, AssertionError, KeyError):
                pass # Re-download invalid project-owned cache atomically.
        meta=offsets[row.file_name]; size=int(np.prod(meta['shape'][1:])); lo=meta['offset']+int(row.file_index)*size
        b,etag=get_range(meta['url'],lo,lo+size-1)
        a=np.frombuffer(b,dtype=np.uint8).reshape(meta['shape'][1:])
        if np.any(a==255): raise ValueError(f'Missing sentinel despite catalog QC: {row.id}')
        blocks=a.reshape(96,4,96,4,49)
        mean=blocks.mean(axis=(1,3)).transpose(2,0,1).astype(np.float16)
        high=(blocks.max(axis=(1,3))>=133).transpose(2,0,1)
        temporary=dest.with_suffix('.part.npz')
        np.savez_compressed(temporary,mean=mean,high=high,sha256=hashlib.sha256(b).hexdigest(),source_etag=str(etag))
        temporary.replace(dest)
        return row.id,'downloaded'
    errors=[]
    with ThreadPoolExecutor(max_workers=workers) as pool:
        futures={pool.submit(fetch,r):r.id for r in sample.itertuples()}
        for i,future in enumerate(as_completed(futures),1):
            try: ident,status=future.result()
            except Exception as e: errors.append({'id':futures[future],'error':repr(e)})
            if i%25==0 or i==len(futures): print(f'{i}/{len(futures)} events, errors={len(errors)}',flush=True)
    (processed/'download_errors.json').write_text(json.dumps(errors,indent=2))
    good=sample[sample.id.apply(lambda x:(processed/'events'/f'{x}.npz').exists())]
    if errors or len(good)!=len(sample): raise RuntimeError(f'{len(errors)} downloads failed; rerun to resume; no silent row dropping')
    summary={'catalog_sha256':hashlib.sha256(catalog.read_bytes()).hexdigest(),'catalog_vil_events':int(pd.read_csv(catalog,usecols=['img_type']).img_type.eq('vil').sum()),
             'selected_events':len(sample),'native_pixels':len(sample)*384*384*49,'nominal_event_payload_bytes':len(sample)*384*384*49,
             'counts':sample.groupby('split').size().to_dict(),'seed':20261111,'missing_sentinel':255,
             'threshold_native_encoded_vil':133,'pooling':'mean for regression; any native pixel for high-echo classification'}
    (processed/'data_summary.json').write_text(json.dumps(summary,indent=2))
    print(json.dumps(summary,indent=2),flush=True)

if __name__=='__main__':
    import argparse
    p=argparse.ArgumentParser();p.add_argument('--root',default='.');p.add_argument('--workers',type=int,default=8)
    p.add_argument('--counts',type=int,nargs=4,default=[600,120,120,200]);a=p.parse_args();ingest(a.root,a.counts,a.workers)
