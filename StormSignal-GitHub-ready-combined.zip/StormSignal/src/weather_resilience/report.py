"""Regenerate all figures, uncertainty intervals, and a self-contained HTML report."""
from __future__ import annotations
import base64, json, html
from pathlib import Path
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.colors import LinearSegmentedColormap

COLORS={'replay_blind':'#ef6a55','missing_aware':'#7b89ed','trusted_age':'#36d4b0','persistence':'#eab85c','advection':'#4ea4d8','climatology':'#7f8c9d','linear_logistic':'#dc81d3'}
LABELS={'replay_blind':'Replay, provenance ignored','missing_aware':'Explicit missing + mask','trusted_age':'Replay + trusted provenance','persistence':'Persistence','advection':'Age-aware global advection','climatology':'Training climatology','linear_logistic':'Age-aware linear + logistic'}
C=LinearSegmentedColormap.from_list('radar',['#0c1526','#225283','#34aeaa','#f0df78','#ed6c4d','#a13380'])
def style():
    plt.rcParams.update({'figure.facecolor':'#0b1220','axes.facecolor':'#111d30','savefig.facecolor':'#0b1220','text.color':'#e4edf7','axes.labelcolor':'#d0ddec','xtick.color':'#b5c6d8','ytick.color':'#b5c6d8','axes.edgecolor':'#526276','grid.color':'#465368','grid.alpha':.3,'font.family':'DejaVu Sans','font.size':10,'axes.titlesize':13,'figure.titlesize':19})
def save(fig,path):
    fig.savefig(path,dpi=160,bbox_inches='tight');plt.close(fig)
def block_difference(a,b,dates,metric,seed=710,repeats=2000):
    rng=np.random.default_rng(seed);groups=[np.flatnonzero(dates==d) for d in np.unique(dates)];out=[]
    def calc(z):
        # z has (seed,event,stat); seeds are paired, never resampled as events.
        if metric=='mae':return z[:,:,0].mean()
        if metric=='brier':return z[:,:,1].mean()
        sums=z.sum(axis=1);return np.mean(sums[:,2]/np.maximum(1,sums[:,2:5].sum(axis=1)))
    for _ in range(repeats):
        ix=np.concatenate([groups[i] for i in rng.integers(0,len(groups),len(groups))]);out.append(calc(a[:,ix])-calc(b[:,ix]))
    return {'difference':float(calc(a)-calc(b)),'low':float(np.quantile(out,.025)),'high':float(np.quantile(out,.975)),'unique_utc_days':len(groups)}
def run(root):
    root=Path(root);rep=root/'reports';figdir=rep/'figures';figdir.mkdir(exist_ok=True);style()
    manifest=pd.read_csv(root/'data/processed/sample_manifest.csv');manifest['time']=pd.to_datetime(manifest.time_utc)
    metrics=pd.read_csv(rep/'metrics.csv');agg=metrics.groupby(['model','delay_minutes']).mean(numeric_only=True).reset_index()
    truth=np.load(rep/'test_truth.npz');y=truth['mean'].astype(float);h=truth['high'];hist=truth['history'];test=manifest[manifest.split=='test'].reset_index(drop=True)
    stats=np.load(rep/'event_stats.npz');seeds=json.loads((rep/'run_config.json').read_text())['seeds']
    pictures=[]
    # Coverage: samples, not a population-weighted map.
    fig,axes=plt.subplots(1,2,figsize=(13,5),gridspec_kw={'width_ratios':[1.5,1]})
    for split,color in [('train','#4ea4d8'),('tune','#eab85c'),('calibration','#dc81d3'),('test','#36d4b0')]:
        s=manifest[manifest.split==split];axes[0].scatter((s.llcrnrlon+s.urcrnrlon)/2,(s.llcrnrlat+s.urcrnrlat)/2,s=11,alpha=.55,c=color,label=f'{split} ({len(s)})')
    axes[0].set(xlabel='Event center longitude',ylabel='Event center latitude',title='Geographic coverage of sampled scenes');axes[0].legend(fontsize=8)
    for split,color in [('train','#4ea4d8'),('tune','#eab85c'),('calibration','#dc81d3'),('test','#36d4b0')]:
        s=manifest[manifest.split==split];counts=s.groupby(s.time.dt.to_period('M')).size();axes[1].bar(counts.index.to_timestamp(),counts.values,width=22,color=color,label=split)
    axes[1].tick_params(axis='x',rotation=40);axes[1].set(ylabel='Sampled events',title='Strict temporal partitions + embargoes')
    fig.suptitle('01 / The data behind the experiment',x=.05,ha='left');fig.tight_layout();save(fig,figdir/'01_data_coverage.png');pictures.append(('01_data_coverage.png','Coverage is sampled by source and time, not weighted to population exposure. No basemap interpolation.'))
    # Training-only exploratory analysis.
    rows=[]
    for row in manifest.itertuples():
        with np.load(root/'data/processed/events'/f'{row.id}.npz') as f:
            mean=f['mean'];hi=f['high'];rows.append({'id':row.id,'split':row.split,'source':row.source,'month':row.time.month,'mean_vil':float(mean[30].mean()),'high_area_pct':float(hi[30].mean()*100),'active_area_pct':float((mean[30]>16).mean()*100),'temporal_change':float(np.abs(mean[24].astype(float)-mean[18]).mean())})
    eda=pd.DataFrame(rows);eda.to_csv(rep/'event_characteristics.csv',index=False)
    fig,axes=plt.subplots(1,3,figsize=(14,4.3));train=eda[eda.split=='train']
    for source,color in [('storm','#ed8266'),('random','#4ea4d8')]:
        s=train[train.source==source];axes[0].hist(s.mean_vil,bins=25,alpha=.65,color=color,label=source);axes[1].scatter(s.temporal_change,s.high_area_pct,s=12,c=color,alpha=.55,label=source)
    axes[0].set(xlabel='Target encoded mean VIL',ylabel='Training events',title='Source selection changes the sample');axes[0].legend()
    axes[1].set(xlabel='Previous 30-min mean absolute change',ylabel='Target high-echo blocks (%)',title='Activity and future core coverage')
    axes[2].boxplot([eda.loc[eda.split==s,'high_area_pct'] for s in ['train','tune','calibration','test']],tick_labels=['Train','Tune','Cal','Test'],showfliers=False)
    axes[2].set(ylabel='Target high-echo blocks (%)',title='Temporal distribution shift')
    fig.suptitle('02 / Rare cores, source bias, and changing seasons',x=.04,ha='left');fig.tight_layout();save(fig,figdir/'02_data_distributions.png');pictures.append(('02_data_distributions.png','Exploratory associations use the training period. The split plot describes temporal shift; it does not justify model retuning.'))
    # Forecast and probabilistic performance.
    fig,axes=plt.subplots(1,3,figsize=(14,4.7))
    for name in COLORS:
        s=agg[agg.model==name]
        for ax,col,title in zip(axes,['mae','brier','csi'],['Mean-field error ↓','Calibrated Brier score ↓','High-echo CSI at p ≥ 0.5 ↑']):
            ax.plot(s.delay_minutes,s[col],marker='o',lw=2,color=COLORS[name],label=LABELS[name]);ax.set(xlabel='Last genuine frame age (minutes)',ylabel=col.upper(),title=title);ax.grid();ax.set_xticks([0,5,15,30])
    axes[0].legend(fontsize=7,loc='best');fig.suptitle('03 / What stale data actually costs',x=.04,ha='left');fig.tight_layout();save(fig,figdir/'03_fault_response.png');pictures.append(('03_fault_response.png','CNN lines average two fixed seeds. All model probabilities are calibrated on separate earlier events. CSI uses a fixed 0.5 probability cutoff, not test optimization.'))
    # Paired day-block uncertainty.
    intervals=[];dates=test.issue_time_utc.str[:10].to_numpy()
    for d in [0,5,15,30]:
        a=np.stack([stats[f'trusted_age_{s}_{d}'] for s in seeds]);b=np.stack([stats[f'replay_blind_{s}_{d}'] for s in seeds])
        for metric in ['mae','brier','csi']:intervals.append({'delay_minutes':d,'metric':metric,**block_difference(a,b,dates,metric)})
    ci=pd.DataFrame(intervals);ci.to_csv(rep/'paired_day_bootstrap.csv',index=False)
    fig,axes=plt.subplots(1,3,figsize=(13,4))
    for ax,metric in zip(axes,['mae','brier','csi']):
        s=ci[ci.metric==metric];ax.axhline(0,color='#8fa3ba',ls='--');ax.errorbar(s.delay_minutes,s.difference,yerr=[s.difference-s.low,s.high-s.difference],fmt='o',capsize=5,color='#36d4b0');ax.set(xlabel='Age of last genuine frame (min)',ylabel='Trusted provenance minus ignored provenance',title=f'{metric.upper()}: paired 95% day-block CI');ax.grid()
    fig.suptitle('04 / Is the difference distinguishable from sample variation?',x=.04,ha='left');fig.tight_layout();save(fig,figdir/'04_paired_uncertainty.png');pictures.append(('04_paired_uncertainty.png','Same-event seed-averaged differences, resampling UTC-day blocks 2,000 times. Intervals do not quantify full training randomness or eliminate multiday dependence.'))
    # Reliability and source stratification.
    fig,axes=plt.subplots(1,2,figsize=(12,4.8));axes[0].plot([0,1],[0,1],ls='--',color='#8397ad');reliability=[]
    for name in ['replay_blind','missing_aware','trusted_age','linear_logistic','advection']:
        seed=seeds[0] if name in ['replay_blind','missing_aware','trusted_age'] else 0
        p=np.load(rep/f'prediction_{name}_{seed}_30.npz')['prob'].astype(float)
        bs=np.linspace(0,1,11);xx=[];yy=[]
        for lo,hi in zip(bs[:-1],bs[1:]):
            mask=(p>=lo)&(p<hi if hi<1 else p<=hi)
            if mask.sum()>0:
                xx.append(p[mask].mean());yy.append(h[mask].mean());reliability.append({'model':name,'lo':lo,'hi':hi,'count':int(mask.sum()),'forecast':xx[-1],'observed':yy[-1]})
        axes[0].plot(xx,yy,marker='o',color=COLORS[name],label=LABELS[name])
        for source,marker in [('storm','o'),('random','s')]:
            ix=test.source.eq(source).to_numpy();a=stats[f'{name}_{seed}_30']
            if ix.any(): axes[1].scatter(name,a[ix,1].mean(),color=COLORS[name],marker=marker,s=65)
    axes[0].set(xlabel='Mean calibrated probability',ylabel='Observed high-echo fraction',title='30-minute-stale feed: reliability');axes[0].legend(fontsize=7)
    axes[1].set(ylabel='Brier score',title='Storm (circle) vs random (square) sources');axes[1].tick_params(axis='x',rotation=35);axes[1].grid()
    fig.suptitle('05 / Calibration and subgroup error',x=.04,ha='left');fig.tight_layout();save(fig,figdir/'05_reliability_sources.png');pictures.append(('05_reliability_sources.png','Reliability and source comparisons use CNN seed 17 (descriptive, not seed-averaged). Pixel bins are not independent-pixel statistical evidence. Source differences reflect selection as well as meteorology.'));pd.DataFrame(reliability).to_csv(rep/'reliability_bins.csv',index=False)
    # Qualitative case chosen by highest target high-echo area (not method improvement).
    i=int(np.argmax(h.mean(axis=(1,2))));d=15;s=seeds[0]
    pp={name:np.load(rep/f'prediction_{name}_{s if name in COLORS and name in ["replay_blind","trusted_age"] else 0}_{d}.npz') for name in ['persistence','replay_blind','trusted_age']}
    fig,axes=plt.subplots(2,4,figsize=(13,8.2))
    fields=[hist[i,11-3]*254,y[i]*254,pp['replay_blind']['mean'][i]*254,pp['trusted_age']['mean'][i]*254]
    titles=['Last genuine frame (t = −15 min)','Observed target (t = +30 min)','Replay, provenance ignored','Replay, trusted provenance']
    for ax,a,title in zip(axes[0],fields,titles):im=ax.imshow(a,cmap=C,vmin=0,vmax=254);ax.set_title(title,fontsize=10);ax.set_xticks([]);ax.set_yticks([])
    for ax,a,title in zip(axes[1],[h[i],pp['persistence']['prob'][i],pp['replay_blind']['prob'][i],pp['trusted_age']['prob'][i]],['Observed any-native-pixel ≥ 133','Persistence probability','Blind replay probability','Trusted provenance probability']):im2=ax.imshow(a,cmap='magma',vmin=0,vmax=1);ax.set_title(title,fontsize=10);ax.set_xticks([]);ax.set_yticks([])
    fig.suptitle(f'06 / A difficult scene, not a handpicked win: {test.iloc[i].id}',x=.04,ha='left');fig.text(.04,.015,'Chosen by largest observed high-echo area in the test set. 384 km scene, displayed at 4 km blocks. Probabilities are calibrated.',fontsize=9);fig.tight_layout(rect=[0,.05,.92,.94],h_pad=3);cax=fig.add_axes([.94,.57,.012,.28]);fig.colorbar(im,cax=cax,label='Encoded mean VIL');cax2=fig.add_axes([.94,.15,.012,.28]);fig.colorbar(im2,cax=cax2,label='High-echo probability');save(fig,figdir/'06_case_study.png');pictures.append(('06_case_study.png',f'Case {test.iloc[i].id}, {test.iloc[i].time_utc}. Selection uses target severity for illustration only; all test events contribute to metrics.'))
    # Retention by known feed age: no oracle future risk ranking.
    fig,axes=plt.subplots(1,2,figsize=(12,4.5));selective=[]
    for name in ['replay_blind','trusted_age','missing_aware','linear_logistic']:
        ss=seeds if name in ['replay_blind','trusted_age','missing_aware'] else [0];cover=[];risk=[]
        for max_age in [0,5,15,30]:
            allowed=[d for d in [0,5,15,30] if d<=max_age];a=np.concatenate([np.mean([stats[f'{name}_{s}_{d}'] for s in ss],axis=0) for d in allowed]);cover.append(len(allowed)/4);risk.append(a[:,1].mean());selective.append({'model':name,'maximum_known_age':max_age,'retained_synthetic_conditions_fraction':len(allowed)/4,'brier':a[:,1].mean()})
        axes[0].plot(cover,risk,marker='o',color=COLORS[name],label=LABELS[name])
    axes[0].set(xlabel='Fraction of four equally weighted fault conditions retained',ylabel='Calibrated Brier score',title='Conservative refusal of older inputs');axes[0].legend(fontsize=8);axes[0].grid()
    histdf=pd.read_csv(rep/'training_history.csv')
    for name in ['replay_blind','missing_aware','trusted_age']:
        a=histdf[histdf.arm==name].groupby('epoch').validation_loss.mean();axes[1].plot(a.index,a,color=COLORS[name],label=LABELS[name])
    axes[1].set(xlabel='Training epoch',ylabel='Mean tuning loss',title='Equal-budget optimization trajectories');axes[1].grid()
    fig.suptitle('07 / Reliability has a coverage cost',x=.04,ha='left');fig.tight_layout();save(fig,figdir/'07_coverage_learning.png');pictures.append(('07_coverage_learning.png','This is a descriptive retention policy requiring external trusted age even for blind-model forecasts, not a learned detector, operational guarantee, or future-error-based gate. Equal weighting of injected delays is experimental, not estimated outage prevalence.'));pd.DataFrame(selective).to_csv(rep/'selective_retention.csv',index=False)
    # Secondary diagnostic added after the primary run: no threshold search.
    if (rep/'raw_score_diagnostics.csv').exists():
        raw=pd.read_csv(rep/'raw_score_diagnostics.csv').groupby(['model','delay_minutes']).mean(numeric_only=True).reset_index()
        fig,axes=plt.subplots(1,2,figsize=(12,4.5))
        for name in COLORS:
            rr=raw[raw.model==name]
            if rr.empty:continue
            for ax,col,title in zip(axes,['csi','pod'],['Raw-score CSI at original cutoff 0.5','Raw-score detection probability']):
                ax.plot(rr.delay_minutes,rr[col],marker='o',color=COLORS[name],label=LABELS[name]);ax.set(xlabel='Age of last genuine frame (min)',ylabel=col.upper(),title=title);ax.grid()
        axes[0].legend(fontsize=7);fig.suptitle('08 / A decision cutoff can conceal baseline skill',x=.04,ha='left');fig.tight_layout();save(fig,figdir/'08_raw_decision_diagnostic.png')
        pictures.append(('08_raw_decision_diagnostic.png','Secondary post-run diagnostic, not a changed primary endpoint: original raw-score cutoff 0.5, with no test tuning. Binary/interpolated baseline scores are not calibrated probabilities. Zero calibrated CSI at 0.5 does not mean zero deterministic echo skill.'))
    # Results tables and self-contained portable report.
    table=agg[agg.delay_minutes.isin([0,30])][['model','delay_minutes','mae','brier','csi','pod','raw_brier']].round(5)
    findings=[]
    for metric in ['mae','brier','csi']:
        row=ci[(ci.delay_minutes==30)&(ci.metric==metric)].iloc[0]
        findings.append(f'At 30 minutes of simulated stale history, trusted-provenance minus blind-replay {metric.upper()} is {row.difference:.5f} (95% UTC-day-block interval {row.low:.5f} to {row.high:.5f}).')
    summary=json.loads((root/'data/processed/data_summary.json').read_text())
    narrative='\n'.join(findings)
    (rep/'findings.json').write_text(json.dumps({'headline_differences_30min':findings,'test_events':len(test),'test_days':len(np.unique(dates)),'case_study_id':str(test.iloc[i].id),'warning':'Research subset and synthetic faults only. Trusted freshness is oracle information under hidden replay. No claim of operational warning skill or first-ever novelty.'},indent=2))
    content='''<!doctype html><html lang="en"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>StormSignal: When Radar Stops Updating</title><style>body{margin:0;background:#0b1220;color:#dce7f3;font:17px/1.6 system-ui,sans-serif}main{max-width:1150px;margin:auto;padding:50px 28px}h1{font-size:50px;line-height:1.08;letter-spacing:-2px}h2{margin-top:44px;color:#64dfc0}p,li{max-width:1000px}small{color:#a8b8ca}img{width:100%;margin-top:25px;border-radius:12px}table{border-collapse:collapse;font-size:12px;display:block;overflow:auto}td,th{padding:10px;border-bottom:1px solid #34435b;text-align:right}.tag{color:#67dec4;letter-spacing:3px;font-size:13px}.callout{border-left:4px solid #efad6d;padding:12px 20px;background:#172437}a{color:#77d7ed}</style><main><div class="tag">REPRODUCIBLE WEATHER ML · RESEARCH PILOT</div><h1>When the storm moves,<br>but the radar feed does not.</h1><p>A controlled SEVIR experiment asking how much trustworthy data provenance matters for 30-minute radar nowcasts. Three compact CNNs receive identical underlying observations, encoded as silent replay, explicit missingness, or replay with trusted source age.</p>'''
    content+=f'<p><strong>{summary["selected_events"]:,} sampled events · {summary["native_pixels"]:,} native pixel-time values processed · {len(test)} held-out test events · {len(seeds)} CNN seeds.</strong></p>'
    content+='<div class="callout">This is a research pilot, not a public warning product. The target is encoded vertically integrated liquid (VIL), not rainfall depth or flooding. Trusted age is an oracle upper bound if a broken feed hides its real timestamps. The study tests an original narrow question; it does not establish first-ever novelty.</div><h2>What the completed run found</h2><ul>'+''.join('<li>'+html.escape(f)+'</li>' for f in findings)+'</ul><p>Lower MAE and Brier are better; higher CSI is better. An interval spanning zero is not evidence of a clear improvement. Compare against the full baseline suite before recommending a neural model.</p>'
    for pic,caption in pictures:
        encoded=base64.b64encode((figdir/pic).read_bytes()).decode();content+=f'<img alt="{html.escape(caption)}" src="data:image/png;base64,{encoded}"><p><small>{html.escape(caption)}</small></p>'
    content+='<h2>Measured results</h2>'+table.to_html(index=False,border=0)+'<h2>Limits that matter</h2><ul><li>Only a curated 1,010-event subset, not the full approximately 1 TB multimodal archive.</li><li>Synthetic replay, not observed outage logs. A repeated image can also be genuine stationary weather.</li><li>Fixed geography, short historical period, and seasonal distribution shift. No claim of climate-trend inference.</li><li>Small CPU CNNs, two seeds, and simple baselines. More training or better motion models can change the ranking.</li><li>All CNNs are fault-augmented. A blind CNN may infer delay from exact repeated images; this is not a clean-trained model surprised by an outage.</li><li>Storm/random source sampling differs from real-world warning incidence. The calibration split has a 60:30 source mix versus 50:50 elsewhere; fitted calibration may fail under base-rate shift.</li><li>At the fixed 0.5 probability cutoff, calibrated persistence and advection issue no positive predictions. Their zero CSI is a decision-threshold effect, not evidence of no useful deterministic forecasting skill.</li><li>Spatial errors correlate; UTC-day bootstrap remains imperfect for multiday systems.</li><li>Mean VIL is in encoded units; the high-echo task uses any native pixel over threshold within a 4 km block.</li></ul><h2>Reproduce and extend</h2><p>See the repository README, data manifest, source-object offsets, per-event source SHA-256 hashes, pinned environment, unit tests, checkpoints, training histories, exact protocol, and novelty audit. Full pipeline: <code>make reproduce</code>. All published numbers come from saved outputs.</p><p>Sources: <a href="https://registry.opendata.aws/sevir/">AWS SEVIR registry</a> · <a href="https://papers.neurips.cc/paper/2020/file/fa78a16157fed00d7a80515818432169-Paper.pdf">SEVIR dataset paper</a></p></main></html>'
    (rep/'StormSignal_report.html').write_text(content)
    print(narrative,flush=True)
if __name__=='__main__':
    import argparse
    p=argparse.ArgumentParser();p.add_argument('--root',default='.');a=p.parse_args();run(a.root)
