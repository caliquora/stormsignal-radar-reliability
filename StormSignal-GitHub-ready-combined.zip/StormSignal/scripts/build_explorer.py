"""Build an offline, dependency-free UI from recorded research artifacts."""
import csv,json,hashlib
from pathlib import Path
import numpy as np
ROOT=Path(__file__).resolve().parents[1]
def build_payload():
    records=[]
    for row in csv.DictReader((ROOT/'reports/metrics.csv').read_text().splitlines()):
        records.append({k:(v if k=='model' else float(v) if v else None) for k,v in row.items()})
    groups={}
    for r in records:groups.setdefault((r['model'],r['delay_minutes']),[]).append(r)
    means=[]
    for (model,delay),rs in sorted(groups.items()):
        means.append({'model':model,'delay_minutes':delay,'runs':len(rs),**{m:sum(r[m] for r in rs)/len(rs) for m in ('mae','brier','csi','pod','far')}})
    intervals=[{k:(v if k=='metric' else float(v)) for k,v in r.items()} for r in csv.DictReader((ROOT/'reports/paired_day_bootstrap.csv').read_text().splitlines())]
    a=np.load(ROOT/'studies/spatial-freshness/results/predetermined_example.npz',allow_pickle=False)
    example={k:a[k].tolist() for k in a.files}
    paths=['reports/metrics.csv','reports/paired_day_bootstrap.csv','studies/spatial-freshness/results/predetermined_example.npz']
    return {'metrics':means,'intervals':intervals,'example':example,'sources':{p:hashlib.sha256((ROOT/p).read_bytes()).hexdigest() for p in paths},'aggregation':'Unweighted mean across saved seeds within each model/age. Baselines have one record. Intervals use the original paired day-block bootstrap, not seed standard errors.'}
def main():
    data=build_payload();encoded=json.dumps(data,separators=(',',':'),allow_nan=False).replace('</','<\\/')
    template=(ROOT/'explorer/template.html').read_text()
    (ROOT/'explorer/index.html').write_text(template.replace('__EVIDENCE_JSON__',encoded))
    (ROOT/'explorer/evidence.json').write_text(json.dumps(data,indent=2,allow_nan=False))
    print('Built explorer/index.html from recorded metrics and one predetermined case. No models trained.')
if __name__=='__main__':main()
