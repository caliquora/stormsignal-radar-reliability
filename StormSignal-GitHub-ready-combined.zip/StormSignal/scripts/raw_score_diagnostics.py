"""Post-run diagnostic: raw-score decisions, never tune a threshold on test."""
from pathlib import Path
import json
import numpy as np
import pandas as pd
import torch
from scipy.special import expit
from weather_resilience.experiment import load_split,predict,features
from weather_resilience.models import TinyNowcaster,advect
from weather_resilience.protocol import score_arrays,DELAYS,ARMS
root=Path(__file__).resolve().parents[1];rep=root/'reports';torch.set_num_threads(4)
m=pd.read_csv(root/'data/processed/sample_manifest.csv');x,y,h,xh=load_split(root,m,'test');rows=[]
for seed in json.loads((rep/'run_config.json').read_text())['seeds']:
    for arm in ARMS:
        model=TinyNowcaster();checkpoint=torch.load(root/'models'/f'{arm}_{seed}.pt',map_location='cpu',weights_only=False);model.load_state_dict(checkpoint['state_dict'])
        for d in DELAYS:
            yp,lp=predict(model,x,xh,d,arm);p=expit(lp);row=score_arrays(y,h,yp,p);row.update(model=arm,seed=seed,delay_minutes=d*5,score_type='uncalibrated CNN probability');rows.append(row)
for d in DELAYS:
    for name in ['persistence','advection']:
        if name=='persistence':yp=x[:,11-d];p=xh[:,11-d].astype(float)
        else:
            pred=[advect(a,b,d) for a,b in zip(x,xh)];yp=np.stack([a for a,b in pred]);p=np.stack([b for a,b in pred])
        row=score_arrays(y,h,yp,p);row.update(model=name,seed=0,delay_minutes=d*5,score_type='binary/interpolated radar echo score, not calibrated probability');rows.append(row)
c=json.loads((root/'models/classical_coefficients.json').read_text())
for d in DELAYS:
    f=features(x,xh,d);p=expit(f@np.asarray(c['logistic_coef'][0])+c['logistic_intercept'][0]);yp=np.clip(f@np.asarray(c['ridge_coef'])+c['ridge_intercept'],0,1)
    row=score_arrays(y,h,yp,p);row.update(model='linear_logistic',seed=0,delay_minutes=d*5,score_type='uncalibrated logistic probability');rows.append(row)
pd.DataFrame(rows).to_csv(rep/'raw_score_diagnostics.csv',index=False)
print(pd.DataFrame(rows).groupby(['model','delay_minutes'])[['csi','pod','far','forecast_positive_fraction']].mean().round(5).to_string())
