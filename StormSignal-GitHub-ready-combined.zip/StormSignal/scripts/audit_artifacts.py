"""Validate real event arrays and create a reproducibility inventory."""
from pathlib import Path
import hashlib,json
import numpy as np
import pandas as pd
root=Path(__file__).resolve().parents[1]
m=pd.read_csv(root/'data/processed/sample_manifest.csv');inventory=[]
for r in m.itertuples():
    p=root/'data/processed/events'/f'{r.id}.npz'
    with np.load(p) as f:
        assert f['mean'].shape==f['high'].shape==(49,96,96)
        assert np.isfinite(f['mean']).all() and (f['mean']>=0).all() and (f['mean']<=254).all()
        assert f['high'].dtype==bool
        sha=str(f['sha256']);assert len(sha)==64
        inventory.append({'id':r.id,'source_event_sha256':sha,'source_etag':str(f['source_etag']),'derived_file_sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'derived_bytes':p.stat().st_size})
pd.DataFrame(inventory).to_csv(root/'data/processed/event_hashes.csv',index=False)
assert not m.id.duplicated().any()
assert (m.dropna(subset=['episode_id']).groupby('episode_id').split.nunique()==1).all()
s={'verified_events':len(inventory),'derived_total_bytes':sum(x['derived_bytes'] for x in inventory),'source_pixel_time_values':len(m)*384*384*49,'cross_split_episode_overlap':0,'passed':True}
(root/'reports/data_integrity_audit.json').write_text(json.dumps(s,indent=2));print(json.dumps(s,indent=2))
