"""Restyle saved research outputs; never retrain, recompute CIs, or edit source data.

Run: python scripts/restyle_figures.py --root .
Uses open-source Matplotlib (PSF-based license), NumPy (BSD), pandas (BSD-3-Clause).
Figure 06 remains the original raster: its underlying prediction tensors are absent.
"""
from pathlib import Path
import argparse
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import matplotlib.dates as mdates
from matplotlib.lines import Line2D
from matplotlib.ticker import PercentFormatter, MaxNLocator

INK='#182E46'; MUTED='#52677B'; GRID='#DFE7ED'
COLORS={'replay_blind':'#C65F17','missing_aware':'#6655B6','trusted_age':'#007D78','persistence':'#9B7512','advection':'#307BB0','climatology':'#75808A','linear_logistic':'#A44B83'}
LABELS={'replay_blind':'Blind replay','missing_aware':'Explicit missing + mask','trusted_age':'Replay + trusted provenance','persistence':'Persistence','advection':'Age-aware global advection','climatology':'Training climatology','linear_logistic':'Age-aware linear + logistic'}
MARKERS=dict(zip(COLORS,['o','s','D','^','v','X','P']))
LINES=dict(zip(COLORS,['--','-.','-',':','--',':','-.']))
SPLITS=['train','tune','calibration','test']
SC=['#307BB0','#B7871E','#A44B83','#007D78']

def style():
    plt.rcParams.update({'figure.facecolor':'white','axes.facecolor':'white','savefig.facecolor':'white','text.color':INK,'axes.labelcolor':MUTED,'xtick.color':MUTED,'ytick.color':MUTED,'axes.edgecolor':GRID,'grid.color':GRID,'grid.linewidth':.7,'font.family':'DejaVu Sans','font.size':12,'axes.labelsize':12,'axes.titlesize':15,'axes.titleweight':'bold','axes.titlelocation':'left','axes.titlepad':17,'axes.spines.top':False,'axes.spines.right':False,'axes.axisbelow':True,'legend.frameon':False,'legend.fontsize':11,'svg.fonttype':'none','pdf.fonttype':42})

def panels(n=2,height=6.5):
    fig,ax=plt.subplots(1,n,figsize=(16,height));fig.subplots_adjust(left=.065,right=.98,top=.88,bottom=.29,wspace=.30 if n==2 else .34)
    for a in ax:a.grid(axis='y');a.tick_params(length=0,pad=8)
    return fig,ax

def line(ax,df,name,x,y):
    a=df[df.model==name].sort_values(x)
    if len(a):ax.plot(a[x],a[y],color=COLORS[name],label=LABELS[name],marker=MARKERS[name],ls=LINES[name],lw=2.3,ms=6.5,markeredgecolor='white',markeredgewidth=.6)

def legend(fig,names,y=.10,ncol=3):
    handles=[Line2D([],[],color=COLORS[n],label=LABELS[n],marker=MARKERS[n],ls=LINES[n],lw=2,ms=6) for n in names]
    fig.legend(handles=handles,loc='lower center',bbox_to_anchor=(.5,y),ncol=ncol,columnspacing=2.2,handlelength=3)

def save(fig,out,name,note):
    fig.text(.065,.025,note,fontsize=10,color=MUTED,va='bottom')
    for ext in ['png','svg']:fig.savefig(out/f'{name}.{ext}',dpi=200)
    plt.close(fig)

def run(root):
    root=Path(root);r=root/'reports';out=r/'figures';out.mkdir(exist_ok=True);style()
    manifest=pd.read_csv(root/'data/processed/sample_manifest.csv');manifest['time']=pd.to_datetime(manifest.time_utc)
    agg=pd.read_csv(r/'metrics.csv').groupby(['model','delay_minutes']).mean(numeric_only=True).reset_index()
    fig,ax=panels()
    for split,color,marker in zip(SPLITS,SC,['o','^','s','D']):
        s=manifest[manifest.split==split]
        ax[0].scatter((s.llcrnrlon+s.urcrnrlon)/2,(s.llcrnrlat+s.urcrnrlat)/2,s=21,alpha=.55,c=color,marker=marker,linewidth=0,label=f'{split.title()} · {len(s):,}')
        count=s.groupby(s.time.dt.tz_localize(None).dt.to_period('M')).size()
        ax[1].bar(count.index.to_timestamp(),count.values,width=23,color=color)
    ax[0].set(xlabel='Event center longitude (°)',ylabel='Event center latitude (°)',title='A   Geographic sampling')
    ax[1].set(ylabel='Sampled events per month',title='B   Temporal partitions',xlabel='Observation month')
    ax[1].xaxis.set_major_locator(mdates.MonthLocator(interval=6));ax[1].xaxis.set_major_formatter(mdates.DateFormatter('%b %Y'))
    fig.legend(*ax[0].get_legend_handles_labels(),loc='lower center',bbox_to_anchor=(.5,.12),ncol=4,markerscale=1.8)
    save(fig,out,'01_data_coverage','Sampled scenes, not population-weighted coverage. Strict time partitions use seven-day boundary embargoes.')

    eda=pd.read_csv(r/'event_characteristics.csv');train=eda[eda.split=='train']
    fig,ax=panels(3)
    for source,color,marker in [('storm','#C65F17','o'),('random','#307BB0','s')]:
        s=train[train.source==source];ax[0].hist(s.mean_vil,bins=25,alpha=.55,color=color,label=source.title(),edgecolor='white',linewidth=.3)
        ax[1].scatter(s.temporal_change,s.high_area_pct,s=23,c=color,alpha=.5,marker=marker,linewidth=0)
    ax[0].set(xlabel='Target mean encoded VIL',ylabel='Training events',title='A   Source selection')
    ax[1].set(xlabel='Prior 30-min mean absolute change',ylabel='Target high-echo blocks (%)',title='B   Activity and core coverage')
    b=ax[2].boxplot([eda.loc[eda.split==s,'high_area_pct'] for s in SPLITS],tick_labels=['Train','Tune','Cal.','Test'],showfliers=False,patch_artist=True,widths=.5,medianprops={'color':INK,'linewidth':2},whiskerprops={'color':MUTED},capprops={'color':MUTED})
    for patch,col in zip(b['boxes'],SC):patch.set(facecolor=col,alpha=.5,edgecolor=col)
    ax[2].set(ylabel='Target high-echo blocks (%)',title='C   Temporal shift')
    fig.legend(*ax[0].get_legend_handles_labels(),loc='lower center',bbox_to_anchor=(.37,.12),ncol=2)
    save(fig,out,'02_data_distributions','A–B: training events only. C: descriptive split comparison; boxplot outliers hidden. No test-driven retuning.')

    fig,ax=panels(3,7)
    for a,col,title,unit in zip(ax,['mae','brier','csi'],['A   Mean-field error ↓','B   Calibrated Brier ↓','C   High-echo CSI ↑'],['MAE · encoded VIL units','Brier score','CSI at probability ≥ 0.5']):
        for n in COLORS:line(a,agg,n,'delay_minutes',col)
        a.set(title=title,ylabel=unit,xlabel='Age of last genuine frame (min)',xticks=[0,5,15,30]);a.margins(x=.06)
    legend(fig,list(COLORS),y=.085,ncol=3)
    save(fig,out,'03_fault_response','CNNs average two fixed seeds. Calibration uses earlier held-out events; the primary probability cutoff stays fixed at 0.5.')

    ci=pd.read_csv(r/'paired_day_bootstrap.csv');fig,ax=panels(3,6.2);fig.subplots_adjust(bottom=.24)
    for a,metric,title,unit in zip(ax,['mae','brier','csi'],['A   MAE difference','B   Brier difference','C   CSI difference'],['Δ MAE · encoded VIL units','Δ Brier score','Δ CSI']):
        s=ci[ci.metric==metric];a.axhline(0,color=MUTED,ls='--',lw=1.2)
        a.errorbar(s.delay_minutes,s.difference,yerr=[s.difference-s.low,s.high-s.difference],fmt='D',capsize=6,color=COLORS['trusted_age'],elinewidth=2,ms=7)
        a.set(title=title,xlabel='Age of last genuine frame (min)',ylabel=unit,xticks=[0,5,15,30]);a.set_xlim(-3,33)
        a.ticklabel_format(axis='y',style='plain',useOffset=False)
        a.text(0,-.23,'Negative favors trusted' if metric!='csi' else 'Positive favors trusted',transform=a.transAxes,color=COLORS['trusted_age'],fontsize=11,fontweight='bold')
    save(fig,out,'04_paired_uncertainty','Trusted provenance − blind replay. Saved 95% paired UTC-day-block intervals (2,000 resamples); not full training uncertainty.')

    bins=pd.read_csv(r/'reliability_bins.csv');stats=np.load(r/'event_stats.npz');test=manifest[manifest.split=='test'].reset_index(drop=True)
    names=['replay_blind','missing_aware','trusted_age','linear_logistic','advection'];fig,ax=panels(2,7.5);fig.subplots_adjust(bottom=.32)
    ax[0].plot([0,1],[0,1],ls=':',color=MUTED,lw=1.4)
    for i,n in enumerate(names):
        line(ax[0],bins,n,'forecast','observed');seed=17 if n in names[:3] else 0;a=stats[f'{n}_{seed}_30']
        for source,marker,offset in [('storm','o',-.10),('random','s',.10)]:
            ix=test.source.eq(source).to_numpy();ax[1].scatter(i+offset,a[ix,1].mean(),color=COLORS[n],marker=marker,s=78,edgecolor='white',linewidth=.7)
    ax[0].set(title='A   Reliability at 30-min staleness',xlabel='Mean calibrated probability',ylabel='Observed high-echo fraction',xlim=(-.025,1.025),ylim=(-.025,1.025))
    ax[1].set(title='B   Source-stratified error',ylabel='Brier score',xticks=range(5),xticklabels=['Blind\nreplay','Explicit\nmissing','Trusted\nreplay','Linear +\nlogistic','Global\nadvection'])
    ax[1].legend(handles=[Line2D([],[],ls='',marker=m,color=MUTED,label=s,ms=7) for s,m in [('Storm source','o'),('Random source','s')]],loc='center right',bbox_to_anchor=(1,.55))
    legend(fig,names,y=.09,ncol=3)
    save(fig,out,'05_reliability_sources','CNN seed 17 only; descriptive, not seed-averaged. Pixel bins are correlated. Source differences also reflect selection.')

    retention=pd.read_csv(r/'selective_retention.csv');history=pd.read_csv(r/'training_history.csv');names=['replay_blind','trusted_age','missing_aware','linear_logistic']
    fig,ax=panels(2,7)
    for n in names:
        line(ax[0],retention,n,'retained_synthetic_conditions_fraction','brier')
        if n!='linear_logistic':
            s=history[history.arm==n].groupby('epoch').validation_loss.mean().reset_index();s['model']=n;line(ax[1],s,n,'epoch','validation_loss')
    ax[0].set(title='A   Retention by known feed age',ylabel='Calibrated Brier score',xlabel='Synthetic conditions retained',xticks=[.25,.5,.75,1]);ax[0].xaxis.set_major_formatter(PercentFormatter(1))
    ax[0].set_xticklabels(['25%\n≤ 0 min','50%\n≤ 5 min','75%\n≤ 15 min','100%\n≤ 30 min']);ax[0].set_xlabel('Conditions retained / maximum known age')
    ax[1].set(title='B   Equal-budget training',ylabel='Mean tuning loss',xlabel='Training epoch');ax[1].xaxis.set_major_locator(MaxNLocator(integer=True,nbins=6))
    legend(fig,names,y=.09,ncol=2)
    save(fig,out,'07_coverage_learning','Equal weighting of four injected delays, not outage prevalence. Retention requires externally trusted age; it is not an outage detector.')

    raw=pd.read_csv(r/'raw_score_diagnostics.csv').groupby(['model','delay_minutes']).mean(numeric_only=True).reset_index()
    fig,ax=panels(2,7);names=[n for n in COLORS if n in set(raw.model)]
    for a,col,title,unit in zip(ax,['csi','pod'],['A   Raw-score CSI','B   Raw-score detection'],['CSI at original raw cutoff 0.5','Detection probability']):
        for n in names:line(a,raw,n,'delay_minutes',col)
        a.set(title=title,xlabel='Age of last genuine frame (min)',ylabel=unit,xticks=[0,5,15,30]);a.margins(x=.06)
    legend(fig,names,y=.085,ncol=3)
    save(fig,out,'08_raw_decision_diagnostic','Secondary post-run diagnostic; original cutoff 0.5, no test tuning. Raw baseline scores are not calibrated probabilities.')
    print('Restyled 7 chart collections as PNG + SVG. Source tables and figure 06 were not modified.')

if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--root',default=Path(__file__).resolve().parents[1]);run(p.parse_args().root)
