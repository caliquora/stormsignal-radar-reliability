"""Create the designed brief from saved metrics, without retraining."""
from pathlib import Path
import json, html, re, sys
from reportlab.pdfgen import canvas
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.lib.colors import HexColor
from reportlab.lib.utils import ImageReader
from reportlab.lib.styles import ParagraphStyle
from reportlab.platypus import Paragraph
from matplotlib import get_data_path
from build_html import SECTIONS, CONTENT, metrics, LABELS
ROOT=Path(__file__).resolve().parents[1];REP=ROOT/'reports';OUT=ROOT/'output/pdf';OUT.mkdir(parents=True,exist_ok=True)
FD=Path(get_data_path())/'fonts/ttf'
for name,file in [('Sans','DejaVuSans.ttf'),('Bold','DejaVuSans-Bold.ttf'),('Light','DejaVuSans.ttf'),('Serif','DejaVuSerif.ttf')]:pdfmetrics.registerFont(TTFont(name,str(FD/file)))
pdfmetrics.registerFontFamily('Sans',normal='Sans',bold='Bold',italic='Sans',boldItalic='Bold')
W,H=960,640;INK='#122a3b';MUTED='#546672';TEAL='#087f79';ORANGE='#b8562b';PAPER='#f4f2ec';WHITE='#ffffff'
c=canvas.Canvas(str(OUT/'StormSignal-research-brief.pdf'),pagesize=(W,H));c.setTitle('StormSignal: When Radar Stops Updating');c.setAuthor('Chris Chiodo - AI-assisted research build');c.setSubject('Controlled SEVIR replay-fault research; visual edition')
styles={}
def para(text,x,y,w,size=11,color=INK,leading=None,bold=False):
 s=ParagraphStyle('body',fontName='Bold' if bold else 'Sans',fontSize=size,leading=leading or size*1.5,textColor=HexColor(color))
 p=Paragraph(text,s);_,h=p.wrap(w,H);p.drawOn(c,x,y-h);return y-h

def rect(x,y,w,h,fill,stroke=None):
 c.setFillColor(HexColor(fill));c.setStrokeColor(HexColor(stroke or fill));c.rect(x,y,w,h,fill=1,stroke=bool(stroke))
def line(x,y,x2,y2,color='#c8d1cf',width=.6):c.setStrokeColor(HexColor(color));c.setLineWidth(width);c.line(x,y,x2,y2)
def txt(s,x,y,size=11,color=INK,font='Sans'):c.setFillColor(HexColor(color));c.setFont(font,size);c.drawString(x,y,s)
def page(n,dark=False):
 bg=INK if dark else PAPER;fg='#c4d6dd' if dark else MUTED;rect(0,0,W,H,bg)
 txt('STORMSIGNAL',40,608,10,fg,'Bold');txt('RESEARCH PILOT / NOVEMBER 2026',153,608,8,fg)
 line(40,40,W-40,40,'#3d5665' if dark else '#c8d1cf')
 txt('SOURCE: SAVED SEVIR EXPERIMENT / SYNTHETIC FAULTS / NOT AN OPERATIONAL WARNING',40,23,7,fg)
 txt(f'{n:02} / 18',W-83,23,8,fg)
def title(kicker,heading,sub=None):
 txt(heading,42,553,30,INK,'Serif')
 if sub:para(sub,43,534,870,11,MUTED)
def imagefit(path,x,y,w,h):
 im=ImageReader(str(path));iw,ih=im.getSize();scale=min(w/iw,h/ih);ww,hh=iw*scale,ih*scale
 c.drawImage(im,x+(w-ww)/2,y+(h-hh)/2,width=ww,height=hh,mask='auto')

agg,cards=metrics()
# 1: integrated reading guide, with the study boundaries visible on arrival.
page(1)
txt('Weather data can',42,539,46,INK,'Serif');txt('age unevenly.',42,483,46,INK,'Serif')
para('Two controlled experiments on SEVIR radar imagery ask what forecasts lose when observations stop updating. The original study varies age across the whole scene; the follow-on varies where old data sit.',45,444,820,15,MUTED,22)
line(43,346,917,346)
txt('Original whole-scene-delay study',43,316,19,INK,'Bold')
para('1,010 sampled events; 200 evaluated on 113 UTC days. At 30-minute staleness, trusted age improves average error and Brier score, but high-echo CSI declines at the fixed 0.5 cutoff.',43,297,535,11,MUTED,17)
para('Read the experiment, evidence and full model table on pages 3-13.',635,307,275,11,TEAL,17)
line(43,224,917,224)
txt('Executed spatial follow-on',43,195,19,INK,'Bold')
para('The same 200 events, not a new holdout. With the stale footprint fixed, swapping its 15- and 30-minute-old halves changes the blind CNN high-echo miss rate by +2.89 percentage points for the primary horizontal patch. The increase is not established across both tested orientations.',43,177,535,11,MUTED,17)
para('Read the matched controls, sensitivity check and novelty assessment on pages 14-18.',635,183,275,11,TEAL,17)
para('<b>Research status:</b> original exploratory experiments; first-ever novelty is not established. Synthetic faults and trusted ages do not demonstrate improved public warnings or safer everyday decisions.',43,85,870,9.5,MUTED,14)
c.showPage()
# 2: the practical reason to care, separated from unproven benefits.
page(2);title('Why should I care?','Why should I care?','A weather screen can look current when its observations are not. The age of its input matters.')
para('For us, the question is simple: <b>is this fresh weather information or an old image carried forward?</b> A 30-minute-old scan used to forecast 30 minutes ahead leaves a 60-minute gap from observation to target.',43,476,865,12,INK,18)
rect(42,341,876,72,'#e5ebe7')
for x,time,label in [(60,'t = -30 min','Last genuine scan'),(355,'t = 0','Forecast issued'),(650,'t = +30 min','Forecast target')]:
 line(x,390,x+242,390,TEAL,1.2);c.setFillColor(HexColor(TEAL));c.circle(x,390,3,fill=1,stroke=0)
 txt(time,x,373,9,MUTED);txt(label,x,353,12,INK,'Bold')
why=[('What does this mean for everyday plans?','Before an outdoor job, event, or trip, observation age is useful context. This project does not tell us whether it is safe to go ahead. It asks whether old or missing information is visible.'),('What decisions could improve a product?','Weather-app teams can decide when to show a stale-data notice, request a fresh scan, or use a fallback. The goal is a screen that does not look more current or certain than its inputs. Those policies were not tested.'),('What did the test actually change?','True age improved average image error and overall probabilistic accuracy. But at 30-minute staleness the high-echo detection score was worse at the chosen cutoff. Better on average did not mean better on this detection task.'),('Does that mean safer decisions for us?','No demonstrated reduction in missed public warnings, flood losses, injuries, or operator workload. Faults are simulated, ages are trusted, and operational use would require field validation.')]
for i,(heading,body) in enumerate(why):
 x=43+(i%2)*450;y=312-(i//2)*108
 txt(heading,x,y,12,TEAL,'Bold');para(body,x,y-13,420,10,MUTED,15)
rect(42,59,876,50,'#eeebe4');para('<b>The spatial follow-on is now executed:</b> equal overall freshness can conceal different input losses. The more informative same-footprint age swap changes the horizontal high-echo outcome, but the increase is not established across both orientations. See pages 14-18.',55,100,850,9,INK,13)
txt('Motivation: NTSB SA-017 documents radar-mosaic age ambiguity. This is not aviation guidance.',43,48,7.8,MUTED)
c.linkURL('https://data.ntsb.gov/advocacy/safety-alerts/Documents/SA-017.pdf',(43,46,502,57),relative=0)
c.showPage()
# 3: method with narrow, accurate scope.
page(3);title('Experiment design','Same weather. Same target. Different inputs.','A fixed issue time and +30-minute target; the genuine observations are matched across arms.')
for i,(name,color,body) in enumerate([
 ('Blind replay',ORANGE,'Repeat frozen terminal frames. Provenance channels falsely indicate freshness. Exact repeats may reveal delay indirectly.'),
 ('Explicit missingness','#5b56a4','Zero-fill unavailable terminal frames and identify them with a mask. On a regular grid, the mask already reveals delay.'),
 ('Trusted replay',TEAL,'Reuse the same frozen arrays as blind replay, with truthful availability and per-slot staleness. True age is oracle information under hidden timestamps.')]):
 x=42+i*298;rect(x,300,282,164,WHITE);rect(x,460,282,4,color);txt(f'0{i+1}',x+17,431,10,color,'Bold');txt(name,x+17,405,18,INK,'Bold');para(body,x+17,388,248,10.5,MUTED,16)
txt('CHRONOLOGICAL PARTITIONS',43,272,9,TEAL,'Bold')
for i,(name,count,dates) in enumerate([('Train','600','2017-2018'),('Tune','120','Jan-Apr 2019'),('Calibration','90','May-Jun 2019'),('Test','200','Jul 8-Nov 30, 2019')]):
 x=43+i*223;rect(x,180,210,72,'#e5ebe7');txt(f'{name} / {count}',x+14,225,14,INK,'Bold');txt(dates,x+14,201,10,MUTED)
para('<b>Protocol.</b> Twelve history frames; simulated age 0, 5, 15, or 30 minutes. Three 23,746-parameter CNNs, seeds 17 and 29, 18 epochs each: 108 training epochs. Four classical/reference baselines. Seven-day embargoes and episode grouping protect the split.',43,160,425,10,MUTED,15)
para('<b>Targets.</b> 384 × 384 native scenes pooled to 96 × 96. Regression uses mean encoded VIL. High-echo labels preserve any native pixel ≥ 133 within each 4 × 4 block. VIL is not rainfall depth or flood risk.',493,160,425,10,MUTED,15)
c.showPage()
# 3-10: one figure per page, with designed section headers and evidence captions.
for i,(stem,heading,sub,anchor) in enumerate(SECTIONS):
 page(i+4)
 if anchor=='case':
  imagefit(REP/'figures'/f'{stem}.png',40,83,880,510)
  caption_y=75
 else:
  title(f'Evidence / {i+1:02}',heading,sub)
  imagefit(REP/'figures'/f'{stem}.png',33,110,894,408)
  caption_y=98
 caption=html.unescape(CONTENT['captions'][i]);para(caption,43,caption_y,870,9.2,MUTED,13)
 c.showPage()
# 11: exact fresh/stale comparison + intervals.
page(12);title('Recorded measurements','Read every model against the same task.','CNN rows average two seeds. Fixed calibrated-probability cutoff 0.5 for CSI and detection.')
rows=agg.reset_index();rows=rows[rows.delay_minutes.isin([0,30])]
xs=[44,330,410,510,610,710,810];cols=['Model','Age (min)','MAE ↓','Brier ↓','CSI ↑','POD ↑','Raw Brier ↓']
rect(42,453,876,28,'#dfe8e3')
for x,lab in zip(xs,cols):txt(lab,x+5,462,9,INK,'Bold')
y=434
for idx,row in enumerate(rows.itertuples()):
 if idx%2==0:rect(42,y-6,876,25,WHITE)
 values=[LABELS[row.model],str(row.delay_minutes),f'{row.mae:.5f}',f'{row.brier:.5f}',f'{row.csi:.5f}',f'{row.pod:.5f}',f'{row.raw_brier:.5f}']
 for x,v in zip(xs,values):txt(v,x+5,y,9,INK,'Bold' if row.model=='trusted_age' else 'Sans')
 y-=25
para('<b>Paired differences at 30 minutes:</b> '+ '; '.join(f'{q["metric"].upper()} {q["delta"]} [95% CI {q["low"]}, {q["high"]}]' for q in cards)+'.',43,90,870,9,MUTED,13)
c.showPage()
# 12: implications, limits, and route to reproduction.
page(13);title('Interpretation and next steps','Keep the claim as narrow as the experiment.','An original exploratory comparison in this setup, not a first-ever method or discovery.')
left=[('What the result supports','Under these synthetic faults and training conditions, trusted-provenance replay improves mean-field error and overall probabilistic accuracy at 30-minute age. Detection quality at the fixed probability cutoff is worse.'),('What the result does not establish','No automatic outage detector, public-warning suitability, flood prediction, state-of-the-art result, or real-world reduction in harm. Trusted source age is oracle information when the feed hides its timestamps.'),('Uncertainty has boundaries','The same test events and seeds are paired; 2,000 UTC-day-block resamples cover 113 issue-date days. Intervals do not capture all training randomness or multiday meteorological dependence.')]
right=[('Sampling and calibration','Only 1,010 sampled scenes from a much larger archive. Calibration has 60 storm and 30 random-source scenes, versus 50:50 elsewhere. Source and seasonal shift can change calibrated behavior.'),('The decision-threshold pitfall','Calibrated persistence and advection have no predictions above 0.5. Their primary CSI is zero at that cutoff, not evidence of no deterministic skill. The raw-score diagnostic is secondary and does not retune the primary endpoint.'),('Reproduce and extend','Read README, METHODOLOGY, NOVELTY_AUDIT, and the source manifest. Use make reproduce for the experiment, make visuals for saved-summary presentation. Genuine outage logs, stronger motion baselines, and independent holdouts remain future work.')]
for x,items in [(43,left),(493,right)]:
 y=472
 for h,b in items:
  txt(h,x,y,13,TEAL,'Bold');y=para(b,x,y-13,422,10,MUTED,15)-26
rect(42,65,876,62,'#e5ebe7');para('<b>Evidence integrity.</b> Full-precision metrics and event statistics are authoritative. The original case image is preserved because the compact archive omits its prediction tensors. This visual revision does not rerun training or alter measured outputs.<br/><b>Portfolio use.</b> AI-assisted work: reproduce and understand the findings before presenting them.',57,116,845,9,INK,13)
c.showPage()
import importlib.util
spatial_path=ROOT/'studies/spatial-freshness/build_brief.py'
spec=importlib.util.spec_from_file_location('spatial_brief',spatial_path)
spatial=importlib.util.module_from_spec(spec);spec.loader.exec_module(spatial)
assert spatial.PAGE_COUNT==5
spatial.draw_pages(c,start_page=14,total_pages=18)
c.save();print(OUT/'StormSignal-research-brief.pdf')
