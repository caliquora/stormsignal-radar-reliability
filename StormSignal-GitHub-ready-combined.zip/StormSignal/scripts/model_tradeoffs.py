"""Descriptive Pareto audit of frozen summary metrics; not new model selection."""
from build_explorer import build_payload,ROOT
import csv

def dominates(a,b):
    av=(a['mae'],a['brier'],-a['csi']);bv=(b['mae'],b['brier'],-b['csi'])
    return all(x<=y for x,y in zip(av,bv)) and any(x<y for x,y in zip(av,bv))
def main():
    data=build_payload()['metrics'];out=[]
    for a in data:
        dominators=[b['model'] for b in data if a['delay_minutes']==b['delay_minutes'] and dominates(b,a)]
        out.append({**a,'pareto_efficient':not dominators,'dominated_by':';'.join(dominators)})
    with (ROOT/'reports/model_tradeoffs.csv').open('w') as f:
        w=csv.DictWriter(f,fieldnames=out[0].keys());w.writeheader();w.writerows(out)
    lines=['# No single score tells the whole story','',
    'Descriptive analysis of existing held-out summary results. This does not retrain models, choose deployment thresholds, or add independent evidence. A model is Pareto-efficient here when no other method has equal or lower MAE and Brier, and equal or higher CSI, with a strict improvement in at least one.',
    '', '## What the recorded means show','']
    for age in [0,5,15,30]:
        rs=[r for r in out if r['delay_minutes']==age]
        frontier=', '.join(r['model'] for r in rs if r['pareto_efficient'])
        lines.append(f'- **{age} minutes old:** nondominated methods: {frontier}.')
    lines+=['','## Why this matters','',
    'If a portfolio presents only its best-looking error metric, it can hide weaker detection at the fixed probability cutoff. This audit makes the competing objectives explicit and helps a reader choose what to investigate next rather than announcing a universal winner.',
    '', '## Limits','',
    '- This frontier is based on point estimates, not confidence-dominance tests. Small differences can be noisy.',
    '- CNN summaries average two seeds; baseline rows have one saved record. Seed means do not provide independent uncertainty estimates.',
    '- CSI uses the frozen calibrated 0.5 threshold. Baseline calibration produced no positive predictions for some methods; raw-score diagnostics are a separate analysis.',
    '- No stakeholder cost function, operational utility, flood forecast, or public-safety benefit has been validated.',
    '- This is an exploratory reading of an already inspected test cohort, not a newly preregistered endpoint.',
    '', 'Source: `reports/metrics.csv`; reproducible command: `python scripts/model_tradeoffs.py`. Full machine-readable comparison: `reports/model_tradeoffs.csv`.']
    (ROOT/'docs/MODEL_TRADEOFFS.md').write_text('\n'.join(lines)+'\n')
    print('\n'.join(lines[6:10]))
if __name__=='__main__':main()
