"""Check presentation structure and scientific-input hashes without PyTorch."""
from pathlib import Path
import hashlib,json,base64,xml.etree.ElementTree as ET
from html.parser import HTMLParser
root=Path(__file__).resolve().parents[1]
protected={}
for manifest in ['evidence_sha256.json','combined_evidence_sha256.json']:
 for name,expected in json.loads((root/'docs'/manifest).read_text()).items():
  assert hashlib.sha256((root/name).read_bytes()).hexdigest()==expected,f'Changed evidence: {name}'
  protected[name]=expected
class Check(HTMLParser):
 def __init__(self):super().__init__();self.ids=[];self.links=[];self.images=[];self.scripts=0;self.external=[]
 def handle_starttag(self,tag,attrs):
  a=dict(attrs)
  if 'id' in a:self.ids.append(a['id'])
  if tag=='a':self.links.append(a.get('href',''))
  if tag=='img':self.images.append(a)
  if tag=='script':self.scripts+=1
  if tag in ['img','script','iframe','source','link']:
   u=a.get('src',a.get('href',''))
   if u.startswith(('http:','https:','//')):self.external.append(u)
p=Check();p.feed((root/'reports/StormSignal_report.html').read_text())
assert len(p.images)==11 and p.scripts==0 and not p.external
assert len(p.ids)==len(set(p.ids)), 'Duplicate HTML ids'
svg=0
for img in p.images:
 assert img.get('alt') and float(img['width'])>0 and float(img['height'])>0
 head,data=img['src'].split(',',1);blob=base64.b64decode(data,validate=True)
 if 'svg' in head:ET.fromstring(blob);svg+=1
 else:assert blob[:8]==b'\x89PNG\r\n\x1a\n'
assert svg==10
for h in p.links:
 if h.startswith('#'):assert h[1:] in p.ids
assert len(list((root/'reports/figures').glob('*.svg')))==7
assert len(list((root/'studies/spatial-freshness/figures').glob('*.svg')))==3
print(f'PASS: {len(protected)} protected scientific files match the saved archives; 11 embedded images, 10 valid SVGs, dimensions, anchors, alt text, and offline no-script structure.')
print('This is a structural check, not browser rendering or a rerun of the scientific experiment.')
