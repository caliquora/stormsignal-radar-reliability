# StormSignal: When Radar Stops Updating

## New: explore the evidence

**[Open the interactive explorer](explorer/index.html)** · [How to use it](docs/EXPLORER.md) · [Model tradeoffs](docs/MODEL_TRADEOFFS.md)

A working, offline evidence explorer lets you change observation age, compare seven forecasting methods, and move simulated stale regions across a real radar case. All values are derived from the saved research outputs. Download the repository and open `explorer/index.html`, or serve the repository root locally; GitHub's normal file view shows source code rather than running HTML.

The new descriptive Pareto audit shows why a single headline score can mislead: at 30-minute staleness, three CNN approaches remain nondominated across field error, probability error and fixed-cutoff detection. This is an exploratory comparison of recorded point estimates, not a new model, proof of novelty, or validated operational benefit.

**Status:** source and evidence tests pass for this addition; full legacy tests require PyTorch. Browser visual QA and GitHub publication are not yet complete. See [validation details](docs/EXPLORER.md).


**A reproducible weather-ML study of silent radar replay, honest missing data, and the value of trustworthy provenance.**

If a radar feed stops updating, repeating its last image can look harmless to a downstream model. How much does that representation matter when the storm continues moving?

This project turns that question into a controlled, testable experiment on a large public weather archive. It includes real data ingestion, temporal leakage safeguards, classical forecasting, three compact spatial CNNs, probability calibration, uncertainty estimates, subgroup analysis, visualizations, and an explicit novelty audit.

> Research only. VIL is a radar proxy, not rainfall depth, flood probability, or an operational warning. A trusted-age channel is an oracle upper bound when a silently broken feed hides its true age. The experiment is original portfolio work; a universal first-ever novelty claim is not established.

## Why should I care?

A weather screen can refresh even when some observations behind it are old. If a scan is already 30 minutes old, a forecast 30 minutes ahead must bridge a 60-minute gap from that scan. For weather-app teams and data operators, observation age belongs alongside the forecast, rather than being hidden by repeated imagery.

The follow-on spatial study asks a sharper question: **can the same freshness badge hide different damage?** In a controlled audit of 200 real radar scenes, identical stale coverage and age counts omitted **20.6% versus 1.3%** of actual issue-time high-echo cells when placed near a pre-issue moving-front proxy rather than a quiet region. The paired difference was **19.3 percentage points**, with a 95% day-bootstrap interval of **17.8 to 21.2**.

That supports preserving a spatial age map and checking where stale information sits, not relying only on an average freshness number. It does not establish a safe warning threshold, an effective repair policy, or improved outcomes for people. The faults are synthetic, the cohort was already inspected, and the forecast-miss increase from the finer age-swap control was not established across both tested orientations. Different interval outcomes alone do not prove an orientation interaction. Academic first-ever novelty is not established.

- [Executed spatial freshness study](studies/spatial-freshness/README.md): methods, full results, controls, sensitivity results, and limitations.
- [Two-page plain-English spatial brief](studies/spatial-freshness/StormSignal-spatial-freshness-brief.pdf).

![The same freshness badge can hide different information loss](studies/spatial-freshness/figures/spatial_freshness_results.png)

## VANE weather application

[VANE × StormSignal](apps/vane/README-STORMSIGNAL.md) imports the existing weather app with explicit radar timestamp provenance, unknown/delayed source states, and cautious motion-estimation gates. It is a local integration candidate, not a newly validated forecasting system. See its separate licensing notice and verification limits.

## Start here

- [Portable research brief](output/pdf/StormSignal-research-brief.pdf): 18-page combined overview, including both executed studies.
- [Visual research report](reports/StormSignal_report.html): self-contained, responsive HTML with measured results, seven vector figure collections, and the preserved case-study image.
- [Methodology](docs/METHODOLOGY.md): exact task, causal inputs, fault matching, splits, metrics, and validity limits.
- [Novelty audit](docs/NOVELTY_AUDIT.md): prior art and the narrow claim that can be defended.
- [Data sources and permissions](docs/DATA_SOURCES.md).
- [Research roadmap](docs/RESEARCH_ROADMAP.md).
- [Machine-readable metrics](reports/metrics.csv), [paired day-block intervals](reports/paired_day_bootstrap.csv), and [training history](reports/training_history.csv).

## Research question

At a fixed issue time, predict the radar field **30 minutes ahead**, while the most recent genuine observation is 0, 5, 15, or 30 minutes old. The same original event, genuine observations, and future target are used for every fault representation:

1. **Replay blind:** frozen terminal frames are repeated, and provenance channels falsely indicate freshness.
2. **Explicit missingness:** unavailable terminal frames are zero-filled and identified by a mask.
3. **Trusted-provenance replay:** the same frozen arrays as arm 1, accompanied by truthful availability and per-slot staleness.

The missingness mask already reveals delay on this regular time grid. Comparing arms 2 and 3 tests representation and imputation, not additional information. Comparing arms 1 and 3 estimates the value of trusted metadata under this training protocol, not the ability to infer a hidden outage.

## Dataset and scale

- **SEVIR**, a public multimodal radar/satellite/lightning archive of approximately 1 TB. The retrieved catalog contains **20,393 VIL sequences**.
- Reproducible executed subset: **1,010 events**, each with **49 × 384 × 384** native VIL values, totaling **7,297,597,440 native pixel-time values** before pooling.
- These are correlated measurements, not 7.3 billion independent examples. The primary independent unit is the sampled event, with uncertainty clustered by UTC day.
- HTTP byte-range requests read selected contiguous event payloads. The project never synchronizes the entire archive.
- Display/training grid: 96 × 96. Mean-pool encoded VIL for regression; preserve a high-core target using **any native pixel ≥ 133** within each 4 × 4 block, rather than thresholding the block mean.
- Twelve history frames are used. Each CNN receives 12 means, 12 high-core indicators, 12 availability masks, and 12 age channels. The two historical radar channels are shared with the baselines.

Saved prediction/truth tensors use float16 for compactness. The full-precision metrics and event statistics are authoritative; recomputing classification metrics from rounded visualization arrays can move values near a threshold.

The exact counts, source-object locations, byte offsets, QC rules, sample selection, and source hashes are retained. Raw weather data are not committed to Git.

## Leakage-safe evaluation

| Partition | Period | Events | Purpose |
|---|---|---:|---|
| Train | 2017–2018 | 600 | Fit forecast models |
| Tune | Jan–Apr 2019 | 120 | CNN checkpoint selection |
| Calibration | May–Jun 2019 | 90 | Fit probability calibration |
| Test | Jul 8–Nov 30, 2019 | 200 | Final held-out evaluation |

The eligible test window extends through December, but the sampled observations end November 30. Seven-day embargoes around split boundaries exceed the four-hour sequence windows. Episodes appearing in multiple splits are excluded. Sampling uses one event per documented storm episode and one random event per available UTC date within each source/partition. Exact dates are in the manifest. Calibration contains 60 storm and 30 random-source scenes because fewer qualifying random dates were available; operational calibration is not implied.

No random frame split, overlapping train/test event windows, future-data normalization, or test-driven checkpoint selection is used.

## Models and analysis

- Training climatology.
- Persistence.
- Global phase-correlation advection, using genuine observed frames and the extended lead from their true source time.
- Causal per-pixel ridge regression and logistic regression, using lagged radar, local neighborhoods, trend, and age.
- Three equal-architecture compact CNNs with identical budgets and fixed seeds 17 and 29.
- Logistic probability calibration fitted only on calibration events; raw Brier scores are retained for comparison.
- MAE and RMSE of mean encoded VIL; Brier score; CSI, detection probability, and false-alarm ratio at a fixed 0.5 probability cutoff.
- Paired UTC-day-block bootstrap, seed-averaged event effects, source stratification, reliability diagrams, and descriptive retention by known data age.

The replay-blind CNN is trained with simulated replay faults. Exact repeated images can indirectly reveal their duration, so a weak benefit from explicit metadata would not show that provenance is irrelevant. A clean-trained CNN under surprise faults is a separate, unexecuted experiment.

The CNN is intentionally small enough for a CPU reproduction. The aim is a credible experiment, not a state-of-the-art leaderboard entry. No architecture novelty is claimed.

## Recorded result

At 30 minutes of simulated data staleness, trusted-provenance replay versus blind replay reduced MAE from **15.0246 to 14.7843 encoded VIL units** and Brier score from **0.03916 to 0.03827**. However, CSI at the fixed calibrated-probability cutoff fell from **0.08267 to 0.07207**. The 95% paired UTC-day-block intervals for all three differences exclude zero in this sample. This is a tradeoff, not a claim of safer warnings.

Fresh-input global advection had lower mean-field MAE than the CNNs; the trusted CNN had lower Brier score. There is no single winner across all tasks. Fitted calibration gave persistence/advection no probabilities above 0.5, so their primary CSI is zero at that cutoff. A separately labeled raw-score diagnostic shows their nonzero deterministic skill without changing the frozen primary endpoint or tuning on test data.

## Visual edition

The report and brief use a light editorial layout, consistent model colors and marker shapes, clearer legends, and explicit tradeoff cards. Seven figure collections are provided as editable SVG and high-resolution PNG. The original case-study raster is preserved because its prediction tensors are not included in this compact archive.

Rebuild the design from saved summaries without downloading weather data or retraining:

```bash
python -m pip install -e ".[report]"
make visuals
```

This presentation-only workflow does not reproduce the experiment. Recorded CSV/JSON/NPZ metrics, model checkpoints, data manifests, and experimental source code are unchanged. See [visual revision verification](docs/VISUAL_REVISION.md) and [open-source design notices](docs/DESIGN_LICENSES.md).

## Reproduce

Python 3.11 or newer and approximately 4 GB RAM are recommended. The subset reads about 7.3 GB of raw event payloads from the public archive, plus metadata; retries and request overhead can add network traffic. Derived events occupy much less local disk. Training time depends strongly on CPU and thread settings.

```bash
python -m venv .venv
source .venv/bin/activate
python -m pip install torch --index-url https://download.pytorch.org/whl/cpu
python -m pip install -e .
make data
make test
make train
make figures
```

`make reproduce` runs ingestion, tests, training, and HTML/figure reporting. To regenerate the optional PDF, install `python -m pip install -e ".[report]"` and run `make pdf`. Existing verified event files are reused. Do not commit raw data, large predictions, or credentials. See `requirements-executed.txt` for the versions used in the recorded run.

Quick smaller run, for workflow debugging only:

```bash
python -m weather_resilience.data --root . --counts 40 20 20 20
python -m weather_resilience.experiment --root . --epochs 2 --seeds 17
```

Use a separate checkout/output folder for a small run, since its manifest and reports replace the previous run. Its metrics must not be substituted for the recorded experiment.

## Repository layout

```text
src/weather_resilience/  Acquisition, protocol, models, training, report generation
configs/                Experiment configuration and provenance
notebooks/              Guided walkthrough linking to reproducible code
scripts/                Integrity and packaging utilities
tests/                  Unit and manifest-integrity tests
data/processed/         Committed manifests; downloaded event arrays ignored
models/                 Forecast checkpoints and interpretable coefficients
reports/                Verified metrics, histories, figures, and HTML report
docs/                   Methods, sources, novelty audit, and next research steps
```

## Public value and boundaries

This is a reliability study for research on resource-constrained storm situational awareness. It explores whether systems should represent incomplete weather observations more honestly rather than conceal them through carry-forward. It does not show fewer injuries, more accurate flood warnings, or suitability for emergency decisions.

The highest-value next steps are independent review of the novelty claim, a larger predeclared holdout, more realistic outage mechanisms, stronger motion/ensemble baselines, provenance validation, and eventually evaluation with a relevant operational partner.

## Publication status

This combined package is prepared for the dedicated public portfolio repository. The original forecasting experiment and the later spatial stress audit are kept separate so their cohorts, claims, and limitations remain clear. Consult GitHub Actions for remote CI status; recorded local verification is documented separately.

## Authorship and portfolio use

This project was prepared with AI-assisted research and implementation. A portfolio owner should be able to explain the design, reproduce the experiment, discuss the unsuccessful as well as successful findings, and demonstrate their own extensions. Do not present unverified novelty or substitute generated results for executed measurements.

## License

Original project code uses the included MIT license. SEVIR data have separate attribution and usage terms. No third-party model code was copied into the implementation.
