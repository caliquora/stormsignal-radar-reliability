import unittest
import numpy as np
from weather_resilience.protocol import corrupt,score_arrays,paired_bootstrap
from weather_resilience.models import motion,TinyNowcaster
import torch

class ProtocolTests(unittest.TestCase):
    def setUp(self):self.x=np.broadcast_to(np.arange(12,dtype=float)[:,None,None],(12,8,8))/12
    def test_matched_information_and_unchanged_input(self):
        original=self.x.copy()
        for delay in (0,1,3,6):
            last=11-delay
            blind=corrupt(self.x,delay,'replay_blind');trusted=corrupt(self.x,delay,'trusted_age');missing=corrupt(self.x,delay,'missing_aware')
            np.testing.assert_equal(blind[:12],trusted[:12])
            np.testing.assert_equal(blind[:last+1],missing[:last+1])
            if delay:
                self.assertTrue((missing[last+1:12]==0).all())
                self.assertTrue((trusted[12+last+1:24]==0).all())
                self.assertTrue((trusted[24+last+1:]>0).all())
                self.assertTrue((blind[12:24]==1).all())
        np.testing.assert_equal(self.x,original)
    def test_batch_equals_individual(self):
        x=np.stack([self.x,self.x+1]);b=corrupt(x,3,'trusted_age')
        np.testing.assert_equal(b[0],corrupt(x[0],3,'trusted_age'))
    def test_invalid_delay(self):
        with self.assertRaises(ValueError):corrupt(self.x,12,'trusted_age')
    def test_metrics_perfect(self):
        y=np.random.default_rng(1).uniform(size=(3,8,8));high=y>.7
        m=score_arrays(y,high,y,high.astype(float));self.assertEqual(m['mae'],0);self.assertEqual(m['csi'],1);self.assertEqual(m['brier'],0)
    def test_cnn_shape_and_gradients(self):
        torch.set_num_threads(1);m=TinyNowcaster();a,b=m(torch.zeros(2,48,96,96));self.assertEqual(tuple(a.shape),(2,96,96));(a.mean()+b.mean()).backward()
        self.assertTrue(all(p.grad is not None for p in m.parameters()))
    def test_motion_translation(self):
        x=np.zeros((32,32));x[8:15,10:14]=1;y=np.roll(np.roll(x,3,axis=0),-2,axis=1)
        np.testing.assert_equal(motion(x,y),[3,-2])
    def test_paired_bootstrap_null(self):
        a=np.ones((20,5));d=paired_bootstrap(a,a);self.assertEqual(d['low'],0);self.assertEqual(d['high'],0)

if __name__=='__main__':unittest.main()
