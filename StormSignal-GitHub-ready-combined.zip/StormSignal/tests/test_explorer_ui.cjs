// Dependency-free behavior test. This is not a substitute for visual browser QA.
const fs=require('fs'),path=require('path'),vm=require('vm'),assert=require('assert');
const html=fs.readFileSync(path.join(__dirname,'../explorer/index.html'),'utf8');
const evidence=html.match(/<script id="evidence" type="application\/json">([\s\S]*?)<\/script>/)[1];
const logic=html.match(/<\/script><script>([\s\S]*?)<\/script>/)[1];
class Element{constructor(){this.textContent='';this.value='';this.dataset={};this.children=[];this.attrs={};this.innerHTML=''}append(b){this.children.push(b)}setAttribute(k,v){this.attrs[k]=v}getContext(){const el=this;return{createImageData:(w,h)=>({data:new Uint8ClampedArray(w*h*4)}),putImageData:i=>el.pixels=Array.from(i.data)}}}
const els={};for(const id of ['evidence','ages','metric','gap','tradeoff','interval','rows','chart','legend','truth','mosaic','agemap','case','casefacts','placement'])els['#'+id]=new Element();
els['#evidence'].textContent=evidence;els['#metric'].value='mae';els['#placement'].value='front';
const document={querySelector:s=>els[s],querySelectorAll:s=>els['#ages'].children,createElement:()=>new Element()};
vm.runInNewContext(logic,{document,console});
for(const metric of ['mae','brier','csi']){els['#metric'].value=metric;els['#metric'].onchange();for(const button of els['#ages'].children){button.onclick();assert.equal(els['#gap'].textContent,`${Number(button.dataset.age)+30} minutes`);assert(!els['#interval'].textContent.includes('NaN'));assert.equal((els['#rows'].innerHTML.match(/<tr>/g)||[]).length,7);assert(els['#chart'].innerHTML.includes('<polyline'));}}
const previous=JSON.stringify(els['#mosaic'].pixels);const badge=els['#casefacts'].textContent;els['#placement'].value='quiet';els['#placement'].onchange();assert.notEqual(JSON.stringify(els['#mosaic'].pixels),previous);assert.equal(els['#casefacts'].textContent,badge);
els['#placement'].value='random';els['#placement'].onchange();assert.equal(els['#casefacts'].textContent,badge);
console.log('PASS: all 12 metric/age states; 7 model rows; 3 spatial placements; matching age badge; changing real case pixels. Layout not tested.');
