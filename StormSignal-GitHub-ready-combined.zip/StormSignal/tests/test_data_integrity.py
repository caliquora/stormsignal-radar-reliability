import unittest
from pathlib import Path
import numpy as np
import pandas as pd
from weather_resilience.protocol import corrupt
ROOT=Path(__file__).parents[1]

class DataIntegrityTests(unittest.TestCase):
    def test_high_history_matches_mean_faults(self):
        x=np.arange(12,dtype=np.float32)[:,None,None]*np.ones((12,3,3),dtype=np.float32)
        h=x%2
        for arm in ['replay_blind','missing_aware','trusted_age']:
            z=corrupt(x,3,arm,h);self.assertEqual(z.shape,(48,3,3))
            np.testing.assert_equal(z[12:21],h[:9])
            if arm=='missing_aware':self.assertTrue((z[21:24]==0).all())
            else:np.testing.assert_equal(z[21:24],np.broadcast_to(h[8],(3,3,3)))
    @unittest.skipUnless((ROOT/'data/processed/sample_manifest.csv').exists(),'download manifest unavailable')
    def test_manifest_no_cross_split_episodes(self):
        m=pd.read_csv(ROOT/'data/processed/sample_manifest.csv');self.assertFalse(m.id.duplicated().any())
        counts=m.dropna(subset=['episode_id']).groupby('episode_id').split.nunique();self.assertTrue((counts==1).all())
        bounds=[]
        for split in ['train','tune','calibration','test']:
            d=pd.to_datetime(m[m.split==split].time_utc);bounds.append((d.min(),d.max()))
        for prev,nxt in zip(bounds[:-1],bounds[1:]):self.assertGreater(nxt[0]-prev[1],pd.Timedelta(days=7))
    @unittest.skipUnless((ROOT/'data/processed/sample_manifest.csv').exists(),'download manifest unavailable')
    def test_time_axis_issue_target(self):
        m=pd.read_csv(ROOT/'data/processed/sample_manifest.csv')
        for r in m.itertuples():
            off=np.array(str(r.minute_offsets).split(':'),dtype=int);self.assertEqual(len(off),49);self.assertTrue((np.diff(off)==5).all())
            self.assertEqual(pd.Timestamp(r.target_time_utc)-pd.Timestamp(r.issue_time_utc),pd.Timedelta(minutes=30))
    def test_threshold_before_pooling(self):
        raw=np.zeros((4,4),dtype=np.uint8);raw[0,0]=134
        self.assertTrue(raw.max()>=133);self.assertFalse(raw.mean()>=133)

if __name__=='__main__':unittest.main()
