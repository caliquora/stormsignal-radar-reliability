import importlib.util,json,unittest
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
spec=importlib.util.spec_from_file_location('explorer',ROOT/'scripts/build_explorer.py');module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
class ExplorerTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):cls.d=module.build_payload()
    def test_complete_grid(self):
        self.assertEqual(len(self.d['metrics']),28)
        for age in [0,5,15,30]:self.assertEqual(sum(r['delay_minutes']==age for r in self.d['metrics']),7)
    def test_recorded_tradeoff(self):
        r={x['model']:x for x in self.d['metrics'] if x['delay_minutes']==30}
        self.assertAlmostEqual(r['replay_blind']['mae'],15.0246,places=4)
        for m in ['mae','brier','csi']:self.assertLess(r['trusted_age'][m],r['replay_blind'][m])
    def test_matched_age_histogram(self):
        e=self.d['example'];flatten=lambda a: sorted(v for row in a for v in row)
        self.assertEqual(flatten(e['age_front']),flatten(e['age_quiet']))
        self.assertEqual(flatten(e['age_front']),flatten(e['age_random']))
    def test_no_nan_and_reproducible_payload(self):
        json.dumps(self.d,allow_nan=False)
        self.assertEqual(self.d,json.loads((ROOT/'explorer/evidence.json').read_text()))
    def test_embedded_evidence_matches(self):
        html=(ROOT/'explorer/index.html').read_text();embedded=html.split('<script id="evidence" type="application/json">')[1].split('</script>')[0]
        self.assertEqual(json.loads(embedded),self.d)
    def test_pareto_report_preserves_all_rows(self):
        import csv
        rows=list(csv.DictReader((ROOT/'reports/model_tradeoffs.csv').read_text().splitlines()))
        self.assertEqual(len(rows),28)
        selected={r['model'] for r in rows if float(r['delay_minutes'])==30 and r['pareto_efficient']=='True'}
        self.assertEqual(selected,{'missing_aware','replay_blind','trusted_age'})
    def test_intervals(self):
        self.assertEqual(len(self.d['intervals']),12)
        for r in self.d['intervals']:self.assertLess(r['low'],r['high'])
if __name__=='__main__':unittest.main()
