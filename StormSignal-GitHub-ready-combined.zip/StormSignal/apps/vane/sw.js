/* Vane service worker.
 *
 * F8: chasers work at the edge of cellular coverage. The app shell is cached so
 * Vane opens instantly and still runs when the network is gone; the last
 * successful API response is cached separately so there is always something to
 * show, clearly labelled stale by the UI.
 *
 * Deliberately NOT cached: radar tiles. They are large, numerous and worthless
 * once stale — caching them would blow the quota to show the user old rain. */

var VERSION = 'vane-stormsignal-v5';
var SHELL = VERSION + '-shell';
var DATA = VERSION + '-data';

var SHELL_FILES = [
  './',
  './index.html',
  './css/style.css',
  './js/install.js',
  './js/update.js',
  './js/live.js',
  './js/stormsignal.js',
  './js/agents.js',
  './js/local-ai.js',
  './js/warning-evidence.js',
  './js/config.js',
  './js/util.js',
  './js/notifylearn.js',
  './js/settings.js',
  './js/api.js',
  './js/derive.js',
  './js/astro.js',
  './js/spc.js',
  './js/cells.js',
  './js/reflectivity.js',
  './js/motion.js',
  './js/motionskill.js',
  './js/shot.js',
  './js/storm3d.js',
  './js/sites.js',
  './js/glossary.js',
  './js/brief.js',
  './js/icons.js',
  './js/theme.js',
  './js/models.js',
  './js/verify.js',
  './js/raincal.js',
  './js/insight.js',
  './js/modelcast.js',
  './js/usstates.js',
  './js/modelchart.js',
  './js/outlook.js',
  './js/outlookchart.js',
  './js/meteogram.js',
  './js/layers.js',
  './js/radar.js',
  './js/ui-core.js',
  './js/lazy.js',
  './js/ui-now.js',
  './js/ui-ai.js',
  './js/stormmodel.js',
  './js/stormmodel-weights.js',
  './js/chaseday.js',
  './js/chaseday-weights.js', './js/popgrid.js', './data/popgrid.png', './js/stormodds.js', './js/stormodds-weights.js',
  './js/ui-chase.js',
  './js/ui-outlook.js',
  './js/ui-chrome.js',
  './js/intelligence.js',
  './js/intelligence-ui.js',
  './js/app.js',
  './manifest.webmanifest',
  './icons/icon.svg',
  './icons/icon-192.png',
  './icons/icon-512.png',
  './icons/maskable-192.png',
  './icons/maskable-512.png',
  './icons/apple-touch-icon.png',
  './icons/favicon-32.png',
  './icons/launch/iphone-15-pro-portrait.png',
  './icons/launch/iphone-14-portrait.png',
  './vendor/leaflet/leaflet.js',
  './vendor/leaflet/leaflet.css'
];

// Hosts whose JSON is worth keeping a last-known-good copy of.
var DATA_HOSTS = [
  'api.open-meteo.com',
  'air-quality-api.open-meteo.com',
  'geocoding-api.open-meteo.com',
  'api.weather.gov',
  'www.spc.noaa.gov'
];

self.addEventListener('install', function (e) {
  e.waitUntil(
    caches.open(SHELL)
      // addAll fails atomically; cache what we can so one bad entry (a CDN
      // hiccup on Leaflet, say) doesn't leave the app with no shell at all.
      .then(function (c) {
        return Promise.all(SHELL_FILES.map(function (f) {
          // A new worker must fetch new bytes. The HTTP cache may still hold
          // the previous release's unversioned CSS/JS for up to an hour.
          return c.add(new Request(f, { cache: 'reload' })).catch(function () { return null; });
        }));
      })
      .then(function () { return self.skipWaiting(); })
  );
});

self.addEventListener('activate', function (e) {
  e.waitUntil(
    caches.keys().then(function (keys) {
      return Promise.all(keys.map(function (k) {
        // vane-watch is state, not shell: it must survive version upgrades
        // or the background check forgets where the user is.
        if (k === 'vane-watch') return null;
        return k.indexOf(VERSION) === 0 ? null : caches.delete(k);
      }));
    }).then(function () { return self.clients.claim(); })
  );
});

/* ── Background alert check ─────────────────────────────────────────
 * No push server exists (Vane has no server at all), but installed on
 * Android or desktop Chrome the browser grants periodic background sync:
 * a few chances a day to re-fetch the alerts for the saved location and
 * notify on anything new at or above the user's severity floor. The page
 * mirrors location, floor and already-seen ids into the vane-watch cache
 * (see Settings.syncWatch); everything here reads from that. */

var WATCH_RANK = { Extreme: 4, Severe: 3, Moderate: 2, Minor: 1, Unknown: 0 };

/* The page's alert families, mirrored into the watch blob. */
function watchFamily(blob, a) {
  var text = (a.event || '') + ' ' + (a.headline || '');
  var fams = blob.families || [];
  for (var i = 0; i < fams.length; i++) {
    if (fams[i].src && new RegExp(fams[i].src, 'i').test(text)) return fams[i].key;
  }
  return 'other';
}

function watchCheck() {
  return caches.open('vane-watch').then(function (c) {
    return c.match('/watch-state').then(function (hit) {
      if (!hit) return null;
      return hit.json().then(function (blob) {
        if (!blob || !blob.notify || !blob.lat) return null;
        var url = 'https://api.weather.gov/alerts/active?status=actual&point=' +
          blob.lat.toFixed(4) + ',' + blob.lon.toFixed(4);
        return fetch(url, { headers: { Accept: 'application/geo+json' } })
          .then(function (res) { return res.json(); })
          .then(function (j) {
            var seen = {};
            (blob.seen || []).forEach(function (id) { seen[id] = true; });
            var fresh = (j.features || []).map(function (f) {
              var p = f.properties || {};
              return { id: f.id || p.id, event: p.event, headline: p.headline,
                       severity: p.severity };
            }).filter(function (a) {
              var rank = WATCH_RANK[a.severity] || 0;
              a.family = watchFamily(blob, a);
              return a.id && !seen[a.id] && rank >= (blob.floor || 3) &&
                ((blob.mute || []).indexOf(a.family) === -1 || rank >= 4);
            });
            var shows = fresh.map(function (a) {
              blob.seen = (blob.seen || []).concat([a.id]).slice(-400);
              return self.registration.showNotification(a.event, {
                body: ((a.headline || '') + ' — ' + (blob.name || 'your location')).slice(0, 180),
                tag: a.id,
                data: { kind: 'alert:' + a.family }
              });
            });
            return Promise.all(shows).then(function () {
              return c.put('/watch-state', new Response(JSON.stringify(blob), {
                headers: { 'Content-Type': 'application/json' }
              }));
            });
          });
      });
    });
  }).catch(function () { /* offline or malformed state: try again next period */ });
}

self.addEventListener('periodicsync', function (e) {
  if (e.tag === 'vane-watch') e.waitUntil(watchCheck());
});

// Tapping a notification opens (or focuses) the app.
/* What happened to a notification, for js/notifylearn.js: the worker has
 * no localStorage, so it appends to a log in the watch cache that the page
 * drains on its next open. Kind comes from the notification's data. */
function logNotify(n, action) {
  var kind = n.data && n.data.kind;
  if (!kind) return Promise.resolve();
  return caches.open('vane-watch').then(function (c) {
    return c.match('./notify-log').then(function (r) { return r ? r.json() : []; })
      .then(function (list) {
        list.push({ kind: kind, action: action, t: Date.now() });
        return c.put('./notify-log', new Response(JSON.stringify(list.slice(-200)),
          { headers: { 'Content-Type': 'application/json' } }));
      });
  }).catch(function () { /* learning is best-effort */ });
}

self.addEventListener('notificationclose', function (e) {
  e.waitUntil(logNotify(e.notification, 'dismiss'));
});

self.addEventListener('notificationclick', function (e) {
  e.notification.close();
  e.waitUntil(logNotify(e.notification, 'open'));
  e.waitUntil(clients.matchAll({ type: 'window' }).then(function (list) {
    for (var i = 0; i < list.length; i++) {
      if ('focus' in list[i]) return list[i].focus();
    }
    return clients.openWindow('./');
  }));
});

/* Cache a data response, stamped with the time it was fetched.
 * The stamp is added by rebuilding the Response, which also turns a CORS
 * response into a basic one so the page can actually read the header back. */
function stash(req, res) {
  return res.blob().then(function (body) {
    var headers = new Headers();
    headers.set('Content-Type', res.headers.get('Content-Type') || 'application/json');
    headers.set('X-Vane-Cached-At', String(Date.now()));
    return caches.open(DATA).then(function (c) {
      return c.put(req, new Response(body, { status: 200, headers: headers }));
    });
  }).catch(function () { /* opaque or unreadable body — skip caching */ });
}

/* The page asks which version controls it — the update flow's only proof
 * that a rollout actually landed. Answered over the provided port rather than
 * broadcast, so the reply cannot reach a client that didn't ask. */
self.addEventListener('message', function (e) {
  if (e.data === 'GET_VERSION' && e.ports && e.ports[0]) e.ports[0].postMessage(VERSION);
});

self.addEventListener('fetch', function (e) {
  var req = e.request;
  if (req.method !== 'GET') return;

  var url;
  try { url = new URL(req.url); } catch (err) { return; }

  // Radar, base-map and model-field tiles: straight to network, never cached.
  if (/tilecache\.rainviewer\.com|arcgisonline\.com|basemaps\.cartocdn\.com|tile\.openstreetmap\.org|thredds\.ucar\.edu/.test(url.host)) {
    return;
  }

  // Weather data: network first, fall back to the last good response.
  if (DATA_HOSTS.indexOf(url.host) !== -1) {
    e.respondWith(
      fetch(req).then(function (res) {
        if (res && res.ok) stash(req, res.clone());
        return res;
      }).catch(function () {
        return caches.match(req).then(function (hit) {
          // A cache hit must never masquerade as live data — the page reads
          // X-Vane-Cached-At and shows a staleness banner.
          return hit || new Response(JSON.stringify({ error: 'offline' }), {
            status: 503, headers: { 'Content-Type': 'application/json' }
          });
        });
      })
    );
    return;
  }

  // App shell and CDN assets: cache first, refresh in the background.
  e.respondWith(
    caches.match(req).then(function (hit) {
      var network = fetch(req).then(function (res) {
        if (res && res.ok && url.origin === self.location.origin) {
          var copy = res.clone();
          caches.open(SHELL).then(function (c) { c.put(req, copy); });
        }
        return res;
      }).catch(function () { return hit; });
      return hit || network;
    })
  );
});

