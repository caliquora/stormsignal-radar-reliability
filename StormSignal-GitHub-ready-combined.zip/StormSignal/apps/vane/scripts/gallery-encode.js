/* Step 1 of the gallery build: re-encode docs/screens/*.png as JPEG data URIs.
 *
 *   node scripts/gallery-encode.js      # writes scripts/gallery.json (~4.6 MB)
 *
 * The gallery has to be a single self-contained file, so every image is
 * inlined; at PNG sizes that would be ~18 MB of base64. Chromium's canvas does
 * the re-encoding because this box has no image tooling. Phone captures are
 * scaled by width alone — they are tall enough that capping their height would
 * shrink them to an illegible sliver. */
const { chromium } = require('playwright');
const fs = require('fs'), path = require('path');
const SRC = path.join(__dirname, '..', 'docs', 'screens');
const OUT = path.join(__dirname, 'gallery.json');

(async () => {
  const b = await chromium.launch({ executablePath: process.env.CHROMIUM_PATH || '/opt/pw-browsers/chromium' });
  const p = await (await b.newContext()).newPage();
  await p.goto('about:blank');

  const files = fs.readdirSync(SRC).filter(f => f.endsWith('.png')).sort();
  const out = {};
  let total = 0;
  for (const f of files) {
    const b64 = fs.readFileSync(path.join(SRC, f)).toString('base64');
    const r = await p.evaluate(async ({ b64, name }) => {
      const img = new Image();
      img.src = 'data:image/png;base64,' + b64;
      await img.decode();
      let w = img.naturalWidth, h = img.naturalHeight;
      // Phone captures are extremely tall; capping their height would shrink
      // them to an illegible sliver, so those are scaled by width alone.
      // Decided on source width, not aspect: a desktop full-page capture is
      // also very tall and must keep its full width.
      const phone = img.naturalWidth <= 800;
      const maxW = phone ? 440 : 1180, maxH = phone ? Infinity : 7600;
      const s = Math.min(1, maxW / w, maxH / h);
      w = Math.round(w * s); h = Math.round(h * s);
      const c = document.createElement('canvas');
      c.width = w; c.height = h;
      const ctx = c.getContext('2d');
      ctx.drawImage(img, 0, 0, w, h);
      return { uri: c.toDataURL('image/jpeg', 0.74), w, h, name };
    }, { b64, name: f });
    out[f] = r;
    total += r.uri.length;
    console.log(f, r.w + 'x' + r.h, Math.round(r.uri.length / 1024) + 'KB');
  }
  fs.writeFileSync(OUT, JSON.stringify(out));
  console.log('\ntotal', (total / 1024 / 1024).toFixed(2), 'MB of data URI');
  await b.close();
})();
