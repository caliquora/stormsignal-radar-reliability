/* iOS launch screens.
 *
 * An installed web app on iOS shows a blank white rectangle while it boots
 * unless you supply an `apple-touch-startup-image` matching that exact device,
 * which is the single most native-feeling thing a PWA can fix. Apple matches
 * them by media query on point size and pixel ratio, so there is no "one big
 * image" option — each device needs its own file.
 *
 *   node scripts/make-launch.js     # writes icons/launch/*.png and prints the tags
 *
 * Rendered by Chromium since this box has no image tooling. Portrait and
 * landscape both, because a dash-mounted phone is usually sideways.
 */
const { chromium } = require('playwright');
const fs = require('fs'), path = require('path');

const OUT = path.join(__dirname, '..', 'icons', 'launch');
fs.mkdirSync(OUT, { recursive: true });

// [label, CSS points wide, CSS points tall, device pixel ratio]
const DEVICES = [
  ['iphone-16-pro-max',   440, 956, 3],
  ['iphone-16-pro',       402, 874, 3],
  ['iphone-15-pro-max',   430, 932, 3],
  ['iphone-15-pro',       393, 852, 3],
  ['iphone-14-plus',      428, 926, 3],
  ['iphone-14',           390, 844, 3],
  ['iphone-13-mini',      375, 812, 3],
  ['iphone-11-pro-max',   414, 896, 3],
  ['iphone-11',           414, 896, 2],
  ['iphone-8-plus',       414, 736, 3],
  ['iphone-8',            375, 667, 2],
  ['ipad-pro-129',       1024, 1366, 2],
  ['ipad-pro-11',         834, 1194, 2],
  ['ipad-air',            820, 1180, 2],
  ['ipad-mini',           744, 1133, 2],
];

/* The launch image must match what the app paints one frame later, or the
 * transition flashes. Same sky gradient; the mark is icons/mark.svg inlined,
 * so a logo change here is a regeneration, not a redraw. */
const MARK = fs.readFileSync(path.join(__dirname, '..', 'icons', 'mark.svg'), 'utf8');

function html(w, h) {
  const short = Math.min(w, h);
  const size = Math.round(short * 0.24);
  return `<!doctype html><html><body style="margin:0">
<div style="width:${w}px;height:${h}px;display:grid;place-items:center;
  background:linear-gradient(180deg,#1d3b5c 0%,#2f5c86 55%,#4a7fae 100%)">
  <div style="display:grid;justify-items:center;gap:${Math.round(short * 0.04)}px">
    ${MARK.replace('<svg ', `<svg width="${size}" height="${size}" `)}
    <div style="font:600 ${Math.round(short * 0.062)}px/1 -apple-system,system-ui,sans-serif;
      color:#fff;letter-spacing:.06em">Vane</div>
  </div>
</div></body></html>`;
}

(async () => {
  const b = await chromium.launch({ executablePath: process.env.CHROMIUM_PATH || '/opt/pw-browsers/chromium' });
  const tags = [];

  for (const [name, w, h, dpr] of DEVICES) {
    for (const orient of ['portrait', 'landscape']) {
      const [pw, ph] = orient === 'portrait' ? [w, h] : [h, w];
      const ctx = await b.newContext({ viewport: { width: pw, height: ph }, deviceScaleFactor: dpr });
      const p = await ctx.newPage();
      await p.setContent(html(pw, ph));
      const file = `${name}-${orient}.png`;
      await p.screenshot({ path: path.join(OUT, file) });
      await ctx.close();
      tags.push(
        `<link rel="apple-touch-startup-image" href="icons/launch/${file}"\n` +
        `      media="(device-width: ${w}px) and (device-height: ${h}px) and ` +
        `(-webkit-device-pixel-ratio: ${dpr}) and (orientation: ${orient})">`);
    }
  }

  fs.writeFileSync(path.join(OUT, 'tags.html'), tags.join('\n') + '\n');
  console.log(`${DEVICES.length * 2} launch images written to icons/launch/`);
  console.log('link tags in icons/launch/tags.html');
  await b.close();
})();
