/* Shared fixture routing for the offline Playwright passes.
 *
 * Both scripts/screenshots.js and scripts/ux-audit.js drive the real app
 * against captured real payloads and tiles, so every run is deterministic and
 * works with no network. Keeping the route table in one place means an audit
 * measures exactly the screens the screenshots show.
 *
 * Set VANE_TILES to point at a different captured tile cache. */
const fs = require('fs'), path = require('path');

const FIX = path.join(__dirname, '..', 'test', 'fixtures');
/* Real captured map and radar tiles keep the pass deterministic and offline.
 * They are ~3.5 MB and git-ignored: they are a cache, not source, and they can
 * be refetched. A missing cache degrades to blank tiles rather than failing, so
 * a run reports what it could not find instead of quietly producing output
 * taken from an empty map. */
const TILES = process.env.VANE_TILES || path.join(__dirname, 'tiles');
const fx = n => fs.readFileSync(path.join(FIX, n), 'utf8');
const json = b => ({ status: 200, contentType: 'application/json', body: b });
const BLANK = Buffer.from('iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAAC0lEQVR42mNkYAAAAAYAAjCB0C8AAAAASUVORK5CYII=', 'base64');

const MCHART_ROWS = JSON.parse(fx('mchart-grid.json'));
const missing = new Set();
function tile(p) {
  try { return fs.readFileSync(path.join(TILES, p)); }
  catch (e) { missing.add(p); return BLANK; }
}
/* The captured sounding covers a fixed 24-hour window, and Chase mode steps
 * forward from whichever hour contains "now". Once wall-clock time drifts
 * within two hours of the end of that window, stepping clamps and the hour-
 * stepping assertions fail on the calendar rather than on a code change.
 *
 * Re-stamped the same way the station list and the 15-minute series already
 * are: the values stay exactly as captured and only the labels move, written
 * as location wall-clock the way Open-Meteo writes them. "Now" is placed two
 * hours into the array so stepping has room in both directions. */
const REPLAY_ENSEMBLE_DAILY = () => {
  // Daily granularity, same aging fix: day zero moves to today, values stay.
  const j = JSON.parse(fx('ensemble-daily.json'));
  const DAY = 86400000;
  const off = (j.utc_offset_seconds || 0) * 1000;
  const start = Math.floor((Date.now() + off) / DAY) * DAY;
  const pad = n => String(n).padStart(2, '0');
  j.daily.time = j.daily.time.map((_, i) => {
    const d = new Date(start + i * DAY);
    return `${d.getUTCFullYear()}-${pad(d.getUTCMonth() + 1)}-${pad(d.getUTCDate())}`;
  });
  return JSON.stringify(j);
};

const REPLAY_ENSEMBLE = () => {
  /* Same aging problem as the sounding: the agreement card reads the next
   * 24 hours from "now", and a captured window drifts out from under it.
   * Values stay exactly as captured; only the labels move. */
  const j = JSON.parse(fx('ensemble.json'));
  const HOUR = 3600 * 1000;
  const off = (j.utc_offset_seconds || 0) * 1000;
  const start = Math.floor((Date.now() + off) / HOUR) * HOUR - 2 * HOUR;
  const pad = n => String(n).padStart(2, '0');
  j.hourly.time = j.hourly.time.map((_, i) => {
    const d = new Date(start + i * HOUR);
    return `${d.getUTCFullYear()}-${pad(d.getUTCMonth() + 1)}-${pad(d.getUTCDate())}` +
      `T${pad(d.getUTCHours())}:${pad(d.getUTCMinutes())}`;
  });
  return JSON.stringify(j);
};

const REPLAY_SOUNDING = () => {
  const j = JSON.parse(fx('sounding.json'));
  const HOUR = 3600 * 1000;
  const off = (j.utc_offset_seconds || 0) * 1000;
  const start = Math.floor((Date.now() + off) / HOUR) * HOUR - 2 * HOUR;
  const pad = n => String(n).padStart(2, '0');
  j.hourly.time = j.hourly.time.map((_, i) => {
    const d = new Date(start + i * HOUR);
    return `${d.getUTCFullYear()}-${pad(d.getUTCMonth() + 1)}-${pad(d.getUTCDate())}` +
      `T${pad(d.getUTCHours())}:${pad(d.getUTCMinutes())}`;
  });
  return JSON.stringify(j);
};

async function routes(page) {
  await page.route('**://api.open-meteo.com/**', r => {
    const u = r.request().url();
    // Per-model DAILY runs (the model viewer) vs per-model HOURLY (agreement).
    if (u.includes('daily=') && u.includes('models=')) return r.fulfill(json(fx('model-daily.json')));
    // The model chart's CONUS lattice: row-band chunks by first latitude.
    if (u.includes('hourly=precipitation%2Cpressure_msl')) {
      const lm = /latitude=([\d.]+)/.exec(u);
      const row = Math.round(((lm ? parseFloat(lm[1]) : 22) - 22) / (30 / 35));
      return r.fulfill(json(JSON.stringify(MCHART_ROWS.slice(row * 80, (row + 4) * 80))));
    }
    if (u.includes('models=')) return r.fulfill(json(REPLAY_ENSEMBLE()));
    // Grid before sounding: the grid asks for CAPE too now.
    if (/latitude=[-\d.]+(%2C|,)/.test(u)) return r.fulfill(json(gridWithCape(fx('grid.json'))));
    if (u.includes('cape')) return r.fulfill(json(REPLAY_SOUNDING()));
    return r.fulfill(json(FORECAST));
  });
  await page.route('**://ensemble-api.open-meteo.com/**', r => r.fulfill(json(REPLAY_ENSEMBLE_DAILY())));
  await page.route('**://archive-api.open-meteo.com/**', r => r.fulfill(json(fx('normals.json'))));
  await page.route('**://air-quality-api.open-meteo.com/**', r => r.fulfill(json(fx('air.json'))));
  await page.route('**://geocoding-api.open-meteo.com/**', r => r.fulfill(json(fx('geocode.json'))));
  await page.route('**://api.weather.gov/radar/stations**', r => r.fulfill(json(STATIONS)));
  await page.route('**://api.weather.gov/alerts/**', r => r.fulfill(json(fx('alerts.json'))));
  await page.route('**://api.weather.gov/points/**', r => r.fulfill(json(JSON.stringify({
    properties: { cwa: 'OUN',
      observationStations: 'https://api.weather.gov/gridpoints/OUN/1,1/stations' } }))));
  await page.route('**://api.weather.gov/products/types/**', r => r.fulfill(json(fx('afd-list.json'))));
  await page.route('**://api.weather.gov/products/*', r => r.fulfill(json(fx('afd.json'))));
  await page.route('**://api.weather.gov/gridpoints/**', r => r.fulfill(json(JSON.stringify({
    features: [{ properties: { stationIdentifier: 'KOUN', name: 'Norman' } }] }))));
  await page.route('**://api.weather.gov/stations/**', r => r.fulfill(json(JSON.stringify({
    properties: {
      timestamp: new Date(Date.now() - 11 * 60000).toISOString(),
      temperature: { value: 29.4 }, dewpoint: { value: 19.0 },
      windSpeed: { value: 25.2 }, windDirection: { value: 190 },
      windGust: { value: 47.0 }, visibility: { value: 16090 },
      textDescription: 'Mostly Clear', rawMessage: 'KOUN 131253Z 19014G26KT 10SM FEW045 29/19'
    } }))));
  await page.route('**nexrad_attr**', r => r.fulfill(json(fx('cells.json'))));
  await page.route('**://www.spc.noaa.gov/products/**', r => r.fulfill(json(fx('spc.json'))));
  await page.route('**://www.spc.noaa.gov/climo/**', r =>
    r.fulfill({ status: 200, contentType: 'text/csv', body: fx('reports.csv') }));
  // NWS local storm reports: a real busy day, re-stamped to end ten minutes ago.
  await page.route('**mesonet.agron.iastate.edu/geojson/lsr.geojson**', r => {
    const g = JSON.parse(fx('lsr.geojson'));
    const newest = Math.max(...g.features.map(f => Date.parse(f.properties.valid)));
    const shift = Date.now() - 10 * 60000 - newest;
    g.features.forEach(f => { f.properties.valid = new Date(Date.parse(f.properties.valid) + shift).toISOString(); });
    r.fulfill(json(JSON.stringify(g)));
  });
  await page.route('**/cgi-bin/wms/hrrr/refd.cgi**', r =>
    r.fulfill({ status: 200, contentType: 'image/png',
                body: fs.readFileSync(path.join(FIX, 'hrrr-refd.png')) }));
  await page.route('**/data/gis/images/4326/hrrr/refd_0000.json**', r => r.fulfill(json(JSON.stringify({
    model_init_utc: new Date(Math.floor(Date.now() / 3600000) * 3600000).toISOString().slice(0, 19) + 'Z',
    forecast_minute: 0, model_forecast_utc: ''
  }))));
  await page.route('**://api.rainviewer.com/**', r => r.fulfill(json(fx('radar.json'))));
  await page.route('**tilecache.rainviewer.com/**', r =>
    r.fulfill({ status: 200, contentType: 'image/png', body: BLANK }));

  /* The 3D view reads real pixels out of these tiles, so a single-site N0Q
   * request must get a genuine one — otherwise the screenshots show the
   * fallback silhouette rather than the feature. */
  const bigN0Q = (() => {
    try {
      const f = fs.readdirSync(TILES).filter(n => /^ridge-\w+-N0Q-9-/.test(n))
        .map(n => ({ n, size: fs.statSync(path.join(TILES, n)).size }))
        .sort((a, b) => b.size - a.size)[0];
      return f && f.size > 2000 ? fs.readFileSync(path.join(TILES, f.n)) : null;
    } catch (e) { return null; }
  })();

  // Real captured tiles: national mosaic, and KDMX single-site reflectivity/velocity.
  await page.route('**mesonet.agron.iastate.edu/cache/**', r => {
    const u = r.request().url();
    const m = /\/(\d+)\/(\d+)\/(\d+)\.png/.exec(u);
    if (!m) return r.fulfill({ status: 200, contentType: 'image/png', body: BLANK });
    const [_, z, x, y] = m;
    const ridge = /ridge::(\w+)-(\w+)-/.exec(u);
    const p = ridge
      ? `ridge-${ridge[1]}-${ridge[2]}-${z}-${x}-${y}.png`
      : `nexrad-${z}-${x}-${y}.png`;
    var body = tile(p);
    // Zoom 9 single-site reflectivity is what the 3D sampler asks for.
    if (bigN0Q && /ridge::\w+-N0Q-/.test(u) && z === '9' && body === BLANK) body = bigN0Q;
    r.fulfill({ status: 200, contentType: 'image/png', body: body,
                headers: { 'Access-Control-Allow-Origin': '*' } });
  });
  /* Radar freshness probes (js/live.js). Static here: the screenshot pass
   * needs them answered so no console errors fire; only the browser suite
   * needs to flip them mid-run. Registered before the basemap route and
   * after the station-list route — Playwright checks the most recently
   * registered route first, so these win over the broader stations glob. */
  await page.route('**mesonet.agron.iastate.edu/json/tms.json**', r => r.fulfill(json(JSON.stringify({
    services: [{ id: 'ridge_uscomp_n0q', utc_valid: new Date(Date.now() - 3 * 60000).toISOString() }]
  }))));
  await page.route('**://api.weather.gov/radar/stations/K**', r => r.fulfill(json(JSON.stringify({
    properties: { latency: { levelTwoLastReceivedTime: new Date(Date.now() - 2 * 60000).toISOString() } }
  }))));

  await page.route('**arcgisonline.com/**', r => {
    // Esri addresses tiles /tile/{z}/{y}/{x}; the cache keeps the old
    // {kind}-{z}-{x}-{y}.png naming, so x and y swap on the way in. The
    // light-theme canvas caches under an l prefix.
    const u = r.request().url();
    const m = /\/tile\/(\d+)\/(\d+)\/(\d+)(?:$|\?)/.exec(u);
    const light = u.includes('Light_Gray') ? 'l' : '';
    const kind = light + (u.includes('Reference') ? 'labels' : 'base');
    r.fulfill({ status: 200, contentType: 'image/png',
      body: m ? tile(`${kind}-${m[1]}-${m[3]}-${m[2]}.png`) : BLANK });
  });
}

/* The captured station list goes stale after 20 minutes, at which point every
 * radar reads as offline. Shift the whole file forward by one constant so the
 * newest reading lands on now, preserving relative staleness exactly. */
const STATIONS = (() => {
  const j = JSON.parse(fx('stations.json'));
  const t = j.features.map(f => Date.parse((f.properties.latency || {}).levelTwoLastReceivedTime || ''))
    .filter(v => !isNaN(v));
  const d = Date.now() - Math.max.apply(null, t);
  j.features.forEach(f => {
    const l = f.properties.latency || {};
    const v = Date.parse(l.levelTwoLastReceivedTime || '');
    if (!isNaN(v)) l.levelTwoLastReceivedTime = new Date(v + d).toISOString();
  });
  return JSON.stringify(j);
})();

/* Re-stamp the 15-minute series onto the current quarter hour, written as
 * location wall-clock the way Open-Meteo writes it. A payload captured hours
 * ago otherwise has no bar covering now, and the nowcast correctly but
 * unhelpfully reports it has nothing to say. */
const FORECAST = (() => {
  const j = JSON.parse(fx('forecast.json'));
  const step = 15 * 60 * 1000;
  const start = Math.floor((Date.now() + (j.utc_offset_seconds || 0) * 1000) / step) * step;
  const pad = n => String(n).padStart(2, '0');
  j.minutely_15.time = j.minutely_15.time.map((_, i) => {
    const d = new Date(start + i * step);
    return `${d.getUTCFullYear()}-${pad(d.getUTCMonth() + 1)}-${pad(d.getUTCDate())}` +
      `T${pad(d.getUTCHours())}:${pad(d.getUTCMinutes())}`;
  });
  return JSON.stringify(j);
})();


/* The captured grid predates the CAPE layer, so its CAPE is SYNTHETIC: a
 * smooth west-to-east ramp from 0 to 3000 J/kg across the grid's own
 * points. Chosen to exercise both the colour ramp and the rule that CAPE
 * under 100 J/kg is left clear. Every other value is the real capture. */
function gridWithCape(raw) {
  const g = JSON.parse(raw);
  const lons = g.map(p => p.longitude), w = Math.min(...lons), e = Math.max(...lons);
  g.forEach(p => { p.current.cape = Math.round(3000 * (p.longitude - w) / ((e - w) || 1)); });
  return JSON.stringify(g);
}

module.exports = { routes, FIX, TILES, fx, json, BLANK, tile, missing, REPLAY_SOUNDING,
                   STATIONS, FORECAST };
