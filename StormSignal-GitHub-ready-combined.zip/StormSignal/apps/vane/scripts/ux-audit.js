/* Vane — user-friendliness audit.
 *
 *   ./serve.sh &
 *   node scripts/ux-audit.js
 *
 * "Not user friendly" is a feeling, and feelings are hard to fix. This turns it
 * into numbers a change can move: how far you scroll before the app answers the
 * one question a casual user came with, how many words of prose sit on each
 * card, how many terms of meteorological jargon appear before you have opted
 * into anything technical, and how many controls are on screen at once.
 *
 * It drives the real app against the same captured payloads the screenshot pass
 * uses, so the findings describe the app as shipped, not a mock of it. */
const { chromium } = require('playwright');
const { routes, missing } = require('./fixtures');

const PHONE = { width: 390, height: 844 };
const FOLD = PHONE.height;

/* Terms that mean nothing to someone who just wants to know about the weather.
 * The test is not "is this word technical" but "would a person who has never
 * read a forecast discussion know what it means". Units count: "hPa" and "kft"
 * are as opaque as "SRH". */
const JARGON = [
  'dBZ', 'VIL', 'SRH', 'LCL', 'LFC', 'CAPE', 'CIN', 'EHI', 'STP',
  'hPa', 'kft', 'kt', 'AGL', 'MSL', 'echo top', 'echo tops',
  'reflectivity', 'velocity', 'storm-relative', 'mesocyclone', 'TVS',
  'hodograph', 'bulk shear', 'ensemble', 'p10', 'p90', 'percentile',
  'anomaly', 'climatology', 'climatological', 'reanalysis', 'ERA5',
  'NEXRAD', 'N0Q', 'N0B', 'N0U', 'N0S', 'geopotential', 'pressure-level',
  'convective', 'CWA', 'AFD', 'Bunkers', 'dewpoint depression',
  'skill horizon', 'super-res', 'sounding', 'wind profile', 'meteogram',
  'derived', 'guidance', 'deterministic', 'spread'
];

const words = s => (String(s || '').trim().match(/\S+/g) || []).length;

async function measure(page, label) {
  return page.evaluate(({ label, JARGON, FOLD }) => {
    const vis = el => el && !el.hidden && el.offsetParent !== null &&
      getComputedStyle(el).display !== 'none';
    const text = el => (el.innerText || '').replace(/\s+/g, ' ').trim();
    const count = s => (s.match(/\S+/g) || []).length;

    const cards = Array.from(document.querySelectorAll('main > section.card'))
      .filter(vis);

    // Prose is body copy, not data: headings, numbers and chart labels are the
    // point of the app. What makes a card feel heavy is paragraphs.
    const prose = el => Array.from(el.querySelectorAll('p, summary, li, .derived-note'))
      .filter(vis).map(text).join(' ');

    const perCard = cards.map(c => {
      const r = c.getBoundingClientRect();
      const body = prose(c);
      return {
        id: c.id || c.className,
        heading: text(c.querySelector('h2, h1')).slice(0, 40),
        height: Math.round(r.height),
        top: Math.round(r.top + window.scrollY),
        proseWords: count(body),
        jargon: JARGON.filter(j =>
          new RegExp('\\b' + j.replace(/[-/\\^$*+?.()|[\]{}]/g, '\\$&') + '\\b', 'i')
            .test(text(c))).length
      };
    });

    const all = document.querySelector('main').innerText;
    const jargonHits = {};
    JARGON.forEach(j => {
      const m = all.match(new RegExp('\\b' + j.replace(/[-/\\^$*+?.()|[\]{}]/g, '\\$&') + '\\b', 'ig'));
      if (m) jargonHits[j] = m.length;
    });

    /* Every interactive thing on screen at once. A screen with thirty controls
     * is not "powerful", it is a cockpit you did not train on.
     *
     * Glossary terms are excluded and counted separately. They are buttons in
     * the DOM, but they are words inside sentences you were already reading —
     * counting them here would say the app got three times busier at the
     * moment it started explaining itself. */
    const controls = Array.from(document.querySelectorAll(
      'main button, main select, main input, header button, header select, header input'))
      .filter(vis).filter(el => !el.classList.contains('gl-term'));
    const controlList = controls.map(el =>
      el.id || el.className || (el.tagName + ':' + (el.textContent || '').slice(0, 14)));

    /* Jargon that is explained where it appears, versus jargon you are simply
     * expected to already know. This is the number the glossary can move —
     * the raw occurrence count cannot go down without deleting the depth. */
    const glossed = new Set(Array.from(document.querySelectorAll('main .gl-term'))
      .filter(vis).map(b => b.dataset.term));

    // How far down the page the app first answers "is it going to rain on me".
    const nowcast = document.getElementById('nowcast-headline');
    const answerTop = nowcast ? Math.round(nowcast.getBoundingClientRect().top + window.scrollY) : -1;

    return {
      label,
      scrollHeight: document.documentElement.scrollHeight,
      screens: +(document.documentElement.scrollHeight / FOLD).toFixed(1),
      cards: perCard,
      cardCount: cards.length,
      totalProse: perCard.reduce((a, c) => a + c.proseWords, 0),
      jargonHits,
      jargonTerms: Object.keys(jargonHits).length,
      jargonTotal: Object.values(jargonHits).reduce((a, b) => a + b, 0),
      glossed: glossed.size,
      controls: controls.length,
      controlList,
      answerTop,
      aboveFold: cards.filter(c => c.getBoundingClientRect().top + window.scrollY < FOLD)
        .map(c => c.id)
    };
  }, { label, JARGON, FOLD });
}

function report(m) {
  console.log('\n── ' + m.label + ' ' + '─'.repeat(Math.max(0, 56 - m.label.length)));
  console.log('  page height      ' + m.scrollHeight + 'px  (' + m.screens + ' phone screens)');
  console.log('  cards visible    ' + m.cardCount);
  console.log('  controls on page ' + m.controls +
    (process.env.VANE_CONTROLS ? '  [' + m.controlList.join(', ') + ']' : ''));
  console.log('  prose words      ' + m.totalProse);
  console.log('  jargon           ' + m.jargonTerms + ' distinct terms, ' +
    m.jargonTotal + ' occurrences · ' + m.glossed + ' explained on this view');
  if (m.answerTop >= 0) {
    console.log('  "will it rain?"  answered at y=' + m.answerTop + 'px' +
      (m.answerTop > FOLD ? '  ← below the fold' : '  ← above the fold'));
  }
  console.log('  above the fold   ' + (m.aboveFold.join(', ') || '(nothing)'));
  console.log('  heaviest cards:');
  m.cards.slice().sort((a, b) => b.proseWords - a.proseWords).slice(0, 6)
    .forEach(c => console.log('    ' + String(c.proseWords).padStart(4) + 'w  ' +
      String(c.jargon).padStart(2) + 'j  ' + String(c.height).padStart(5) + 'px  ' +
      (c.heading || c.id)));
  const top = Object.entries(m.jargonHits).sort((a, b) => b[1] - a[1]).slice(0, 12);
  if (top.length) {
    console.log('  most-used jargon: ' + top.map(([k, v]) => k + '×' + v).join(', '));
  }
}

(async () => {
  const browser = await chromium.launch({
    // Full Chromium (not the headless shell) unless a path is given.
    ...(process.env.CHROMIUM_PATH ? { executablePath: process.env.CHROMIUM_PATH } : { channel: 'chromium' })
  });
  const ctx = await browser.newContext({
    viewport: PHONE, deviceScaleFactor: 2, isMobile: true, hasTouch: true,
    timezoneId: 'America/Chicago', serviceWorkers: 'block'
  });
  const page = await ctx.newPage();
  await routes(page);
  await page.goto('http://127.0.0.1:8000/index.html', { waitUntil: 'load' });
  await page.waitForTimeout(4000);

  const out = [];
  out.push(await measure(page, 'Simple / Now (phone)'));

  for (const tab of ['radar', 'outlook']) {
    await page.click('.tabbar button[data-tab="' + tab + '"]');
    await page.waitForTimeout(1800);
    out.push(await measure(page, 'Simple / ' + tab + ' (phone)'));
  }

  await page.evaluate(() => window.Vane.setLocation(
    { lat: 42.8997, lon: -94.6912, name: 'Storm Lake', admin: 'Iowa, US' }));
  await page.waitForTimeout(3200);
  await page.evaluate(() => window.Vane.setMode('chase'));
  await page.waitForTimeout(3500);
  await page.click('.tabbar button[data-tab="chase"]');
  await page.waitForTimeout(2500);
  out.push(await measure(page, 'Chase (phone)'));

  await ctx.close();

  /* Desktop, where there is no tab bar at all and every card stacks. */
  const dctx = await browser.newContext({
    viewport: { width: 1400, height: 1000 },
    timezoneId: 'America/Chicago', serviceWorkers: 'block'
  });
  const dp = await dctx.newPage();
  await routes(dp);
  await dp.goto('http://127.0.0.1:8000/index.html', { waitUntil: 'load' });
  await dp.waitForTimeout(4000);
  out.push(await measure(dp, 'Simple (desktop 1400px)'));
  await dctx.close();

  await browser.close();

  out.forEach(report);
  console.log('\n' + '═'.repeat(60));
  if (missing.size) console.log(missing.size + ' tiles missing from the captured set');
  console.log(JSON.stringify(out.map(m => ({
    view: m.label, px: m.scrollHeight, cards: m.cardCount,
    controls: m.controls, prose: m.totalProse,
    jargon: m.jargonTotal, explained: m.glossed
  })), null, 1));
})();
