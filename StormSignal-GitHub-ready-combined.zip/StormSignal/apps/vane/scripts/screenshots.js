/* Full screenshot pass over every view in Vane, against captured real data.
 *
 *   ./serve.sh &
 *   node scripts/screenshots.js          # writes docs/screens/
 *
 * Everything is replayed from test/fixtures, including real captured NEXRAD
 * and base-map tiles, so the pass is deterministic and runs offline. The route
 * table and the two fixtures that need re-stamping onto the current clock live
 * in scripts/fixtures.js, shared with the UX audit.
 *
 * Set CHROMIUM_PATH to use an existing Chromium. */
const { chromium } = require('playwright');
const fs = require('fs'), path = require('path');
const { routes, TILES, missing } = require('./fixtures');

const OUT = path.join(__dirname, '..', 'docs', 'screens');
// Shipped with the app, not just the docs: the manifest points installers here.
const SHOTS = path.join(__dirname, '..', 'screenshots');
fs.mkdirSync(SHOTS, { recursive: true });
fs.mkdirSync(OUT, { recursive: true });
// A list left by an earlier pass would send fetch-tiles after tiles that are
// already here; this pass writes its own.
try { fs.unlinkSync(path.join(TILES, 'missing.txt')); } catch (e) { /* none */ }
const shots = [];

async function hideChrome(page, on) {
  await page.evaluate((hide) => {
    const bar = document.querySelector('.topbar');
    if (bar) bar.style.display = hide ? 'none' : '';
  }, on);
}

async function shot(target, name, opts) {
  await target.screenshot(Object.assign({ path: path.join(OUT, name + '.png') }, opts || {}));
  shots.push(name);
  console.log('  ✓', name);
}

// Card captures: hide the sticky header so it does not overlap the element.
async function card(page, selector, name) {
  const el = page.locator(selector);
  await el.scrollIntoViewIfNeeded();
  await page.waitForTimeout(400);
  await hideChrome(page, true);
  await shot(el, name);
  await hideChrome(page, false);
}

/* Sections are sections at every width now, so a capture has to navigate to
 * the card's own section first — a card on another tab is display:none and
 * screenshots as a zero-height sliver. */
async function tab(page, name) {
  const sel = `.tabbar button[data-tab="${name}"]`;
  if (!await page.locator(sel).isVisible()) return false;
  if (await page.getAttribute(sel, 'aria-selected') !== 'true') {
    await page.click(sel);
    await page.waitForTimeout(900);
  }
  return true;
}

// Card captures on a named section.
async function tabCard(page, name, selector, file) {
  await tab(page, name);
  await card(page, selector, file);
}

/* Overlays, dual pane and opacity live behind the Options disclosure now, so
 * every press of one is open → act → close. Wrapping it keeps the sequence
 * honest: forgetting the close leaves the sheet covering the next capture. */
async function withOpts(page, fn) {
  if (!await page.locator('#radar-opts').isVisible()) {
    await page.click('#radar-opts-btn');
    await page.waitForTimeout(500);
  }
  await fn();
  if (await page.locator('#radar-opts').isVisible()) {
    await page.click('#radar-opts-btn');
    await page.waitForTimeout(500);
  }
}

// Map captures additionally wait for tile settling, since Leaflet keeps
// upscaled tiles from the previous zoom until the new level finishes.
async function mapCard(page, name, ms) {
  await tab(page, 'radar');
  await page.waitForTimeout(ms || 2600);
  await page.evaluate(() => window.Radar.invalidate());
  await page.waitForTimeout(1400);
  await card(page, '#radar-card', name);
}

(async () => {
  const browser = await chromium.launch({
    // Full Chromium (not the headless shell) unless a path is given.
    ...(process.env.CHROMIUM_PATH ? { executablePath: process.env.CHROMIUM_PATH } : { channel: 'chromium' })
  });

  /* ── Desktop ──────────────────────────────────────────────────────── */
  const ctx = await browser.newContext({
    viewport: { width: 1400, height: 1000 },
    timezoneId: 'America/Chicago', serviceWorkers: 'block', locale: 'en-US'
  });
  const page = await ctx.newPage();
  await routes(page);
  await page.goto('http://127.0.0.1:8000/index.html', { waitUntil: 'load' });
  await page.waitForTimeout(3500);

  console.log('Simple mode');
  await tab(page, 'now');
  await shot(page, '01-simple-full', { fullPage: true });
  await card(page, '.hero', '02-hero');
  await card(page, '#nowcast', '03-nowcast');
  await card(page, '#alerts', '04-alerts');
  await card(page, '#hourly-card', '07-hourly');
  await card(page, '#daily-card', '08-daily');
  await card(page, '#details-card', '09-details');
  await card(page, '#astro-card', '10-sun-moon');
  await card(page, '#air-card', '11-air-quality');
  await shot(page, '53-section-nav', { clip: { x: 0, y: 0, width: 1400, height: 150 } });

  console.log('Outlook');
  await tabCard(page, 'outlook', '#meteogram-card', '05-meteogram');
  await tabCard(page, 'outlook', '#models-card', '06-model-agreement');
  await tabCard(page, 'outlook', '#modelcast-card', '55-model-forecasts');
  await page.evaluate(() => {
    window.Vane.state.modelFocus = 'gfs_seamless';
    window.Modelcast.render(window.Vane.state);
  });
  await page.waitForTimeout(500);
  await card(page, '#modelcast-card', '56-model-forecast-gfs');
  await tabCard(page, 'outlook', '#mchart-card', '58-model-chart');
  await page.evaluate(() => {
    window.Vane.state.modelFocus = null;
    window.Modelcast.render(window.Vane.state);
  });
  await tabCard(page, 'outlook', '#outlook-card', '44-outlook');
  await tabCard(page, 'outlook', '#afd-card', '42-discussion');

  await page.screenshot({ path: path.join(SHOTS, 'desktop.png') });

  console.log('Radar');
  await mapCard(page, '12-radar-mosaic');

  // The controls that moved out of the header, one press away.
  await withOpts(page, async () => {
    await page.waitForTimeout(400);
    await card(page, '#radar-card', '54-radar-options');
  });

  // The Forecast regime: HRRR simulated reflectivity at +6 h.
  await page.click('#mode-forecast');
  await page.waitForTimeout(1200);
  await page.evaluate(() => {
    const sl = document.getElementById('radar-frame');
    sl.value = '23';
    sl.dispatchEvent(new Event('input', { bubbles: true }));
  });
  await page.waitForTimeout(1800);
  await mapCard(page, '57-future-radar', 1200);
  // The History regime: an archived hour, for the docs.
  await page.click('#mode-history');
  await page.waitForTimeout(300);
  await page.fill('#history-when', '2026-08-15T13:15');
  await page.evaluate(() => document.getElementById('history-when')
    .dispatchEvent(new Event('change', { bubbles: true })));
  await page.waitForTimeout(1500);
  await mapCard(page, '59-history-radar', 1200);
  await page.click('#mode-live');
  await page.waitForTimeout(800);

  // Field overlays
  await withOpts(page, () => page.click('#layer-wind'));
  await page.waitForTimeout(2100);
  await mapCard(page, '13-radar-wind-field');
  await withOpts(page, () => page.click('#layer-temp'));
  await page.waitForTimeout(2100);
  await mapCard(page, '14-radar-temperature-field');
  await withOpts(page, () => page.click('#layer-temp'));
  await page.waitForTimeout(900);

  console.log('Radar sites');
  await page.click('#site-btn');
  await page.waitForTimeout(1200);
  await card(page, '#radar-card', '15-radar-site-picker');
  await page.check('#site-active-only');
  await page.waitForTimeout(700);
  await card(page, '#site-panel', '16-site-picker-active-only');
  await page.uncheck('#site-active-only');

  // Single-site: reflectivity, then velocity (the rotation view).
  await page.fill('#site-search', 'KDMX');
  await page.waitForTimeout(600);
  await page.locator('#site-list .site-row').first().click();
  await page.waitForTimeout(1800);
  await page.evaluate(() => window.Radar.panTo(41.7311, -93.7228, 8));
  await page.waitForTimeout(2200);
  await mapCard(page, '17-single-site-reflectivity', 3200);

  await page.selectOption('#radar-product', 'N0U');
  await page.waitForTimeout(2400);
  await mapCard(page, '18-single-site-velocity', 3200);

  // Dual pane, taken here because this is where real single-site tiles for
  // both products were captured. Reflectivity goes back in the left pane so
  // the pair illustrates the comparison rather than showing velocity twice.
  await page.selectOption('#radar-product', 'N0Q');
  await page.waitForTimeout(1500);
  await withOpts(page, () => page.click('#pair-btn'));
  await page.waitForTimeout(2000);
  await page.evaluate(() => window.Radar.panTo(41.7311, -93.7228, 8));
  await mapCard(page, '47-dual-pane', 3400);
  console.log('    pane tiles:',
    await page.locator('#map2 img.leaflet-tile').count(),
    'main:', await page.locator('#map img.leaflet-tile').count());
  await withOpts(page, () => page.click('#pair-btn'));
  await page.waitForTimeout(800);

  await page.click('#site-btn');
  await page.waitForTimeout(600);
  await page.selectOption('#radar-source', 'nexrad');
  await page.waitForTimeout(1200);
  await page.click('#site-close');
  await page.waitForTimeout(900);

  console.log('Chase mode');
  await page.evaluate(() => window.Vane.setLocation(
    { lat: 42.8997, lon: -94.6912, name: 'Storm Lake', admin: 'Iowa, US' }));
  await page.waitForTimeout(3500);
  await page.evaluate(() => window.Vane.setMode('chase'));
  await page.waitForTimeout(3800);
  await tab(page, 'chase');
  await page.waitForTimeout(1500);
  await shot(page, '19-chase-full', { fullPage: true });
  await card(page, '#shot-card', '45-shot-planner');
  await page.click('.view-switch button[data-view="orbit"]');
  await page.waitForTimeout(1100);
  await card(page, '#shot-card', '46-storm-3d');
  await page.click('.view-switch button[data-view="observer"]');
  await page.waitForTimeout(600);
  await card(page, '#cells-card', '20-areas-of-interest');
  await card(page, '#convective-card', '21-convective-parameters');
  await card(page, '#hodo-card', '22-hodograph');
  await card(page, '#sounding-card', '23-wind-profile');
  await tabCard(page, 'outlook', '#spc-card', '24-spc-outlook');
  await tabCard(page, 'outlook', '#reports-card', '25-storm-reports');
  await tabCard(page, 'outlook', '#alerts-full-card', '26-alerts-full');
  await page.evaluate(() => window.Radar.panTo(42.8997, -94.6912, 7));
  await page.waitForTimeout(1800);
  await mapCard(page, '27-radar-with-cells');

  console.log('Overlays');
  await page.click('#settings-btn');
  await page.waitForTimeout(800);
  await shot(page.locator('.settings-box'), '28-settings');
  await page.click('#settings-close');
  await page.keyboard.press('?');
  await page.waitForTimeout(500);
  await shot(page.locator('#help .help-box'), '29-keyboard-help');
  await page.keyboard.press('Escape');

  await page.click('#saved-btn');
  await page.waitForTimeout(600);
  await shot(page.locator('.topbar'), '30-saved-locations');
  await page.keyboard.press('Escape');
  await page.click('body');

  await page.fill('#search-input', 'Norman');
  await page.waitForTimeout(1400);
  await shot(page.locator('.topbar'), '31-search');
  await page.fill('#search-input', '');
  await page.keyboard.press('Escape');

  console.log('Accessibility variant');
  await page.evaluate(() => {
    window.Settings.save({ solid: true });
    document.body.classList.add('solid');
  });
  await page.waitForTimeout(900);
  await shot(page, '32-reduced-transparency', { fullPage: false });
  await page.evaluate(() => {
    window.Settings.save({ solid: false });
    document.body.classList.remove('solid');
  });

  console.log('Sky themes');
  const THEMES = [
    ['33-sky-clear-day', 0, 45], ['34-sky-golden-hour', 0, 4],
    ['35-sky-clear-night', 0, -25], ['36-sky-thunderstorm', 95, 25],
    ['37-sky-rain-twilight', 63, -5], ['38-sky-snow-night', 73, -20],
    ['39-sky-fog-day', 45, 20]
  ];
  await page.evaluate(() => window.Vane.setMode('simple'));
  await page.waitForTimeout(1200);
  await tab(page, 'now');
  for (const [name, code, alt] of THEMES) {
    await page.evaluate(({ code, alt }) => {
      window.Theme.apply(code, alt, { reduceMotion: false });
      const cur = window.Vane.state.data.current;
      cur.weather_code = code; cur.is_day = alt > 0 ? 1 : 0;
      window.Icons.into(document.getElementById('now-icon'), code, alt > 0, 108);
      document.getElementById('now-cond').textContent = window.U.wmo(code)[0];
    }, { code, alt });
    await page.waitForTimeout(1900);
    await card(page, '.hero', name);
  }
  await ctx.close();

  /* ── Mobile ───────────────────────────────────────────────────────── */
  console.log('Mobile');
  const mctx = await browser.newContext({
    viewport: { width: 390, height: 844 }, deviceScaleFactor: 2,
    isMobile: true, hasTouch: true,
    timezoneId: 'America/Chicago', serviceWorkers: 'block'
  });
  const mp = await mctx.newPage();
  await routes(mp);
  await mp.goto('http://127.0.0.1:8000/index.html', { waitUntil: 'load' });
  await mp.waitForTimeout(3800);
  await shot(mp, '40-mobile-simple', { fullPage: true });
  await mp.screenshot({ path: path.join(SHOTS, 'phone-now.png') });
  await mp.click('.tabbar button[data-tab="radar"]');
  await mp.waitForTimeout(2600);
  await mp.evaluate(() => window.Radar.invalidate());
  await mp.waitForTimeout(2200);
  await shot(mp, '48-mobile-radar');
  // Viewport-sized captures for the manifest's install card — the full-page
  // ones are 13,000px tall and no installer will show those.
  await mp.screenshot({ path: path.join(SHOTS, 'phone-radar.png') });
  await mp.evaluate(() => window.Vane.setLocation(
    { lat: 42.8997, lon: -94.6912, name: 'Storm Lake', admin: 'Iowa, US' }));
  await mp.waitForTimeout(3200);
  await mp.evaluate(() => window.Vane.setMode('chase'));
  await mp.waitForTimeout(3500);
  await shot(mp, '41-mobile-chase', { fullPage: true });
  await mp.click('.tabbar button[data-tab="chase"]');
  await mp.waitForTimeout(2500);
  await shot(mp, '49-mobile-chase-tab');
  await mp.screenshot({ path: path.join(SHOTS, 'phone-chase.png') });
  await mp.click('.tabbar button[data-tab="outlook"]');
  await mp.waitForTimeout(2000);
  await shot(mp, '50-mobile-outlook');
  await mctx.close();

  await browser.close();
  console.log('\n' + shots.length + ' screenshots written to docs/screens/');
  if (missing.size) {
    console.log('\n' + missing.size + ' tiles missing from the captured set:');
    Array.from(missing).slice(0, 40).forEach(t => console.log('  ' + t));
    // `node scripts/fetch-tiles.js` refetches exactly this list.
    fs.mkdirSync(TILES, { recursive: true });      // a cold cache has no directory yet
    fs.writeFileSync(path.join(TILES, 'missing.txt'), Array.from(missing).join('\n'));
  }
})();
