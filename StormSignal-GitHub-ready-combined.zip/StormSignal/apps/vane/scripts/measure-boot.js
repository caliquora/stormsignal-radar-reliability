/* Boot cost, measured the way a phone pays it: CPU throttled 4x, every
 * external request stubbed (so only Vane's own code is on the clock),
 * median of N cold loads. Reports script count and bytes executed at boot,
 * DOMContentLoaded, and the main-thread script evaluation time.
 *
 *   node scripts/measure-boot.js [runs]     (serves from VANE_URL or :8000)
 */
const { chromium } = require('playwright');
const BASE = process.env.VANE_URL || 'http://127.0.0.1:8000/index.html';
const RUNS = +process.argv[2] || 9;
const median = a => a.slice().sort((x, y) => x - y)[Math.floor(a.length / 2)];

(async () => {
  const browser = await chromium.launch(process.env.CHROMIUM_PATH
    ? { executablePath: process.env.CHROMIUM_PATH } : { channel: 'chromium' });
  const rows = [];
  for (let i = 0; i < RUNS; i++) {
    const ctx = await browser.newContext({ serviceWorkers: 'block', viewport: { width: 390, height: 844 } });
    const page = await ctx.newPage();
    await page.route(u => !/^http:\/\/127\.0\.0\.1/.test(u.href), r => r.abort());
    const cdp = await ctx.newCDPSession(page);
    await cdp.send('Emulation.setCPUThrottlingRate', { rate: 4 });
    await cdp.send('Network.setCacheDisabled', { cacheDisabled: true });
    await cdp.send('Performance.enable');
    await page.goto(BASE, { waitUntil: 'load' });
    await page.waitForTimeout(300);
    const m = await page.evaluate(() => {
      const nav = performance.getEntriesByType('navigation')[0];
      const js = performance.getEntriesByType('resource').filter(e => /\.js(\?|$)/.test(e.name));
      return { dcl: nav.domContentLoadedEventEnd, scripts: js.length,
               bytes: js.reduce((s, e) => s + (e.decodedBodySize || 0), 0) };
    });
    const t = await cdp.send('Performance.getMetrics');
    const get = n => (t.metrics.find(x => x.name === n) || {}).value || 0;
    m.scriptMs = get('ScriptDuration') * 1000;
    rows.push(m);
    await ctx.close();
  }
  await browser.close();
  const out = {
    runs: RUNS,
    scripts: median(rows.map(r => r.scripts)),
    kb: Math.round(median(rows.map(r => r.bytes)) / 1024),
    dclMs: Math.round(median(rows.map(r => r.dcl))),
    scriptMs: Math.round(median(rows.map(r => r.scriptMs)))
  };
  console.log(JSON.stringify(out));
})();
