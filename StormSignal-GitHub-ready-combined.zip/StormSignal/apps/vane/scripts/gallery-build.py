"""Step 2 of the gallery build: captions, structure, and the finished page.

    node scripts/gallery-encode.js
    python3 scripts/gallery-build.py     # writes docs/gallery.html

docs/gallery.html is generated and git-ignored: it is the same images as
docs/screens/ carried a second time as base64, so committing it would double
the repository for no new information. Regenerate it with the two commands
above.
"""
import json, html, os

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
G = json.load(open(os.path.join(HERE, 'gallery.json')))

SECTIONS = [
    ("Simple mode", "What a casual user opens the app for", [
        ("01-simple-full.png", "The whole page", "Hero, nowcast, radar, discussion, meteogram, model agreement, hourly, week, outlook, details, sun and moon, air quality.", None),
        ("02-hero.png", "Current conditions", "Model output alongside the nearest real METAR, each labelled. The <span class='m'>OBSERVED</span> tag is not decoration — it marks the one number on the card that was measured rather than computed.", None),
        ("03-nowcast.png", "Two-hour nowcast", "The answer written as a sentence, with the 15-minute chart underneath as the evidence for it.", None),
        ("04-alerts.png", "Live NWS alerts", "Severity-styled, and filterable by event family so a heat advisory can't bury a tornado warning.", None),
        ("05-meteogram.png", "Meteogram", "Day and night bands, cloud strip, temperature inside its multi-model envelope, precipitation bars tinted by how many models agree, wind arrows.", None),
        ("06-model-agreement.png", "Model agreement", "Five agencies' runs compared, the current outlier named. This measures model formulation differences, not forecast uncertainty — a distinction plate 44 turns on.", None),
        ("07-hourly.png", "Hourly", "24 hours in Simple, 48 in Chase.", None),
        ("08-daily.png", "The week", "Seven days with range bars scaled to the week alone.", None),
        ("09-details.png", "Details", None, None),
        ("10-sun-moon.png", "Sun and moon", "Computed locally from Meeus, no network call. Includes usable daylight remaining.", None),
        ("11-air-quality.png", "Air quality", "US AQI with the pollutants behind it.", None),
    ]),
    ("The forecaster's discussion", "The one product where a meteorologist writes down their reasoning", [
        ("42-discussion.png", "No key needed", "The NWS Area Forecast Discussion parsed into its sections, with the office's own key messages lifted to the top. Free, always on, no model involved.", None),
    ]),
    ("Extended outlook", "Where the forecast stops being a forecast", [
        ("44-outlook.png", "16 days, as a distribution", "A box plot per day over 51 ECMWF ensemble members — box is the middle half, whisker is p10 to p90 — with the 20-year local normal band behind it and the single deterministic run dashed over the top.", "The skill horizon is measured, not assumed: it falls where the ensemble spread reaches the climatological spread for the same dates. Past it, no daily temperature is printed at all."),
    ]),
    ("Radar", "The most-used feature, never buried", [
        ("12-radar-mosaic.png", "National mosaic", "NEXRAD Level III base reflectivity on the standard NWS dBZ ramp. Place labels are drawn in a pane above the returns so you can still read which town the cell is over.", None),
        ("13-radar-wind-field.png", "Wind field", "Particles flowing along the actual flow, built in-browser from a 42-point model grid — Open-Meteo has no tile service, so the layer is computed rather than fetched.", None),
        ("14-radar-temperature-field.png", "Temperature field", "Inverse-distance weighted from the same grid, re-sampled as you pan.", None),
        ("15-radar-site-picker.png", "Radar site picker", "All 159 WSR-88D sites, nearest first. Green is scanning storms, blue is clear-air, grey is no recent data — read from the live Volume Coverage Pattern, not guessed.", None),
        ("16-site-picker-active-only.png", "Active only", "Filtered to radars actually in a precipitation VCP.", None),
        ("17-single-site-reflectivity.png", "Single-site reflectivity", "With the coverage ring, so range folding and beam height are legible.", None),
        ("18-single-site-velocity.png", "Base velocity", "Green toward the radar, red away. A tight couplet is rotation — and no mosaic product shows it, which is the reason single-site mode exists.", None),
        ("27-radar-with-cells.png", "Storm cells on the radar", "Rotation ringed, 30-minute tracks projected forward.", None),
    ]),
    ("Chasing for footage", "Where to stand, and what it will look like when you get there", [
        ("45-shot-planner.png", "Shot planner", "Light from the real solar position, whether the updraft is rain-wrapped or exposed, the storm's angular size and the focal length that implies, and a vantage to drive to.", "It will not suggest a position in the storm's forward path — that is checked, not assumed. It is a framing aid, not a routing or safety system."),
        ("46-storm-3d.png", "The storm in 3D", "The real 0.5&nbsp;degree reflectivity field, read out of the radar tiles and inverted to dBZ through the published NWS colour table, then extruded. Same colours as the map, same shape, standing up.", "The shape is measured; the vertical is not. Only that one tilt is published publicly &mdash; every higher elevation scan returns 503 from the keyless endpoints &mdash; so column heights are interpolated between the measured echo top and a floor, and drawn 2.5&times; exaggerated as operational radar displays do."),
        ("47-dual-pane.png", "Dual pane", "Reflectivity beside base velocity from the same radar and the same scan, locked to one view. The green/red couplet is rotation — and it only means something against the structure it sits in.", None),
    ]),
    ("Chase mode", "The same app, zoomed in", [
        ("19-chase-full.png", "The whole page", None, None),
        ("20-areas-of-interest.png", "Areas of interest", "Cells ranked by threat, each showing why it was flagged.", "Rotation and hail come from the WSR-88D's own detection algorithms. Vane does not infer them from imagery, and it states the false-alarm caveat rather than implying certainty."),
        ("21-convective-parameters.png", "Convective parameters", "CAPE, CIN, lifted index, bulk shear, storm-relative helicity, Bunkers motions — derived in-browser from pressure-level winds and labelled as derived.", None),
        ("22-hodograph.png", "Hodograph", "Surface to 400 hPa, layer-coloured, with right- and left-mover motions plotted.", None),
        ("23-wind-profile.png", "Wind profile", "Every pressure level, heights AGL. Levels underground at this elevation are dropped rather than extrapolated.", None),
        ("24-spc-outlook.png", "SPC convective outlook", "Days 1 to 3, categorical plus tornado, hail and wind probabilities.", None),
        ("25-storm-reports.png", "Today's storm reports", "Tornado, wind and hail, by distance from you.", None),
        ("26-alerts-full.png", "Full warning text", None, None),
    ]),
    ("Controls", "", [
        ("28-settings.png", "Settings", "Alert families, notifications, appearance, and the optional API key — stored in this browser and sent to no other host.", None),
        ("29-keyboard-help.png", "Keyboard", "Sixteen shortcuts; the whole app is operable without a pointer.", None),
        ("30-saved-locations.png", "Saved locations", None, None),
        ("31-search.png", "Search", "By name, or paste coordinates and they're parsed locally with no request at all.", None),
    ]),
    ("Accessibility", "", [
        ("32-reduced-transparency.png", "Reduced transparency", "Every frosted panel swaps for a solid one. Built for reading a phone in direct sunlight from a moving vehicle.", None),
    ]),
    ("The sky is the weather", "32 palettes across 8 condition groups and 4 light bands", [
        ("33-sky-clear-day.png", "Clear, midday", None, None),
        ("34-sky-golden-hour.png", "Golden hour", None, None),
        ("35-sky-clear-night.png", "Clear, night", None, None),
        ("36-sky-thunderstorm.png", "Thunderstorm", None, None),
        ("37-sky-rain-twilight.png", "Rain, twilight", None, None),
        ("38-sky-snow-night.png", "Snow, night", None, None),
        ("39-sky-fog-day.png", "Fog, day", None, None),
    ]),
    ("Phone", "Its own information architecture, not the desktop layout stood on its end", [
        ("40-mobile-simple.png", "Simple mode", "The Now tab: current conditions, nowcast, hourly, week, details, sun and air.", None),
        ("48-mobile-radar.png", "Radar tab", "The map fills the screen rather than sitting in a 320px letterbox.", None),
        ("49-mobile-chase-tab.png", "Chase tab", "The shot planner and cell triage lead; the hodograph and level-by-level table fold below. Chase mode went from 8,838px of stacked cards to 5,341px.", None),
        ("50-mobile-outlook.png", "Outlook tab", "Forecaster's discussion, the ensemble outlook, and SPC planning products.", None),
        ("51-install.png", "Installing", "Vane installs from the browser, not a store: an icon on the home screen, full screen, working offline.", "Safari has no install API and never has, so on iOS the app shows the actual Share &rarr; Add to Home Screen instructions instead of an Install button that would silently do nothing &mdash; the most common broken thing in shipped web apps."),
        ("41-mobile-chase.png", "Chase mode, full page", None, None),
    ]),
]

def plate(fn, title, note, limit, n):
    g = G[fn]
    num = fn.split('-')[0]
    parts = ['<figure class="plate" id="p%s">' % num]
    parts.append('<figcaption class="plate-head">')
    parts.append('<span class="plate-no">%s</span>' % num)
    parts.append('<h3 class="plate-title">%s</h3>' % html.escape(title))
    parts.append('</figcaption>')
    if note:
        parts.append('<p class="plate-note">%s</p>' % note)
    if limit:
        parts.append('<p class="plate-limit"><span class="limit-label">Stated limit</span>%s</p>' % html.escape(limit))
    cls = 'frame' + (' frame-phone' if g['w'] <= 500 else '')
    parts.append('<div class="%s"><img src="%s" width="%d" height="%d" alt="%s" loading="lazy"></div>'
                 % (cls, g['uri'], g['w'], g['h'], html.escape(title)))
    parts.append('</figure>')
    return '\n'.join(parts)

out = []
nav = []
n = 0
for si, (name, blurb, plates) in enumerate(SECTIONS):
    slug = name.lower().replace(' ', '-').replace("'", '')
    nav.append('<li><a href="#%s"><span class="nav-name">%s</span><span class="nav-count">%d</span></a></li>'
               % (slug, html.escape(name), len(plates)))
    out.append('<section class="chapter" id="%s">' % slug)
    out.append('<header class="chapter-head">')
    first, last = plates[0][0].split('-')[0], plates[-1][0].split('-')[0]
    out.append('<p class="eyebrow">%s</p>' % ('Plate ' + first if first == last else 'Plates %s&ndash;%s' % (first, last)))
    out.append('<h2>%s</h2>' % html.escape(name))
    if blurb:
        out.append('<p class="chapter-blurb">%s</p>' % html.escape(blurb))
    out.append('</header>')
    for fn, title, note, limit in plates:
        n += 1
        out.append(plate(fn, title, note, limit, n))
    out.append('</section>')

body = '\n'.join(out)
navhtml = '\n'.join(nav)
total = n

shell = open(os.path.join(HERE, 'gallery-shell.html')).read()
page = shell.replace('NAVHERE', navhtml).replace('BODYHERE', body)
out = os.path.join(ROOT, 'docs', 'gallery.html')
open(out, 'w').write(page)
print('%d plates, %.2f MB -> %s' % (total, len(page) / 1024 / 1024, out))
