/* Renders icons/icon.svg into every raster the manifest and iOS need.
 *
 *   node scripts/make-icons.js
 *
 * Chromium does the rasterising since this box has no image tooling. Three
 * variants from one source of truth:
 *
 *   - standard (icon-*.png, favicon-32): the SVG as-is — rounded corners,
 *     transparent outside them.
 *   - apple-touch-icon: square corners. iOS applies its own mask, and
 *     transparency in the corners renders as black on a real home screen.
 *   - maskable-*: square corners with the mark scaled into the 80% safe zone,
 *     because Android may crop anything outside a centred circle.
 */
const { chromium } = require('playwright');
const fs = require('fs'), path = require('path');

const ICONS = path.join(__dirname, '..', 'icons');
const SRC = fs.readFileSync(path.join(ICONS, 'icon.svg'), 'utf8');

const square = SRC.replace(/rx="115"/g, 'rx="0"');
const maskable = square.replace('<!-- the mark -->\n  <g>',
  '<!-- the mark, inside the maskable safe zone -->\n  ' +
  '<g transform="translate(256 256) scale(0.8) translate(-256 -256)">');

const OUT = [
  ['icon-512.png', SRC, 512],
  ['icon-192.png', SRC, 192],
  ['favicon-32.png', SRC, 32],
  ['apple-touch-icon.png', square, 180],
  ['maskable-512.png', maskable, 512],
  ['maskable-192.png', maskable, 192]
];

(async () => {
  const b = await chromium.launch({ executablePath: process.env.CHROMIUM_PATH || '/opt/pw-browsers/chromium' });
  const p = await b.newPage();
  for (const [file, svg, size] of OUT) {
    await p.setViewportSize({ width: size, height: size });
    await p.setContent(
      `<body style="margin:0"><div style="width:${size}px;height:${size}px">` +
      svg.replace('<svg ', `<svg width="${size}" height="${size}" `) + '</div></body>');
    await p.screenshot({ path: path.join(ICONS, file), omitBackground: true });
    console.log('  ✓', file);
  }
  await b.close();
})();
