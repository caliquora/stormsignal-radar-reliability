/* Refetch the map and radar tiles the screenshot pass could not find.
 *
 *   node scripts/screenshots.js     # writes scripts/tiles/missing.txt
 *   node scripts/fetch-tiles.js     # fills the gaps, then re-run the pass
 *
 * The cache is git-ignored — it is a cache, not source. This is the only part
 * of the pass that touches the network, and it is deliberately separate so the
 * screenshot run itself stays offline and deterministic. */
const fs = require('fs'), path = require('path');
const { execFileSync } = require('child_process');

const TILES = process.env.VANE_TILES || path.join(__dirname, 'tiles');
const LIST = path.join(TILES, 'missing.txt');

function urlFor(name) {
  let m;
  // Esri (keyless, replaced CARTO): URL order is {z}/{y}/{x}, cache names stay {z}-{x}-{y}.
  if ((m = /^base-(\d+)-(\d+)-(\d+)\.png$/.exec(name)))
    return `https://server.arcgisonline.com/ArcGIS/rest/services/Canvas/World_Dark_Gray_Base/MapServer/tile/${m[1]}/${m[3]}/${m[2]}`;
  if ((m = /^labels-(\d+)-(\d+)-(\d+)\.png$/.exec(name)))
    return `https://server.arcgisonline.com/ArcGIS/rest/services/Canvas/World_Dark_Gray_Reference/MapServer/tile/${m[1]}/${m[3]}/${m[2]}`;
  // The light-theme canvas the redesign boots into.
  if ((m = /^lbase-(\d+)-(\d+)-(\d+)\.png$/.exec(name)))
    return `https://server.arcgisonline.com/ArcGIS/rest/services/Canvas/World_Light_Gray_Base/MapServer/tile/${m[1]}/${m[3]}/${m[2]}`;
  if ((m = /^llabels-(\d+)-(\d+)-(\d+)\.png$/.exec(name)))
    return `https://server.arcgisonline.com/ArcGIS/rest/services/Canvas/World_Light_Gray_Reference/MapServer/tile/${m[1]}/${m[3]}/${m[2]}`;
  if ((m = /^nexrad-(\d+)-(\d+)-(\d+)\.png$/.exec(name)))
    return `https://mesonet.agron.iastate.edu/cache/tile.py/1.0.0/nexrad-n0q-900913/${m[1]}/${m[2]}/${m[3]}.png`;
  if ((m = /^ridge-(\w+)-(\w+)-(\d+)-(\d+)-(\d+)\.png$/.exec(name)))
    return `https://mesonet.agron.iastate.edu/cache/tile.py/1.0.0/ridge::${m[1]}-${m[2]}-0/${m[3]}/${m[4]}/${m[5]}.png`;
  return null;
}

// curl, not node https: it honours the proxy environment everywhere this runs.
function get(url) {
  const buf = execFileSync('curl', ['-sf', '--max-time', '30',
    '-A', 'vane-screenshot-cache', url], { maxBuffer: 10 << 20 });
  if (!buf.length) throw new Error('empty');
  return Promise.resolve(buf);
}

(async () => {
  if (!fs.existsSync(LIST)) {
    console.log('No missing.txt — run scripts/screenshots.js first.');
    return;
  }
  const names = fs.readFileSync(LIST, 'utf8').split('\n').map(s => s.trim()).filter(Boolean);
  let ok = 0, skipped = 0;
  for (const name of names) {
    const url = urlFor(name);
    if (!url) { console.log('  ? unrecognised', name); skipped++; continue; }
    try {
      fs.writeFileSync(path.join(TILES, name), await get(url));
      ok++;
    } catch (e) {
      // An empty radar tile is a legitimate answer: no returns there right now.
      console.log('  ✗', name, e.message);
      skipped++;
    }
  }
  console.log(`${ok} fetched, ${skipped} skipped, into ${TILES}`);
})();
