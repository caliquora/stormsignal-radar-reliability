/* Train and evaluate the chase-day model; write js/chaseday-weights.js.
 *
 *   node scripts/train/fetch-env.js
 *   node scripts/train/env.js
 *
 * One sample per sounding station per day, April–July 2023–2024: the
 * station's evening (00Z) sounding — its derived CAPE, CIN, bulk shear,
 * helicity and LCL, as Iowa State computed them — and whether a severe
 * local storm report (tornado, hail ≥ 1", gust ≥ 58 mph, thunderstorm wind
 * damage) was made within 100 km between 16Z that day and 06Z the next.
 *
 * Features come from js/chaseday.js featuresOf(), the function the app runs.
 * Held out: every fourth day, never seen by the fit. The model ships only if
 * it beats climatology (Brier skill) AND out-ranks two classic forecaster
 * shortcuts on those days: WMAXSHEAR (√(2·CAPE) × shear) and Vane's own
 * supercell index. */
const fs = require('fs'), path = require('path'), vm = require('vm');
const T = require('./train.js');

const ROOT = path.join(__dirname, '..', '..');
const DATA = path.join(__dirname, 'data');
const OUT = path.join(ROOT, 'js', 'chaseday-weights.js');
const RADIUS_KM = 100, WINDOW = [16, 30];          // hours after 00Z of day D

const sandbox = { console }; sandbox.window = sandbox; sandbox.globalThis = sandbox;
vm.createContext(sandbox);
vm.runInContext(fs.readFileSync(path.join(ROOT, 'js', 'chaseday.js'), 'utf8'), sandbox);
const { ChaseDay } = sandbox;

const stations = {};
JSON.parse(fs.readFileSync(path.join(DATA, 'raob-stations.json'), 'utf8')).data
  .forEach(s => { stations[s.id] = { lat: s.latitude, lon: s.longitude }; });

// Severe reports, all months, sorted by time.
let lsr = [];
fs.readdirSync(DATA).filter(f => /^lsrmonth-/.test(f)).forEach(f => {
  lsr = lsr.concat(T.readLsr(path.join(DATA, f)));
});
lsr.sort((a, b) => a.t - b.t);
const seen = new Set();
lsr = lsr.filter(r => { const k = r.t + ':' + r.lat + ':' + r.lon + ':' + r.type; if (seen.has(k)) return false; seen.add(k); return true; });

const rows = [];
fs.readdirSync(DATA).filter(f => /^raob-K\w+-\d{4}\.json$/.test(f)).forEach(f => {
  const id = f.split('-')[1], st = stations[id];
  if (!st) return;
  JSON.parse(fs.readFileSync(path.join(DATA, f), 'utf8')).data.forEach(s => {
    if (!/T00:00:00Z$/.test(s.valid) || !s.computed || s.sbcape_jkg === null || s.shear_sfc_6km_smps === null) return;
    const t00 = Date.parse(s.valid), dayD = new Date(t00 - 86400000);   // the afternoon before 00Z
    const m = dayD.getUTCMonth() + 1;
    if (m < 4 || m > 7) return;
    const env = { cape: s.sbcape_jkg, cin: s.sbcin_jkg, shear6: s.shear_sfc_6km_smps,
                  srh1: s.srh_sfc_1km_total, srh3: s.srh_sfc_3km_total, lcl: s.lcl_agl_m };
    const d0 = Date.UTC(dayD.getUTCFullYear(), dayD.getUTCMonth(), dayD.getUTCDate());
    const t0 = d0 + WINDOW[0] * 3600000, t1 = d0 + WINDOW[1] * 3600000;
    let y = 0;
    for (let k = T.lowerBound(lsr, t0); k < lsr.length && lsr[k].t <= t1; k++) {
      if (T.km(st.lat, st.lon, lsr[k].lat, lsr[k].lon) <= RADIUS_KM) { y = 1; break; }
    }
    rows.push({ x: ChaseDay.featuresOf(env), y, day: new Date(d0).toISOString().slice(0, 10), env, id });
  });
});

const days = Array.from(new Set(rows.map(r => r.day))).sort();
const testDays = new Set(days.filter((_, i) => i % 4 === 3));
const tr = rows.filter(r => !testDays.has(r.day)), te = rows.filter(r => testDays.has(r.day));
const use = ChaseDay.FEATURES.map((_, i) => i);
const m = T.logistic(tr, use, 1, 30);
const base = tr.reduce((a, r) => a + r.y, 0) / tr.length;

let brier = 0, brierClim = 0;
const scored = [], wmax = [], idx = [];
const edges = [0, 0.05, 0.1, 0.2, 0.3, 0.45, 0.6, 1.01];
const bins = edges.slice(0, -1).map(() => ({ n: 0, p: 0, y: 0 }));
te.forEach(r => {
  const p = 1 / (1 + Math.exp(-T.predict(m, r.x)));
  brier += (p - r.y) ** 2; brierClim += (base - r.y) ** 2;
  scored.push({ s: p, y: r.y });
  const cape = Math.max(0, r.env.cape), sh = Math.max(0, r.env.shear6);
  wmax.push({ s: Math.sqrt(2 * cape) * sh, y: r.y });
  idx.push({ s: cape / 1000 * Math.min(2, sh / 20) * Math.abs(r.env.srh1 || 0) / 150, y: r.y });
  for (let k = 0; k < edges.length - 1; k++) {
    if (p >= edges[k] && p < edges[k + 1]) { bins[k].n++; bins[k].p += p; bins[k].y += r.y; break; }
  }
});
const ev = {
  stations: new Set(rows.map(r => r.id)).size, days: days.length, heldOutDays: testDays.size,
  trainN: tr.length, testN: te.length, reports: lsr.length,
  trainBase: T.r3(base), baseRate: T.r3(te.reduce((a, r) => a + r.y, 0) / te.length),
  bss: T.r3(1 - brier / brierClim), auc: T.r3(T.auc(scored)),
  aucWmaxshear: T.r3(T.auc(wmax)), aucIndex: T.r3(T.auc(idx)),
  reliability: bins.map((b, k) => ({ from: edges[k], to: Math.min(1, edges[k + 1]), n: b.n,
    forecast: b.n ? T.r3(b.p / b.n) : null, observed: b.n ? T.r3(b.y / b.n) : null })).filter(b => b.n)
};
const ship = ev.bss > 0 && ev.auc > ev.aucWmaxshear && ev.auc > ev.aucIndex;
console.log(JSON.stringify(ev, null, 1), '\nship', ship);

const out = { ship, eval: ev, radiusKm: RADIUS_KM, trained: new Date().toISOString().slice(0, 10),
  first: days[0], last: days[days.length - 1],
  b: T.r3(m.b), w: m.w.map(T.r3), mean: m.mean.map(T.r3), std: m.std.map(T.r3) };
fs.writeFileSync(OUT,
  '/* GENERATED by scripts/train/env.js — do not edit. The chase-day model, fitted on\n' +
  ' * Iowa State\'s archived upper-air soundings and local storm reports, with its\n' +
  ' * held-out evaluation. See js/chaseday.js for what it is and is not. */\n' +
  '(function (global) {\n  global.ChaseDayWeights = ' + JSON.stringify(out, null, 1).replace(/\n/g, '\n  ') +
  ';\n})(typeof window !== \'undefined\' ? window : globalThis);\n');
console.log('wrote', path.relative(ROOT, OUT));
