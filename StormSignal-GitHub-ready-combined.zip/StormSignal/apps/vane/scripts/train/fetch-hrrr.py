"""Download the training environments for the Vane Storm Odds model.

    python3 -m venv .venv && .venv/bin/pip install pygrib numpy
    .venv/bin/python scripts/train/fetch-hrrr.py

NOAA's HRRR analyses (the 3 km model's best estimate of the atmosphere at
each hour) from the public, keyless AWS Open Data archive. Only the fields
the app can read live from Open-Meteo are taken -- surface CAPE and CIN,
lifted index, 2 m dewpoint, precipitable water, and the wind at 10 m,
850 hPa and 500 hPa -- each fetched alone with an HTTP range request from
the archive's .idx byte index, so a 130 MB file costs ~8 MB.

Deliberately NOT taken: reflectivity, updraft helicity, precipitation.
Those are the storms themselves; a model fed them would learn that storms
are where storms are.

Sample: April-July 2023 and 2024, every fourth day, every third hour --
quiet days and night hours included, systematically. Land points only
(over water reports are rare for want of people, not storms), every 12th
grid point (~36 km). Saved as float32 arrays in scripts/train/data/hrrr/.
"""
import datetime as dt
import os
import sys
import tempfile
import urllib.request
from concurrent.futures import ThreadPoolExecutor

import numpy as np
import pygrib

BASE = 'https://noaa-hrrr-bdp-pds.s3.amazonaws.com/hrrr.{d}/conus/hrrr.t{h:02d}z.wrfsfcf00.grib2'
OUT = os.path.join(os.path.dirname(__file__), 'data', 'hrrr')
STRIDE = 12
# (idx variable, idx level) in the order the arrays are stored; storm.js
# reads them by this order.
FIELDS = [
    ('CAPE', 'surface'), ('CIN', 'surface'), ('LFTX', '500-1000 mb'),
    ('DPT', '2 m above ground'), ('PWAT', 'entire atmosphere (considered as a single layer)'),
    ('UGRD', '10 m above ground'), ('VGRD', '10 m above ground'),
    ('UGRD', '850 mb'), ('VGRD', '850 mb'), ('UGRD', '500 mb'), ('VGRD', '500 mb'),
]
LAND = ('LAND', 'surface')


def get(url, rng=None, tries=4):
    for k in range(tries):
        try:
            req = urllib.request.Request(url, headers={'Range': 'bytes=%d-%d' % rng} if rng else {})
            with urllib.request.urlopen(req, timeout=60) as r:
                return r.read()
        except Exception as e:  # noqa: BLE001 -- retry anything transient
            if k == tries - 1:
                raise
    return None


def ranges(url, wanted):
    lines = get(url + '.idx').decode().strip().split('\n')
    starts = [int(l.split(':')[1]) for l in lines]
    out = {}
    for i, l in enumerate(lines):
        p = l.split(':')
        key = (p[3], p[4])
        if key in wanted and key not in out:
            out[key] = (starts[i], starts[i + 1] - 1 if i + 1 < len(starts) else None)
    return out


def fields(url, wanted):
    r = ranges(url, wanted)
    missing = [w for w in wanted if w not in r]
    if missing:
        raise RuntimeError('missing %s' % missing)
    blob = b''.join(get(url, r[w]) for w in wanted)
    with tempfile.NamedTemporaryFile(suffix='.grb2') as f:
        f.write(blob)
        f.flush()
        g = pygrib.open(f.name)
        arrs = [m.values[::STRIDE, ::STRIDE].astype(np.float32) for m in g]
        lats, lons = g.message(1).latlons()
        g.close()
    return arrs, lats[::STRIDE, ::STRIDE], lons[::STRIDE, ::STRIDE]


def one(stamp, mask):
    d, h = stamp
    out = os.path.join(OUT, '%s_%02d.npy' % (d, h))
    if os.path.exists(out):
        return 'cached'
    try:
        arrs, _, _ = fields(BASE.format(d=d, h=h), FIELDS)
    except Exception as e:  # noqa: BLE001
        return 'FAILED %s' % e
    np.save(out, np.stack([a[mask] for a in arrs], axis=1))
    return 'ok'


def main():
    os.makedirs(OUT, exist_ok=True)
    grid = os.path.join(OUT, 'grid.npy')
    if not os.path.exists(grid):
        arrs, lats, lons = fields(BASE.format(d='20240501', h=0), [LAND])
        mask = arrs[0] > 0.5
        np.save(grid, np.stack([lats[mask], lons[mask]], axis=1).astype(np.float32))
        np.save(os.path.join(OUT, 'mask.npy'), mask)
    mask = np.load(os.path.join(OUT, 'mask.npy'))
    stamps = []
    for year in (2023, 2024):
        day = dt.date(year, 4, 1)
        while day <= dt.date(year, 7, 31):
            stamps += [(day.strftime('%Y%m%d'), h) for h in range(0, 24, 3)]
            day += dt.timedelta(days=4)
    print('%d analyses, %d land points each' % (len(stamps), int(mask.sum())), flush=True)
    with ThreadPoolExecutor(8) as pool:
        for s, res in zip(stamps, pool.map(lambda s: one(s, mask), stamps)):
            if res != 'cached':
                print(s, res, flush=True)


if __name__ == '__main__':
    sys.exit(main())
