/* Train and evaluate Vane Storm Odds; write js/stormodds-weights.js.
 *
 *   .venv/bin/python scripts/train/fetch-hrrr.py   (HRRR analyses)
 *   node scripts/train/fetch-env.js                (storm reports, if not cached)
 *   node scripts/train/storm.js
 *
 * One sample per land grid point (~36 km apart) per analysis hour: the
 * HRRR's analysed environment there, and whether a severe local storm
 * report (tornado, hail ≥ 1", gust ≥ 58 mph, thunderstorm wind damage) was
 * made within 40 km in the next three hours.
 *
 * Features come from js/stormodds.js featuresOf(), the function the app
 * runs. Days are split three ways, whole days at a time: every fourth day
 * is held out as the TEST set, never seen by any fit or choice; another
 * quarter VALIDATES (early stopping, and logistic vs neural network); the
 * rest TRAINS. Quiet negatives are thinned 1-in-8 for training and weighted
 * back up, so the probabilities stay calibrated; the test set keeps every
 * sample. The model ships only if, on the test days, it beats climatology
 * (Brier skill) AND out-ranks CAPE alone and CAPE × shear (WMAXSHEAR). */
const fs = require('fs'), path = require('path'), vm = require('vm');
const T = require('./train.js');

const ROOT = path.join(__dirname, '..', '..');
const DATA = path.join(__dirname, 'data');
const HRRR = path.join(DATA, 'hrrr');
const OUT = path.join(ROOT, 'js', 'stormodds-weights.js');
const RADIUS_KM = 40, WINDOW_H = 3, NEG_KEEP = 8, HIDDEN = 16;

const sandbox = { console }; sandbox.window = sandbox; sandbox.globalThis = sandbox;
vm.createContext(sandbox);
vm.runInContext(fs.readFileSync(path.join(ROOT, 'js', 'stormodds.js'), 'utf8'), sandbox);
const { StormOdds } = sandbox;
const NF = StormOdds.FEATURES.length;

function readNpy(file) {
  const b = fs.readFileSync(file);
  const hl = b.readUInt16LE(8), header = b.toString('latin1', 10, 10 + hl);
  if (!/'descr': '<f4'/.test(header) || /'fortran_order': True/.test(header)) throw new Error('unexpected npy ' + file);
  const shape = /'shape': \((\d+), (\d+)\)/.exec(header).slice(1).map(Number);
  const ab = new ArrayBuffer(shape[0] * shape[1] * 4);
  b.copy(Buffer.from(ab), 0, 10 + hl);
  return { rows: shape[0], cols: shape[1], data: new Float32Array(ab) };
}

// Deterministic thinning: the same samples on every run.
function keep(i, t) { let h = (i * 2654435761 + t / 3600000 * 40503) >>> 0; h ^= h >>> 15; return h % NEG_KEEP === 0; }

/* ── Data ─────────────────────────────────────────────────────────── */
const grid = readNpy(path.join(HRRR, 'grid.npy'));
const N = grid.rows, lat = new Float64Array(N), lon = new Float64Array(N);
for (let i = 0; i < N; i++) { lat[i] = grid.data[2 * i]; lon[i] = grid.data[2 * i + 1]; }

let lsr = [];
fs.readdirSync(DATA).filter(f => /^lsrmonth-/.test(f)).forEach(f => { lsr = lsr.concat(T.readLsr(path.join(DATA, f))); });
lsr.sort((a, b) => a.t - b.t);
const seen = new Set();
lsr = lsr.filter(r => { const k = r.t + ':' + r.lat + ':' + r.lon + ':' + r.type; if (seen.has(k)) return false; seen.add(k); return true; });

const files = fs.readdirSync(HRRR).filter(f => /^\d{8}_\d{2}\.npy$/.test(f)).sort();
const days = Array.from(new Set(files.map(f => f.slice(0, 8)))).sort();
const role = {};
days.forEach((d, i) => { role[d] = i % 4 === 3 ? 'test' : i % 4 === 2 ? 'val' : 'train'; });

function makeSet() { return { x: [], y: [], w: [], cape: [], wmax: [] }; }
const sets = { train: makeSet(), val: makeSet(), test: makeSet() };
let reportsUsed = 0;
const DLAT = RADIUS_KM / 111;

files.forEach(f => {
  const day = f.slice(0, 8), hr = +f.slice(9, 11);
  const t = Date.UTC(+day.slice(0, 4), +day.slice(4, 6) - 1, +day.slice(6, 8), hr);
  const a = readNpy(path.join(HRRR, f));
  if (a.rows !== N) throw new Error('grid mismatch ' + f);
  const reps = [];
  for (let k = T.lowerBound(lsr, t); k < lsr.length && lsr[k].t < t + WINDOW_H * 3600000; k++) reps.push(lsr[k]);
  reportsUsed += reps.length;
  const S = sets[role[day]];
  for (let i = 0; i < N; i++) {
    let y = 0;
    for (let k = 0; k < reps.length && !y; k++) {
      const r = reps[k];
      if (Math.abs(r.lat - lat[i]) > DLAT) continue;
      if (T.km(lat[i], lon[i], r.lat, r.lon) <= RADIUS_KM) y = 1;
    }
    let w = 1;
    if (!y && role[day] !== 'test') { if (!keep(i, t)) continue; w = NEG_KEEP; }
    const o = i * a.cols, v = a.data;
    const env = { cape: v[o], cin: v[o + 1], li: v[o + 2], td: v[o + 3] - 273.15, pwat: v[o + 4],
                  u10: v[o + 5], v10: v[o + 6], u850: v[o + 7], v850: v[o + 8], u500: v[o + 9], v500: v[o + 10] };
    const x = StormOdds.featuresOf(env, t, lon[i]);
    S.x.push(Float32Array.from(x)); S.y.push(y); S.w.push(w);
    S.cape.push(Math.max(0, env.cape)); S.wmax.push(x[8]);
  }
});
const count = s => ({ n: s.y.length, pos: s.y.reduce((a, b) => a + b, 0) });
console.log('analyses', files.length, 'days', days.length, 'points', N, 'reports in windows', reportsUsed);
console.log('train', count(sets.train), 'val', count(sets.val), 'test', count(sets.test));

/* ── Fitting: weighted log loss, Adam, early stopping on validation ── */
const tr = sets.train;
const mean = new Array(NF).fill(0), std = new Array(NF).fill(0);
let wsum = 0;
tr.x.forEach((x, n) => { wsum += tr.w[n]; for (let i = 0; i < NF; i++) mean[i] += tr.w[n] * x[i]; });
for (let i = 0; i < NF; i++) mean[i] /= wsum;
tr.x.forEach((x, n) => { for (let i = 0; i < NF; i++) std[i] += tr.w[n] * (x[i] - mean[i]) ** 2; });
for (let i = 0; i < NF; i++) std[i] = Math.sqrt(std[i] / wsum) || 1;
const zs = x => Array.from(x, (v, i) => Math.max(-5, Math.min(5, (v - mean[i]) / std[i])));
const Z = { train: sets.train.x.map(zs), val: sets.val.x.map(zs), test: sets.test.x.map(zs) };

let seed = 12345;
const rand = () => { seed = (seed * 1664525 + 1013904223) >>> 0; return seed / 4294967296; };
const gauss = () => Math.sqrt(-2 * Math.log(rand() + 1e-12)) * Math.cos(2 * Math.PI * rand());

function newModel(kind) {
  if (kind === 'logistic') return { kind, b: Math.log(0.01 / 0.99), w: new Array(NF).fill(0) };
  return { kind, b2: Math.log(0.01 / 0.99), w2: Array.from({ length: HIDDEN }, () => gauss() * 0.1),
           b1: new Array(HIDDEN).fill(0), W1: Array.from({ length: HIDDEN }, () => Array.from({ length: NF }, () => gauss() / Math.sqrt(NF))) };
}
function flat(m) { return m.kind === 'logistic' ? [m.b].concat(m.w) : [m.b2].concat(m.w2, m.b1, [].concat(...m.W1)); }
function unflat(m, p) {
  if (m.kind === 'logistic') { m.b = p[0]; m.w = p.slice(1); return m; }
  let k = 0; m.b2 = p[k++]; m.w2 = p.slice(k, k += HIDDEN); m.b1 = p.slice(k, k += HIDDEN);
  m.W1 = Array.from({ length: HIDDEN }, () => p.slice(k, k += NF)); return m;
}
// Forward and gradient of the weighted log loss for one sample.
function step(m, s, y, w, g) {
  if (m.kind === 'logistic') {
    let z = m.b; for (let i = 0; i < NF; i++) z += m.w[i] * s[i];
    const p = 1 / (1 + Math.exp(-z)), d = w * (p - y);
    g[0] += d; for (let i = 0; i < NF; i++) g[1 + i] += d * s[i];
    return p;
  }
  const h = new Array(HIDDEN);
  let z = m.b2;
  for (let j = 0; j < HIDDEN; j++) { let a = m.b1[j]; const r = m.W1[j]; for (let i = 0; i < NF; i++) a += r[i] * s[i]; h[j] = Math.tanh(a); z += m.w2[j] * h[j]; }
  const p = 1 / (1 + Math.exp(-z)), d = w * (p - y);
  g[0] += d;
  for (let j = 0; j < HIDDEN; j++) {
    g[1 + j] += d * h[j];
    const da = d * m.w2[j] * (1 - h[j] * h[j]);
    g[1 + HIDDEN + j] += da;
    const o = 1 + 2 * HIDDEN + j * NF;
    for (let i = 0; i < NF; i++) g[o + i] += da * s[i];
  }
  return p;
}
function predict(m, s) {
  const p = step(m, s, 0, 0, new Array(flat(m).length).fill(0));
  return m.calib ? isotonic(m.calib, p) : p;
}
// Piecewise-linear through the knots; flat beyond the ends. Shared with
// js/stormodds.js, which applies the same map in the app.
function isotonic(c, p) { return StormOdds.isotonic(c, p); }
function logloss(m, Zs, S) {
  let l = 0, w = 0;
  Zs.forEach((s, n) => { const p = Math.min(1 - 1e-7, Math.max(1e-7, predict(m, s))); l -= S.w[n] * (S.y[n] ? Math.log(p) : Math.log(1 - p)); w += S.w[n]; });
  return l / w;
}

function fit(kind) {
  let m = newModel(kind), p = flat(m);
  const mo = p.map(() => 0), ve = p.map(() => 0), L2 = 1e-5, LR = kind === 'logistic' ? 0.01 : 0.003, B = 512;
  let best = Infinity, bestP = p.slice(), bad = 0, t = 0;
  const order = Z.train.map((_, i) => i);
  for (let epoch = 1; epoch <= 40; epoch++) {
    for (let i = order.length - 1; i > 0; i--) { const j = Math.floor(rand() * (i + 1)); [order[i], order[j]] = [order[j], order[i]]; }
    for (let s0 = 0; s0 < order.length; s0 += B) {
      const g = p.map(() => 0); let ws = 0;
      for (let k = s0; k < Math.min(order.length, s0 + B); k++) { const n = order[k]; step(m, Z.train[n], tr.y[n], tr.w[n], g); ws += tr.w[n]; }
      t++;
      for (let i = 0; i < p.length; i++) {
        const gi = g[i] / ws + L2 * p[i];
        mo[i] = 0.9 * mo[i] + 0.1 * gi; ve[i] = 0.999 * ve[i] + 0.001 * gi * gi;
        p[i] -= LR * (mo[i] / (1 - 0.9 ** t)) / (Math.sqrt(ve[i] / (1 - 0.999 ** t)) + 1e-8);
      }
      unflat(m, p);
    }
    const v = logloss(m, Z.val, sets.val);
    console.log(kind, 'epoch', epoch, 'val logloss', v.toFixed(5));
    if (v < best - 1e-5) { best = v; bestP = p.slice(); bad = 0; } else if (++bad >= 3) break;
  }
  return { model: unflat(m, bestP), val: best };
}

/* ── Evaluation on the test days ────────────────────────────────────── */
function evaluate(m) {
  const te = sets.test, base = tr.y.reduce((a, y, n) => a + y * tr.w[n], 0) / wsum;
  let brier = 0, clim = 0;
  const scored = [], edges = [0, 0.01, 0.02, 0.05, 0.1, 0.2, 0.3, 0.5, 1.01];
  const bins = edges.slice(0, -1).map(() => ({ n: 0, p: 0, y: 0 }));
  Z.test.forEach((s, n) => {
    const p = predict(m, s), y = te.y[n];
    brier += (p - y) ** 2; clim += (base - y) ** 2; scored.push({ s: p, y });
    const b = edges.findIndex((e, i) => p >= e && p < edges[i + 1]); bins[b].n++; bins[b].p += p; bins[b].y += y;
  });
  return { auc: T.auc(scored), bss: 1 - brier / clim, base,
           reliability: bins.map((b, i) => ({ from: edges[i], to: Math.min(1, edges[i + 1]), n: b.n,
             forecast: b.n ? +(b.p / b.n).toFixed(4) : null, observed: b.n ? +(b.y / b.n).toFixed(4) : null })) };
}

const fits = ['logistic', 'mlp'].map(fit);
fits.forEach(f => console.log(f.model.kind, 'best val logloss', f.val.toFixed(5)));
const chosen = fits.reduce((a, b) => (b.val < a.val ? b : a));

/* Recalibration, fitted on the VALIDATION days. The raw net ran a little
 * low below 20% and far too high above it: its "37%" verified at 8% on the
 * first run, and a smooth two-number (Platt) correction left the top band
 * at "38%" → 12%, because there the truth FALLS as the score rises.
 * Isotonic regression (pool-adjacent-violators) is the honest fix: the
 * map from raw score to odds must rise, so the unreliable top is pooled
 * with what is below it, and the model can claim no more than it has
 * shown. Bins of 0.25 in log-odds; stored as knots the app interpolates. */
function fitCalibration(m) {
  const bins = new Map();
  Z.val.forEach((s, n) => {
    const p = Math.min(1 - 1e-9, Math.max(1e-9, predict(m, s)));
    const k = Math.floor(Math.log(p / (1 - p)) / 0.25);
    const b = bins.get(k) || { w: 0, wp: 0, wy: 0 };
    const w = sets.val.w[n];
    b.w += w; b.wp += w * p; b.wy += w * sets.val.y[n];
    bins.set(k, b);
  });
  // Pool adjacent violators over the bins, in score order.
  const blocks = [];
  Array.from(bins.keys()).sort((a, b) => a - b).forEach(k => {
    const b = bins.get(k);
    blocks.push({ w: b.w, wp: b.wp, wy: b.wy });
    while (blocks.length > 1 && blocks[blocks.length - 2].wy / blocks[blocks.length - 2].w >= blocks[blocks.length - 1].wy / blocks[blocks.length - 1].w) {
      const top = blocks.pop(), under = blocks[blocks.length - 1];
      under.w += top.w; under.wp += top.wp; under.wy += top.wy;
    }
  });
  return { x: blocks.map(b => b.wp / b.w), y: blocks.map(b => b.wy / b.w) };
}
fits.forEach(f => { f.model.calib = fitCalibration(f.model); });
console.log('isotonic knots', chosen.model.calib.x.length, 'top', chosen.model.calib.y[chosen.model.calib.y.length - 1].toFixed(4));
const evals = {};
fits.forEach(f => { evals[f.model.kind] = evaluate(f.model); });
const te = sets.test;
const aucCape = T.auc(te.cape.map((s, n) => ({ s, y: te.y[n] })));
const aucWmax = T.auc(te.wmax.map((s, n) => ({ s, y: te.y[n] })));
const E = evals[chosen.model.kind];
/* The headline AUC flatters every score: most samples are cold, stable
 * night hours anything gets right. The decision a chaser faces is among
 * environments that COULD produce storms, so the model must also win there:
 * the test samples with CAPE ≥ 500 J/kg, against CAPE × shear. */
const hard = [];
te.cape.forEach((c, n) => { if (c >= 500) hard.push(n); });
const aucHard = T.auc(hard.map(n => ({ s: predict(chosen.model, Z.test[n]), y: te.y[n] })));
const aucHardWmax = T.auc(hard.map(n => ({ s: te.wmax[n], y: te.y[n] })));
const aucHardCape = T.auc(hard.map(n => ({ s: te.cape[n], y: te.y[n] })));
console.log('CAPE >= 500 subset', hard.length, 'samples:', { aucHard, aucHardWmax, aucHardCape });
const ship = E.bss > 0 && E.auc > aucCape && E.auc > aucWmax && aucHard > aucHardWmax && aucHard > aucHardCape;
console.log(JSON.stringify({ chosen: chosen.model.kind, logistic: { auc: evals.logistic.auc, bss: evals.logistic.bss },
  mlp: { auc: evals.mlp.auc, bss: evals.mlp.bss }, aucCape, aucWmax, ship }, null, 1));
console.log(JSON.stringify(E.reliability));

const r5 = v => +(+v).toPrecision(5);
const m = chosen.model;
const W = {
  ship, kind: m.kind, radiusKm: RADIUS_KM, windowHours: WINDOW_H,
  trained: new Date().toISOString().slice(0, 10), first: days[0], last: days[days.length - 1],
  eval: {
    analyses: files.length, days: days.length, heldOutDays: days.filter(d => role[d] === 'test').length,
    points: N, trainN: tr.y.length, testN: te.y.length, testPositives: te.y.reduce((a, b) => a + b, 0),
    reports: reportsUsed, baseRate: +E.base.toFixed(5), auc: +E.auc.toFixed(3), bss: +E.bss.toFixed(3),
    aucCape: +aucCape.toFixed(3), aucWmaxshear: +aucWmax.toFixed(3),
    unstable: { minCape: 500, n: hard.length, positives: hard.reduce((a, n) => a + te.y[n], 0),
                auc: +aucHard.toFixed(3), aucWmaxshear: +aucHardWmax.toFixed(3), aucCape: +aucHardCape.toFixed(3) },
    other: { kind: fits.find(f => f !== chosen).model.kind, auc: +evals[fits.find(f => f !== chosen).model.kind].auc.toFixed(3),
             bss: +evals[fits.find(f => f !== chosen).model.kind].bss.toFixed(3) },
    reliability: E.reliability
  },
  mean: mean.map(r5), std: std.map(r5)
};
W.calib = { x: m.calib.x.map(r5), y: m.calib.y.map(r5) };
if (m.kind === 'mlp') { W.b2 = r5(m.b2); W.w2 = m.w2.map(r5); W.b1 = m.b1.map(r5); W.W1 = m.W1.map(r => r.map(r5)); }
else { W.b = r5(m.b); W.w = m.w.map(r5); }
fs.writeFileSync(OUT, '/* GENERATED by scripts/train/storm.js — do not edit. Vane Storm Odds, fitted on NOAA HRRR\n' +
  ' * analyses and NWS local storm reports, with its held-out evaluation. See js/stormodds.js for\n' +
  ' * what it is and is not. */\n(function (global) {\n  global.StormOddsWeights = ' +
  JSON.stringify(W, null, 1).replace(/\n/g, '\n  ') + ';\n})(typeof window !== \'undefined\' ? window : globalThis);\n');
console.log('wrote', OUT, 'ship', ship);
