/* Train and check Vane Ground Truth; write js/groundtruth-weights.js.
 *
 *   node scripts/train/fetch.js        (NEXRAD storm attributes + reports, cached)
 *   node scripts/train/popgrid.js      (Census population grid)
 *   node scripts/train/groundtruth.js [--data-dir DIR] [--out-dir DIR]
 *
 * One sample per scan of every convective cell (≥ 35 dBZ) on the archived
 * days: its radar signature, the people along its next half hour, the
 * local hour — and whether a severe report (tornado, hail ≥ 1", gust ≥
 * 58 mph, wind damage) came within 15 km of it from 5 minutes before to
 * 30 minutes after, exactly as Vane's severe model is labelled.
 *
 * Three models are fitted on the same training days and judged on whole
 * days none of them saw:
 *   M0  radar only — what Vane (and most severe models) do today
 *   M1  radar + people, one logistic — does population matter at all?
 *   GT  σ(f(radar)) × σ(g(people, hour)) — occurring × witnessed
 * GT ships only if it predicts the real reports on unseen days better than
 * M0 in log loss AND AUC, no more than 0.0005 worse than M1 in log loss,
 * its witness curve
 * rises with population, and — on synthetic reports drawn from a known
 * occurrence × detection truth — refitting recovers that truth. The last
 * check is a simulation sanity check, not proof that the latent occurrence
 * and detection probabilities are identified by real report-only labels. */
const fs = require('fs'), path = require('path'), vm = require('vm');
const crypto = require('crypto');
const T = require('./train.js');
const Evaluation = require('./groundtruth-eval.js');

const ROOT = path.join(__dirname, '..', '..');
const options = {};
for (let i = 2; i < process.argv.length; i += 2) {
  const key = process.argv[i], value = process.argv[i + 1];
  if (!['--data-dir', '--out-dir'].includes(key) || !value || value.startsWith('--')) {
    throw new Error('Usage: node scripts/train/groundtruth.js [--data-dir DIR] [--out-dir DIR]');
  }
  options[key] = path.resolve(value);
}
const DATA = options['--data-dir'] || path.join(__dirname, 'data');
const OUT = path.join(options['--out-dir'] || path.join(ROOT, 'js'), 'groundtruth-weights.js');
const EVAL_OUT = path.join(options['--out-dir'] || path.join(ROOT, 'docs'), 'groundtruth-evaluation.json');
const MIN_DBZ = 35, SEV_WINDOW = [-5, 30], SEV_KM = 15;

// A partial cache must not silently move dates between train/validation/test.
const days = Evaluation.scheduledDays();
const dataFiles = ['popgrid.bin', ...days.flatMap(d => ['attrs-' + d + '.csv', 'lsr-' + d + '.csv'])];
const missing = dataFiles.filter(f => !fs.existsSync(path.join(DATA, f)));
if (missing.length) throw new Error('Incomplete Ground Truth dataset; run fetch.js and popgrid.js. Missing: ' + missing.join(', '));
const cachedDays = fs.readdirSync(DATA).filter(f => /^attrs-.*\.csv$/.test(f)).map(f => f.slice(6, 16)).sort();
if (JSON.stringify(cachedDays) !== JSON.stringify(days)) {
  throw new Error('Archive dates differ from the fixed 50-day evaluation schedule; use a separate data directory.');
}
const split = Evaluation.splitDays(days), role = {};
Object.entries(split).forEach(([name, dates]) => dates.forEach(d => { role[d] = name; }));
const digest = file => crypto.createHash('sha256').update(fs.readFileSync(file)).digest('hex');
const inputs = dataFiles.map(file => ({ file, bytes: fs.statSync(path.join(DATA, file)).size,
  sha256: digest(path.join(DATA, file)) }));

const sandbox = { console }; sandbox.window = sandbox; sandbox.globalThis = sandbox;
vm.createContext(sandbox);
['js/config.js', 'js/util.js', 'js/stormmodel.js', 'js/popgrid.js', 'js/groundtruth.js'].forEach(f =>
  vm.runInContext(fs.readFileSync(path.join(ROOT, f), 'utf8'), sandbox, { filename: f }));
const { GroundTruth: GT } = sandbox;
const G = GT.GRID;

// The population grid, as the app decodes it: RGBA, no PNG filter bytes.
const raw = fs.readFileSync(path.join(DATA, 'popgrid.bin'));
if (raw.length !== G.rows * (1 + G.cols * 4) ||
    Array.from({ length: G.rows }, (_, r) => raw[r * (1 + G.cols * 4)]).some(f => f !== 0)) {
  throw new Error('popgrid.bin must contain the complete unfiltered RGBA grid');
}
const grid = { data: new Uint8Array(G.rows * G.cols * 4) };
for (let r = 0; r < G.rows; r++) raw.copy(Buffer.from(grid.data.buffer), r * G.cols * 4, r * (1 + G.cols * 4) + 1, (r + 1) * (1 + G.cols * 4));

/* ── Samples ─────────────────────────────────────────────────────────── */
const sets = { train: [], val: [], test: [] };
const dayCounts = [];
let reports = 0, offGrid = 0;
days.forEach(day => {
  const before = sets[role[day]].length, offBefore = offGrid;
  const archiveStart = Date.parse(day + 'T12:00:00Z'), archiveEnd = archiveStart + 86400000;
  let boundaryScans = 0, boundaryNegativeScans = 0;
  const trs = T.tracks(T.readAttrs(path.join(DATA, 'attrs-' + day + '.csv')));
  const lsr = T.readLsr(path.join(DATA, 'lsr-' + day + '.csv'));
  reports += lsr.length;
  trs.forEach(tr => tr.forEach(r => {
    if (r.cell.maxDbz < MIN_DBZ) return;
    const xd = GT.detectFeatures(r.cell, r.lat, r.lon, r.t, grid);
    if (!xd) { offGrid++; return; }
    let y = 0;
    const t0 = r.t + SEV_WINDOW[0] * 60000, t1 = r.t + SEV_WINDOW[1] * 60000;
    for (let k = T.lowerBound(lsr, t0); k < lsr.length && lsr[k].t <= t1 && !y; k++) {
      const p = T.posAt(tr, lsr[k].t);
      if (T.km(p.lat, p.lon, lsr[k].lat, lsr[k].lon) <= SEV_KM) y = 1;
    }
    // Diagnostic only in the baseline audit: labels outside the downloaded
    // report window are unknown. Do not silently change the historical fit.
    if (t0 < archiveStart || t1 > archiveEnd) { boundaryScans++; if (!y) boundaryNegativeScans++; }
    sets[role[day]].push({ xr: Array.from(GT.radarFeatures(r.cell)), xd: Array.from(xd), y, day });
  }));
  const rows = sets[role[day]].slice(before);
  dayCounts.push({ day, role: role[day], n: rows.length,
    positiveScans: rows.reduce((n, r) => n + r.y, 0), qualifyingArchiveReportRows: lsr.length,
    boundaryWindowScans: boundaryScans, boundaryWindowNegativeScans: boundaryNegativeScans,
    offGridScans: offGrid - offBefore });
  process.stdout.write('.');
});
const pos = s => s.reduce((a, r) => a + r.y, 0);
if (Object.values(sets).some(s => !s.length || !pos(s) || pos(s) === s.length)) {
  throw new Error('Every split must contain both positive and negative cell scans');
}
console.log('\nDay split:', Object.fromEntries(Object.entries(split).map(([k, v]) => [k, v.length])));
console.log('\n' + days.length + ' days; train', sets.train.length, pos(sets.train), '| val', sets.val.length, pos(sets.val),
  '| test', sets.test.length, pos(sets.test), '| reports', reports, '| off grid', offGrid);

/* ── Standardisation (training days only) ───────────────────────────── */
function stats(rows, key) {
  const n = rows[0][key].length, mean = new Array(n).fill(0), std = new Array(n).fill(0);
  rows.forEach(r => r[key].forEach((v, i) => { mean[i] += v; }));
  mean.forEach((_, i) => { mean[i] /= rows.length; });
  rows.forEach(r => r[key].forEach((v, i) => { std[i] += (v - mean[i]) ** 2; }));
  return { mean, std: std.map(s => Math.sqrt(s / rows.length) || 1) };
}
const SR = stats(sets.train, 'xr'), SD = stats(sets.train, 'xd');
const z = (x, S) => x.map((v, i) => Math.max(-5, Math.min(5, (v - S.mean[i]) / S.std[i])));
Object.values(sets).forEach(s => s.forEach(r => { r.zr = z(r.xr, SR); r.zd = z(r.xd, SD); r.zrd = r.zr.concat(r.zd); }));

/* ── Fitting: Adam on the log-likelihood ────────────────────────────── */
let seed = 7;
const rand = () => { seed = (seed * 1664525 + 1013904223) >>> 0; return seed / 4294967296; };
const sig = v => 1 / (1 + Math.exp(-v));
const dot = (w, x) => { let s = 0; for (let i = 0; i < x.length; i++) s += w[i] * x[i]; return s; };

// kind 'logit' over key ('zr' or 'zrd'), or 'gt': σ(b + w·zr) × σ(c + v·zd).
function predictP(m, r) {
  if (m.kind === 'logit') return sig(m.b + dot(m.w, r[m.key]));
  return sig(m.b + dot(m.w, r.zr)) * sig(m.c + dot(m.v, r.zd));
}
function newModel(kind, key, init) {
  const nr = SR.mean.length, nd = SD.mean.length;
  if (kind === 'logit') return { kind, key, b: -3, w: new Array(key === 'zr' ? nr : nr + nd).fill(0) };
  return Object.assign({ kind, b: -2, w: new Array(nr).fill(0), c: 1, v: new Array(nd).fill(0) }, init || {});
}
function params(m) { return m.kind === 'logit' ? [m.b, ...m.w] : [m.b, ...m.w, m.c, ...m.v]; }
function setParams(m, p) {
  if (m.kind === 'logit') { m.b = p[0]; m.w = p.slice(1); return; }
  const nr = m.w.length; m.b = p[0]; m.w = p.slice(1, 1 + nr); m.c = p[1 + nr]; m.v = p.slice(2 + nr);
}
function grad(m, r, g) {
  const y = r.y;
  if (m.kind === 'logit') {
    const p = sig(m.b + dot(m.w, r[m.key])), d = p - y, x = r[m.key];
    g[0] += d; for (let i = 0; i < x.length; i++) g[1 + i] += d * x[i];
    return;
  }
  const a = sig(m.b + dot(m.w, r.zr)), q = sig(m.c + dot(m.v, r.zd)), p = Math.min(1 - 1e-9, Math.max(1e-9, a * q));
  // d(-loglik)/dp, then the chain through each sigmoid.
  const dp = (p - y) / (p * (1 - p));
  const da = dp * q * a * (1 - a), dq = dp * a * q * (1 - q), nr = m.w.length;
  g[0] += da; for (let i = 0; i < nr; i++) g[1 + i] += da * r.zr[i];
  g[1 + nr] += dq; for (let i = 0; i < r.zd.length; i++) g[2 + nr + i] += dq * r.zd[i];
}
function logloss(m, rows, ykey) {
  let l = 0;
  rows.forEach(r => { const p = Math.min(1 - 1e-9, Math.max(1e-9, predictP(m, r))), y = ykey ? r[ykey] : r.y; l -= y ? Math.log(p) : Math.log(1 - p); });
  return l / rows.length;
}
function fit(m, train, val, label, ykey) {
  const get = ykey ? (r => Object.assign({}, r, { y: r[ykey] })) : (r => r);
  const tr = ykey ? train.map(get) : train, va = ykey ? val.map(get) : val;
  let p = params(m);
  const mo = p.map(() => 0), ve = p.map(() => 0), LR = 0.01, B = 1024, L2 = 1e-5;
  let best = Infinity, bestP = p.slice(), bad = 0, t = 0, bestEpoch = 0, epochsRun = 0;
  const order = tr.map((_, i) => i);
  for (let epoch = 1; epoch <= 30; epoch++) {
    epochsRun = epoch;
    for (let i = order.length - 1; i > 0; i--) { const j = Math.floor(rand() * (i + 1)); [order[i], order[j]] = [order[j], order[i]]; }
    for (let s0 = 0; s0 < order.length; s0 += B) {
      const g = p.map(() => 0), end = Math.min(order.length, s0 + B);
      for (let k = s0; k < end; k++) grad(m, tr[order[k]], g);
      t++;
      for (let i = 0; i < p.length; i++) {
        const gi = g[i] / (end - s0) + L2 * p[i];
        mo[i] = 0.9 * mo[i] + 0.1 * gi; ve[i] = 0.999 * ve[i] + 0.001 * gi * gi;
        p[i] -= LR * (mo[i] / (1 - 0.9 ** t)) / (Math.sqrt(ve[i] / (1 - 0.999 ** t)) + 1e-8);
      }
      setParams(m, p);
    }
    const v = logloss(m, va);
    if (v < best - 1e-6) { best = v; bestP = p.slice(); bestEpoch = epoch; bad = 0; } else if (++bad >= 3) break;
  }
  setParams(m, bestP);
  m.fit = { label, validationLogLoss: best, bestEpoch, epochsRun };
  console.log(label, 'val logloss', best.toFixed(5));
  return m;
}

/* ── The three models ───────────────────────────────────────────────── */
const M0 = fit(newModel('logit', 'zr'), sets.train, sets.val, 'M0 radar only');
const M1 = fit(newModel('logit', 'zrd'), sets.train, sets.val, 'M1 radar + people');
// Several starts: the product likelihood is not convex. Keep the best on validation.
let GTm = null, GTval = Infinity;
const starts = [];
[{ c: 0 }, { c: 2 }, { c: 4 }].forEach((init, k) => {
  const m = fit(newModel('gt', null, init), sets.train, sets.val, 'GT start ' + k);
  const v = logloss(m, sets.val);
  starts.push({ initialDetectionIntercept: init.c, ...m.fit });
  if (v < GTval) { GTval = v; GTm = m; }
});

function report(m, rows) {
  const scored = rows.map(r => ({ s: predictP(m, r), y: r.y }));
  const base = pos(sets.train) / sets.train.length;
  let b = 0, c = 0; scored.forEach(s => { b += (s.s - s.y) ** 2; c += (base - s.y) ** 2; });
  return { logloss: logloss(m, rows), auc: T.auc(scored), bss: 1 - b / c };
}
const te = sets.test;
const E = { m0: report(M0, te), m1: report(M1, te), gt: report(GTm, te) };
const validation = { m0: report(M0, sets.val), m1: report(M1, sets.val), gt: report(GTm, sets.val) };
console.log(JSON.stringify(E, null, 1));

/* ── The witness curve: P(someone reports | severe is occurring) ──────
 * By population (log10 people within 40 km, with 10 km at its typical
 * ratio) and day vs night, holding everything else at its mean. */
const dayH = 15, nightH = 2;               // local solar hours
const p10for40 = (() => {                  // typical p10 at each p40, from the data
  const by = {}; sets.train.forEach(r => { const k = Math.round(r.xd[1] * 2) / 2; (by[k] = by[k] || []).push(r.xd[0]); });
  return k => { const a = by[Math.round(k * 2) / 2]; return a ? a.reduce((x, y) => x + y, 0) / a.length : k - 1; };
})();
function detectAt(m, l40, hour) {
  const c = Math.cos(2 * Math.PI * hour / 24), sn = Math.sin(2 * Math.PI * hour / 24);
  const xd = [p10for40(l40), l40, c, sn, l40 * c, l40 * sn];
  return sig(m.c + dot(m.v, z(xd, SD)));
}
const curve = [2, 3, 4, 5, 6, 6.5].map(l => ({ people40km: Math.round(10 ** l), day: +detectAt(GTm, l, dayH).toFixed(3),
  night: +detectAt(GTm, l, nightH).toFixed(3) }));
console.log('witness curve', JSON.stringify(curve));

/* ── Report-label calibration and model-implied latent counts ───────── */
const stratified = Evaluation.stratify(te, { m0: M0, m1: M1, gt: GTm }, predictP,
  r => sig(GTm.b + dot(GTm.w, r.zr)));
const quint = te.map(r => r.xd[1]).sort((a, b) => a - b);
const cuts = [0.2, 0.4, 0.6, 0.8].map(q => quint[Math.floor(q * quint.length)]);
const byQ = [0, 1, 2, 3, 4].map(() => ({ occ: 0, rep: 0, obs: 0, n: 0 }));
te.forEach(r => {
  const q = cuts.filter(c => r.xd[1] > c).length;
  const a = sig(GTm.b + dot(GTm.w, r.zr)), d = sig(GTm.c + dot(GTm.v, r.zd));
  byQ[q].occ += a; byQ[q].rep += a * d; byQ[q].obs += r.y; byQ[q].n++;
});
const unreported = byQ.map((b, i) => ({ quintile: i + 1, maxPeople40km: i < 4 ? Math.round(10 ** cuts[i]) : null,
  expectedSevere: Math.round(b.occ), predictedReported: Math.round(b.rep), actuallyReported: b.obs,
  shareUnreported: +(1 - b.rep / b.occ).toFixed(3) }));
console.log('unreported by population quintile', JSON.stringify(unreported, null, 1));

/* ── Can the split be recovered at all? ───────────────────────────────
 * Draw synthetic reports from a KNOWN truth (the fitted model, with its
 * witness curve made deliberately steeper) on the training samples, refit
 * from scratch, and compare the recovered witness curve to the truth. */
const truth = JSON.parse(JSON.stringify(GTm));
truth.v = truth.v.map(v => v * 1.5); truth.c = truth.c - 0.5;
sets.train.forEach(r => { r.ysyn = rand() < predictP(truth, r) ? 1 : 0; });
sets.val.forEach(r => { r.ysyn = rand() < predictP(truth, r) ? 1 : 0; });
const rec = fit(newModel('gt', null, { c: 1 }), sets.train, sets.val, 'GT on synthetic', 'ysyn');
const recErr = Math.max(...[2, 3, 4, 5, 6].flatMap(l => [dayH, nightH].map(h => Math.abs(detectAt(rec, l, h) - detectAt(truth, l, h)))));
console.log('synthetic recovery: worst witness-curve error', recErr.toFixed(3));

const gate = Evaluation.gate(E, curve, recErr);
const ship = gate.ship;
console.log('ship', ship, JSON.stringify(gate, null, 2));

const evaluation = {
  schemaVersion: 1, generatedAt: new Date().toISOString(), nodeVersion: process.version,
  evaluationUnit: 'cell scan (a report can label multiple scans and radars); not independent events',
  split: { rule: 'Sorted 12Z-to-12Z convective dates; zero-based i%4: 0,1 train; 2 validation; 3 test',
    dates: split, counts: Object.fromEntries(Object.entries(sets).map(([k, rows]) =>
      [k, { days: split[k].length, scans: rows.length, positiveScans: pos(rows) }])), dayCounts },
  inputs,
  sourceFiles: ['scripts/train/groundtruth.js', 'scripts/train/groundtruth-eval.js', 'scripts/train/train.js',
    'js/stormmodel.js', 'js/groundtruth.js', 'js/popgrid.js'].map(file => ({ file, sha256: digest(path.join(ROOT, file)) })),
  labels: { minDbz: MIN_DBZ, severeKm: SEV_KM, windowMinutes: SEV_WINDOW,
    qualifyingArchiveReportRows: reports, offGridScans: offGrid },
  fitting: { seed: 7, sharedSequentialRng: true, optimizer: 'Adam', learningRate: 0.01,
    batchSize: 1024, l2: 1e-5, maxEpochs: 30, patience: 3, minValidationImprovement: 1e-6,
    standardisation: 'Training rows only; population SD; clip at +/-5', starts },
  features: { radar: sandbox.StormModel.FEATURES.slice(0, 11).concat(['range100', 'range100sq']), detection: GT.DETECT },
  standardisation: { radar: SR, detection: SD },
  models: { m0: M0, m1: M1, gt: GTm },
  validation, test: E, gate, ...stratified,
  caveats: ['The test set has already informed the next experiment and is not a fresh final confirmation set.',
    'Latent occurrence and unreported fractions are model-implied, not measured ground truth.',
    'Synthetic recovery is within-family simulation, not empirical identification of the latent split.',
    'The witness-curve gate retains the original three-decimal inputs and 0.01 allowed drop.']
};
fs.mkdirSync(path.dirname(EVAL_OUT), { recursive: true });
fs.writeFileSync(EVAL_OUT, JSON.stringify(evaluation, null, 2) + '\n');
fs.writeFileSync(EVAL_OUT.replace(/\.json$/, '.md'), Evaluation.markdown(evaluation));
console.log('wrote full-precision evaluation', EVAL_OUT);

/* ── Write ──────────────────────────────────────────────────────────── */
const r5 = v => +(+v).toPrecision(5);
const W = {
  ship, trained: new Date().toISOString().slice(0, 10), first: days[0], last: days[days.length - 1],
  severeKm: SEV_KM, windowMin: SEV_WINDOW,
  radar: { b: r5(GTm.b), w: GTm.w.map(r5), mean: SR.mean.map(r5), std: SR.std.map(r5) },
  detect: { b: r5(GTm.c), w: GTm.v.map(r5), mean: SD.mean.map(r5), std: SD.std.map(r5) },
  eval: {
    days: days.length, heldOutDays: split.test.length, trainDays: split.train.length, validationDays: split.val.length,
    splitDates: split, valN: sets.val.length, testPositiveScans: pos(te),
    countUnit: 'cell scans; testReports is a legacy alias of testPositiveScans',
    gate,
    trainN: sets.train.length, testN: te.length, testReports: pos(te), reports,
    radarOnly: { logloss: r5(E.m0.logloss), auc: +E.m0.auc.toFixed(3), bss: +E.m0.bss.toFixed(3) },
    radarPeople: { logloss: r5(E.m1.logloss), auc: +E.m1.auc.toFixed(3), bss: +E.m1.bss.toFixed(3) },
    groundTruth: { logloss: r5(E.gt.logloss), auc: +E.gt.auc.toFixed(3), bss: +E.gt.bss.toFixed(3) },
    witnessCurve: curve, unreported, syntheticRecoveryError: +recErr.toFixed(3)
  }
};
fs.mkdirSync(path.dirname(OUT), { recursive: true });
fs.writeFileSync(OUT, '/* GENERATED by scripts/train/groundtruth.js — do not edit. Vane Ground Truth:\n' +
  ' * occurring × witnessed, fitted on NEXRAD storm attributes, NWS reports and Census 2020\n' +
  ' * population, with its held-out checks. See js/groundtruth.js. */\n(function (global) {\n  global.GroundTruthWeights = ' +
  JSON.stringify(W, null, 1).replace(/\n/g, '\n  ') + ';\n})(typeof window !== \'undefined\' ? window : globalThis);\n');
console.log('wrote', OUT);
