/* Download the training set for the chase-day model (scripts/train/env.js).
 *
 *   node scripts/train/fetch-env.js
 *
 * Two public, keyless Iowa State archives:
 *   - Upper-air soundings with their derived parameters (CAPE, CIN, bulk
 *     shear, storm-relative helicity, LCL…), one request per station-year:
 *     /api/1/raobs_by_year.json. Real observed environments, not a model.
 *   - Local storm reports, a month per request.
 *
 * Sample: every active NWS upper-air site from the Rockies to the East
 * Coast, every day of April through July in 2023 and 2024 — quiet days
 * included, systematically. Cached in scripts/train/data/ (git-ignored). */
const fs = require('fs'), path = require('path');
const { execFileSync } = require('child_process');

const DIR = path.join(__dirname, 'data');
const API = 'https://mesonet.agron.iastate.edu/api/1/';
const LSR = 'https://mesonet.agron.iastate.edu/cgi-bin/request/gis/lsr.py';
const STATIONS = ['KABR', 'KAMA', 'KAPX', 'KBIS', 'KBMX', 'KBNA', 'KBRO', 'KBUF', 'KCHS', 'KCRP',
  'KDDC', 'KDNR', 'KDRT', 'KDTX', 'KDVN', 'KFFC', 'KFWD', 'KGRB', 'KGSO', 'KILN', 'KILX', 'KINL',
  'KJAN', 'KJAX', 'KLBF', 'KLCH', 'KLZK', 'KMAF', 'KMFL', 'KMPX', 'KOAX', 'KOUN', 'KPIT', 'KRNK',
  'KSGF', 'KSHV', 'KTBW', 'KTLH', 'KTOP', 'KUNR'];
const YEARS = [2023, 2024];

function get(url, file) {
  if (fs.existsSync(file) && fs.statSync(file).size > 100) return 'cached';
  const buf = execFileSync('curl', ['-sf', '--max-time', '180', url], { maxBuffer: 1 << 30 });
  fs.writeFileSync(file, buf);
  execFileSync('sleep', ['1']);                      // be a polite client
  return buf.length;
}

fs.mkdirSync(DIR, { recursive: true });
get(API + 'network/RAOB.json', path.join(DIR, 'raob-stations.json'));
STATIONS.forEach(st => YEARS.forEach(y => {
  try {
    const n = get(API + 'raobs_by_year.json?station=' + st + '&year=' + y,
      path.join(DIR, 'raob-' + st + '-' + y + '.json'));
    console.log(st, y, n);
  } catch (e) { console.log(st, y, 'FAILED', e.message.split('\n')[0]); }
}));
YEARS.forEach(y => [4, 5, 6, 7].forEach(m => {
  const mm = String(m).padStart(2, '0'), next = String(m + 1).padStart(2, '0');
  const n = get(LSR + '?fmt=csv&sts=' + y + '-' + mm + '-01T00:00:00Z&ets=' + y + '-' + next + '-02T12:00:00Z',
    path.join(DIR, 'lsrmonth-' + y + '-' + mm + '.csv'));
  console.log('lsr', y, mm, n);
}));
