/* Train and evaluate Vane's two storm models; write js/stormmodel-weights.js.
 *
 *   node scripts/train/fetch.js     # the archives (cached, git-ignored)
 *   node scripts/train/train.js
 *
 * Features come from js/stormmodel.js featuresOf() — the same function the
 * app runs — so the model never sees a number in the browser that it was
 * not trained on.
 *
 * Held out: every fourth day in the sample, never seen by the fit. Both
 * models are judged there against an honest baseline, and the weights file
 * records whether each one beat it ("ship"); the app shows only a model
 * that did. No libraries: ridge regression by normal equations, logistic
 * regression by Newton's method (IRLS), both a few dozen lines below. */
const fs = require('fs'), path = require('path'), vm = require('vm');

const ROOT = path.join(__dirname, '..', '..');
const DATA = path.join(__dirname, 'data');
const OUT = path.join(ROOT, 'js', 'stormmodel-weights.js');

// The app's own code, loaded the way the browser loads it.
const sandbox = { console };
sandbox.window = sandbox; sandbox.globalThis = sandbox;
vm.createContext(sandbox);
['js/config.js', 'js/util.js', 'js/stormmodel.js', 'js/cells.js'].forEach(f =>
  vm.runInContext(fs.readFileSync(path.join(ROOT, f), 'utf8'), sandbox, { filename: f }));
const { StormModel, Cells } = sandbox;

const MIN_DBZ = 35;              // convective cells only, in training and in the app
const LEAD_MIN = 20, LEAD_TOL = 3;
const SEV_WINDOW = [-5, 30];     // minutes around the scan a report may fall
const SEV_KM = 15;
const TRACK_MIN = 30, TRACK_TOL = 3;

/* ── Parsing and tracks ─────────────────────────────────────────────── */

function stamp(s) {               // YYYYmmddHHMM (UTC) → ms
  return Date.UTC(+s.slice(0, 4), +s.slice(4, 6) - 1, +s.slice(6, 8), +s.slice(8, 10), +s.slice(10, 12));
}

function km(lat1, lon1, lat2, lon2) {
  const r = Math.PI / 180, dLat = (lat2 - lat1) * r, dLon = (lon2 - lon1) * r;
  const a = Math.sin(dLat / 2) ** 2 + Math.cos(lat1 * r) * Math.cos(lat2 * r) * Math.sin(dLon / 2) ** 2;
  return 6371 * 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
}

function readAttrs(file) {
  const lines = fs.readFileSync(file, 'utf8').split('\n');
  const rows = [];
  for (let i = 1; i < lines.length; i++) {
    const c = lines[i].split(',');
    if (c.length < 18) continue;
    rows.push({
      t: stamp(c[0]), id: c[1], radar: c[2],
      cell: {
        tvs: c[5] !== 'NONE' && c[5] !== '', mesoRank: parseInt(c[6], 10) || 0,
        posh: +c[7] || 0, poh: +c[8] || 0, maxSize: +c[9] || 0, vil: +c[10] || 0,
        maxDbz: +c[11] || 0, maxDbzHeight: +c[12] || 0, top: +c[13] || 0,
        fromDeg: +c[14] || 0, speedKt: +c[15] || 0,
        range: +c[4] || 0                       // from the radar (Ground Truth only)
      },
      lat: +c[16], lon: +c[17]
    });
  }
  return rows;
}

/* Storm IDs are recycled, so a track is one ID on one radar with no gap
 * over 12 minutes and no jump over 25 km between scans. */
function tracks(rows) {
  const by = {};
  rows.forEach(r => (by[r.radar + ':' + r.id] = by[r.radar + ':' + r.id] || []).push(r));
  const out = [];
  Object.values(by).forEach(list => {
    list.sort((a, b) => a.t - b.t);
    let cur = [];
    list.forEach(r => {
      const p = cur[cur.length - 1];
      if (p && (r.t - p.t > 12 * 60000 || km(p.lat, p.lon, r.lat, r.lon) > 25 || r.t === p.t)) {
        if (cur.length) out.push(cur);
        cur = [];
      }
      if (!cur.length || cur[cur.length - 1].t !== r.t) cur.push(r);
    });
    if (cur.length) out.push(cur);
  });
  return out;
}

function readLsr(file) {
  const lines = fs.readFileSync(file, 'utf8').split('\n');
  const out = [];
  for (let i = 1; i < lines.length; i++) {
    const c = lines[i].split(',');
    if (c.length < 8) continue;
    const type = c[6], mag = parseFloat(c[4]);
    const severe = type === 'T' || type === 'D' ||
      (type === 'H' && mag >= 1.0) || (type === 'G' && mag >= 58);
    if (severe) out.push({ t: stamp(c[0]), lat: +c[2], lon: +c[3], type, mag: isNaN(mag) ? 0 : mag });
  }
  return out.sort((a, b) => a.t - b.t);
}

/* Where the cell was at time t: interpolated along its track, or carried
 * on its motion past either end. drct is the direction it comes FROM. */
function posAt(track, t) {
  if (t <= track[0].t) return track[0];
  const last = track[track.length - 1];
  if (t >= last.t) {
    const hrs = (t - last.t) / 3600000, distKm = last.cell.speedKt * 1.852 * hrs;
    const toward = (last.cell.fromDeg + 180) * Math.PI / 180;
    return { lat: last.lat + distKm * Math.cos(toward) / 111.32,
             lon: last.lon + distKm * Math.sin(toward) / (111.32 * Math.cos(last.lat * Math.PI / 180)) };
  }
  for (let i = 1; i < track.length; i++) {
    if (track[i].t >= t) {
      const a = track[i - 1], b = track[i], f = (t - a.t) / (b.t - a.t);
      return { lat: a.lat + f * (b.lat - a.lat), lon: a.lon + f * (b.lon - a.lon) };
    }
  }
  return last;
}

/* ── Samples ────────────────────────────────────────────────────────── */

function samples(day) {
  const trs = tracks(readAttrs(path.join(DATA, 'attrs-' + day + '.csv')));
  const lsr = readLsr(path.join(DATA, 'lsr-' + day + '.csv'));
  const inten = [], sev = [], trk = [];
  trs.forEach(tr => {
    for (let i = 0; i < tr.length; i++) {
      const r = tr[i];
      if (r.cell.maxDbz < MIN_DBZ) continue;
      const hist = tr.slice(0, i + 1).map(p => ({ t: p.t, dbz: p.cell.maxDbz, top: p.cell.top,
                                                    lat: p.lat, lon: p.lon }));
      const f = StormModel.featuresOf(r.cell, hist);

      // Intensity: the scan closest to twenty minutes on, if the track has one.
      if (f.hasTrend) {
        let best = null;
        for (let j = i + 1; j < tr.length; j++) {
          const dt = (tr[j].t - r.t) / 60000;
          if (dt > LEAD_MIN + LEAD_TOL) break;
          if (Math.abs(dt - LEAD_MIN) <= LEAD_TOL &&
              (!best || Math.abs(dt - LEAD_MIN) < Math.abs((best.t - r.t) / 60000 - LEAD_MIN))) best = tr[j];
        }
        if (best) inten.push({ x: f.x, y: best.cell.maxDbz - r.cell.maxDbz, day });
      }

      // Track: where the cell actually was thirty minutes on.
      let later = null;
      for (let j = i + 1; j < tr.length; j++) {
        const dt = (tr[j].t - r.t) / 60000;
        if (dt > TRACK_MIN + TRACK_TOL) break;
        if (Math.abs(dt - TRACK_MIN) <= TRACK_TOL &&
            (!later || Math.abs(dt - TRACK_MIN) < Math.abs((later.t - r.t) / 60000 - TRACK_MIN))) later = tr[j];
      }
      if (later) {
        const tf = StormModel.trackFeaturesOf(r.cell, hist);
        const dtMin = (later.t - r.t) / 60000;
        const kx = 111.32 * Math.cos(r.lat * Math.PI / 180);
        // Scaled to exactly 30 minutes, so a 28- or 33-minute scan is fair.
        trk.push({ x: tf.x, hasObs: tf.hasObs, day,
          e: (later.lon - r.lon) * kx * 30 / dtMin, n: (later.lat - r.lat) * 111.32 * 30 / dtMin });
      }

      // Severe and hail: a qualifying report near the cell's own position, in time.
      const t0 = r.t + SEV_WINDOW[0] * 60000, t1 = r.t + SEV_WINDOW[1] * 60000;
      let hit = false, hail1 = false, hail175 = false;
      for (let k = lowerBound(lsr, t0); k < lsr.length && lsr[k].t <= t1; k++) {
        const p = posAt(tr, lsr[k].t);
        if (km(p.lat, p.lon, lsr[k].lat, lsr[k].lon) > SEV_KM) continue;
        hit = true;
        if (lsr[k].type === 'H' && lsr[k].mag >= 1.0) hail1 = true;
        if (lsr[k].type === 'H' && lsr[k].mag >= 1.75) hail175 = true;
      }
      const single = StormModel.featuresOf(r.cell, null);
      // The app's existing hand-tuned threat score, as a baseline to beat.
      const heuristic = Cells.score(Object.assign({}, r.cell,
        { vilDensity: Cells.vilDensity(r.cell.vil, r.cell.top) })).total;
      sev.push({ x: single.x, y: hit ? 1 : 0, day, heuristic,
                 h1: hail1 ? 1 : 0, h175: hail175 ? 1 : 0, size: r.cell.maxSize });
    }
  });
  return { inten, sev, trk, lsr: lsr.length, tracks: trs.length };
}

function lowerBound(a, t) {
  let lo = 0, hi = a.length;
  while (lo < hi) { const m = (lo + hi) >> 1; if (a[m].t < t) lo = m + 1; else hi = m; }
  return lo;
}

/* ── Fitting ────────────────────────────────────────────────────────── */

function standardise(rows, use) {
  const mean = use.map(() => 0), std = use.map(() => 0);
  rows.forEach(r => use.forEach((k, i) => { mean[i] += r.x[k]; }));
  mean.forEach((_, i) => { mean[i] /= rows.length; });
  rows.forEach(r => use.forEach((k, i) => { std[i] += (r.x[k] - mean[i]) ** 2; }));
  std.forEach((_, i) => { std[i] = Math.sqrt(std[i] / rows.length) || 1; });
  return { mean, std };
}

// Standardised, and clipped at ±5 SD: a few extreme hail sizes or VIL
// values must not dominate the fit. The app clips the same way.
const CLIP = 5;
function zrow(r, use, s) {
  return [1].concat(use.map((k, i) => Math.max(-CLIP, Math.min(CLIP, (r.x[k] - s.mean[i]) / s.std[i]))));
}

function solve(A, b) {             // Gaussian elimination, partial pivoting
  const n = b.length, M = A.map((row, i) => row.concat([b[i]]));
  for (let c = 0; c < n; c++) {
    let p = c;
    for (let r = c + 1; r < n; r++) if (Math.abs(M[r][c]) > Math.abs(M[p][c])) p = r;
    [M[c], M[p]] = [M[p], M[c]];
    for (let r = 0; r < n; r++) {
      if (r === c) continue;
      const f = M[r][c] / M[c][c];
      for (let k = c; k <= n; k++) M[r][k] -= f * M[c][k];
    }
  }
  return M.map((row, i) => row[n] / row[i]);
}

function ridge(rows, use, lambda) {
  const s = standardise(rows, use), d = use.length + 1;
  const A = Array.from({ length: d }, () => new Array(d).fill(0)), b = new Array(d).fill(0);
  rows.forEach(r => {
    const z = zrow(r, use, s);
    for (let i = 0; i < d; i++) { b[i] += z[i] * r.y; for (let j = 0; j < d; j++) A[i][j] += z[i] * z[j]; }
  });
  for (let i = 1; i < d; i++) A[i][i] += lambda;
  const w = solve(A, b);
  return { use, mean: s.mean, std: s.std, b: w[0], w: w.slice(1) };
}

/* Newton's method is not globally convergent for logistic regression: a
 * full step can overshoot and diverge. So every step is damped until the
 * penalised log-likelihood actually improves (backtracking line search). */
function logistic(rows, use, lambda, iters) {
  const s = standardise(rows, use), d = use.length + 1;
  const Z = rows.map(r => zrow(r, use, s));
  let w = new Array(d).fill(0);
  const base = rows.reduce((a, r) => a + r.y, 0) / rows.length;
  w[0] = Math.log(base / (1 - base));
  const objective = ww => {
    let ll = 0;
    rows.forEach((r, n) => {
      let e = 0; for (let i = 0; i < d; i++) e += ww[i] * Z[n][i];
      ll += r.y ? -Math.log1p(Math.exp(-e)) : -Math.log1p(Math.exp(e));
    });
    for (let i = 1; i < d; i++) ll -= lambda * ww[i] * ww[i] / 2;
    return ll;
  };
  let cur = objective(w);
  for (let it = 0; it < iters; it++) {
    const H = Array.from({ length: d }, () => new Array(d).fill(0)), g = new Array(d).fill(0);
    rows.forEach((r, n) => {
      const z = Z[n];
      let e = 0; for (let i = 0; i < d; i++) e += w[i] * z[i];
      const p = 1 / (1 + Math.exp(-e)), v = p * (1 - p);
      for (let i = 0; i < d; i++) { g[i] += (r.y - p) * z[i]; for (let j = 0; j < d; j++) H[i][j] += v * z[i] * z[j]; }
    });
    for (let i = 1; i < d; i++) { g[i] -= lambda * w[i]; H[i][i] += lambda; }
    const step = solve(H, g);
    let t = 1, next = null, val = -Infinity;
    for (let k = 0; k < 20; k++, t /= 2) {
      next = w.map((x, i) => x + t * step[i]);
      val = objective(next);
      if (val > cur) break;
    }
    if (!(val > cur + 1e-9)) break;               // converged
    w = next; cur = val;
  }
  return { use, mean: s.mean, std: s.std, b: w[0], w: w.slice(1) };
}

function predict(m, x) {
  let s = m.b;
  m.use.forEach((k, i) => { s += m.w[i] * Math.max(-CLIP, Math.min(CLIP, (x[k] - m.mean[i]) / m.std[i])); });
  return s;
}

/* ── Evaluation ─────────────────────────────────────────────────────── */

function auc(scored) {             // rank-sum; ties share their rank
  const a = scored.slice().sort((p, q) => p.s - q.s);
  let pos = 0, neg = 0, sumRanks = 0;
  for (let i = 0; i < a.length;) {
    let j = i; while (j < a.length && a[j].s === a[i].s) j++;
    const rank = (i + j + 1) / 2;
    for (let k = i; k < j; k++) if (a[k].y) { pos++; sumRanks += rank; } else neg++;
    i = j;
  }
  return pos && neg ? (sumRanks - pos * (pos + 1) / 2) / (pos * neg) : null;
}

const r3 = x => Math.round(x * 1000) / 1000;

/* ── Run ────────────────────────────────────────────────────────────── */

// Required (by the test suite) rather than run: export the parser, so the
// suite can hold training-time features to the app's live ones.
if (require.main !== module) {
  module.exports = { readAttrs, tracks, readLsr, posAt, auc, solve, logistic, predict,
    standardise, km, stamp, lowerBound, r3 };
  return;
}

const days = fs.readdirSync(DATA).filter(f => /^attrs-.*\.csv$/.test(f)).map(f => f.slice(6, 16)).sort()
  .filter(d => fs.existsSync(path.join(DATA, 'lsr-' + d + '.csv')));
const testDays = new Set(days.filter((_, i) => i % 4 === 3));
let I = [], S = [], T = [], nLsr = 0, nTracks = 0;
days.forEach(d => {
  const s = samples(d);
  I = I.concat(s.inten); S = S.concat(s.sev); T = T.concat(s.trk); nLsr += s.lsr; nTracks += s.tracks;
  process.stdout.write('.');
});
console.log('\n' + days.length + ' days (' + testDays.size + ' held out), ' + nTracks + ' tracks, ' +
  nLsr + ' severe reports');

// Intensity
const Itr = I.filter(r => !testDays.has(r.day)), Ite = I.filter(r => testDays.has(r.day));
const intensity = ridge(Itr, StormModel.FEATURES.map((_, i) => i), 1);
let maeModel = 0, maePersist = 0, maeTrend = 0, signOk = 0, signN = 0;
Ite.forEach(r => {
  const p = predict(intensity, r.x), slope = r.x[11];
  maeModel += Math.abs(p - r.y); maePersist += Math.abs(r.y); maeTrend += Math.abs(2 * slope - r.y);
  if (Math.abs(r.y) >= 5) { signN++; if (Math.sign(p) === Math.sign(r.y)) signOk++; }
});
const iEval = {
  trainN: Itr.length, testN: Ite.length,
  maeModel: r3(maeModel / Ite.length), maePersistence: r3(maePersist / Ite.length),
  maeTrend: r3(maeTrend / Ite.length),
  directionHit: signN ? r3(signOk / signN) : null, directionN: signN
};
intensity.ship = iEval.maeModel < iEval.maePersistence && iEval.maeModel < iEval.maeTrend;
intensity.eval = iEval;
console.log('intensity', JSON.stringify(iEval), 'ship', intensity.ship);

// Severe (single scan: the trend columns are not used)
const Str = S.filter(r => !testDays.has(r.day)), Ste = S.filter(r => testDays.has(r.day));
const sevUse = StormModel.FEATURES.map((_, i) => i).filter(i => i < 11);
const severe = logistic(Str, sevUse, 1, 12);
const baseTr = Str.reduce((a, r) => a + r.y, 0) / Str.length;
let brier = 0, brierClim = 0;
const scored = [], heur = [];
const bins = [0, 0.01, 0.02, 0.05, 0.1, 0.2, 0.4, 1.01].map(() => ({ n: 0, p: 0, y: 0 }));
const edges = [0, 0.01, 0.02, 0.05, 0.1, 0.2, 0.4, 1.01];
Ste.forEach(r => {
  const p = 1 / (1 + Math.exp(-predict(severe, r.x)));
  brier += (p - r.y) ** 2; brierClim += (baseTr - r.y) ** 2;
  scored.push({ s: p, y: r.y });
  if (r.heuristic !== null) heur.push({ s: r.heuristic, y: r.y });
  for (let b = 0; b < edges.length - 1; b++) {
    if (p >= edges[b] && p < edges[b + 1]) { bins[b].n++; bins[b].p += p; bins[b].y += r.y; break; }
  }
});
const sEval = {
  trainN: Str.length, testN: Ste.length,
  baseRate: r3(Ste.reduce((a, r) => a + r.y, 0) / Ste.length),
  brier: r3(brier / Ste.length), brierClimatology: r3(brierClim / Ste.length),
  bss: r3(1 - brier / brierClim),
  auc: r3(auc(scored)), aucHeuristic: r3(auc(heur)),
  reliability: bins.slice(0, edges.length - 1).map((b, i) => ({
    from: edges[i], to: Math.min(1, edges[i + 1]), n: b.n,
    forecast: b.n ? r3(b.p / b.n) : null, observed: b.n ? r3(b.y / b.n) : null
  })).filter(b => b.n)
};
severe.ship = sEval.bss > 0;
severe.eval = sEval;
console.log('severe', JSON.stringify(sEval), 'ship', severe.ship);

/* Probability models share one evaluation: Brier skill against the
 * training base rate, ranking (AUC) against a baseline score, and a
 * reliability table. */
function evalProb(model, test, label, baseRate, baselineScore) {
  let brier = 0, brierClim = 0;
  const scored = [], base = [];
  const b = edges.slice(0, -1).map(() => ({ n: 0, p: 0, y: 0 }));
  test.forEach(r => {
    const y = r[label], p = 1 / (1 + Math.exp(-predict(model, r.x)));
    brier += (p - y) ** 2; brierClim += (baseRate - y) ** 2;
    scored.push({ s: p, y }); base.push({ s: baselineScore(r), y });
    for (let k = 0; k < edges.length - 1; k++) {
      if (p >= edges[k] && p < edges[k + 1]) { b[k].n++; b[k].p += p; b[k].y += y; break; }
    }
  });
  return {
    trainBase: r3(baseRate), testN: test.length,
    baseRate: r3(test.reduce((a, r) => a + r[label], 0) / test.length),
    bss: r3(1 - brier / brierClim), auc: r3(auc(scored)), aucBaseline: r3(auc(base)),
    reliability: b.map((x, k) => ({ from: edges[k], to: Math.min(1, edges[k + 1]), n: x.n,
      forecast: x.n ? r3(x.p / x.n) : null, observed: x.n ? r3(x.y / x.n) : null })).filter(x => x.n)
  };
}

// Hail: the radar's own size estimate is the baseline to out-rank.
function hailModel(label) {
  const rows = Str.map(r => ({ x: r.x, y: r[label] }));
  const m = logistic(rows, sevUse, 1, 12);
  const base = rows.reduce((a, r) => a + r.y, 0) / rows.length;
  m.eval = evalProb(m, Ste, label, base, r => r.size);
  m.ship = m.eval.bss > 0 && m.eval.auc > m.eval.aucBaseline;
  console.log(label, JSON.stringify(m.eval), 'ship', m.ship);
  return m;
}
const hail1 = hailModel('h1'), hail175 = hailModel('h175');

// Track: east and north displacement in 30 min, with and without the
// cell's observed motion. Baselines: the table's straight line, and (when
// watched) the observed motion carried on.
function trackModel(watched) {
  const use = watched ? [0, 1, 2, 3, 4, 5, 6, 7, 8] : [0, 1, 4, 5, 6, 7, 8];
  const rows = T.filter(r => r.hasObs === watched);
  const tr = rows.filter(r => !testDays.has(r.day)), te = rows.filter(r => testDays.has(r.day));
  const east = ridge(tr.map(r => ({ x: r.x, y: r.e })), use, 1);
  const north = ridge(tr.map(r => ({ x: r.x, y: r.n })), use, 1);
  let errM = 0, errS = 0, errO = 0;
  te.forEach(r => {
    errM += Math.hypot(predict(east, r.x) - r.e, predict(north, r.x) - r.n);
    errS += Math.hypot(r.x[0] - r.e, r.x[1] - r.n);
    if (watched) errO += Math.hypot(r.x[2] - r.e, r.x[3] - r.n);
  });
  const ev = { trainN: tr.length, testN: te.length,
    kmModel: r3(errM / te.length), kmStraightLine: r3(errS / te.length),
    kmObserved: watched ? r3(errO / te.length) : null };
  const ship = ev.kmModel < ev.kmStraightLine && (!watched || ev.kmModel < ev.kmObserved);
  console.log('track ' + (watched ? 'watched' : 'single'), JSON.stringify(ev), 'ship', ship);
  return { east, north, eval: ev, ship };
}
const track = { watched: trackModel(true), single: trackModel(false) };

const meta = {
  trained: new Date().toISOString().slice(0, 10),
  days: days.length, heldOutDays: testDays.size, first: days[0], last: days[days.length - 1],
  tracks: nTracks, reports: nLsr, minDbz: MIN_DBZ, leadMin: LEAD_MIN,
  severeKm: SEV_KM, severeWindowMin: SEV_WINDOW
};
['b', 'w', 'mean', 'std'].forEach(k => {
  [intensity, severe, hail1, hail175, track.watched.east, track.watched.north,
   track.single.east, track.single.north].forEach(m => {
    m[k] = Array.isArray(m[k]) ? m[k].map(r3) : r3(m[k]);
  });
});
fs.writeFileSync(OUT,
  '/* GENERATED by scripts/train/train.js — do not edit. Storm models fitted on\n' +
  ' * Iowa State\'s archived NEXRAD storm attributes and local storm reports, with\n' +
  ' * their held-out evaluation. See js/stormmodel.js for what they are and are not. */\n' +
  '(function (global) {\n  global.StormModelWeights = ' +
  JSON.stringify({ meta, intensity, severe, hail1, hail175, track }, null, 1).replace(/\n/g, '\n  ') +
  ';\n})(typeof window !== \'undefined\' ? window : globalThis);\n');
console.log('wrote', path.relative(ROOT, OUT));
