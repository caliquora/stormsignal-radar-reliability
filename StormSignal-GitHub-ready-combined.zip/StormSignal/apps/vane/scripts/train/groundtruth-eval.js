'use strict';

// Shared evaluation policy. These thresholds are the original Ground Truth gate.
const NO_WORSE_TOLERANCE = 0.0005;

function scheduledDays() {
  const days = [];
  [2023, 2024].forEach(year => {
    for (let t = Date.UTC(year, 3, 1); t <= Date.UTC(year, 6, 31); t += 5 * 86400000) {
      days.push(new Date(t).toISOString().slice(0, 10));
    }
  });
  return days;
}

function splitDays(days) {
  if (new Set(days).size !== days.length) throw new Error('Duplicate archive day');
  const split = { train: [], val: [], test: [] };
  days.slice().sort().forEach((day, i) => {
    split[i % 4 === 3 ? 'test' : i % 4 === 2 ? 'val' : 'train'].push(day);
  });
  return split;
}

function gate(metrics, witnessCurve, recoveryError) {
  const { m0, m1, gt } = metrics;
  // Preserve the original curve check, which used values rounded to 3 decimals.
  const rises = witnessCurve.length > 0 && witnessCurve.every((c, i) =>
    Number.isFinite(c.day) && Number.isFinite(c.night) && (!i ||
      (c.day >= witnessCurve[i - 1].day - 0.01 && c.night >= witnessCurve[i - 1].night - 0.01)));
  const values = [m0.logloss, m0.auc, m1.logloss, gt.logloss, gt.auc, recoveryError];
  const checks = {
    finiteInputs: values.every(Number.isFinite),
    beatsRadarOnlyLogLoss: gt.logloss < m0.logloss,
    beatsRadarOnlyAuc: gt.auc > m0.auc,
    noWorseThanRadarPeople: gt.logloss <= m1.logloss + NO_WORSE_TOLERANCE,
    witnessCurveRises: rises,
    syntheticRecovery: recoveryError < 0.1
  };
  const limit = m1.logloss + NO_WORSE_TOLERANCE;
  return {
    ship: Object.values(checks).every(Boolean), checks,
    failed: Object.keys(checks).filter(k => !checks[k]),
    inputs: { metrics, witnessCurve, syntheticRecoveryError: recoveryError },
    thresholds: { radarPeopleLogLossTolerance: NO_WORSE_TOLERANCE,
      witnessCurveAllowedDrop: 0.01, syntheticRecoveryErrorExclusiveMax: 0.1 },
    groundTruthMinusRadarOnlyLogLoss: gt.logloss - m0.logloss,
    groundTruthMinusRadarPeopleLogLoss: gt.logloss - m1.logloss,
    maxAllowedGroundTruthLogLoss: limit,
    excessOverRadarPeopleLimit: gt.logloss - limit
  };
}

function calibration(predictedPositiveScans, observedPositiveScans, n) {
  return {
    predictedPositiveScans, observedPositiveScans,
    residualScans: predictedPositiveScans - observedPositiveScans,
    predictedToObserved: observedPositiveScans ? predictedPositiveScans / observedPositiveScans : null,
    relativeBias: observedPositiveScans ? predictedPositiveScans / observedPositiveScans - 1 : null,
    predictedRate: n ? predictedPositiveScans / n : null,
    observedRate: n ? observedPositiveScans / n : null
  };
}

// All models use the exact same rows, labels and population cut points.
// These are scan-weighted quantiles of mean log10(1 + population) along
// the track, not equal land areas or independent storm/report counts.
function stratify(rows, models, predict, occurring) {
  const ordered = rows.map(r => r.xd[1]).sort((a, b) => a - b);
  const cuts = [0.2, 0.4, 0.6, 0.8].map(q => ordered[Math.floor(q * ordered.length)]);
  const fresh = () => ({ n: 0, observed: 0, latent: 0,
    models: Object.fromEntries(Object.keys(models).map(k => [k, { predicted: 0, loss: 0 }])) });
  const quintiles = Array.from({ length: 5 }, fresh), days = {};
  rows.forEach(r => {
    const q = cuts.filter(c => r.xd[1] > c).length;
    const day = days[r.day] || (days[r.day] = fresh());
    const occ = occurring(r);
    const scores = Object.entries(models).map(([name, m]) => [name, predict(m, r)]);
    [quintiles[q], day].forEach(b => {
      b.n++; b.observed += r.y; b.latent += occ;
      scores.forEach(([name, p]) => {
        b.models[name].predicted += p;
        const clipped = Math.max(1e-9, Math.min(1 - 1e-9, p));
        b.models[name].loss -= r.y ? Math.log(clipped) : Math.log(1 - clipped);
      });
    });
  });
  const summary = b => ({ n: b.n, observedPositiveScans: b.observed,
    modelImpliedSevereScans: b.latent,
    modelImpliedUnreportedShare: b.latent ? 1 - b.models.gt.predicted / b.latent : null,
    models: Object.fromEntries(Object.entries(b.models).map(([k, v]) => [k,
      { ...calibration(v.predicted, b.observed, b.n), logloss: b.n ? v.loss / b.n : null }])) });
  return {
    populationFeature: 'Mean of log10(1 + Census population within 40 km) at 0, 15 and 30 minutes',
    populationLogCuts: cuts,
    populationQuintiles: quintiles.map((b, i) => ({ quintile: i + 1,
      upperPopulationProxyInclusive: i < 4 ? 10 ** cuts[i] - 1 : null, ...summary(b) })),
    byDay: Object.keys(days).sort().map(day => ({ day, ...summary(days[day]) }))
  };
}

function markdown(e) {
  const f = n => n === null ? 'n/a' : n.toFixed(8);
  const names = { m0: 'Radar only', m1: 'Radar + people logistic', gt: 'Ground Truth' };
  const c = e.split.counts, g = e.gate;
  const lines = [
    '# Ground Truth evaluation', '',
    'Generated from the same run as `groundtruth-evaluation.json`. Do not edit these numbers by hand.', '',
    `**ship: ${g.ship}**. ${g.failed.length ? 'Failed checks: ' + g.failed.join(', ') + '.' : 'All existing gate checks pass.'}`, '',
    `Split: **${c.train.days} training / ${c.val.days} validation / ${c.test.days} test days**.`, '',
    '| Split | Days | Cell scans | Positive cell scans |', '|---|---:|---:|---:|',
    ...Object.entries(c).map(([name, v]) => `| ${name} | ${v.days} | ${v.scans} | ${v.positiveScans} |`), '',
    'Counts are cell scans. One report can label multiple scans or radars; they are not independent storm events.', '',
    '| Model | Validation log loss | Test log loss | Test AUC | Test Brier skill |',
    '|---|---:|---:|---:|---:|',
    ...Object.keys(names).map(k => `| ${names[k]} | ${f(e.validation[k].logloss)} | ${f(e.test[k].logloss)} | ${f(e.test[k].auc)} | ${f(e.test[k].bss)} |`), '',
    `Ground Truth minus plain radar + people log loss: **${f(g.groundTruthMinusRadarPeopleLogLoss)}**.`, '',
    `Allowed degradation: **${g.thresholds.radarPeopleLogLossTolerance}**; maximum Ground Truth log loss: **${f(g.maxAllowedGroundTruthLogLoss)}**; excess over that limit: **${f(g.excessOverRadarPeopleLimit)}**.`, '',
    'The gate uses full-precision values saved in JSON; table formatting does not determine pass/fail.', '',
    '| Gate check | Pass |', '|---|---|',
    ...Object.entries(g.checks).map(([k, pass]) => `| ${k} | ${pass} |`), '',
    '## Shared population-quintile calibration', '',
    'Quintiles are by test-scan population feature, with ties kept together. These are not quintiles of country area. Predicted values sum report probabilities.', '',
    '| Quintile | Scans | Observed positive scans | Radar only predicted | Radar + people predicted | Ground Truth predicted | Ground Truth relative bias |',
    '|---|---:|---:|---:|---:|---:|---:|',
    ...e.populationQuintiles.map(q => `| ${q.quintile} | ${q.n} | ${q.observedPositiveScans} | ${q.models.m0.predictedPositiveScans.toFixed(2)} | ${q.models.m1.predictedPositiveScans.toFixed(2)} | ${q.models.gt.predictedPositiveScans.toFixed(2)} | ${q.models.gt.relativeBias === null ? 'n/a' : (100 * q.models.gt.relativeBias).toFixed(2) + '%'} |`), '',
    '## Exact test dates', '', e.split.dates.test.join(', '), '',
    'Each date identifies a 12Z-to-12Z convective day. Validation dates select epochs and the Ground Truth start; test dates do not enter fitting.', '',
    '## Reproducibility and limits', '',
    `Generated at ${e.generatedAt} with ${e.nodeVersion}. The JSON includes all split dates, input/source SHA-256 hashes, full-precision model coefficients, standardisation, validation selection, per-day results and all gate inputs.`, '',
    ...e.caveats.map(v => '- ' + v), '',
    'See [the audit notes](groundtruth-audit.md) for the correction to the historical 15-day claim and the next experiment.', ''
  ];
  return lines.join('\n');
}

module.exports = { NO_WORSE_TOLERANCE, scheduledDays, splitDays, gate, calibration, stratify, markdown };
