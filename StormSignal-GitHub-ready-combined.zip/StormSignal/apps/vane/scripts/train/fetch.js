/* Download the training set for the storm models (scripts/train/*.js).
 *
 *   node scripts/train/fetch.js
 *
 * Two public, keyless Iowa State archives:
 *   - NEXRAD storm attribute tables: every cell, every volume scan — the
 *     same fields the app reads live from nexrad_attr.geojson.
 *   - Local storm reports (LSRs): what was actually observed on the ground.
 *
 * The sample is SYSTEMATIC, not cherry-picked: every fifth day from April
 * through July of 2023 and 2024, over twenty radars covering the Plains,
 * Midwest and South. Quiet days are in it on purpose; a model trained only
 * on outbreak days learns that every storm is severe.
 *
 * Cached in scripts/train/data/ (git-ignored); re-running skips what is
 * already there. */
const fs = require('fs'), path = require('path');
const { execFileSync } = require('child_process');

const DIR = path.join(__dirname, 'data');
const RADARS = ['TLX', 'INX', 'FWS', 'LBB', 'AMA', 'ICT', 'DDC', 'TWX', 'EAX', 'OAX',
  'DMX', 'LSX', 'SGF', 'SHV', 'LZK', 'MPX', 'FSD', 'UEX', 'GLD', 'FDR'];
const BASE = 'https://mesonet.agron.iastate.edu/cgi-bin/request/gis/';

function days() {
  const out = [];
  [2023, 2024].forEach(y => {
    for (let t = Date.UTC(y, 3, 1); t <= Date.UTC(y, 6, 31); t += 5 * 86400000) {
      out.push(new Date(t).toISOString().slice(0, 10));
    }
  });
  return out;
}

function get(url, file) {
  if (fs.existsSync(file) && fs.statSync(file).size > 100) return 'cached';
  const buf = execFileSync('curl', ['-sf', '--max-time', '180', url], { maxBuffer: 1 << 30 });
  fs.writeFileSync(file, buf);
  execFileSync('sleep', ['1.5']);                  // be a polite client
  return buf.length;
}

fs.mkdirSync(DIR, { recursive: true });
const list = days();
list.forEach((d, i) => {
  const sts = d + 'T12:00:00Z';                     // 12Z to 12Z: one convective day
  const ets = new Date(Date.parse(sts) + 86400000).toISOString().slice(0, 19) + 'Z';
  const a = get(BASE + 'nexrad_storm_attrs.py?fmt=csv&sts=' + sts + '&ets=' + ets +
    '&radar=' + RADARS.join(','), path.join(DIR, 'attrs-' + d + '.csv'));
  const l = get(BASE + 'lsr.py?fmt=csv&sts=' + sts + '&ets=' + ets,
    path.join(DIR, 'lsr-' + d + '.csv'));
  console.log(`${i + 1}/${list.length} ${d} attrs ${a} lsr ${l}`);
});
