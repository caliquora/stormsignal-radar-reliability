/* Build data/popgrid.png: how many people live near every point of the
 * lower 48, for the Ground Truth model's "would anyone see it?" half.
 *
 *   node scripts/train/popgrid.js
 *
 * Source: the US Census Bureau's 2020 centres of population for all
 * 242,335 block groups (public, keyless), downloaded by this script.
 *
 * Grid: 0.1° from 24°N to 50°N and 125°W to 66°W (260 × 590). Each cell
 * holds the population within 10 km (red) and within 40 km (green) of its
 * centre, as log10(1 + people) scaled so 255 = 10^7.5. The app decodes the
 * same PNG (js/groundtruth.js), so training and the app read one source. */
const fs = require('fs'), path = require('path'), zlib = require('zlib');
const { execFileSync } = require('child_process');

const ROOT = path.join(__dirname, '..', '..');
const SRC = path.join(__dirname, 'data', 'cenpop2020-bg.txt');
const OUT = path.join(ROOT, 'data', 'popgrid.png');
const URL = 'https://www2.census.gov/geo/docs/reference/cenpop2020/blkgrp/CenPop2020_Mean_BG.txt';
const G = { lat0: 24, lon0: -125, step: 0.1, rows: 260, cols: 590, scale: 7.5 };

if (!fs.existsSync(SRC)) fs.writeFileSync(SRC, execFileSync('curl', ['-sf', '--max-time', '300', URL], { maxBuffer: 1 << 28 }));

// Block groups, binned by 0.1° for the radius search.
const bins = new Map();
let people = 0, groups = 0;
fs.readFileSync(SRC, 'utf8').split('\n').slice(1).forEach(line => {
  const c = line.split(',');
  if (c.length < 7) return;
  const pop = +c[4], lat = +c[5], lon = +c[6];
  if (!(pop > 0) || !isFinite(lat) || !isFinite(lon)) return;
  const k = Math.floor((lat - G.lat0) / G.step) + ':' + Math.floor((lon - G.lon0) / G.step);
  if (!bins.has(k)) bins.set(k, []);
  bins.get(k).push(lat, lon, pop);
  people += pop; groups++;
});
console.log(groups, 'block groups,', people, 'people');

function km(lat1, lon1, lat2, lon2) {
  const r = Math.PI / 180, dLat = (lat2 - lat1) * r, dLon = (lon2 - lon1) * r;
  const a = Math.sin(dLat / 2) ** 2 + Math.cos(lat1 * r) * Math.cos(lat2 * r) * Math.sin(dLon / 2) ** 2;
  return 6371 * 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
}

function within(lat, lon, radiusKm) {
  const dy = Math.ceil(radiusKm / 111 / G.step) + 1;
  const dx = Math.ceil(radiusKm / (111 * Math.cos(lat * Math.PI / 180)) / G.step) + 1;
  const by = Math.floor((lat - G.lat0) / G.step), bx = Math.floor((lon - G.lon0) / G.step);
  let sum = 0;
  for (let y = by - dy; y <= by + dy; y++) {
    for (let x = bx - dx; x <= bx + dx; x++) {
      const pts = bins.get(y + ':' + x);
      if (!pts) continue;
      for (let i = 0; i < pts.length; i += 3) if (km(lat, lon, pts[i], pts[i + 1]) <= radiusKm) sum += pts[i + 2];
    }
  }
  return sum;
}

const q = p => Math.max(0, Math.min(255, Math.round(Math.log10(1 + p) / G.scale * 255)));
const raw = Buffer.alloc(G.rows * (1 + G.cols * 4));
for (let r = 0; r < G.rows; r++) {
  // Row 0 is the NORTH edge, as images are read.
  const lat = G.lat0 + (G.rows - 1 - r + 0.5) * G.step;
  raw[r * (1 + G.cols * 4)] = 0;                       // PNG filter: none
  for (let c = 0; c < G.cols; c++) {
    const lon = G.lon0 + (c + 0.5) * G.step, o = r * (1 + G.cols * 4) + 1 + c * 4;
    raw[o] = q(within(lat, lon, 10)); raw[o + 1] = q(within(lat, lon, 40)); raw[o + 2] = 0; raw[o + 3] = 255;
  }
  if (r % 26 === 0) process.stdout.write('.');
}

// A minimal PNG writer: RGBA, 8 bits, one IDAT.
const crcTable = Array.from({ length: 256 }, (_, n) => {
  let c = n; for (let k = 0; k < 8; k++) c = c & 1 ? 0xedb88320 ^ (c >>> 1) : c >>> 1; return c >>> 0;
});
const crc = b => { let c = 0xffffffff; for (const x of b) c = crcTable[(c ^ x) & 255] ^ (c >>> 8); return (c ^ 0xffffffff) >>> 0; };
const chunk = (type, data) => {
  const len = Buffer.alloc(4); len.writeUInt32BE(data.length);
  const td = Buffer.concat([Buffer.from(type), data]), cr = Buffer.alloc(4); cr.writeUInt32BE(crc(td));
  return Buffer.concat([len, td, cr]);
};
const ihdr = Buffer.alloc(13);
ihdr.writeUInt32BE(G.cols, 0); ihdr.writeUInt32BE(G.rows, 4); ihdr[8] = 8; ihdr[9] = 6;
fs.mkdirSync(path.dirname(OUT), { recursive: true });
fs.writeFileSync(OUT, Buffer.concat([Buffer.from([137, 80, 78, 71, 13, 10, 26, 10]),
  chunk('IHDR', ihdr), chunk('IDAT', zlib.deflateSync(raw, { level: 9 })), chunk('IEND', Buffer.alloc(0))]));
// The raw grid too, for training (no PNG decoder needed in Node).
fs.writeFileSync(path.join(__dirname, 'data', 'popgrid.bin'), raw);
console.log('\nwrote', OUT, fs.statSync(OUT).size, 'bytes');
