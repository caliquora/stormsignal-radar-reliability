> **StormSignal integration edition:** Start with [README-STORMSIGNAL.md](README-STORMSIGNAL.md). The document below is the imported upstream feature description; its historical claims are not newly verified.

# Vane

A weather app that works for checking whether you need a jacket **and** for
deciding whether to keep driving toward a storm.

No ads. No accounts. No tracking. No server. No build step. Open
`index.html` and it works — every forecast, radar and warning in it comes from
a public, keyless source.

There is no API key of any kind, anywhere — not Vane's, not yours. An
optional AI translation of the forecast discussion once lived behind a
user-supplied key; it was removed, and the discussion stands on the
forecaster's own words instead.

The look is a user-supplied mockup made real: white cards on a pale blue-grey
canvas, deep navy ink, one blue for everything you can press, and a full dark
variant that follows the system setting. The weather still colours the app —
a palette derived from the current condition and the sun's real altitude
tints the hero card, so golden hour, a night thunderstorm and an overcast
morning each look like themselves — but as a soft wash, not a wallpaper.

![simple mode](docs/screenshot-simple.png)

![radar](docs/screenshot-radar.png)

**[→ Every view, screenshotted](docs/SCREENS.md)** — the images are rebuilt by CI on every push

![areas of interest](docs/screenshot-cells.png)

---

## Why this exists

The design is driven by market research rather than taste — see
[`docs/MARKET_RESEARCH.md`](docs/MARKET_RESEARCH.md) for the sources and the
full brief. The short version of what people actually complain about:

| Finding | What Vane does |
|---|---|
| Accuracy and speed beat polish — *"a boring, accurate forecast over a beautiful, wrong one"* | Data first, no splash, sources and observation times shown |
| Ad loads now damage brand perception | Zero ads, zero analytics, zero third-party requests beyond the weather APIs |
| Removing the radar map caused a user revolt at Google | Radar is on the default screen, animated and scrubbable |
| Casual users are asking exactly one question: *will it rain on me soon* | A 2-hour nowcast with a plain-English headline, above the fold |
| Good weather UX zooms between macro and minute scale | **Simple ⇄ Chase** — same data, two densities, one keystroke |
| Users trust observations more than model output | The nearest real METAR station is shown and labelled `OBSERVED` |
| Chasers need radar, warning polygons, convective parameters, and offline tolerance | All present, with honest limits stated below |
| 2026 design language is condition-reactive colour, not flat gradients | 32 sky palettes keyed to condition × sun altitude, all contrast-tested |
| No app can win the accuracy fight — the honest move is showing uncertainty | Five global models compared; the spread is drawn, not hidden |
| Radar shows precipitation; it doesn't show what's driving it | Animated wind, temperature and CAPE fields built from gridded model data |
| On an active day the skill is knowing which two cells matter | Ranked "areas of interest" from the radar's own rotation and hail detections |

The insight the whole app rests on: **the second audience is the first audience
on a bad day.** One app, two modes.

---

## Features

### Both modes
- **Current conditions** from the model, alongside the nearest **real NWS
  station observation**, each clearly labelled.
- **2-hour precipitation nowcast** at 15-minute resolution, led by a sentence:
  *"Light rain starting around 3:45 PM, lasting about 40 minutes."*
- **Vane Insight** — the fifth layer, and the reason no other weather app
  reads like this one: everything the on-device learners know, fused into
  a few tagged sentences at the top of the Now tab. The centrepiece is
  **Vane's number** — a consensus of all seven agencies' forecasts,
  weighted by each agency's *measured accuracy at your location* and
  corrected by your learned microclimate, offered beside the official
  figure with its provenance spelled out: *"Vane's number for today:
  93° / 74° (official 95° / 76°) — 4 agencies weighted by their record
  here, adjusted for your microclimate."* Around it: the loudest NWS
  alert (which always leads, and Vane says to follow it first), the
  inbound cell with its fitted trend, VaneMotion's arrival time, and
  which agency has earned your trust. Weights are only applied once at
  least two agencies carry a local record — before that the card says
  "equal weights until they earn a record here" — and a quiet day reads
  as a quiet day rather than padded insight.
- **VaneMotion** — Vane's own machine learning, and nobody else's: the browser
  fits a motion model to the last hour of radar over your head (a block match
  across the mosaic frames, a least-squares fit through the displacements) and
  the nowcast answers the question the radar loop only gestures at — *"Echoes
  are moving NE at about 32 km/h; the nearest rain reaches you in about 25
  minutes."* Learned entirely on your device, no server, no key, and labelled
  as exactly that. See *VaneMotion* below.
- **The local scorecard** — more on-device learning, and just as original:
  Vane records what every agency's model says tomorrow's high and low will
  be *at your pin*, then verifies each finished day against the nearest
  station's **own thermometer** (its METAR extremes, not another model's
  opinion of the day), and keeps a running per-agency error. After three
  verified days the Model agreement card carries a ranked leaderboard —
  *"ECMWF ±1.2°, GFS ±2.0°, over 11 days at KOKC"* — for your exact spot.
  Day-ahead forecasts only, so a 7-day miss never pollutes the score;
  half-measured days are discarded, never guessed; moving the pin starts a
  fresh scorecard, because Oklahoma's scores say nothing about Denver.
- **The microclimate correction** — the same verification data, turned on
  the forecast itself: the mean *signed* error of the day-ahead numbers is
  the model's systematic lean at your exact spot, and the week card offers
  it back — *"the forecast has run 2.0° warm on highs here; adjusted for
  that lean, today reads closer to 95°."* The official numbers are never
  silently edited, the correction is shrunk until enough days have earned
  it, an alternating lean is refused as noise, and a forecast running true
  is told so in as many words.
- **Per-cell trend learning** (Chase) — the attribute table is a snapshot;
  the real question is the derivative. Vane strings each storm cell's
  scans into a history by the radar's own cell id and fits a line through
  the core: *"▲ Strengthening — 38→51 dBZ over 4 scans (+8.7 dBZ/10 min),
  top 41→52 kft."* At least three scans before a verdict — two points is a
  line through anything — and histories die with their storms.
- **Radar**, from three sources:
  - **National mosaic** — NEXRAD Level III base reflectivity (N0Q, via Iowa
    State Mesonet) on the standard NWS dBZ ramp, 12 frames covering the last
    hour. Used automatically anywhere in the US. **Clutter filtered**: raw
    reflectivity also sees wind-farm blades and, on spring and autumn nights,
    migrating birds and insects — a user in Des Moines photographed a map
    speckled with "rain" under a sky every station around reported clear. Each
    frame (and every archived hour) is masked by NOAA's quality-controlled MRMS
    composite (SeamlessHSR, dual-polarisation QC) at the same time, widened by
    ~2 km so a moving storm's edge survives; real rain keeps its colours. If a
    mask cannot load the raw frame is shown. **Filter clutter** in the radar
    options turns it off, for chasers reading the fine lines insects draw
    along boundaries.
  - **Single radar** — pick any of the 159 WSR-88D sites and view its own
    products, including **base velocity (N0U)** and **storm-relative velocity
    (N0S)**. Velocity is the reason single-site mode exists: rotation is a
    velocity couplet, and no mosaic product shows it. Draws the site's coverage
    ring so range folding and beam height are legible.
  - **Global** coverage via RainViewer, including forecast frames.

  The basemap is Esri's keyless dark-gray canvas — CARTO's free tiles began
  watermarking "API KEY REQUIRED" across the map, so they are gone.

  Place labels are drawn in a pane **above** the radar, so you can still read
  which town the cell is over. Plus a frame scrubber, opacity control, scale
  bar and full-screen mode.
- **History · Live · Forecast** — one segmented control above the timeline
  selects the radar's time regime, and each regime owns the full width of
  the scrubber. **History** replays any archived hour of the national
  mosaic — IEM keeps the composite by the five-minute stamp going back
  years — picked with a date-time control, tagged ARCHIVE, dated on the
  clock, and deliberately frozen: a new live scan cannot update the past
  out from under the viewer. **Live** is the last hour plus now. Forecast
  is below.
- **Future radar** — the timeline keeps going past "now": every stop right
  of the newest frame is **HRRR simulated reflectivity** (NOAA's 3 km
  convection-allowing model, via Iowa State Mesonet's WMS), every 15 minutes
  to +18 h and hourly to +36 h. It is the one model that genuinely looks
  like radar — discrete cells with cores, not smoothed blobs — drawn on the
  same map in the same palette. The timeline tag flips to FORECAST, the
  clock shows the run's real valid time (from the run's own metadata, not
  guessed), and an on-map badge says *"simulated reflectivity — forecast"*.
  **Pressing Play runs the whole story**: the observed loop crosses "now"
  into the forecast (hourly leads to +18 h — every future frame is a fresh
  fetch, so the animation visits fewer stops than the scrubber offers) and
  wraps. The autoplay that starts on its own stays observed-only, so a
  backgrounded app never streams forecast tiles nobody is watching. The
  global radar source has no future half because HRRR covers the lower 48.
- **The radar keeps itself current.** Each source is watched through a tiny
  freshness signal — the mosaic's published valid time, a station's last-scan
  timestamp, the RainViewer frame index — and tiles re-fetch exactly when a
  new scan exists, not on a timer. A viewer parked on "latest" stays on
  latest; one who scrubbed back keeps their place; a playing loop keeps
  playing. Nothing polls imagery, nothing refreshes behind a hidden tab, and
  in Chase mode a new volume scan re-ranks the storm cells with it.
- **Radar site picker** (`N`) — every WSR-88D site, nearest first, searchable
  by identifier or city, showing live status from the NWS station feed: which
  radars are online, and which are in a **precipitation VCP** rather than
  idling in clear-air mode. That is what "active radar" actually means, and
  the list can be filtered to just those. In single-site mode the sites are
  also **on the map itself** — every other radar drawn as a dot coloured by
  that same live status, one tap to switch. Chasing crosses coverage
  boundaries constantly; the next radar over should never be a search away.
- **Map field layers** — an animated wind field (particles flowing along the
  actual flow), a smooth temperature field, and **CAPE** — the instability
  storms feed on. **Over the US, CAPE is the HRRR model's own 3 km field**,
  drawn by Unidata's public THREDDS server from the newest published run, in
  the parcel you pick: **Surface**, **Mixed-layer** (the default, SPC's go-to
  for surface-based severe storms) or **Most unstable** — the one that shows
  the elevated instability feeding storms at night above a stable surface,
  where the other two read zero. A sampled grid could never look like this:
  measured at national zoom, 42 points put a third of the map in the wrong
  CAPE band. Outside the HRRR's coverage, or with THREDDS down, CAPE falls
  back to a grid sampled from Open-Meteo (42 points locally, 80 zoomed out),
  and the legend says which you are looking at. Wind and temperature always
  use the sampled grid, drawn bilinearly between its points — an earlier
  inverse-distance fill made flat blocks and pillars around every point. Temperature and CAPE draw *beneath* the radar, so an
  echo reads against the fuel it sits in rather than being tinted by it, and
  the legend says what CAPE is not: storms. Toggle with `W`, `T` and `C`.
- **Layer switches** — everything drawn on the map is one tap on or off in
  the radar Options sheet: warning polygons, storm cells, SPC outlines,
  storm reports, and the field overlays. The chips can never lie: they read
  their state from what the map is actually showing.
- **Model charts** — the classic synoptic frame, in the app: 1-hour
  precipitation shaded in the familiar greens, mean sea-level pressure
  contoured every 4 hPa, genuine highs and lows lettered with their values,
  state outlines underneath — for GFS, the Euro, ICON, GEM, ARPEGE **and
  HRRR** (charted over an inset lower-48 box: its Lambert cone clips the
  full frame's ocean corners, and one outside point poisons a multi-point
  request), hour by hour out to each agency's horizon. Rendered by Vane over the lower 48
  from a 2,880-point (~0.8°) Open-Meteo lattice of the agency's own run —
  nine row-band requests, ~1 MB gzipped per model, bilinear shading,
  marching-squares isobars — and captioned as exactly that: Vane's rendering
  of the agency's grid, not the agency's native-resolution graphic.
- **Areas of interest** — the storms worth looking at, ranked. Mesocyclone and
  tornado-vortex detections come from the **WSR-88D's own algorithms** (MDA and
  TVS, via the NEXRAD Level III storm attribute table), not from anything
  inferred here. Vane adds an explainable threat score fusing rotation, hail and
  structure, closest-approach maths ("will it reach me, and when"), and
  cross-reference against the derived convective environment. Every flagged cell
  shows *why* it was flagged. Plotted on the radar with projected 30-minute
  tracks; rotation gets a ring, a TVS gets two.
- **Inbound-storm line** — in Simple mode, one sentence when something is
  actually heading at you: *"Rotating storm heading your way — closest approach
  in about 40 minutes."*
- **Meteogram** — 24/48/72 hours in one chart: day/night bands, a cloud-cover
  strip, the temperature line inside its multi-model spread envelope,
  precipitation bars tinted by model agreement, and a wind-arrow row. Hover
  anywhere to scrub.
- **Model agreement** — five independent global models (ECMWF, GFS, ICON, GEM,
  ARPEGE) plotted together, with a plain-English confidence read, the current
  outlier named, and an hour-by-hour "how many models actually produce rain"
  strip.
- **Model forecasts by name** — GFS, the Euro (ECMWF), ICON, GEM, ARPEGE,
  UKMO and JMA, each agency's daily run browsable as a scenario: overlay all
  seven, or focus one for its ten-day highs, lows and precipitation. Each
  agency publishes to a different public horizon — ARPEGE stops near day 4,
  UKMO near day 6 — and the card says "stops here" rather than padding the
  tail with blanks. A run is a scenario, not a probability; the ensemble
  outlook below is where uncertainty is measured rather than eyeballed.
- **Hourly** (24 h) and **7-day** forecasts, plus humidity, dew point, gusts,
  pressure, cloud cover, UV, visibility and sunrise/sunset.
- **The forecaster's discussion** (`D`) — the Area Forecast Discussion from
  your local NWS office, parsed into sections with that office's own **key
  messages** pulled to the top. This is the one product where a human
  meteorologist writes down *why* they forecast what they did, which model they
  distrusted this cycle, and what they are unsure about; none of that exists in
  any gridded API.
- **16-day outlook built on a real ensemble**, and a marker showing where it
  stops being a forecast. ECMWF's IFS run 51 times from slightly different
  starting states, drawn as a box plot per day against 20 years of ERA5 for the
  same dates. Past the point where the ensemble spread reaches the local
  climate spread, Vane stops printing daily numbers and shows only which way
  the pattern leans — see [Does long range actually work](#does-long-range-actually-work).
- **Live NWS alerts** with severity styling and full warning text.
- **Sun & moon** computed locally — sunrise, sunset, golden hour, civil dusk,
  solar altitude, moon phase and illumination.
- **Air quality** — US AQI with PM2.5, PM10, ozone, NO₂, SO₂ and dust.
- Location search by name or pasted `lat,lon`, geolocation, saved locations,
  °F/°C toggle, and full keyboard control.
- **Condition-reactive theming** — 32 sky palettes across 8 condition groups and
  4 light bands, tinting the hero card, plus falling rain/snow and a rare
  lightning flash in thunderstorms. Light and dark themes follow the system
  setting, and the radar basemap swaps with them. All motion respects
  `prefers-reduced-motion`.

### Chase mode adds
- **Shot planner** — the panel for chasers who are there for the footage. It
  answers "what will this look like from where I'm standing, and where should I
  be standing instead": whether the sun is behind you or behind the storm
  (Meeus solar position, not a clock), whether the updraft is rain-wrapped or
  exposed (VIL density and core height against echo top), how big the storm is
  in frame and what focal length that implies, and a **suggested vantage** on
  the storm's inflow flank, biased toward the sunlit side. See
  [Positioning for the shot](#positioning-for-the-shot).
- **The storm in 3D, built from the radar image itself** — Vane reads the real
  0.5° reflectivity field out of the tiles and inverts every pixel to dBZ
  through the NWS colour table, then extrudes it. Same colours as the map, same
  shape, standing up. Two viewpoints: *from here*, framed as the lens you'd
  actually need, and an orbit view showing where you are relative to the storm
  and the sun.
- **Dual pane** (`V`) — reflectivity and velocity side by side from the same
  radar and the same scan, locked to one view. Rotation is a velocity couplet
  and it only means something against the structure it sits in; flipping
  between products loses the comparison.
- **Convective parameters**: CAPE, CIN, lifted index, 0–1/0–3/0–6 km bulk
  shear, 0–1/0–3 km storm-relative helicity, Bunkers right- and left-mover
  storm motions, mean 0–6 km wind, freezing level and mixing height.
- **Interactive hodograph**, surface to 400 hPa, layer-coloured with RM/LM
  storm motions plotted.
- **Wind profile table** for every pressure level, in knots and AGL heights.
- **NWS warning polygons** drawn live on the radar, with tornado and severe
  thunderstorm warnings styled loudest.
- **SPC convective outlooks** — days 1–3, categorical plus tornado/hail/wind
  probabilities, overlaid on the map with the risk at your point called out.
- **Storm reports, every kind** — every NWS local storm report of the last 24
  hours: tornadoes and landspouts, funnel clouds and waterspouts, hail (with
  size), wind (gusts with speed, damage), flash flooding and heavy rain, snow
  and ice, and the rest — lightning, landslides, dust, wildfire. Each kind has
  its own colour *and* letter on the radar (T, F, H, W, ≈, S), older reports
  fade, and the filter chips in Radar → Options double as the legend with live
  counts. **Tap one for the full report**: what, how big (measured or
  estimated) against the spotter yardsticks ("1.75″ — golf ball size"),
  whether it met SPC's severe or significant criteria, the town and county,
  how far and which way it is from you, when (on your location's clock), who
  reported it, the issuing NWS office and the reporter's remark. Two buttons:
  **Radar at this time** rewinds the radar loop to the scan nearest the
  report — the live hour if it is recent, otherwise the archived hour around
  it, so the storm that did it is on screen under the marker — and **NWS
  report** opens the office's original text. Refreshed with the forecast; on in Chase mode,
  available in Simple mode from the same chip. From Iowa State's feed of NWS
  reports, with SPC's tornado/wind/hail list as the fallback.
- **Hour stepping** through the next 24 hours of the sounding (`←` / `→`).
- Faster auto-refresh (2 min vs 10 min) and 48-hour hourly.

### Finding your way around
Vane is four sections — **Now, Radar, Chase, Outlook** — at every width. A
segmented control under the header on a desktop, a thumb-height bar pinned to
the bottom on a phone. `1`–`4` jump between them.

The desktop used to have no navigation at all: twelve cards in one 5,438px
column, with no way to reach the radar except scrolling past everything above
it. Sections cut that to seven cards and 1,931px.

Alerts and the inbound-cell banner sit outside the sections entirely — a
tornado warning does not belong behind a tab.

### Jargon is pressable, not deleted
The Chase tab carries 54 occurrences of meteorological jargon, and none of it
can go: a chaser needs `0–3 km SRH 340 m²/s²`, not "quite twisty". So every
term the app uses is a button. Press it and get one sentence saying what it is,
and one saying what it means for you — with the actual threshold, because "high
shear" is not a definition and "over about 35 kt supports organised storms" is.

Two rules the definitions follow: no term is defined using another undefined
term, and where a number has an operational threshold, the number is named.
Both are enforced by the test suite rather than by good intentions.

### On a phone
Vane's own research says this runs on a phone mounted in a moving vehicle, and
the shot planner is for someone standing in a field — so the phone gets its own
information architecture rather than the desktop layout stood on its end.

- **Radar fills the screen** on its own tab rather than sitting in a 320px
  letterbox.
- **Every control is at least 44px.** Sized by pointer type *or* width, so a
  touchscreen laptop gets the same treatment as a phone.
- **Drag to turn the 3D storm, pinch to zoom.** Buttons are still there.
- **Reference panels fold** — the hodograph and the level-by-level table are
  things you look up when a number surprises you, not things you scan.
- Chase mode went from **8,838px of stacked cards to 4,799px across sections**,
  with the two panels you act on leading and the read — the plain sentence —
  above the fourteen numbers that produced it.

### Field-ready
- **Offline**: a service worker caches the app shell and the last good API
  response. Cached data is *always* labelled with its age — it is never shown
  as if it were live.
- **Screen wake lock** for dash-mounted use.
- **Alert filtering** by event family, so you aren't buzzed about a heat
  advisory while tracking a tornado.
- **Desktop notifications** for newly issued alerts at or above a severity you
  choose. Fires once per alert, and never for alerts already active when you
  opened the app.
- Installable as a PWA.

---

## Install it on a phone

**Live at https://vane-production-02e7.up.railway.app**

Vane is a progressive web app: it installs from the browser rather than a
store. No account, no review queue, no 40 MB download — and **updates finish
themselves**. New versions download in the background; the app refreshes
itself the moment nobody would notice (at launch, or whenever it's idle or
backgrounded), and if one lands while you're mid-radar it waits behind a
one-tap pill rather than yanking the screen. You never reinstall, and you
never owe it a close-and-reopen. Long sessions check hourly and on every
return to the app, because the browser alone only checks on navigation.
Once installed it is an icon on your home screen that opens full screen and
**keeps working with no signal** — the app, the last forecast and your saved
locations are all on the device.

It needs to be served over https (or localhost). Any static host will do —
there is no build step and no server-side anything.

- **Android / Chrome / Edge** — open the site and take the *Install* offer, in
  the app itself, the address bar, or the ⋮ menu.
- **iPhone / iPad** — Safari has no install button and never has. Tap **Share →
  Add to Home Screen**. Vane detects iOS and shows those instructions rather
  than an Install button that would do nothing.

Once installed on iOS it launches from its own splash screen rather than a
white flash — 30 launch images, portrait and landscape, matched to each device
by exact metrics — and the **app icon carries a badge** counting active severe
alerts. That badge is the closest a web app gets to a widget: a number on the
home screen you can see without opening anything. It counts severe and above
only, and respects the alert families you have muted.

### Notifications

Three kinds, all opt-in in Settings, all computed for **your pin**:

- **New alerts** — once per NWS alert at Severe or above, respecting the
  same family filters as everything else. Delivered through the service
  worker where the platform requires it (Android's installed-app rule) and
  the plain constructor elsewhere.
- **Rain on the way** — VaneMotion's on-device fit (see above) sees rain
  tracking to your location within about 45 minutes and says so once per
  approaching echo, with the evidence in the body: the echo's strength,
  where it is, how fast it is moving, and the "learned in your browser"
  label it always carries.
- **Severe outlook** — once a day when the Storm Prediction Center's Day 1
  or Day 2 categorical outlook puts a Slight risk or higher over your pin,
  and again only if the category upgrades during the day.

Honest limits, stated in the settings sheet too: **Vane has no server, so
there is no push.** Notifications fire while the app is open (it re-checks
every few minutes — every two in Chase mode). Installed on Android or
desktop Chrome, the service worker also re-checks alerts a few times a day
in the background via periodic background sync, using a location mirror the
page writes for it — still no server, nothing sent anywhere. On an iPhone,
Apple offers no background path to a web app without a push server, so
notifications appear when the app is open. Nothing here fakes otherwise.

### Notifications that learn

Every notification carries its kind — a rain heads-up, an SPC outlook, or an
NWS alert family — and what you do with it is the signal: opened, or swiped
away unread (`js/notifylearn.js`, on the device only; taps handled by the
service worker while the app is closed are logged and picked up next open).

- **Vane's own heads-ups adapt by themselves.** Five or more outcomes with
  under one in five opened, and rain heads-ups go quiet — only rain of 35 dBZ
  or more within 20 minutes — while outlook notices wait for an Enhanced
  risk. Start opening them again and they come back. Settings shows each
  change with its numbers (*"Rain heads-ups: opened 0 of 5. You rarely open
  these, so they now fire only for rain of 35 dBZ or more within 20
  minutes."*) and a **Back to normal** button that sticks.
- **Official alerts never adapt by themselves.** A family you keep dismissing
  is only *offered* for muting in Settings, with the evidence — and a muted
  family still lets Extreme alerts through. A learner must never be the
  reason someone missed a tornado warning.

### What a web app cannot do on iOS

**Home Screen and Lock Screen widgets are native-only.** They are built with
WidgetKit, compiled into an app binary, and delivered through the App Store.
Safari has no API for them and never has, so no PWA can provide one.

If you want a real widget, `ios/` holds an **unbuilt, untested** scaffold: an
XcodeGen spec, a WKWebView wrapper, and a SwiftUI WidgetKit extension that
fetches Open-Meteo natively for small, medium and Lock Screen families. It was
written without a Mac and has never been compiled — that is stated at the top of
its README and in every Swift file, and the test suite asserts those markers are
still there. Shipping it needs the Apple Developer Program at $99/year plus
review. The web app needs nothing from that directory.

It is deployed on Railway from `Dockerfile` + `nginx.conf.template`, which
exists for three headers a default static server gets wrong: the manifest must
be `application/manifest+json` or browsers reject it and never offer to
install, and `sw.js` and `index.html` must be `no-cache` or a stale service
worker can pin a released fix behind it with no way for a user to clear it.
`railway.json` pins the Dockerfile builder — Railway's autodetect picks
Railpack, which looks for a language runtime, finds none here, and fails before
producing a log line.

The repo also ships a GitHub Pages workflow at `.github/workflows/pages.yml`. It
runs the unit suite, then publishes. One manual step, once: **Settings → Pages
→ Source → GitHub Actions**. Pages serves from a subdirectory, which is why
every path in the manifest, the service worker and the HTML is relative — and
the test suite asserts that rather than assuming it.

## Running it

```sh
./serve.sh          # http://localhost:8000
```

Any static server works — there is no build, no bundler, and the app has no
dependencies to install. `python3 -m http.server` is enough.

Opening `index.html` directly from disk also works, but the service worker and
geolocation both require an `http://` or `https://` origin, so offline support
and "use my location" need the server.

### Tests

The app has no dependencies. The tests have two, pinned exactly in
`package.json` (jsdom and Playwright) with a lockfile, and nothing in
`package.json` ships — Railway builds the Dockerfile, which copies only the app.

```sh
npm ci                              # jsdom + playwright, exact versions
npx playwright install chromium     # once, for the browser suites
npm test                            # pure suites: 334 + 24 + 12 + shell update
npm run serve &                     # the browser suites drive a real server
npm run test:browser                # 372 end-to-end checks
npm run test:sw                     # service worker: update flow, notifications
```

CI (`.github/workflows/ci.yml`) runs all of it on every push, in four jobs.
The service-worker suite is its own job with one retry, because Chromium's
idle-promotion timing is load-sensitive: a timing flake there must not hide a
real failure anywhere else, and a real failure still fails twice. The fourth
job runs the screenshot pass and attaches `docs/screens/` as the `screens`
artifact — those images are regenerated, so they are built, not committed.

`test/run.js` needs nothing installed at all:

The browser modules are plain IIFEs, so the suite loads them into Node under a
small shim. It covers unit conversion, wind vector maths, timezone handling,
nowcast state transitions, profile construction, shear, Bunkers storm motion,
SRH, solar and lunar geometry, point-in-polygon for SPC outlooks, ensemble
statistics, storm-cell scoring and closest-approach maths, radar site status
and VCP classification, alert filtering, AFD parsing against a real captured
product, the VaneMotion maths — that the block match recovers a known synthetic
displacement exactly, that a uniform field is reported as no verdict rather
than "stationary", that the least-squares fit exposes disagreement in its
residual instead of hiding it, and that arrival times come from upstream
projection and are never fabricated from identical frames — and the
ensemble percentile / climatology / skill-horizon maths against a real captured
ECMWF ensemble and twenty years of ERA5, METAR present-weather parsing —
including that fog is not rain, that rain reported in the vicinity is not rain
on you, and that the remarks section is never mistaken for present weather —
the observation-versus-model precedence, and the shot geometry — that the
suggested vantage always lands in the inflow arc and never in the storm's path,
that earth curvature eventually puts a storm below the horizon, and that the 3D
model's heights are the measured ones. It also asserts that **every one of the 32 sky
palettes keeps white text at WCAG AA** — the design commits to white-on-colour
everywhere, so a single pastel palette slipping in would make the app unreadable
in exactly the conditions it matters most. No dependencies.

There is also an end-to-end browser suite (372 assertions) that replays real
captured API payloads, so it runs offline and deterministically
(`npm run test:browser`, with the app served on :8000).

It drives both modes and asserts on rendered output — hero, nowcast, radar
frames, meteogram, model ensemble, wind and temperature field layers (including
sampling the canvas to confirm they actually painted), convective parameters,
hodograph, SPC products, storm cells and their map overlay, radar site
selection and velocity products, storm reports, unit toggling, alert filtering,
search and keyboard shortcuts. It also resizes to a 390px phone and asserts the
mobile-first work rather than trusting a screenshot: every control at 44px, no
body copy under 12px, the tabs actually filtering, radar on screen without
scrolling, the reference panels folded, and the 3D responding to a synthesised
pointer drag. It holds the usability work to the same standard — that the
desktop has navigation at all, that no card is stranded outside every section,
that the radar header stays at three controls and everything moved out of it is
still one press away, that a marked-up term always resolves to a definition and
never lands inside a heading, and that re-rendering a card does not accumulate
underlines on it. And it reproduces the reported bug end to end: with the model
fixture dry, the nearest station starts reporting rain, and the suite asserts
that the "no rain expected" claim disappears, that the headline, hero condition
and icon all follow the observation, that the disagreement is stated rather than
resolved silently, and that the override releases again when the station
clears — including that a foggy report never triggers it. Installed-app layout
is exercised with Chromium's safe-area emulation rather than assumed: with a
59px status-bar inset the search field must clear the clock, the tab bar must
clear the home indicator, landscape must keep controls out from under the
notch — and with no insets, everything must fall back to plain padding. The
update path is exercised for real, not mocked: a local server whose sw.js
version can be flipped mid-test plays the role of a deploy, and the suite
watches an actual service worker carry the running app across two releases —
a first install that never reloads the page it claimed, an idle update that
applies itself, and a mid-session update that waits behind the pill until
tapped. (That part lives in `test/sw.js`, isolated; its 90-second allowances
are Chrome's own idle-promotion delay, not slack in the app.) The suite asserts that no request in the
entire run carries an API key header — there is no key to leak. It deliberately runs
the browser in `Asia/Tokyo` against an Oklahoma forecast, a 14-hour gap, so any
regression in timezone handling fails the suite rather than shipping.

Set `CHROMIUM_PATH` to use an existing Chromium, and `VANE_URL` if you're
serving on a port other than 8000.

### Measuring the interface

"Not user friendly" is a feeling, and feelings are hard to fix. `ux-audit.js`
turns it into numbers a change can move — how far you scroll before the app
answers the question you opened it with, how many controls are on screen at
once, how much of the jargon is explained where it appears:

```sh
./serve.sh &
node scripts/ux-audit.js
```

It drives the real app against the same captured payloads the screenshot pass
uses, so it describes the app as shipped. The redesign it drove:

| | before | after |
|---|---|---|
| Desktop, Simple mode | 12 cards, 5,438px, **no navigation** | 7 cards, 1,931px, sections |
| Radar tab controls | 16 | 12 (4 in the radar header itself, down from 9) |
| Chase tab | 5,691px | 4,799px |
| Convective parameters card | 1,672px of 14 tiles | 790px, read first, rest folded |
| Jargon explained in place | 0 | 25 of 54 occurrences on Chase |

The jargon count itself barely moves, and that is the point: it cannot go down
without the app getting less useful. What changed is how much of it explains
itself.

### Measuring boot

Chase and Outlook load their own code on first entry to the tab
(`js/lazy.js`): the 3D storm view, the shot planner, the model chart and its
state outlines, the outlook and meteogram charts, and both tabs' renderers.
Until then each of those renderers is a stub that remembers its latest call
and replays it when the code arrives. Every file is still in the service
worker's shell cache, so offline is unaffected — a lazy load is a cache read.
The browser suite asserts none of it is parsed at boot.

```sh
./serve.sh &
node scripts/measure-boot.js     # 4x CPU throttle, external requests stubbed, median of 9
```

| | every module at boot | tabs load their own |
|---|---|---|
| Scripts executed at boot | 41 | 34 |
| JavaScript executed at boot | 810 KB | 654 KB |
| DOMContentLoaded | 851–895 ms | 703–741 ms |
| Main-thread script time | 348–402 ms | 296–313 ms |

---

## Where AI fits

Everywhere it can be checked, and nowhere it needs a key. Vane never calls a
cloud AI service: there is no API key of any kind, no account, no server. What
it has instead is learning that runs on your device or ships as plain numbers,
each piece with its working shown and its record kept:

| What | Kind | Checked against |
|---|---|---|
| VaneMotion | block-match + least-squares fit, in the browser | its own graded arrival calls; corrects its timing and audits the correction |
| Scorecard + microclimate | running verification | the nearest station's METAR extremes, worldwide |
| Rain chances | reliability binning | the station's hourly reports |
| **Storm Odds** | Vane's own neural network, trained offline on NOAA HRRR analyses and NWS reports | 15 held-out days; calibrated so its percentages verify |
| Storm models | ridge + logistic regression, trained offline on two years of archives | 12 held-out days; then every later scan this session |
| Notifications | open-rate learning | what you open and dismiss — never mutes an Extreme alert |
| Plain-English discussion | your browser's built-in on-device model, where it has one | every point pinned to the forecaster's own sentence, or dropped |

**Finding them.** Every one of these lives in the **Vane AI** card at the top
of the Now tab — one row per model: what it says for your place right now (or
what it is waiting for), how it has done, and a button to where it works.
Wherever a model speaks anywhere in the app it carries the same ✦ AI mark.
"Vane Insight", the learners fused into sentences, now sits inside that card.

The last row is the only language model, and it is the browser's, not Vane's:
desktop Chrome ships a Summarizer that runs on the device. Where the browser
says it is available, the forecast discussion card offers a plain-English
version. Vane does not take its word for anything — each point must use the
forecaster's numbers and words, is shown with the sentence it rests on
(highlighted in the product below), and any point that fails is dropped and
counted on screen. On phones and other browsers there is no button; the
forecaster's own `KEY MESSAGES` are the summary there, as before. Warnings,
alerts and radar never pass through any model — in severe weather, follow
the NWS.

---

## Positioning for the shot

A radar app answers *where is the storm*. Someone out there for footage has a
harder question: **what will this look like from where I am standing, and where
should I be standing instead.** Two chasers the same distance from the same
supercell get completely different days — one gets a backlit grey smudge
through rain, the other gets a sunlit striated updraft against a black core.
The difference is geometry, and geometry is computable.

Four things decide whether there is a shot, and Vane solves all four from
measurements it already has.

**Light.** Where the sun is relative to the storm, *from your position*. Sun
behind you lights the tower; sun behind the storm gives a silhouette. Solar
position is Meeus, so this is exact rather than "check the time" — and "golden
hour" is treated as a solar altitude below 10°, not a clock reading.

**Structure.** Whether the interesting part is visible at all. VIL density
separates a precipitation-loaded HP storm, which wraps its own updraft in rain
and photographs badly from every angle, from a classic storm with a bare base.
Core height as a fraction of echo top is the second signal: a core held high is
an updraft still lofting, a core collapsed to the bottom is a storm raining
itself out and going visually soft.

**Framing.** Echo top height and range give a real angular size, which converts
to a focal length. A 15 km tower at 30 km is an ultra-wide subject; the same
tower at 120 km is a 500 mm one. Earth curvature is included, so past a few
hundred kilometres the panel tells you the base is below the horizon instead of
quietly reporting a tiny storm.

**Position.** The classic vantage on a right-moving supercell in the northern
hemisphere is in the inflow sector — 90–150° clockwise of the direction of
travel — looking back up into the base with the precipitation core beyond it.
That keeps you in warm inflow air rather than in the rain, and it is where the
wall cloud and striations are actually visible. Within that arc Vane picks the
bearing that also puts the sun at your back. Standoff scales with the storm:
big enough to fill the frame, far enough to see the whole tower.

### The 3D view

Two viewpoints of the same scene. **From here** puts the camera at your
position and frames the storm as the lens you'd actually need — the focal
length is stated, so the render and the read-out agree rather than silently
disagreeing. **Orbit** lifts the camera away so the lean, the core aloft, the
sun and your own position all read at once.

Every dimension is a measurement:

| In the render | Where it comes from |
|---|---|
| The **shape** | The real 0.5° reflectivity field. Iowa State serves the tiles with `Access-Control-Allow-Origin: *`, so the browser draws them to a canvas and reads the pixels back; IEM publishes the exact 256-entry colour table the product is rendered with, which makes the inversion a lookup rather than a guess |
| Column **colours** | The same ramp, so the 3D and the map agree pixel for pixel |
| Height of the tallest column | Echo top, WSR-88D storm attribute table |
| Cloud base | Derived LCL (Espy, labelled approximate) |
| The lean | Derived 0–6 km shear vector |
| Ground arrow | The cell's own tracked motion |
| Sun | Meeus, for this location and moment |

Each grid node carries the **strongest** return inside its own footprint rather
than one sampled pixel — the grid is about five image pixels apart and a core
can be a few pixels across, so point sampling walks straight past it. A cell
whose attribute table reported 66 dBZ came back as 34 before this was fixed.

Two things are honestly modelled rather than measured, and the panel says both
on screen. **The vertical distribution**: only the 0.5° tilt is published as
public tiles — every higher elevation scan returns 503 from the keyless
endpoints — so there is no volume to render. Column heights are interpolated
between two measured anchors: the strongest return reaches the measured echo
top, weaker returns are proportionally shallower. **The vertical scale**:
heights are drawn 2.5× exaggerated, as operational 3D radar displays do,
because a storm really is several times wider than it is tall and a true-scale
render is an unreadable pancake.

If the tiles cannot be read — offline, outside NEXRAD coverage, or a host that
stops sending CORS headers — the view falls back to a generic silhouette and
**says that it has**, rather than passing a stock shape off as this storm.

### What it refuses to do

- It will not put you in front of the core. The inflow arc should never produce
  that, but a suggested position is a thing people drive to, so it is checked
  rather than assumed and refused loudly if it ever fails.
- It does not route you. It assumes a road exists where it points, and it
  cannot see terrain, trees or traffic.
- It is working from a snapshot already up to six minutes old.

It is a framing aid. Never let it put a storm between you and your way out.

---

## Does long range actually work?

Short answer: **as probability, yes. As a daily forecast, no** — and the gap
between those two is the whole design of the outlook panel.

**Two different things get called "ensemble".** Vane has both, and they measure
different errors:

| | What it is | What it measures |
|---|---|---|
| **Model agreement** panel | Five agencies' *single* runs (ECMWF, GFS, ICON, GEM, ARPEGE) compared | Model *formulation* differences — physics, resolution, assimilation |
| **16-day outlook** panel | One model (ECMWF IFS) integrated 51 times from slightly perturbed starting states | The chaos in the atmosphere itself — the thing that actually bounds prediction |

The second is the real one. Its spread is not vendor disagreement, it is the
forecast's own uncertainty, and it grows the way you'd expect. Measured at
Oklahoma City on the captured run:

| Lead | p10–p90 spread |
|---|---|
| Day 1 | 1.0 °C |
| Day 3 | 1.5 °C |
| Day 6 | 4.6 °C |
| Day 8 | 7.4 °C |
| Day 10 | 8.4 °C |
| Day 14 | 11.6 °C |

**What ensembles do and don't buy you.** They do not push the predictability
limit further out — nothing does; it is a property of the atmosphere, not of
the model. What they give you is *calibrated* uncertainty and an ensemble mean
that beats any single run at longer leads, because averaging discards detail
that was never predictable in the first place. Past roughly a week to ten days,
only regime-scale signal survives: warmer or cooler, wetter or drier than
normal. Specific daily highs do not.

**So where exactly does it stop?** Most apps answer this with a fixed rule —
show 10 days, or 14, or grey out day 11 — which is wrong, because the answer
moves. A locked-in summer ridge stays skilful much longer than a progressive
winter pattern, and the same date can be firm in Phoenix and mush in
Reykjavík.

Vane measures it instead. For each day it computes the ensemble's p10–p90
spread, and divides by the p10–p90 spread of the last **20 years of ERA5** for
the same calendar window at that exact point (±7 days, ~300 samples). That
ratio is the answer:

- **≤ 0.35** — forecast. Members agree; the day is knowable.
- **≤ 0.65** — low confidence. The shape is there, the detail isn't.
- **≤ 0.90** — trend only.
- **> 0.90** — the ensemble is as uncertain as the climate record. It has told
  you nothing you didn't already know from the calendar.

The skill horizon is drawn where that ratio stays above the threshold for two
consecutive days — sustained, so one noisy day doesn't move the marker. **Past
it, Vane stops printing daily temperatures entirely** and shows arrows for
which way the pattern leans against normal. That is the only statement left
with any skill in it, so it is the only statement made.

The panel also draws the single deterministic run as a dashed line over the
ensemble. Watching it wander outside its own ensemble's middle half around day
8 is the most useful thing in the chart: that line is what every other app
would have shown you as *the* forecast.

---

## Data sources

Every source is public and requires no key or account.

| Source | Used for |
|---|---|
| [Open-Meteo](https://open-meteo.com/) | Forecast, 15-minute nowcast, pressure levels, convective parameters |
| [Open-Meteo Ensemble](https://open-meteo.com/en/docs/ensemble-api) | ECMWF IFS 51-member ensemble, 16 days, for the extended outlook |
| [Open-Meteo Archive (ERA5)](https://open-meteo.com/en/docs/historical-weather-api) | 20 years of daily values, used to compute local normals in-browser |
| [Open-Meteo Geocoding](https://open-meteo.com/en/docs/geocoding-api) | Location search |
| [Open-Meteo Air Quality](https://open-meteo.com/en/docs/air-quality-api) | US AQI and pollutants |
| [NWS api.weather.gov](https://www.weather.gov/documentation/services-web-api) | Alerts, warning polygons, station observations, Area Forecast Discussions, and the radar station list with live VCP and latency (US) |
| [NOAA SPC](https://www.spc.noaa.gov/) | Convective outlooks; tornado/wind/hail reports as the fallback (US) |
| [Iowa State Mesonet](https://mesonet.agron.iastate.edu/ogc/) | NEXRAD Level III tiles — national mosaic, five-minute archive, and per-site reflectivity/velocity — plus the storm attribute table carrying MDA / TVS / hail detections (US); worldwide METAR station directory and archive (the scorecard outside the US) |
| [RainViewer](https://www.rainviewer.com/api.html) | Global radar tiles and coverage mask; outside the US, the radar VaneMotion learns from and the overhead reading |
| [Esri](https://www.esri.com/) canvas basemaps | Base map tiles |

Leaflet 1.9.4 is vendored in `vendor/` rather than loaded from a CDN — radar is
the app's most-used feature and shouldn't depend on a third-party host being
reachable.

---

## When the model and the sky disagree

Open-Meteo's 15-minute precipitation field is *model output*, not an
observation. When it misses a shower — which happens — a nowcast built on it
alone will tell somebody standing in the rain that no rain is expected for two
hours. A forecast that contradicts the window is not one anybody reads again.

So the nowcast is reconciled against things that actually observe the sky,
both of which Vane already fetched and only ever displayed elsewhere:

- **The nearest METAR.** An instrument at an airport reporting what is falling
  at the ground. Read from the NWS's structured present-weather groups, with
  the raw report as a fallback. Fog and mist are not precipitation; rain
  reported `VC` — in the vicinity — is not rain on you; and the remarks section
  is never read, because `RAB05` there means *rain began at :05*, which is past
  weather.
- **The radar directly overhead**, read out of the same NEXRAD tiles the map is
  drawing, over a 4 km box — "is it raining on me", not "in the county".

Neither wins automatically. The METAR stands on the ground but can be 20 km
away, and a summer shower is smaller than that, so a dry airport is no evidence
that your street is dry — the radar sample is the more local reading and may
override it. What the radar may *not* do is override on a weak echo: 15–20 dBZ
is the band where virga lives, and it is reported without ever being called
rain. Below both sits the model, which speaks only when neither can.

One case gets a hedge instead of a verdict: real rain-grade echo overhead
against a *fresh* station report of nothing falling. That is genuinely
ambiguous — a shower may have started since the station reported, or the beam
may be seeing rain that evaporates before it lands — so the headline says
"radar shows precipitation overhead" and states the station's dissent, rather
than flatly asserting "precipitation is falling now" over two instruments that
disagree with it. That flat assertion was photographed, questioned, and
retired.

A reading that could not be taken is never a dry reading. Offline, outside
NEXRAD coverage, or with the canvas tainted, that source simply has no verdict.

When the observation and the forecast disagree, the card says so — and the
whole card moves together. The headline, the hero's condition, its icon and the
sky tint behind them all follow the observation, because a sun captioned
"Clear" beside a line reading "Light rain now" is the same broken promise moved
up one line.

---

## VaneMotion: machine learning that runs on your device

Every radar app animates the last hour and leaves you to eyeball where the
echoes are headed. Vane fits the motion instead — and the fit is original to
Vane: it is not an agency product, not an API, not a model someone else runs.
It is learned in your browser, from the radar over your own head, every scan
cycle.

How it works, in full, because a learned number you cannot audit is a number
you should not trust:

1. **Observe.** The browser samples the national mosaic around your pin at six
   times over the last fifty minutes — the same CORS-open Iowa State tiles the
   map draws, inverted to real dBZ with the same pixel-exact colour table the
   3D view uses. A ~112 km box, 48×48 grid per frame.
2. **Match.** For each consecutive pair of fields, an integer block match
   finds the displacement that best maps one onto the other — cross-correlation
   over every shift up to a physical cap of 120 km/h. A flat correlation
   surface (uniform rain, or nearly no echo) is *no verdict*, never
   "stationary": you cannot learn motion from a field with no trackable
   structure, and Vane refuses to pretend otherwise.
3. **Fit.** A least-squares fit through those displacements yields one
   velocity — and a residual, which is the fit's own report of how much the
   pairs agreed. Pairs that fought each other beyond the gate discard the
   fit entirely. Five independent observations, one straight-line model,
   honest error bars: that is statistical learning in its plainest form, run
   to completion on a phone in milliseconds.
4. **Project.** From the velocity and the newest field, Vane looks upstream
   for the nearest rain-grade echo whose track actually crosses your pin, and
   converts distance over speed into an arrival time. An echo moving away, or
   passing to one side, gets no arrival time. Nothing inbound within the
   corridor is said as exactly that.

The line it produces under the nowcast ends with the same words every time:
*"Learned in your browser from the last hour of radar."* That is the label
doing its job — this is Vane's own on-device fit, one rung below a direct
observation, and the reader deserves to know which rung they are standing on.

**Outside the United States** the same four steps run on RainViewer's global
composite. Its free tiles turn out to be exactly as readable as Iowa State's:
whatever colour scheme the URL asks for, the cache serves one palette —
"Universal Blue" — and RainViewer publishes that palette per decibel. Checked
against 28,382 live pixels: every opaque pixel is an exact table colour, and
every translucent one is identified by its alpha alone (canvas readback
distorts translucent RGB but never alpha). The differences are carried, not
hidden: frames are ten minutes apart, so each pair's interval is its real
one; the newest frame is typically five to fifteen minutes old, so arrival
times are counted from now rather than from the frame; the free cache stops
at zoom 7; and before anything is read, RainViewer's coverage mask is asked
whether a radar sees the pin at all. Where none does, the nowcast says
*"No public weather radar covers this location"* — because a blank tile over
Kinshasa is not clear sky, it is no radar. The line names its source:
*"Learned in your browser from the last hour of RainViewer's global radar
composite."*

What it will not do: it never speaks when it could not measure (offline,
outside radar coverage, too little echo, an ambiguous match — the line simply
does not appear), it never extrapolates growth or decay (a building cell will
arrive sooner and harder than pure advection says; the storm section of the
app is for that), and it never dresses the fit up as a forecast product. It is
an extrapolation of observed motion, exactly one hour deep, and it says so.

### VaneMotion grades its own homework

An arrival time is a claim, so Vane checks it. Every call — "rain reaches you
in about 25 minutes" — is recorded when it is made (one per approaching echo;
a 25-, 20-, 15-minute countdown on the same rain is one call). Once its window
has passed, Vane looks back at the archived radar over the pin, frame by
frame, and finds when rain actually arrived, using the same ≥ 20 dBZ test the
nowcast uses. Within ±10 minutes is a hit; otherwise early, late, or — if it
never came — a miss, which counts. A frame that fails to load leaves the call
unsettled and retried, never scored dry. From three graded calls on, the
motion line and Insight carry the record: *"Its record here: 7 of 10 arrival
calls landed within ±10 min (1 early, 1 late, 1 never came)."*

In the US the archive is Iowa State's five-minute mosaic, kept for years.
Abroad it is RainViewer's, which keeps two hours at ten-minute frames, at
addresses that exist only in its current index — so a call outside the US is
graded only if Vane is opened within about two hours of its window closing.
Later than that, its frames are gone, and the call is dropped and counted as
expired: never guessed, never scored.

**And it corrects itself.** Every graded call that saw rain arrive records the
*raw* fit's timing error. Once there are five, the median becomes a
correction: if rain here keeps arriving 8 minutes after the fit's time, the
next call is moved later. Cautiously — the median is shrunk toward zero as if
five more calls had said "no bias", anything under 2 minutes is left alone,
and it is capped at 20. It keeps learning from the raw fit's errors, never
from its own corrections, and the motion line says every time it applies
(*"That is 4 min later than the raw fit said, because over 6 graded calls
here rain has arrived a median 4 min after the fit's time."*). It also audits
itself: once five corrected calls are graded, if the corrected times were
further off than the raw ones would have been, it switches itself off and
says so; if they were closer, it says by how much.

**Two clocks, one answer.** VaneMotion extrapolates the radar; the forecast
model's 15-minute nowcast (HRRR in the US, global models elsewhere) runs the
physics. Radar extrapolation usually wins at short range and the model further
out — but which is better *here* is an empirical question. So both make
arrival calls, both are graded by the same archive check, and when both see
rain coming Insight gives a blended time weighted by each one's record (inverse
mean squared error; rain that never came costs as much as being 30 minutes
out): *"Rain around 5:42 PM: the radar fit says 5:35, the forecast model 5:50 —
weighted 70/30 by their records here."* Equal weights until each has five
graded calls. The blended call is graded too, so whether blending earns its
keep is on the record, beside the radar fit's own.

### The local scorecard: which agency is best *here*

The second learner, same spirit. Every weather argument — "the Euro nailed
it, the GFS blew it" — is usually fought from memory. Vane keeps score, and
keeps it for your exact location:

1. **Record.** Each time forecasts refresh, Vane notes what all seven
   agencies say the coming days' highs and lows will be at your pin. Future
   dates are overwritten on every refresh, so what finally sticks for a
   date is the last forecast seen before the day began — the **day-ahead**
   forecast, by construction. Leads are never mixed.
2. **Verify.** Once a day has happened, Vane fetches that day's METARs from
   the nearest station and reduces them to the true observed high and low —
   a thermometer's answer, not another model's. A day with too few
   observations to bound its extremes is discarded, never guessed.
3. **Rank.** The running mean absolute error per agency is the leaderboard,
   shown on the Model agreement card once an agency has three verified
   days: rank, error on highs, error on lows, sample size. The best model
   at your location is simply the one that has been the least wrong there.

Everything lives in localStorage on your device. Moving the pin starts a
fresh scorecard rather than blending climates, and the card says which
station's thermometer did the judging.

**Outside the US** weather.gov has no stations, and the scorecard used to sit
empty abroad. METARs are global, though, and Iowa State archives them all,
CORS-open. Vane finds the nearest one from Iowa State's station directory
(one network per country, each with the bounding box of its stations),
within 50 km, skipping stations that file too few reports to bound a day — a
heliport filing nine reports a day would have every day discarded — and then
verifies against that station's archived METARs exactly as it does with
weather.gov at home. Still a thermometer, never reanalysis. Over open ocean or
anywhere without a reporting station within 50 km, there is nothing to verify
against, and the scorecard stays empty rather than inventing one.

### Rain chances: what "40%" means here

A rain chance is a claim about frequency — of all the hours given 40%, rain
should fall in about four in ten. `js/raincal.js` checks that claim at your
location, hour by hour:

1. **Record.** Every forecast hour six to forty-eight hours out has its chance
   written down, overwritten on each refresh, so what sticks is the chance
   shown about six hours before the hour.
2. **Verify.** After the hour, the nearest station's METARs for it — from
   Iowa State's archive, worldwide — say whether precipitation fell there:
   rain, drizzle, snow, ice pellets, hail or unknown precipitation reported
   at the station, or 0.25 mm measured where the station measures. "In the
   vicinity" is not on you and does not count; thunder without rain does not
   count. An hour with no report is not dry — it waits, and is dropped after
   a few days.
3. **Bin and calibrate.** Each verified hour joins its 10% band. Once a band
   has twenty hours, Insight offers the day's highest chance beside what such
   chances have meant here (*"The forecast gives 60% around 6:00 PM. Here,
   hours given that chance have only seen rain 32% of the time (40 hours
   checked against KOUN)."*), shrunk toward the forecast's own number as if
   ten hours had agreed with it. The official chance is never replaced, and
   the full reliability table is on the Outlook accountability card.

A station a few kilometres away can miss a shower that hits you, and the
other way round; the table says which station judged it, and the curve is
only as local as that station.

### The microclimate correction: how the forecast leans at your spot

The scorecard's errors are stored *signed* — forecast minus observed —
because the sign is where the third learner lives. The displayed forecast's
own day-ahead highs and lows go on record beside the agencies', and their
mean signed error over verified days is the model's systematic lean at your
exact location: some places genuinely run cooler than their grid cell says
(a valley floor, a lake shore), and only a thermometer can prove it.

The offered correction is the negated bias, shrunk toward zero by
n/(n+4) — three days of evidence earn under half the correction, weeks earn
nearly all of it, so a small sample can never fling a wild adjustment at
the card. A lean that alternates warm and cool averages to nothing and is
refused as noise. And the correction is *offered*, never applied: the week
card keeps the official numbers and adds "adjusted for that lean, today
reads closer to…" beside them, because a forecast that silently edits
itself is a forecast nobody can check. When there is no lean, the card says
"running true — nothing to correct", which is the finding that earns the
feature its trust.

**Weather-aware.** A spot's lean is rarely one number — a valley runs cold
on clear calm nights and true under cloud; a lake shore runs cool on onshore
wind. Each verified day also carries the forecast's own picture of it (sky
from mean cloud cover; the dominant wind's quarter), and the correction can
become the overall lean plus a per-regime adjustment, each shrunk toward zero.
It has to earn that: once ten days carry a regime, every day is predicted
leave-one-out — corrected by a fit made without it — both ways, and the
weather-aware version is used only if it leaves the smaller typical miss. When
it is, the card says what about today moves the number and the test it passed
(*"On cloudy days like today it leans further: highs 2.7° warmer… tested day by
day on the 16 verified days here, it cut the typical miss from 2.1° to 0.9°."*).

### Per-cell trend learning: the derivative of the attribute table

The storm attribute table is a snapshot per volume scan; a chaser's real
question is usually the derivative. The feed carries stable per-radar cell
ids, so Vane strings each cell's scans into a short history and fits a
least-squares line through its core reflectivity and echo top. A cell whose
core has climbed 38 → 51 dBZ across four scans is organising, whatever its
current rank says — and its row in Areas of interest now says so, slope and
evidence attached, with echo-top corroboration when the top is moving too.

The rules: at least three scans spanning eight minutes before any verdict
(two points is a line through anything), the verdict comes from the fitted
slope rather than first-versus-last, a ±1 dBZ wobble reads as steady and
stays quiet, re-served scans are not new observations, and a history dies
with its storm rather than bleeding into the next cell to reuse the id.

### Two storm models, trained offline, run in your browser

Every storm cell on the Chase tab can carry a **Model** line from two models
trained on real history and shipped as 3 KB of plain numbers
(`js/stormmodel-weights.js`). No server runs them; no key unlocks them.

- **Core in ~20 min** — where the cell's peak reflectivity will be in twenty
  minutes, from its current attributes and its fitted trend. Linear
  regression. It needs the trend, so it speaks once the app has watched the
  cell for three scans.
- **Severe report within 30 min** — the probability that a tornado, an inch
  of hail, a 58 mph gust or thunderstorm wind damage is *reported* within
  15 km of the cell in the next half hour. Logistic regression on a single
  scan, so it speaks at once.

**How they were made** (`scripts/train/`, fully reproducible):
`fetch.js` downloads Iowa State's archived NEXRAD storm attribute tables —
the same fields the app reads live — and local storm reports for every fifth
day from April to July of 2023 and 2024, over twenty radars from the Plains
to the South. Systematic, not cherry-picked: quiet days are in the sample, so
the model does not learn that every storm is severe. `train.js` links scans
into cell tracks, labels them, and fits both models with no libraries (ridge
regression; logistic regression by damped Newton). Features come from
`js/stormmodel.js featuresOf()` — the very function the app runs — and a test
holds an archive row and the equivalent live record to identical features.

**How they scored**, on 12 days the fit never saw (351,422 tracks,
13,902 severe reports in all):

| | Model | Baseline |
|---|---|---|
| 20-min core error | **3.41 dBZ** | 3.63 assuming no change · 6.49 extending the trend |
| Direction of a ≥ 5 dBZ change | **75%** right | — |
| Severe-report ranking (AUC) | **0.913** | 0.839 for Vane's own hand-tuned threat score |
| Brier skill vs climatology | **+0.246** | 0 |

Its percentages hold up: cells given 1–2% were followed by a report 1.0% of
the time, 5–10% → 7.1%, 40% and up → 54%. A model ships only if it beat its
baseline on the held-out days; the weights file records that test and the
app checks it. In the app, each 20-minute outlook is also graded against the
scan that actually arrives, and the cell card's disclosure reports the
session's record beside what "no change" would have scored.

**Hail and track** came next, from the same archive and pipeline:

- **Hail 1″+ / 1.75″+** — probabilities of a *report* of hail at least an inch,
  and at least golf-ball size, within 15 km and 30 minutes. They out-rank the
  radar's own hail-size estimate by a wide margin (AUC 0.93 vs 0.61 for 1″
  hail; 0.94 vs 0.61 for golf ball), with positive Brier skill — but they ran
  low in the middle of the range on the held-out days, so the card says to
  read them as a floor.
- **Model track** — where the cell will be in 30 minutes. A trained correction
  to the attribute table's straight-line motion, using the cell's observed
  motion once the app has watched it. Thirty minutes out it was 13.9 km off
  on average against 16.7 km for the straight line (8.3 vs 8.6 km for watched
  cells). It replaces the straight line in closest-approach timing, the
  threat banner and the map's projected tracks, says "model track" wherever
  it is used, and is graded against the scan 30 minutes on, live.

**What they are not.** Storm reports are what people reported — a storm over
empty country produces fewer of them — so the severe number predicts a report,
not the weather itself, and the card says so. The sample is spring and summer
in the central and southern US; outside that, the numbers have not been
tested. And neither is a warning: follow the NWS.

### Chase-day odds: is the environment worth the drive?

The Chase tab's convective card ends with **Chase-day odds**: the chance of a
severe local storm report within 100 km of you this evening and tomorrow
evening, and each compared chase target carries the same number for its own
point. It is a logistic model (`js/chaseday.js`, weights in
`js/chaseday-weights.js`) fed the forecast's profile at 00Z — the hour the
training soundings were launched — through the same CAPE, CIN, 0–6 km shear,
0–1 and 0–3 km helicity and LCL the card already shows.

**How it was made.** `scripts/train/fetch-env.js` downloads Iowa State's
archive of real upper-air soundings, with their derived parameters, for 39
NWS sites from the Rockies to the East Coast, every day of April–July 2023 and
2024, plus every local storm report in those months. `scripts/train/env.js`
labels each evening sounding by whether a tornado, 1″ hail, 58 mph gust or
wind-damage report followed within 100 km between 11 am and 1 am Central, and
fits the model with the same no-library pipeline as the storm models.

**How it scored**, on 61 days it never saw (2,255 station-evenings; 12.6% had
a report):

| | Model | Baseline |
|---|---|---|
| Ranking good days above bad (AUC) | **0.782** | 0.737 CAPE × shear (WMAXSHEAR) · 0.732 Vane's own index |
| Brier skill vs climatology | **+0.132** | 0 |

Its percentages hold up: evenings given under 5% saw a report 2.8% of the
time, 10–20% → 15.7%, 45–60% → 56%.

**What it is not.** It reads the forecast's environment, so it is only as
good as that forecast. It is the environment's odds, not a forecast that
storms will form: a strongly capped day with big CAPE and shear is what it
learned to discount, but it cannot see the cap break or the boundary that
fires a storm. A report needs a person to see and send it, and the sample is
spring and summer east of the Rockies. Not a warning; follow the NWS and SPC.

### Vane Storm Odds: Vane's own model

**What it says.** The chance that a severe storm is *reported* — a tornado,
hail an inch or larger, a 58 mph gust or thunderstorm wind damage — within
40 km of a point in the next three hours. It is in the Vane AI card for your
place (now, and the highest of the next 12 hours), and on the map as the
**Storm odds** layer, stepping Now / +3 h / +6 h / +9 h.

**What it reads.** The atmosphere only: CAPE, CIN, lifted index, dewpoint,
precipitable water and the wind at 10 m, 850 hPa and 500 hPa — the same
variables, from Open-Meteo's forecast, in the app as in training. Never the
storms themselves: no radar, no model rain or reflectivity. It is the
environment's odds; it cannot see whether the cap breaks.

**How it was made** (`scripts/train/`, reproducible, no libraries in the fit):
`fetch-hrrr.py` takes NOAA's HRRR analyses — the 3 km model's best estimate of
the real atmosphere — from the public AWS archive, field by field with byte
ranges: April–July of 2023 and 2024, every fourth day, every third hour, land
points ~36 km apart. 496 hours × 8,392 points; quiet days and nights included.
`storm.js` labels each with the NWS reports that followed (12,164 of them),
splits whole days three ways — train, validate, and 15 test days nothing ever
touched — and fits a logistic model and a small neural network (one hidden
layer of 16), keeping whichever validates better: the network. Its raw
percentages ran high at the top ("37%" verified at 8%), so an isotonic map
fitted on the validation days calibrates them; it can now claim at most about
20%.

**How it scored** on the 15 test days (1,007,040 samples, 3,911 with a report):

| | Storm Odds | CAPE × shear | CAPE alone |
|---|---|---|---|
| Ranking (AUC), all samples | **0.947** | 0.896 | 0.878 |
| Ranking where CAPE ≥ 500 J/kg — the hard cases | **0.868** | 0.758 | 0.680 |
| Brier skill vs climatology | **+0.051** | — | — |

Its percentages hold up: hours it gave 1.4% saw a report 1.4% of the time,
3.1% → 3.5%, 6.4% → 7.7%, 13% → 13%; its top band ("20%") verified at 12% on
237 samples, so read the top of the scale as "the highest it goes".

**What it is not.** A report needs someone to see and send it, so empty
country scores lower than the weather deserves. It learned spring and summer
in the US; other seasons are untested, and other places are not drawn at all:
the layer and the card speak only over the lower 48 (masked with the Census
population grid, `data/popgrid.png`), after it was photographed painting
Mexico and the open Pacific. It runs on the forecast,
so it is only as good as that. Not a warning: follow the NWS and SPC.

### Vane Insight: the learners, fused

The fifth layer takes the other four's outputs and composes the read a
sharp meteorologist friend would give you — as deterministic sentence
synthesis, not a language model. Priority order: the loudest NWS alert
always leads (and the line itself says to follow official guidance first);
then the inbound storm cell with its fitted trend; then rain timing, where
VaneMotion's measured fit outranks the model nowcast and the nowcast
speaks only when the fit has nothing; then Vane's number; then the
scorecard's verdict on who to trust here. Every line carries a tag naming
the learner it came from.

Vane's number is the piece nobody else can compute: each agency's forecast
for your point, weighted by the inverse of that agency's *measured local
error* from the scorecard, then shifted by the microclimate correction. A
forecast tuned to one location by evidence gathered at that location. The
honesty rules carry through — weights apply only once two or more agencies
have verified local records (one scored agency against unscored peers is a
thumb on the scale, so it falls back to equal weights and says so), the
official forecast is always shown beside Vane's, and when the agencies
simply agree, the card reports agreement instead of dressing it up as
insight.

---

## Honest limits

Stated here rather than papered over:

- **A nowcast is still a forecast past the current minute.** The observation
  settles whether it is raining *now*. Nothing observes what happens in ninety
  minutes, so when the model has missed the shower entirely Vane says it cannot
  tell you when it will stop rather than inventing a time.
- **The nearest station can be a long way away.** It is named, and its age in
  minutes is printed, so you can judge how much it is worth. An observation
  older than 75 minutes is discarded rather than quietly aged.

- **No national velocity mosaic, and no dual-pol products.** Base velocity
  (N0U) and storm-relative velocity (N0S) are available *per radar site* and
  Vane shows them, but there is no keyless national velocity mosaic, so
  velocity means picking a site. Dual-pol products (ZDR, CC) aren't publicly
  tiled at all — that is what RadarScope is for, and Vane doesn't fake them.
- **RainViewer's free tile cache ignores its own colour-scheme parameter.** All
  nine documented scheme ids return byte-identical tiles in its "Universal
  Blue" palette. That palette *is* published per decibel, and the tiles match
  it exactly, so the global legend is a real dBZ key — but the cache stops at
  zoom 7 and keeps only two hours of frames. NEXRAD is still preferred wherever
  it's available: finer, five-minute, and archived for years.
- **Rotation detections are the radar's, not ours — and they are fallible.**
  MDA and TVS have well-documented false-alarm rates. A TVS is a velocity
  signature indicating a mesocyclone in some stage of tornadogenesis; it is
  **not** a confirmed tornado. Attributes update per volume scan (~4–6 min).
- **The shot planner is a framing aid, not a routing or safety system.** It is
  geometry over a radar snapshot that is already up to six minutes old. It
  assumes a road exists where it points, cannot see terrain, trees or traffic,
  and does not know what the storm will do next. It will not hand you a
  position in front of the core — that is checked, not assumed — but no
  computed vantage replaces knowing your escape route.
- **The 3D view's shape is real; its vertical is a model.** The footprint and
  intensity are the actual 0.5° reflectivity field. But only that tilt is
  published as public tiles — every higher elevation scan (N1Q, N2Q, N3Q)
  returns 503 from the keyless endpoints — so nothing observes the storm's
  interior. Column heights are interpolated between the measured echo top and a
  floor, and drawn 2.5× vertically exaggerated. Both facts are stated in the
  panel.
- **Cloud base is Espy's approximation**, 125 m per degree of dewpoint
  depression — the rule of thumb chasers use, good to a couple of hundred
  metres in a well-mixed boundary layer, and labelled as approximate wherever
  it appears rather than dressed up as a parcel calculation.
- **No lightning data.** There is no free, CORS-accessible real-time lightning
  feed. Rather than show a stale or fabricated layer, there isn't one.
- **The 3 km CAPE field is US-only** (it is the HRRR's domain) and comes from
  Unidata's public THREDDS server, which publishes each run about two hours
  after it starts; elsewhere CAPE is the coarse sampled grid.
- **Alerts, outlooks, storm reports and station observations are US-only.**
  Everything else is global.
- **Convective parameters are derived model guidance, not observations.** Shear,
  storm motion and SRH are computed in-browser from Open-Meteo pressure-level
  winds and geopotential heights using standard formulations. The app labels
  them as derived. The "supercell index" is a rough blend of CAPE, shear and
  SRH — it is deliberately *not* the SPC SCP and is labelled as such.
- **The AI summary is a reading aid, not a source.** It only ever compresses
  the discussion sitting underneath it, and every point it makes is checked
  against that text before it is shown — but the discussion itself is one
  forecaster's reasoning at one moment, and a verified quote proves the words
  are real, not that the summary weighed them the way you would. Read the
  original; it is right there. Nothing in the safety path — warnings, alerts,
  radar — passes through a model.
- **The extended outlook is not a 16-day forecast and does not claim to be.**
  Past the measured skill horizon it deliberately shows no daily numbers,
  because there aren't any worth showing. The horizon itself is a
  spread-vs-climatology ratio, which is a good practical proxy for
  predictability but is not a formal skill score against verified outcomes —
  Vane has no verification archive to compute one from.
- **Normals come from ERA5 reanalysis at the model grid point**, not from a
  nearby station. At the scale of a valley or a coastline the reanalysis can
  differ noticeably from what a local station would record.
- **Area Forecast Discussions are US-only**, and a few offices publish them
  under a location code Vane's lookup doesn't resolve. When that happens the
  card simply doesn't appear.
- **Vane is not a substitute for official warnings.** In severe weather, follow
  the NWS and local emergency management.

---

## Architecture

No framework, no build. Plain ES5-compatible IIFE modules on `window`, loaded
in dependency order.

```
index.html            markup and load order
css/style.css         dark-first, high-contrast, theme-aware
js/config.js          endpoints, WMO codes, model list, risk tables, shortcuts
js/util.js            unit conversion, formatting, geometry, timezone helpers
js/settings.js        preferences, alert filtering, notifications, wake lock
js/api.js             every network call, all keyless
js/derive.js          nowcast, observed-vs-model reconciliation, derived meteorology
js/icons.js           animated SVG weather icons
js/theme.js           sky palettes, condition theming, precipitation canvas
js/models.js          multi-model ensemble statistics and confidence
js/modelcast.js       per-agency daily runs: GFS, Euro and five more as scenarios
js/outlook.js         ensemble percentiles, local normals, measured skill horizon
js/outlookchart.js    the 16-day box-plot chart
js/meteogram.js       the combined forecast chart
js/layers.js          wind, temperature and CAPE field overlays for the map
js/cells.js           storm cell triage: threat scoring, closest approach
js/reflectivity.js    reads dBZ back out of radar tiles: IEM's N0Q table, RainViewer's Universal Blue
js/motion.js          VaneMotion: block-match + least-squares motion fit, arrival calls
js/motionskill.js     VaneMotion's report card: calls graded against the archived radar
js/verify.js          the scorecard and microclimate learner: forecasts vs METAR extremes
js/raincal.js         rain-chance reliability at your location: hourly chances vs station reports
js/notifylearn.js     notifications that learn from what you open and dismiss — never mutes Extreme
js/insight.js         Vane Insight: the learners fused into one tagged read (pure)
js/stormmodel.js      two storm models (20-min intensity, severe-report probability): features + inference
js/stormmodel-weights.js  GENERATED by scripts/train/train.js: the fitted numbers and their held-out scores
js/chaseday.js        chase-day odds: a severe report within 100 km, from the evening (00Z) profile
js/chaseday-weights.js    GENERATED by scripts/train/env.js: the fitted numbers and their held-out scores
js/stormodds.js       Vane Storm Odds: features + inference (shared with scripts/train/storm.js)
js/stormodds-weights.js   GENERATED by scripts/train/storm.js: the network, its calibration, its held-out scores
js/ui-ai.js           the Vane AI card: every model, what it says here, its record
js/intelligence.js    decision layer: forecast changes, scenarios, plans, targets, storm stories
js/intelligence-ui.js decision layer rendering
js/modelchart.js      synoptic model chart (pressure + precipitation) over the lower 48
js/usstates.js        lower-48 state outlines for the model chart
js/install.js         home-screen install, and the iOS path that has no API
js/update.js          updates that finish themselves: silent reload or one-tap pill
ios/                  UNTESTED native wrapper + WidgetKit scaffold
js/shot.js            light, structure, framing and vantage geometry
js/storm3d.js         the 3D storm structure render
js/sites.js           NEXRAD site registry, live status, nearest-radar search
js/glossary.js        plain-English definitions, and the markup pass that offers them
js/brief.js           AFD parsing: sections, key messages, mode-aware order
js/radar.js           map, radar sources, frame animation, warning polygons
js/live.js            watches each radar source and refreshes tiles per real new scan
js/astro.js           solar and lunar position (Meeus), no network
js/spc.js             SPC outlooks, NWS storm reports (every kind), point-in-polygon
js/ui-core.js         rendering core — the UI object, status bar, SVG factory
js/lazy.js            loads Chase / Outlook code on first entry; stubs + replay until then
js/ui-now.js          Now tab rendering — hero, nowcast, Insight, hourly, week, storm banner
js/ui-chase.js        Chase rendering — parameters, hodograph, cells, shot planner (lazy)
js/ui-outlook.js      Outlook rendering — models, scorecard, discussion, SPC, reports (lazy)
js/ui-chrome.js       chrome rendering — search, saved places, help, settings, radar sites
js/app.js             controller: state, loading, events, refresh
sw.js                 offline shell and stamped data cache
test/run.js           test suite
```

Two conventions worth knowing before editing:

1. **Everything is SI internally** — °C, m/s, mm. Conversion happens only at
   render time, so derived meteorology never has to care about display units.
2. **Timestamps from Open-Meteo are wall-clock in the *forecast location's*
   timezone.** Use `U.parseLocal` to display them and `U.epochOf(iso, offset)`
   to compare them against `Date.now()`. Mixing these up silently breaks
   everything for any user in a different timezone from the location they're
   looking at — there are regression tests for exactly this.
3. **Sky palettes are generated, not hand-picked.** Each stop is set to a
   contrast target against white (zenith deepest, horizon at the AA floor).
   If you edit `SKIES` in `js/theme.js`, run the tests — adding a colour that
   is too light will fail the build rather than quietly hurting legibility.

---

## Keyboard

| Key | Action |
|---|---|
| `1`–`4` | Jump to a section (Now / Radar / Chase / Outlook) |
| `M` | Toggle Simple / Chase |
| `G` | Use my location |
| `U` | Toggle units |
| `S` | Saved locations |
| `/` | Focus search |
| `Space` | Play / pause radar |
| `F` | Expand radar |
| `O` | Radar options |
| `W` | Wind field layer |
| `T` | Temperature layer |
| `C` | CAPE (instability) layer |
| `N` | Choose a radar site |
| `←` `→` | Step forecast hour (Chase) |
| `R` | Refresh now |
| `V` | Reflectivity + velocity dual pane |
| `D` | Jump to the forecaster's discussion |
| `,` | Settings |
| `Esc` | Close overlay / collapse radar |
| `?` | Help |

---

## Privacy

### Decision features

Vane now includes five connected tools built on its existing public feeds:

| Tool | Where | Behavior |
| --- | --- | --- |
| Forecast briefing | Now → What changed? | Compares successive forecasts for the same future hours, groups named-model rain scenarios, and explains what evidence could change the outlook. |
| Storm stories | Chase → Areas of interest → Follow storm | Saves scan history for up to five cells, shows warning overlap and fixed-motion closest approach, and offers an optional spoken briefing. |
| Chase target comparison | Chase → Compare chase targets | Compares up to three places at a selected forecast hour, including environment, visibility, gusts, daylight and model disagreement. |
| Personal activity windows | Now → Weather for your plans | Saves activities and finds contiguous hourly windows matching temperature, gust, rain and daylight preferences. |
| Forecast accountability | Outlook → Forecast accountability | Records predictions before their valid time and verifies them against later nearby station observations; exports the local history. |

These features run while Vane is open. The briefing is deterministic and
source-based; it does not call an LLM. Model agreement is not a calibrated
probability. A missing or stale storm feed pauses projections without silently
switching to another cell. Split/merge identity is not automatically resolved.
Chase comparisons are point forecasts, not safe intercept routes: road
closures, escape routes, cellular coverage and travel time are unavailable.
The directions link opens Google Maps with the selected destination.

The journal keeps temperature errors separate by lead bucket and verifying
station; it does not rank providers. Small samples remain explicitly
preliminary. Storm-position errors are checked against subsequent NEXRAD cell
positions, not ground-truth tornado positions. Cached or stale forecasts do
not become fresh predictions. Official alert outages remain unknown, and
severe official alerts pause activity suggestions.

The September UI refresh follows the current Vane mockup: navy labels, pale
blue surfaces, an asymmetric desktop Now layout, underline navigation,
responsive cards and larger mobile controls. Sources remain readable in
both color schemes. Service-worker shell version 37 includes the new modules.

Validation: `TZ=UTC node test/run.js` (314 tests),
`node test/intelligence.js` (27 tests), and
`node test/intelligence-dom.js` (12 checks; requires `jsdom` via Node module
resolution). The DOM checks exercise the real application modules with
fixture APIs. Browser visual review and the existing full browser suite
still need to run in a browser-enabled environment before release.

There is no server. Preferences, saved locations and one cached forecast live
in `localStorage` on your device and nowhere else. Requests go directly from
your browser to the weather APIs listed above. Nothing is logged, profiled or
sold. Clearing your data is one button in Settings.

Decision history also stays in localStorage (`vane.intelligence.v1`), including
saved activities, targets, followed storms and bounded forecast records.
Use Outlook → Forecast accountability to export or clear this history.

There is no API key of any kind. The browser test suite asserts that no
request in the entire run carries a key header. (If an earlier version of
Vane stored one on this device, it is deleted on the next launch.)

