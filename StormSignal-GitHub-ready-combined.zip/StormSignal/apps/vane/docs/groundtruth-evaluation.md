# Ground Truth evaluation

Generated from the same run as `groundtruth-evaluation.json`. Do not edit these numbers by hand.

**ship: false**. Failed checks: noWorseThanRadarPeople.

Split: **26 training / 12 validation / 12 test days**.

| Split | Days | Cell scans | Positive cell scans |
|---|---:|---:|---:|
| train | 26 | 748189 | 32911 |
| val | 12 | 380018 | 19651 |
| test | 12 | 356002 | 17834 |

Counts are cell scans. One report can label multiple scans or radars; they are not independent storm events.

| Model | Validation log loss | Test log loss | Test AUC | Test Brier skill |
|---|---:|---:|---:|---:|
| Radar only | 0.14178751 | 0.12795335 | 0.91362261 | 0.25032618 |
| Radar + people logistic | 0.13317438 | 0.12276779 | 0.92342896 | 0.27133868 |
| Ground Truth | 0.13444512 | 0.12341537 | 0.92362568 | 0.26285573 |

Ground Truth minus plain radar + people log loss: **0.00064758**.

Allowed degradation: **0.0005**; maximum Ground Truth log loss: **0.12326779**; excess over that limit: **0.00014758**.

The gate uses full-precision values saved in JSON; table formatting does not determine pass/fail.

| Gate check | Pass |
|---|---|
| finiteInputs | true |
| beatsRadarOnlyLogLoss | true |
| beatsRadarOnlyAuc | true |
| noWorseThanRadarPeople | false |
| witnessCurveRises | true |
| syntheticRecovery | true |

## Shared population-quintile calibration

Quintiles are by test-scan population feature, with ties kept together. These are not quintiles of country area. Predicted values sum report probabilities.

| Quintile | Scans | Observed positive scans | Radar only predicted | Radar + people predicted | Ground Truth predicted | Ground Truth relative bias |
|---|---:|---:|---:|---:|---:|---:|
| 1 | 71399 | 3400 | 3746.90 | 2379.05 | 2422.41 | -28.75% |
| 2 | 73105 | 3388 | 3542.10 | 2959.06 | 3045.34 | -10.11% |
| 3 | 71363 | 3567 | 3669.27 | 3632.88 | 3591.43 | 0.68% |
| 4 | 69494 | 3012 | 3346.44 | 3564.35 | 3396.99 | 12.78% |
| 5 | 70641 | 4467 | 4071.52 | 5334.37 | 4582.31 | 2.58% |

## Exact test dates

2023-04-16, 2023-05-06, 2023-05-26, 2023-06-15, 2023-07-05, 2023-07-25, 2024-04-11, 2024-05-01, 2024-05-21, 2024-06-10, 2024-06-30, 2024-07-20

Each date identifies a 12Z-to-12Z convective day. Validation dates select epochs and the Ground Truth start; test dates do not enter fitting.

## Reproducibility and limits

Generated at 2026-10-05T01:40:47.474Z with v24.19.0. The JSON includes all split dates, input/source SHA-256 hashes, full-precision model coefficients, standardisation, validation selection, per-day results and all gate inputs.

- The test set has already informed the next experiment and is not a fresh final confirmation set.
- Latent occurrence and unreported fractions are model-implied, not measured ground truth.
- Synthetic recovery is within-family simulation, not empirical identification of the latent split.
- The witness-curve gate retains the original three-decimal inputs and 0.01 allowed drop.

See [the audit notes](groundtruth-audit.md) for the correction to the historical 15-day claim and the next experiment.
