# Existing Railway deployment target

Verified 2026-11-12 through the authenticated Railway connector. Reuse this service; do not create another project.

- Project: `vane-weather` (`a613b197-55a7-4acb-ac93-4fbf1d4ab8e3`)
- Service: `vane` (`5c7c40ee-2ff7-401c-9b08-572251be9821`)
- Environment: `production` (`86021774-84f1-4dd4-bfc1-bce9fc454106`)
- Public URL: https://vane-production-02e7.up.railway.app
- Current GitHub source: `caliquora/junk`, branch `claude/weather-app-market-research-gaegw1`
- Latest successful deployment: `ae7d4e0a-e53a-48ca-8a76-e58219980b09`, source commit `89d608043cc9f0ffbc0337948ddddfd099a0d9b0`, deployed October 6, 2026.
- Dockerfile build; `railway.json` config file; no service variables listed.

## Integrated source migration

This document records the deployment target. It does **not** link or deploy the local package. The existing production service remains unchanged.

Before changing the source to `caliquora/stormsignal-radar-reliability`, ensure the reviewed application is actually committed there, under `apps/vane`, and finishes browser/live-feed QA. Configure the build root and Dockerfile/config-file locations for that subdirectory, preserving the existing service/domain/environment. Validate the effective configuration before triggering a build. Do not point Railway to an empty or README-only repository.

After deployment, verify Railway SUCCESS, the public URL, new agent and warning panels, live data errors, service-worker update behavior and source provenance. Keep official warnings separate from experimental explanations. The optional Ollama connection intentionally works only when the app is served on localhost on the same computer as Ollama; it is not an AI server on this Railway deployment.
