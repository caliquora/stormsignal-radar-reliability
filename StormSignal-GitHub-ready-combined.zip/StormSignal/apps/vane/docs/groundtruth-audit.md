# Ground Truth audit of PR #1 at 1547a342

Audited starting commit: `1547a3426238ffa3bb02d84128feac5ea06b3e14` (October 4, 2026).
The historical commit is preserved; this document corrects its evaluation description.
The current numerical results are generated together in
[groundtruth-evaluation.md](groundtruth-evaluation.md) and
[groundtruth-evaluation.json](groundtruth-evaluation.json).

## Reproduction result

The fresh 50-day archive fetch reproduced **every original serialized radar and
detection coefficient, scaling value, and recorded evaluation field exactly**.
The regenerated population PNG also has the identical Git blob hash
`664053c7241f2ddc83320fe1d00cc2ac7db4990c`. The audit preserves the fit,
initialization order, seed, features, labels and gate; only reporting and input
completeness checks change. The original raw-cache hashes were not committed, so
this establishes numerical reproduction rather than proving byte identity of
every historical CSV. The new manifest records those CSV hashes for future runs.

The rerun contains 748,189 training scans (32,911 positive), 380,018 validation
scans (19,651 positive), and 356,002 test scans (17,834 positive). An independent
CSV count gives the same 1,484,209 eligible scans; none is excluded by the grid.

Ground Truth test log loss is **0.12341536694283492**, versus
**0.1227677915868445** for M1. The delta is **0.0006475753559904152**, exceeding
the unchanged allowance by **0.00014757535599041471**. Ground Truth also trails M1
on validation log loss (0.13444512 versus 0.13317438). Its test AUC advantage is
only 0.00019672 before rounding (0.92362568 versus 0.92342896); the old three-decimal
display made that difference look larger.

## The holdout is 12 days

The source selects every fifth date from April through July in 2023 and 2024,
50 dates altogether. Across the sorted dates, zero-based indices modulo four
assign 0 and 1 to training, 2 to validation, and 3 to test. That gives **26
training, 12 validation, and 12 test days**. There is no 15-day test set in this
code. The commit message's “15 held-out days” is a documentation error, not an
alternative evaluation. Validation is used for epoch and initialization selection
and must not be counted as an untouched test set.

All three models receive the same eligible scans, labels, train-only
standardisation, and date split. M0 uses 13 radar features (11 single-scan storm
features plus radar range and squared range). M1 uses those 13 plus the six
population/hour features in one logistic regression. Ground Truth uses the same
inputs in two sigmoids whose probabilities are multiplied. Its three starts are
selected on validation log loss, not test loss. M0 is an experimental radar-only
baseline with range features, not a direct evaluation of the separately deployed
StormModel weights.

## The unchanged gate fails

The historical rounded results are:

| Model | Test log loss | Test AUC | Test Brier skill |
|---|---:|---:|---:|
| Radar only | 0.12795 | 0.914 | 0.250 |
| Radar + people logistic | 0.12277 | 0.923 | 0.271 |
| Ground Truth | 0.12342 | 0.924 | 0.263 |

The gate requires all of the following:

1. Ground Truth log loss strictly below radar-only log loss.
2. Ground Truth AUC strictly above radar-only AUC.
3. Ground Truth log loss no more than **0.0005** above M1 log loss, inclusive.
4. The recorded witness curve does not drop by more than 0.01 between adjacent
   population levels, separately at 15:00 and 02:00 local solar time.
5. Synthetic witness-curve recovery error strictly below 0.1.

Using the recorded rounded losses, the M1 limit is `0.12277 + 0.0005 = 0.12327`.
Ground Truth is 0.00065 worse than M1 and exceeds the allowed limit by 0.00015.
Its slightly higher AUC does not override the failed log-loss condition. The
full-precision rerun and each gate predicate are saved in the generated report.
No threshold was relaxed. `ship` remains false, and the page does not load the
Ground Truth scripts.

The two successful CI runs at the starting head were
[push](https://github.com/caliquora/junk/actions/runs/37176766727) and
[pull request](https://github.com/caliquora/junk/actions/runs/37176769117).
Those workflows exercise application suites and screenshots; they do not fetch
the training archives or rerun the model. Green application CI is not evidence
that the statistical gate passed. This change adds evaluation-policy tests to
the unit job via `npm test`.

## What the sparse-area numbers mean

The historical first quintile sums to 2,422 predicted positive scans against
3,400 observed positive scans: **978 short, or 28.8% below observed**. These are
scan-level report labels, not 3,400 unique reports. A report can label several
scans and overlapping radars. The historical `testReports: 17834` is likewise a
positive-scan count; `reports: 13902` counts qualifying archive report rows across
all 50 days. Neither field is a deduplicated storm-event count.

Quintiles divide the test scans by their population feature, not the country's
land area. The feature averages log10(1 + population) within 40 km at three
projected positions. Its inverse is a geometric population proxy, not an
arithmetic population total or a unique count along a corridor. Ties stay in the
lower bin, so bin sizes can differ. The generated report compares M0, M1 and
Ground Truth using exactly the same bins and denominators, including unrounded
probability sums, residuals, ratios, and per-bin log loss.

The shared first quintile contains **71,399 scans**, with 3,400 positives:

| Model | Predicted positive scans | Relative bias | First-quintile log loss |
|---|---:|---:|---:|
| Radar only | 3,746.90 | +10.20% | 0.12851655 |
| Radar + people logistic | 2,379.05 | -30.03% | 0.12528398 |
| Ground Truth | 2,422.41 | -28.75% | 0.12417676 |

The population-aware models **both** underpredict this group. Ground Truth is
slightly better than M1 within it, including log loss; sparse underprediction
alone does not explain why Ground Truth loses overall. The full report preserves
the other four bins and per-day comparisons instead of attributing the overall
failure to this one subgroup.

`expectedSevere` and `shareUnreported` are latent, model-implied quantities.
Report labels cannot verify that the estimated missing events actually occurred.
The synthetic test draws labels from a perturbed version of the fitted model;
successful recovery is a useful within-family sanity check, not proof of real-world
identifiability. Chasers and automated stations remain hypotheses for the sparse
residual, not established causes. No new observation-source feature is justified
by this residual alone.

## Smallest justified next experiment

**Exclude scans whose complete [-5, +30] minute labeling window falls outside
the downloaded 12Z-to-12Z report window.** The current code reads only that day's
reports. Near the boundaries, an absent report can mean it was not downloaded,
rather than that none existed. This is a concrete label-coverage issue and needs
no new model feature or inferred chaser density.

The baseline audit records `boundaryWindowScans` and
`boundaryWindowNegativeScans` per day without changing its historical labels or
fit:

| Split | Scans with incomplete report windows | Currently negative |
|---|---:|---:|
| Training | 16,081 | 15,962 |
| Validation | 7,082 | 6,975 |
| Test | 9,423 | 9,374 |

There are **32,586** boundary scans overall. These counts do not establish that
any specific negative scan should be positive; they identify incomplete label
coverage. The proposed experimental filter is:

```js
if (t0 < archiveStart || t1 > archiveEnd) return;
```

Apply it before labeling to every model and every split, preserving the same
26/12/12 dates, features, optimiser, seed, and gate. Exclude *all* boundary scans,
not just negatives: selecting on the label would bias the sample. Fit on training,
select epochs/starts on validation, and report all three models on the identical
filtered test rows. Do not compare a filtered Ground Truth score against the
old unfiltered M1 score. An alternative later experiment is fetching report
buffers; that changes the input dataset and must have its own manifest.

This is a data-quality hypothesis, not a claim that boundary censoring explains
the sparse residual or will make Ground Truth pass. Since these test results
have already informed the next experiment, use validation for further decisions
and a separately reserved date block for final independent confirmation. Do not
cycle features against the same 12 test days until one happens to pass.

## Reproduce and inspect

```sh
node scripts/train/fetch.js
node scripts/train/popgrid.js
node --max-old-space-size=8192 scripts/train/groundtruth.js --out-dir /tmp/vane-groundtruth-audit
npm run test:groundtruth
```

The optional `--data-dir DIR` accepts a complete cache. Missing or extra dates
fail before fitting so a partial cache cannot silently reassign the split.
`--out-dir` keeps research output separate from checked-in weights; without it,
the trainer writes weights under `js/` and paired JSON/Markdown under `docs/`.
The report includes exact dates, input/source hashes, full-precision coefficients
for all three models, train-only scaling, per-day counts/results, chosen epochs,
and all gate inputs. The Markdown is generated from that JSON's in-memory object;
its displayed precision does not control the gate.
