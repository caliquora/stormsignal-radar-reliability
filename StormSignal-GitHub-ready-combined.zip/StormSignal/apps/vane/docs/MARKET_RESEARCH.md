# Market Research — What people actually want from a weather app

Research date: August 2026. This document is the design brief for **Vane**. Every
feature in the app traces back to a finding here.

---

## 1. Method

Reviewed current (2025–2026) app-store and community complaint roundups, storm-chaser
tooling guides, and the free/public weather data landscape:

- App complaint rankings and reviews — [Unstar: 8 Weather Apps Ranked by User Complaints (2026)](https://unstar.app/blog/weather-apps-ranked-by-user-complaints-2026), [SoftPicker: 8 Best Weather Apps in 2026](https://softpicker.com/best-weather-apps/)
- Feature-removal backlash — [PhoneArena: Pixel Weather's fan-favorite feature vanished](https://www.phonearena.com/news/pixel-weather-fan-favorite-feature-just-vanished-users-are-not-happy_id169029)
- Incumbent dissatisfaction — [TechRadar: Apple's bad Weather app is making me long for Dark Sky](https://www.techradar.com/opinion/apples-bad-weather-app-is-making-me-long-for-dark-sky)
- Storm-chaser tooling — [Clime: Which Weather App Is Best for Storm Chasers?](https://climeradar.com/blog/best-weather-app-for-storm-chasers), [Crazy Storm Chasers: 7 Best Storm Tracking Tools](https://crazystormchasers.com/best-storm-tracking-tools-for-storm-chasers/), [RadarScope alternatives](https://alternativeto.net/software/radarscope)
- Nowcasting expectations — [The Weather Company: the science behind minute-by-minute forecasting](https://www.weathercompany.com/blog/minute-by-minute-forecasting/), [Clime: best app for tracking rain hour by hour](https://climeradar.com/blog/best-weather-app-tracking-rain-hourly)
- Data sources — [Open-Meteo](https://open-meteo.com/), [Jua: Best Free Weather API in 2026](https://jua.ai/articles/free-weather-api-comparison-2026/), [weather.gov API](https://freeapihub.com/apis/weather-gov-api)

---

## 2. Findings

### F1 — Accuracy and speed beat visual polish
The recurring sentiment is that users would rather have "a boring, accurate forecast
than a beautiful, wrong one." Animated skies and parallax scrolling are not what
retains people; getting the answer in under two seconds is.

> **Build:** No splash screen, no animation gating. Data on screen as fast as the
> network allows, with a skeleton state rather than a spinner-blocked page. Show the
> model and observation time so the user can judge freshness themselves.

### F2 — Ads have crossed a tolerance threshold
Weather.com, AccuWeather and Weather Live are all cited for ad loads that block or
delay the primary task. This is now a brand-damage issue, not a mild annoyance.

> **Build:** No ads, no analytics, no accounts, no telemetry. Nothing loads that isn't
> weather. This is stated in the UI footer as a feature.

### F3 — The radar map is the single most-loved feature
When Google quietly removed the weather map from Pixel Weather via a server-side
change, the backlash was immediate and sustained. Users treat radar as the app's
core, not a secondary screen.

> **Build:** Radar is a first-class panel on the default view, not buried behind a
> tab. It animates, it scrubs, and in Chase mode it goes full-bleed.

### F4 — Casual users are asking exactly one question
"When people ask about the weather, they rarely care about macro-scale physics — they
want to know if it's going to rain on their street in the next few minutes."
Minute-level precipitation timing (MinuteCast-style) is the feature that defines the
casual category.

> **Build:** A 2-hour precipitation nowcast is the first thing under the hero, with a
> plain-English headline: *"Rain starting around 3:45 PM, lasting about 40 minutes."*
> Never make the user read a chart to get the answer.

### F5 — The "zoom lens" principle
Good weather UX transitions between macro-scale and minute-scale detail based on how
close the weather is to the user, rather than making the user navigate there.

> **Build:** This is the architectural spine of the app. **Simple mode** and **Chase
> mode** are the same data at two densities, one keystroke apart (`M`). The app also
> auto-suggests Chase mode when a severe alert is active for the location — the lens
> zooms itself.

### F6 — Personal/observed data is trusted more than model output
Weather Underground's decline is attributed to personal weather station data becoming
less reliable and less prominent after acquisition. Users valued the *observation*,
not the forecast.

> **Build:** Current conditions show the nearest real METAR/station observation from
> the NWS API alongside model output, and label which is which. Never present a model
> value as an observation.

### F7 — Storm chasers need a specific, non-negotiable feature set
Level 3 NEXRAD reflectivity and velocity, warning polygons, real-time lightning,
customizable alerting, and GPS position on the radar. RadarScope is the benchmark;
chasers run a *stack* of apps because no single one covers situational awareness plus
interrogation.

> **Build:** Cover what public data honestly allows and say plainly what it doesn't:
> - Animated radar reflectivity with forecast frames — **yes** (RainViewer)
> - Live NWS warning polygons drawn on the radar — **yes** (api.weather.gov)
> - Convective parameters: CAPE, CIN, LI, bulk shear, SRH, storm motion — **yes**
>   (derived from Open-Meteo pressure-level data)
> - Interactive hodograph — **yes** (derived)
> - Base velocity / dual-pol products — **no**, not available keyless. Stated in-app
>   rather than faked.

### F8 — Field conditions are hostile
Chasers work on cellular data at the edge of coverage, in daylight glare, one-handed,
often while someone else drives.

> **Build:** Last good payload cached to localStorage and shown with a staleness
> badge when the network fails. Keyboard shortcuts for everything. High-contrast
> palette. Auto-refresh with a user-set interval so the app updates without touch.

### F9 — The palette *is* the weather
The 2026 design language for weather apps has moved past flat gradients to what
one roundup calls "chromatic intelligence": colour that adapts to condition,
ambient light and time of day, layered with blur and depth, so the interface
"becomes" the weather rather than merely displaying it. Users pick apps on this.

Sources: [InspoAI: 50 Best Mobile App Designs in 2026](https://www.inspoai.io/blog/best-mobile-app-designs-2026),
[Design4Users: Weather Apps UI Collection](https://design4users.com/sunny-and-rainy-design-weather-apps-ui-collection/),
[Gradient Weather](https://gradientweather.app/),
[Behance: Weather App UI using Glassmorphism](https://www.behance.net/gallery/171451405/Weather-App-UI-Design-using-Glassmorphism)

> **Build:** The background gradient is derived from the WMO condition group and
> the sun's *actual altitude*, not a day/night flag — so the sky eases through
> golden hour and twilight the way the real one does. Panels are frosted glass
> over it. Icons are drawn as animated SVG rather than emoji.
>
> **The constraint that outranks it:** F8 said the app has to be readable on a
> sunlit windshield, and the design commits to white text everywhere. So every
> one of the 32 palettes is generated against a contrast target — zenith 12:1
> down to horizon 4.6:1 — guaranteeing WCAG AA. There is a unit test that fails
> the build if any palette drifts above that ceiling, and a "Reduce
> transparency" setting that swaps glass for solid.

### F10 — Show uncertainty instead of claiming accuracy
The top complaint (F1) is accuracy, but no app can win that fight outright —
every provider draws from the same handful of models. The apps users trust are
the ones that don't overstate a single deterministic line.

> **Build:** Vane requests five independent global models (ECMWF, GFS, ICON,
> GEM, ARPEGE) in one call and shows where they agree. The meteogram draws the
> spread between them as an envelope around the forecast line; a separate panel
> plots each model, names the current outlier, and answers "how many models
> actually produce rain this hour?" — a far more honest signal than one
> probability figure. Rather than claiming to be more accurate, show the user
> exactly how confident the forecast is.

### F11 — Maps should show the drivers, not just the precipitation
Radar answers "where is the rain now". It does not answer "why", or "what is
about to change". The pro tools chasers pay for are the ones that overlay the
fields — wind, temperature, moisture — that explain the radar.

> **Build:** Open-Meteo has no tile service, so the field layers are built
> rather than fetched: one multi-coordinate request samples a 42-point grid
> across the visible map, inverse-distance weighting fills the gaps, and the
> result is drawn to a canvas over the radar — an animated wind field and a
> smooth temperature field, both toggleable and both re-sampled as you pan.

### F12 — "Just show me what matters" is the whole job in severe weather
The chase-tooling reviews all converge on triage: on an active day a radar shows
hundreds of cells and the skill is knowing which two matter. RadarScope's own
storm-attribute feature exists for exactly this. Casual users have the same
problem in miniature — they don't want a cell table, they want to know whether
the storm is coming to *them*.

> **Build:** An "areas of interest" layer built on the NEXRAD Level III storm
> attribute table.
>
> **Where the detections come from matters more than the feature.** Rotation is
> *not* inferred here from a reflectivity image. Every mesocyclone and
> tornado-vortex signature is the WSR-88D's own Mesocyclone Detection Algorithm
> and TVS output, run on the full volumetric Doppler velocity data at the radar
> site. That is strictly better than anything this app could derive — base
> velocity isn't available from any keyless endpoint, and the operational
> algorithm sees data the tiles don't contain. Inventing a rotation detector on
> top of reflectivity pixels would have been the dishonest version of this
> feature.
>
> What Vane adds on top: an **explainable** threat score fusing rotation, hail
> and structure so 500 cells can be triaged at a glance; **closest-approach
> maths** answering "will it reach me, and when"; and **cross-reference against
> the derived environment** (SRH, deep-layer shear), because the same
> mesocyclone means something different in 300 m²/s² of helicity than in 50.
>
> The score always shows its reasons rather than a bare number, and the panel
> states the limits: MDA and TVS have known false-alarm rates, a TVS is a
> velocity signature and not a confirmed tornado, attributes update per volume
> scan, US only, and never a substitute for an NWS warning.
>
> Following F5, the same data surfaces at two densities: Simple mode gets one
> sentence when something is actually inbound ("rotating storm, closest approach
> in about 40 minutes"), Chase mode gets the ranked table and the map overlay.

### F13 — Chasers work a specific radar, not a national picture
The mosaic is a situational-awareness product. Interrogating a storm means
picking the radar that is actually painting it, knowing how far away that radar
is, and — above all — looking at velocity, because rotation is a velocity
couplet and no reflectivity product shows it.

> **Correction to F7.** The earlier finding recorded that velocity was
> unavailable from keyless public sources. That was wrong, and only half
> checked: there is no national velocity *mosaic*, but Iowa State's RIDGE
> service publishes **base velocity (N0U)** and **storm-relative velocity
> (N0S)** per radar site, keyless and CORS-open. Verified across seven sites.
>
> **Build:** A radar site picker covering all 159 WSR-88D sites, searchable by
> identifier or city, sorted by distance, with per-site products including both
> velocity types and a coverage ring.
>
> "Active radar" is defined from the NWS station feed rather than guessed: a
> radar in a **precipitation VCP** (12/212/215…) is scanning storms, one in a
> clear-air VCP (31/35…) is idling, and Level II latency says whether it is
> reporting at all. At the time of writing, 85 of 154 online radars were in
> precipitation mode. Online status is judged from data actually arriving, not
> from the maintenance flag — a third of the network reports a maintenance
> action while scanning perfectly well.
>
> One honest limit surfaced in the UI: RIDGE's frame index is ignored by its
> cache, so single-site mode is the latest scan only. The play control is
> disabled and relabelled rather than looping one frame and pretending.

### F14 — The best free weather product is the one nobody can read
Ask experienced weather watchers where they get their edge and the same answer
keeps coming back: the **Area Forecast Discussion**. Chaser forums treat reading
the AFD as the dividing line between hobbyists and people who know what they're
doing; r/weather threads recommend it constantly; NWS offices themselves point
the public at it. It is free, it updates about four times a day for every one of
the 122 forecast offices, and it is the only product in which a working
meteorologist writes down their *reasoning* — which model they threw out this
cycle, what would have to happen for the severe scenario to verify, how
confident they actually are. No gridded API contains any of that.

And essentially nobody outside the field reads it, for one reason: it is written
in shop talk, hard-wrapped at 69 columns, with sentences like *"a weak burst of
southwesterly 500 mb flow ... will induce a 1000 mb low across the northern
panhandles."* The complaint pattern is not "I wish there were more forecast
data" — it is "I can't tell what any of this means."

This is also the one place in a weather app where a language model has an
honest job. Everywhere else the pitch for AI is paraphrasing numbers the app
already displays, which adds a fabrication risk to a problem that didn't have
one. Here the model is not generating facts, it is compressing a document that
is on screen next to it — and that difference can be *checked* rather than
trusted.

> **Build:** The discussion card ships in two layers. Free and always on: the
> product is parsed into its sections and the office's own `KEY MESSAGES`
> bullets are lifted to the top, which makes the AFD readable with no model
> involved at all. An optional AI translation layer (on the user's own key)
> was built to the design below, then **removed at the user's request** so
> that Vane needs no API key of any kind, anywhere. The verification design
> is kept here as a record of how it was made checkable while it existed.
>
> The rule that makes it defensible: every summary point must carry a quote
> copied verbatim from the source, and Vane searches the product for that quote
> before rendering the point. Whitespace is normalised (the source is
> hard-wrapped); nothing else is, so a paraphrase fails. Points whose quote
> cannot be found are **discarded, and the count is printed**. Each surviving
> quote is shown under its point and highlighted in the raw text below.
>
> This deliberately does not extend to the safety path. Warnings, alerts and
> radar never pass through a model, and Vane does not ask one to infer rotation
> from imagery — the WSR-88D's own MDA already does that better (see F12).

### F15 — "10-day forecasts are useless" is a complaint about presentation
This one turns up everywhere: app-store reviews, r/weather, forum threads about
every provider. *"Day 10 changes every time I look."* *"Why bother showing two
weeks."* The complaint is treated by the industry as a demand for better
models. It is not. Day 10 changes every time you look because day 10 genuinely
is uncertain — the model is behaving correctly. What people are actually
objecting to is that **it was presented identically to day 2**: same size, same
single number, same icon, same implied confidence.

The apps that draw an 88° on day 14 are not being optimistic, they are
discarding the one piece of information the forecast system produced about that
day, which is how little it knows. Users then generalise the failure backwards
and stop trusting day 2 as well.

There is a second confusion worth separating, because Vane had it too. Comparing
several agencies' single runs — what the model agreement panel does — measures
*model formulation* differences. A true ensemble runs one model many times from
slightly perturbed initial states and measures the chaos in the atmosphere
itself. Only the second is a measure of predictability, and only the second is
available for free: Open-Meteo publishes ECMWF's 51-member IFS ensemble, 16
days, keyless.

> **Build:** The outlook panel draws each of the 16 days as a box plot over the
> 51 members — middle half as the box, p10–p90 as the whisker — rather than a
> number. Behind it sits the local climatological range for the same calendar
> dates, computed in-browser from 20 years of ERA5 at that point.
>
> The skill horizon is then *measured* rather than asserted: the ratio of the
> ensemble's p10–p90 spread to the climatological p10–p90 spread. At a ratio of
> 1 the forecast has told you exactly as much as the calendar has. The marker
> is drawn where that ratio stays high for two consecutive days, so it moves
> with the pattern and with the location instead of sitting at a fixed day
> number. Past it, no daily temperature is printed at all — only which way the
> pattern leans against normal, because that is the only thing left with skill.
>
> The single deterministic run is overlaid as a dashed line. Seeing it stray
> outside its own ensemble's middle half around day 8 is the clearest possible
> demonstration of why the number other apps show you there is not a forecast.

### F16 — Chasers are producing content, and the radar is a camera-positioning tool
The visible chase community is not primarily made of researchers. It is made of
people with a camera, a YouTube channel or a stringer contract, and the footage
is the point. Read the forums and the difference is stark: the questions are not
"is this cell severe" but *"will I get anything from the south side"*, "is it
going to be rain-wrapped by the time I'm there", "how much light have I got
left". A chaser with a warned supercell in view and the sun behind it has
technically found the storm and practically wasted the day.

No consumer app answers any of this, and the professional radar tools do not
either — they are interrogation tools that show reflectivity and velocity
extremely well and stop there. The positioning knowledge lives in mentorship and
hard-won experience: get in the inflow notch, keep the core downwind, put the
sun at your back, don't be in the bear's cage. All of that is *geometry*, and
every input to it is already in this app or one derived step away.

The second, smaller finding: chasers read reflectivity and velocity **together**,
never one at a time. A hook echo means nothing without the couplet, and a
couplet means nothing without the structure it sits in. Every tool a chaser
actually pays for shows both at once; flipping between products is the thing
they complain about in free tools.

> **Build:** A shot planner in Chase mode that solves the four things deciding
> whether there is a shot — light (Meeus solar position relative to your line of
> sight, so "golden hour" is a sun altitude and not a clock), structure (VIL
> density and core height against echo top, separating a rain-wrapped HP storm
> from a classic one with a bare base), framing (echo top and range give an
> angular size and therefore a focal length, with earth curvature included), and
> position (a suggested vantage in the inflow sector, 90–150° clockwise of the
> storm's track, picking the bearing within that arc that puts the sun behind
> you).
>
> Alongside it, the storm rendered in 3D at true scale from the measured echo
> top, core height, derived cloud base and shear-driven lean — with a "from
> here" camera framed as the lens the read-out is recommending, so the picture
> and the numbers agree. Only the 0.5° tilt is publicly tiled, so the silhouette
> is a structure diagram rather than a volume render and the panel says so.
>
> And dual-pane reflectivity beside velocity from the same radar and the same
> scan, locked to one view.
>
> The one hard rule: it refuses to suggest a position in the storm's forward
> path, and it states plainly that it is a framing aid rather than a routing or
> safety system. It is working from a snapshot up to six minutes old and cannot
> see a road, a tree or a river.

---

## 3. Positioning

| | Casual apps (Apple, Pixel) | Pro apps (RadarScope, GRLevel3) | **Vane** |
|---|---|---|---|
| Time to answer "will it rain" | Good | Poor | Good |
| Radar depth | Shallow | Excellent | Good |
| Convective parameters | None | Partial | Good |
| Cost / signup | Free / account | Paid | Free, no account, no key |
| Ads | Often | No | No |

The gap Vane fills: **one app that a casual user and a chaser can both use**, because
the second audience is the first audience on a bad day.

---

## 4. Non-goals

- Not attempting to beat RadarScope on radar interrogation — dual-pol and velocity
  products are not publicly available without a key or subscription.
- No social feed, no gamification, no "weather personality" content.
- No accounts. Saved locations and preferences stay in localStorage.
- No proprietary "RealFeel"-style index; apparent temperature is used and labelled as
  the standard formula it is.

---

## 5. Data sources (all public, all keyless)

| Source | Used for | Notes |
|---|---|---|
| [Open-Meteo Forecast](https://open-meteo.com/) | Current, 15-min nowcast, hourly, daily, pressure levels, convective params | Free, no key, CORS-enabled, multi-model |
| [Open-Meteo Ensemble](https://open-meteo.com/en/docs/ensemble-api) | ECMWF IFS 51-member ensemble, 16 days | Free, no key — the real uncertainty measurement |
| [Open-Meteo Archive](https://open-meteo.com/en/docs/historical-weather-api) | 20 years of ERA5 daily values for local normals | Free, no key, ~200 KB per location |
| [Open-Meteo Geocoding](https://open-meteo.com/en/docs/geocoding-api) | Location search | Free, no key |
| [NWS api.weather.gov](https://www.weather.gov/documentation/services-web-api) | Active alerts, warning polygons, station observations, Area Forecast Discussions | US only, free, no key |
| [RainViewer](https://www.rainviewer.com/api.html) | Global animated radar tiles incl. forecast frames | Free public endpoint, no key |
| [OpenStreetMap](https://www.openstreetmap.org/copyright) | Base map tiles | Attribution required and rendered |
