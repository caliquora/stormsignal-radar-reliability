# Embedded VANE agents

## What works now

Open **VANE agents** above the weather cards. Choose a task and run it:

- **Brief me on the evidence** checks official alert status, radar source age and next-day temperature model disagreement.
- **Where do models disagree?** finds the widest temperature range at a matched valid hour across at least two loaded models. The range is not a calibrated probability or verified accuracy.
- **Check my field data** checks warnings and freshness, then explicitly identifies navigation/coverage limits. It does not select a safe route or storm intercept.

These are bounded rule-based task agents. They inspect loaded app state, record a tool trace and evidence references, and abstain when inputs are missing. They make no new network requests. Export produces a JSON snapshot. Optional watching repeats the selected workflow while the page is visible; it is not a background warning service.

## Optional local AI

The workspace can connect to **an already-running Ollama server** at `http://127.0.0.1:11434`. Serve VANE on localhost on that same computer. The app does not install Ollama, download a model, open network access, or provide credentials.

1. Run the deterministic evidence task.
2. Expand Optional local AI and press Connect.
3. Select an installed model.
4. Optionally save a short preference, such as “explain radar terms.”
5. Press Explain latest evidence run.

The snapshot and saved preferences are sent to the local server. No cloud fallback exists. Browser origin policy and local server configuration may prevent access; the app reports this rather than changing security settings. Hosted VANE views are intentionally blocked from this connection. On iPhone, localhost means the phone, not a laptop. This is **not an embedded on-device mobile model**.

The local model returns an experimental explanation, not verified forecast output. Official instructions remain separately visible. Outputs render as text, never executable HTML; model responses cannot call tools or change app data. Requests can be stopped and time out after two minutes. Client cancellation does not prove a local server has immediately stopped its compute.

## “Learning” and privacy

Saved preferences are explicit, editable browser memory. They are only sent when Explain is pressed. Forget preferences removes them. This does not train model weights, fine-tune, infer preferences, collect telemetry, or learn operational forecasts automatically. Exported runs include the location label and evidence snapshot; review them before sharing.

## Research connection

StormSignal motivates explicit source-age and unknown-data states. Its retrospective experiments do not establish that VANE improves warning accuracy or safety. Source timestamp is not per-pixel freshness. A recently received forecast is not necessarily a recently initialized model run.

## Verification

`TZ=UTC npm run test:agents` tests pure workflows and DOM behavior with fixed fixtures. The local-model server is **stubbed**, not a downloaded or executed model. Live model quality and actual browser layout remain unverified. This code does not justify a claim that VANE beats a competitor's predictions.
