#!/usr/bin/env sh
# Vane is a static site with no build step. This just avoids the file:// origin
# restrictions that block service workers and geolocation.
PORT="${1:-8000}"
echo "Vane running at http://localhost:$PORT"
exec python3 -m http.server "$PORT" --bind 127.0.0.1
