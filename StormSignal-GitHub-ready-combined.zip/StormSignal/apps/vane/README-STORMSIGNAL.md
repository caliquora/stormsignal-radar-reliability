# VANE × StormSignal

A weather application with an explicit distinction between **when the screen refreshed** and **when the weather source updated**.

## Run it

From the StormSignal repository root:

```sh
python3 -m http.server 8000 --bind 127.0.0.1
```

Open `http://localhost:8000/apps/vane/`. No server-side API keys or production backend is required. Weather services must be reachable; a static shell is not an offline weather service. Search a location manually; location permission is optional.

To run development checks (Node 22.22 or newer):

```sh
cd apps/vane
npm ci --ignore-scripts
TZ=UTC npm test
```

## What the research changes

- Radar has a **StormSignal radar inspector** with source metadata age, unknown/cached/delayed states and a direct link to the research explorer.
- Rolling mosaic and single-site images no longer display the browser's current time as an established scan time. Nominal request times are explicitly marked unverified.
- A bounded **What changed this session?** timeline records provider timestamp and status changes, with UTC timestamps. It deduplicates unchanged responses and does not claim to detect storm evolution. The inspector separates source time, last-check time and the selected observation/archive/model frame.
- An unchanged source timestamp continues aging. Refreshing or reopening the UI does not make it fresh.
- A feed-wide timestamp does not demonstrate local pixel freshness. The panel says this explicitly. The spatial freshness study is the reason this distinction matters.
- Cached metadata is not treated as proof of a currently healthy source.
- NEXRAD-derived motion arrival estimates are withheld in this edition because rolling tile URLs lack verified per-frame timestamps. RainViewer motion requires increasing source timestamps and a recent last frame. Official forecasts and radar remain available.

The 15-minute delay flag and 2-minute future-clock tolerance are conservative interface policies, **not thresholds validated by the study**. Recent metadata is not a safety score. The Level II receipt timestamp for a station is not proof of the scan time of its rendered Level III tile.

## Official warning desk

Official warnings are accessible across every tab, with original instructions, issue/effective/expiry timestamps, and direct links to the exact NWS record when its URL is supplied. Extreme and severe current records open their instructions by default. Explicitly expired records are excluded from current summaries, banners and badge counts. Unknown expiry is not silently discarded. Alert unavailability and aging are visible even if no records are returned. This desk is a complete feed view; existing notification/filter preferences still govern notifications and the compact banner.

A session-only, 30-entry change ledger distinguishes first-seen records, changed content, and records no longer returned. Absence does not establish cancellation. Outages and cached feeds do not generate inferred all-clears. Switching the selected point clears the ledger. The log is not a complete official warning archive or a safety/navigation system. No LLM rewrites the official instruction text.

## Embedded agents

Three bounded workflows summarize evidence, compare matched model times, and check field-data limitations. Every result includes evidence references and a trace. Optional local AI uses an already-installed Ollama model on the same localhost computer; no cloud fallback, downloads, training, or autonomous actions. See [embedded agents](docs/EMBEDDED-AGENTS.md).

## Why should I care?

A weather image can look current while its underlying observations have stopped updating. StormSignal's controlled replay study found that better provenance reduced some errors, but high-echo detection at a fixed cutoff could get worse. The appropriate first application is honest data status and cautious derived estimates, not an unsupported claim of better warnings.

The spatial follow-up showed the same stale-age totals could hide very different missing high-echo information depending on where the stale area was located. VANE's public tiles do not expose the per-pixel age map needed to implement that finding fully. We display this unknown rather than fabricate a spatial confidence map.

## What is not integrated

No research CNN is serving live forecasts. No weights have been retrained, no novel operational skill is claimed, and no safe storm-chasing guidance is inferred from this study. The research and VANE's live feeds use different targets and processing, so direct transfer requires a prospective evaluation. Existing VANE model descriptions and screenshots are upstream historical material, not new validation results.

## Source and rights

Imported from [`caliquora/junk`](https://github.com/caliquora/junk/tree/89d608043cc9f0ffbc0337948ddddfd099a0d9b0), branch `claude/weather-app-market-research-gaegw1`, pinned commit `89d608043cc9f0ffbc0337948ddddfd099a0d9b0` (2026-10-06). This was newer than the three named VANE branches inspected.

The upstream package declares `UNLICENSED`; no root LICENSE was present in that snapshot. The StormSignal root MIT license does **not** relicense this imported application. Ownership/licensing must be confirmed before offering VANE itself as open-source software. Vendored dependencies retain their upstream notices. Public/keyless weather feeds have separate terms, attribution and rate limits; keyless does not imply unrestricted commercial use.

The iOS scaffold, historical documentation screenshots and old deployment workflows are not part of this integration. Runtime assets, browser app modules, test fixtures and development scripts are included. The retained `.github` examples inside this subdirectory are not active root workflows. Nothing is deployed automatically.

See [verification](VERIFICATION-STORMSIGNAL.md) for checks actually run and remaining release gates. This is a local integration candidate, not a verified production release. In severe weather follow NWS and local emergency management.
