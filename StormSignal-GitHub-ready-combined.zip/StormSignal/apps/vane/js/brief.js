/* Vane — the forecaster's discussion, parsed.
 *
 * The Area Forecast Discussion is the one product where a human
 * meteorologist explains their reasoning. It is also 8,000 characters of
 * fixed-format teletype, which is why almost nobody outside the field
 * reads it. This file parses it into sections, lifts the forecaster's own
 * KEY MESSAGES to the top, and orders sections for the current mode.
 *
 * There was once an optional second layer here: an AI translation on the
 * user's own API key. It was removed at the user's request — Vane now
 * needs no key of any kind, anywhere. The forecaster's own words were
 * always the product; this file just makes them readable. */
(function (global) {
  'use strict';


  /* AFDs are fixed-format teletype: a WMO header, a plain-language office
   * block, then sections introduced by `.NAME...` at column zero and separated
   * by `&&`, ending at `$$`. Section names vary by office and by season —
   * KEY MESSAGES, NEAR TERM, SHORT TERM, LONG TERM, AVIATION, MARINE, FIRE
   * WEATHER, HYDROLOGY — so the parser keys off the syntax, not a name list. */

  /* A header is `.NAME...` at column zero. The name may carry a qualifier the
   * office added — `.AVIATION /12Z TAFS/...`, `.SHORT TERM /TONIGHT/...` — and
   * anything after the closing `...` on the same line is already body text.
   * Note the leading dot is required, which is what keeps the common
   * `...New AVIATION...` update marker from being read as a section. */
  var SECTION_RE = /^\.([A-Z][A-Z0-9 /&'\-]*?)\.\.\.(.*)$/;

  function parse(text) {
    var raw = String(text || '');
    var lines = raw.split(/\r?\n/);
    var out = { office: null, issued: null, wmo: null, preamble: [], sections: [] };
    var current = null;
    var seenSection = false;

    for (var i = 0; i < lines.length; i++) {
      var line = lines[i];

      if (i < 6 && /^[A-Z]{4}\d{2} K[A-Z]{3} \d{6}/.test(line)) { out.wmo = line.trim(); continue; }
      if (line.trim() === '$$') break;
      if (line.trim() === '&&') { current = null; continue; }

      var m = SECTION_RE.exec(line);
      if (m) {
        seenSection = true;
        current = { name: m[1].trim(), issued: null, body: [] };
        if (m[2].trim()) current.body.push(m[2]);
        out.sections.push(current);
        continue;
      }

      if (!current) {
        if (!seenSection) out.preamble.push(line);
        continue;
      }
      current.body.push(line);
    }

    out.sections.forEach(function (s) {
      // Sections restate their own issuance time near the top, which matters:
      // the LONG TERM block is routinely hours older than the KEY MESSAGES
      // above it. Lift it out of the body so it can be shown in the heading.
      for (var j = 0; j < Math.min(4, s.body.length); j++) {
        var hit = /^(?:Issued|Updated) at (.+)$/.exec(s.body[j].trim());
        if (hit) { s.issued = hit[1].trim(); s.body.splice(j, 1); break; }
      }
      s.text = s.body.join('\n').replace(/^\s*\n+/, '').replace(/\s+$/, '');
      delete s.body;
    });
    out.sections = out.sections.filter(function (s) { return s.text; });

    var pre = out.preamble.join('\n').trim();
    out.preamble = pre;
    var office = /^National Weather Service (.+)$/m.exec(pre);
    if (office) out.office = office[1].trim();
    var when = /^(\d{1,4} [AP]M [A-Z]{2,4} \w{3} \w{3} \d{1,2} \d{4})$/m.exec(pre);
    if (when) out.issued = when[1];

    return out;
  }

  // A forecaster's KEY MESSAGES block is already the summary they'd give you.
  // Lead with it when it exists — no model required.
  function keyMessages(parsed) {
    for (var i = 0; i < parsed.sections.length; i++) {
      if (/^KEY MESSAGES/.test(parsed.sections[i].name)) {
        // Bullets are `- ` at the left margin with indented continuation
        // lines. Anything before the first bullet is administrative chatter.
        var out = [], cur = null;
        parsed.sections[i].text.split(/\r?\n/).forEach(function (line) {
          var b = /^[ \t]*-[ \t]+(.*)$/.exec(line);
          if (b) { cur = [b[1]]; out.push(cur); return; }
          if (cur && line.trim()) cur.push(line.trim());
          else cur = null;
        });
        return out.map(function (parts) { return parts.join(' ').replace(/\s+/g, ' ').trim(); })
          .filter(function (b) { return b.length > 3; });
      }
    }
    return [];
  }

  // Sections a chaser and a commuter each care about, in the order they'd read
  // them. Anything not listed still renders, just after these.
  var PRIORITY = {
    simple: ['KEY MESSAGES', 'NEAR TERM', 'SHORT TERM', 'LONG TERM'],
    chase: ['KEY MESSAGES', 'NEAR TERM', 'SHORT TERM', 'FIRE WEATHER', 'LONG TERM', 'AVIATION']
  };

  function ordered(parsed, mode) {
    var pri = PRIORITY[mode] || PRIORITY.simple;
    var rank = function (s) {
      for (var i = 0; i < pri.length; i++) {
        if (s.name.indexOf(pri[i]) === 0) return i;
      }
      return pri.length + 1;
    };
    return parsed.sections.slice().sort(function (a, b) { return rank(a) - rank(b); });
  }

  /* ── Grounding an on-device summary ──────────────────────────────────
   *
   * Where the browser has a built-in summarizer (desktop Chrome's on-device
   * model), the discussion can be put into plain English with no key and
   * nothing leaving the machine. A summarizer can still invent, though, so
   * no point is shown on its own word. Each must rest on the forecaster's
   * text: every number in it must appear in the discussion, and most of its
   * content words too. A point that passes is shown with the forecaster's
   * own sentence it rests on; one that fails is dropped, and the drop is
   * counted on screen. */
  var STOP = ('about above after again also among and are around because been before being ' +
    'below between both but can could does down during each even from further have here ' +
    'into its just like likely more most much near next only other over same should since ' +
    'some such than that their them then there these they this those through today tonight ' +
    'toward under until very what when where which while will with within would your ' +
    'expected expect area areas forecast').split(' ');
  var STOPSET = {};
  STOP.forEach(function (w) { STOPSET[w] = true; });

  /* The discussion's own units of thought: paragraphs and "- " bullets
   * first (key messages are a list, not prose), then sentences in each. */
  function sentences(text) {
    var out = [];
    String(text || '').split(/\n\s*\n|\n\s*-\s+|&&/).forEach(function (chunk) {
      chunk.replace(/\s+/g, ' ').replace(/^\s*-\s+/, '')
        .split(/(?<=[.!?])\s+(?=[A-Z0-9])/).forEach(function (x) {
          x = x.trim();
          if (x.length > 20 && !/^Updated at|^Issued at|^\.\w/.test(x)) out.push(x);
        });
    });
    return out;
  }

  function contentWords(t) {
    return (String(t).toLowerCase().match(/[a-z][a-z'-]{3,}/g) || [])
      .map(function (w) { return w.replace(/'s$/, '').replace(/s$/, ''); })
      .filter(function (w) { return !STOPSET[w] && !STOPSET[w + 's']; });
  }

  function numbersIn(t) { return String(t).match(/\d+(?:\.\d+)?/g) || []; }

  /* → { ok, quote, why }. */
  function groundPoint(point, sourceText) {
    var src = String(sourceText || ''), low = src.toLowerCase();
    var srcNums = {};
    numbersIn(src).forEach(function (n) { srcNums[n] = true; });
    var bad = numbersIn(point).filter(function (n) { return !srcNums[n]; });
    if (bad.length) return { ok: false, why: 'number not in the discussion: ' + bad[0] };
    var words = contentWords(point);
    if (words.length < 2) return { ok: false, why: 'too little to check' };
    var srcWords = {};
    contentWords(low).forEach(function (w) { srcWords[w] = true; });
    var found = words.filter(function (w) { return srcWords[w]; }).length;
    if (found / words.length < 0.6) return { ok: false, why: 'mostly not the forecaster\'s words' };
    var best = null, bestScore = 0;
    sentences(src).forEach(function (sen) {
      var sw = {};
      contentWords(sen).forEach(function (w) { sw[w] = true; });
      var score = words.filter(function (w) { return sw[w]; }).length;
      if (score > bestScore) { best = sen; bestScore = score; }
    });
    if (!best || bestScore < 2) return { ok: false, why: 'no sentence it rests on' };
    return { ok: true, sentence: best, quote: best.length > 260 ? best.slice(0, 257) + '…' : best };
  }

  /* A key-points summary in plain text → its points. */
  function bullets(out) {
    return String(out || '').split(/\n+/).map(function (l) {
      return l.replace(/^\s*(?:[-*•]|\d+[.)])\s*/, '').trim();
    }).filter(function (l) { return l.length > 8; });
  }

  global.Brief = {
    parse: parse,
    keyMessages: keyMessages,
    ordered: ordered,
    sentences: sentences,
    groundPoint: groundPoint,
    bullets: bullets
  };
})(window);
