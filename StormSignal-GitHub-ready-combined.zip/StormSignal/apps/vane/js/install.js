/* Vane — installing to a home screen.
 *
 * Vane is a progressive web app, which means it installs from the browser
 * rather than from a store: no review queue, no developer account, no 40 MB
 * download, and updates land the next time it is opened. What the user gets is
 * the thing they asked for — an icon on the home screen that opens full
 * screen, works offline, and keeps its own data.
 *
 * The two platforms could not be less alike about it.
 *
 * ANDROID / DESKTOP CHROME fire `beforeinstallprompt` once the app qualifies,
 * and hand you an event you can hold and fire later from your own button.
 * That event is single-use and is only delivered on a page load where the app
 * is not already installed, so it has to be captured at the earliest possible
 * moment — which is why this module registers its listener at parse time
 * rather than waiting for anything else to be ready.
 *
 * IOS has no such API and never has. Safari installs only through Share → Add
 * to Home Screen, so the honest thing is to detect iOS and show those
 * instructions rather than a button that cannot work. Getting this wrong is
 * the single most common broken thing in shipped PWAs: an Install button that
 * silently does nothing on an iPhone.
 *
 * Neither path is nagged. The prompt is a line in Settings and a one-time
 * banner that can be dismissed for good. */
(function (global) {
  'use strict';

  var DISMISS_KEY = 'vane.install.dismissed.v1';
  var deferred = null;          // the captured beforeinstallprompt event
  var listeners = [];

  /* Captured at parse time. The browser fires this early and only once per
   * page load; a listener attached after the app has finished booting has
   * already missed it. */
  global.addEventListener('beforeinstallprompt', function (e) {
    // Suppress the browser's own mini-infobar so the app can ask in its own
    // words, at a moment that makes sense.
    e.preventDefault();
    deferred = e;
    notify();
  });

  global.addEventListener('appinstalled', function () {
    deferred = null;
    try { localStorage.setItem(DISMISS_KEY, '1'); } catch (err) { /* ignore */ }
    notify();
  });

  function notify() {
    listeners.forEach(function (fn) {
      try { fn(status()); } catch (e) { /* a bad listener must not break install */ }
    });
  }

  function onChange(fn) { listeners.push(fn); }

  /* ── Platform ───────────────────────────────────────────────────────── */

  function isIos() {
    var ua = navigator.userAgent || '';
    // iPadOS 13+ reports itself as a Mac; the touch points give it away.
    var iPadOnMac = /Macintosh/.test(ua) && navigator.maxTouchPoints > 1;
    return /iPad|iPhone|iPod/.test(ua) || iPadOnMac;
  }

  // True once the app is running from the home screen rather than a browser
  // tab. `standalone` is Safari's own flag; the media query covers everyone else.
  function isInstalled() {
    if (global.navigator.standalone === true) return true;
    var mq = global.matchMedia;
    if (!mq) return false;
    return mq('(display-mode: standalone)').matches ||
      mq('(display-mode: window-controls-overlay)').matches ||
      mq('(display-mode: fullscreen)').matches;
  }

  function dismissed() {
    try { return localStorage.getItem(DISMISS_KEY) === '1'; } catch (e) { return false; }
  }

  function dismiss() {
    try { localStorage.setItem(DISMISS_KEY, '1'); } catch (e) { /* ignore */ }
    notify();
  }

  /* Requires a secure context. A page served over plain http has no service
   * worker and cannot be installed at all, which is worth saying out loud
   * rather than showing a button that will never light up. */
  function secure() {
    return global.isSecureContext === true ||
      location.protocol === 'https:' ||
      location.hostname === 'localhost' ||
      location.hostname === '127.0.0.1';
  }

  /* One object describing what this device can actually do, so the UI never
   * has to branch on user agents itself. */
  function status() {
    if (isInstalled()) return { state: 'installed', can: false };
    if (!secure()) {
      return {
        state: 'insecure', can: false,
        note: 'Installing needs a secure connection. Open Vane over https and the ' +
          'option will appear.'
      };
    }
    if (deferred) {
      return {
        state: 'ready', can: true,
        note: 'Adds Vane to your home screen. It opens full screen, keeps working ' +
          'offline, and updates itself.'
      };
    }
    if (isIos()) {
      return {
        state: 'ios', can: false,
        note: 'On iPhone and iPad, tap the Share button in Safari, then ' +
          '“Add to Home Screen”. Safari has no install button of its own — this ' +
          'is the only way, and it produces the same app.'
      };
    }
    return {
      state: 'unavailable', can: false,
      note: 'Your browser has not offered an install for this page yet. In Chrome ' +
        'and Edge it appears in the address bar or the ⋮ menu as “Install app”.'
    };
  }

  /* Fires the held event. Resolves to the user's choice, or to why it could
   * not be asked. The event cannot be reused, so it is released either way. */
  function install() {
    if (!deferred) return Promise.resolve(status().state);
    var e = deferred;
    deferred = null;
    var result = e.prompt();
    // Older implementations return undefined from prompt() and expose the
    // choice on a promise property instead.
    var choice = (result && result.then) ? result : e.userChoice;
    return Promise.resolve(choice).then(function (c) {
      var outcome = (c && c.outcome) || 'unknown';
      if (outcome === 'accepted') dismiss();
      notify();
      return outcome;
    }).catch(function () {
      notify();
      return 'failed';
    });
  }

  // Whether the one-time banner should appear: installable, not already
  // installed, and not previously waved away.
  function shouldOfferBanner() {
    var s = status();
    return !dismissed() && (s.state === 'ready' || s.state === 'ios');
  }

  global.Install = {
    status: status,
    install: install,
    onChange: onChange,
    dismiss: dismiss,
    dismissed: dismissed,
    shouldOfferBanner: shouldOfferBanner,
    isInstalled: isInstalled,
    isIos: isIos,
    secure: secure,
    DISMISS_KEY: DISMISS_KEY
  };
})(window);
