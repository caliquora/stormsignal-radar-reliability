/* Vane — solar and lunar geometry, computed locally (no network).
 *
 * Casual users want sunrise/sunset. Chasers want two extra things the standard
 * apps bury: how much usable daylight is left for visual confirmation and
 * photography, and how much moonlight there'll be after dark. Both fall out of
 * the same solar/lunar position math, so it lives in one module.
 *
 * Algorithms follow Meeus, "Astronomical Algorithms", low-precision forms —
 * accurate to well under a minute for civil use. */
(function (global) {
  'use strict';

  var RAD = Math.PI / 180;
  var DAY_MS = 86400000;
  var J1970 = 2440588, J2000 = 2451545;

  var e = RAD * 23.4397;    // obliquity of the ecliptic

  function toJulian(date) { return date.valueOf() / DAY_MS - 0.5 + J1970; }
  function fromJulian(j) { return new Date((j + 0.5 - J1970) * DAY_MS); }
  function toDays(date) { return toJulian(date) - J2000; }

  function rightAscension(l, b) {
    return Math.atan2(Math.sin(l) * Math.cos(e) - Math.tan(b) * Math.sin(e), Math.cos(l));
  }
  function declination(l, b) {
    return Math.asin(Math.sin(b) * Math.cos(e) + Math.cos(b) * Math.sin(e) * Math.sin(l));
  }
  function azimuth(H, phi, dec) {
    return Math.atan2(Math.sin(H), Math.cos(H) * Math.sin(phi) - Math.tan(dec) * Math.cos(phi));
  }
  function altitude(H, phi, dec) {
    return Math.asin(Math.sin(phi) * Math.sin(dec) + Math.cos(phi) * Math.cos(dec) * Math.cos(H));
  }
  function siderealTime(d, lw) { return RAD * (280.16 + 360.9856235 * d) - lw; }

  function solarMeanAnomaly(d) { return RAD * (357.5291 + 0.98560028 * d); }

  function eclipticLongitude(M) {
    var Ctr = RAD * (1.9148 * Math.sin(M) + 0.02 * Math.sin(2 * M) + 0.0003 * Math.sin(3 * M));
    var P = RAD * 102.9372;   // perihelion of the Earth
    return M + Ctr + P + Math.PI;
  }

  function sunCoords(d) {
    var M = solarMeanAnomaly(d), L = eclipticLongitude(M);
    return { dec: declination(L, 0), ra: rightAscension(L, 0) };
  }

  function sunPosition(date, lat, lon) {
    var lw = RAD * -lon, phi = RAD * lat, d = toDays(date);
    var c = sunCoords(d), H = siderealTime(d, lw) - c.ra;
    return {
      azimuth: azimuth(H, phi, c.dec) / RAD + 180,   // degrees from north
      altitude: altitude(H, phi, c.dec) / RAD
    };
  }

  /* ── Sun event times ────────────────────────────────────────────────── */

  var J0 = 0.0009;
  function julianCycle(d, lw) { return Math.round(d - J0 - lw / (2 * Math.PI)); }
  function approxTransit(Ht, lw, n) { return J0 + (Ht + lw) / (2 * Math.PI) + n; }
  function solarTransitJ(ds, M, L) {
    return J2000 + ds + 0.0053 * Math.sin(M) - 0.0069 * Math.sin(2 * L);
  }
  function hourAngle(h, phi, d) {
    return Math.acos((Math.sin(h) - Math.sin(phi) * Math.sin(d)) /
      (Math.cos(phi) * Math.cos(d)));
  }

  // Standard altitude thresholds. Golden and blue hour matter for chase
  // photography and for how long a storm stays visually resolvable.
  var TIMES = [
    [-0.833, 'sunrise', 'sunset'],
    [-0.3, 'sunriseEnd', 'sunsetStart'],
    [-6, 'dawn', 'dusk'],
    [-12, 'nauticalDawn', 'nauticalDusk'],
    [-18, 'astronomicalDawn', 'astronomicalDusk'],
    [6, 'goldenHourEnd', 'goldenHourStart']
  ];

  function sunTimes(date, lat, lon) {
    var lw = RAD * -lon, phi = RAD * lat, d = toDays(date);
    var n = julianCycle(d, lw), ds = approxTransit(0, lw, n);
    var M = solarMeanAnomaly(ds), L = eclipticLongitude(M), dec = declination(L, 0);
    var Jnoon = solarTransitJ(ds, M, L);

    var result = { solarNoon: fromJulian(Jnoon), nadir: fromJulian(Jnoon - 0.5) };

    TIMES.forEach(function (t) {
      var h0 = t[0] * RAD;
      var w = hourAngle(h0, phi, dec);
      if (isNaN(w)) {                      // polar day or night for this threshold
        result[t[1]] = null;
        result[t[2]] = null;
        return;
      }
      var a = approxTransit(w, lw, n);
      var Jset = solarTransitJ(a, M, L);
      var Jrise = Jnoon - (Jset - Jnoon);
      result[t[1]] = fromJulian(Jrise);
      result[t[2]] = fromJulian(Jset);
    });
    return result;
  }

  /* ── Moon ───────────────────────────────────────────────────────────── */

  function moonCoords(d) {
    var L = RAD * (218.316 + 13.176396 * d);      // ecliptic longitude
    var M = RAD * (134.963 + 13.064993 * d);      // mean anomaly
    var F = RAD * (93.272 + 13.229350 * d);       // mean distance
    var l = L + RAD * 6.289 * Math.sin(M);
    var b = RAD * 5.128 * Math.sin(F);
    var dt = 385001 - 20905 * Math.cos(M);        // distance, km
    return { ra: rightAscension(l, b), dec: declination(l, b), dist: dt };
  }

  function moonPosition(date, lat, lon) {
    var lw = RAD * -lon, phi = RAD * lat, d = toDays(date);
    var c = moonCoords(d), H = siderealTime(d, lw) - c.ra;
    var h = altitude(H, phi, c.dec);
    // Refraction correction near the horizon.
    h = h + RAD * 0.017 / Math.tan(h + RAD * 10.26 / (h / RAD + 5.10));
    return { azimuth: azimuth(H, phi, c.dec) / RAD + 180, altitude: h / RAD, distance: c.dist };
  }

  function moonIllumination(date) {
    var d = toDays(date || new Date());
    var s = sunCoords(d), m = moonCoords(d);
    var sdist = 149598000;   // AU in km

    var phi = Math.acos(Math.sin(s.dec) * Math.sin(m.dec) +
      Math.cos(s.dec) * Math.cos(m.dec) * Math.cos(s.ra - m.ra));
    var inc = Math.atan2(sdist * Math.sin(phi), m.dist - sdist * Math.cos(phi));
    var angle = Math.atan2(
      Math.cos(s.dec) * Math.sin(s.ra - m.ra),
      Math.sin(s.dec) * Math.cos(m.dec) -
      Math.cos(s.dec) * Math.sin(m.dec) * Math.cos(s.ra - m.ra));

    var phase = 0.5 + 0.5 * inc * (angle < 0 ? -1 : 1) / Math.PI;
    return {
      fraction: (1 + Math.cos(inc)) / 2,     // 0 = new, 1 = full
      phase: phase,                          // 0 → 1 through the synodic month
      angle: angle
    };
  }

  var PHASE_NAMES = [
    [0.0625, 'New moon', '🌑'], [0.1875, 'Waxing crescent', '🌒'],
    [0.3125, 'First quarter', '🌓'], [0.4375, 'Waxing gibbous', '🌔'],
    [0.5625, 'Full moon', '🌕'], [0.6875, 'Waning gibbous', '🌖'],
    [0.8125, 'Last quarter', '🌗'], [0.9375, 'Waning crescent', '🌘']
  ];

  function phaseName(phase) {
    for (var i = 0; i < PHASE_NAMES.length; i++) {
      if (phase < PHASE_NAMES[i][0]) return PHASE_NAMES[i];
    }
    return PHASE_NAMES[0];
  }

  /* ── The chase-relevant summary ─────────────────────────────────────── */

  function daylightRemaining(date, lat, lon) {
    var t = sunTimes(date, lat, lon);
    if (!t.sunset) return null;
    var msToSunset = t.sunset.getTime() - date.getTime();
    var msToDusk = t.dusk ? t.dusk.getTime() - date.getTime() : null;
    return {
      sunset: t.sunset,
      dusk: t.dusk,
      minutesToSunset: Math.round(msToSunset / 60000),
      minutesToDark: msToDusk === null ? null : Math.round(msToDusk / 60000),
      goldenHourStart: t.goldenHourStart,
      isDaylight: msToSunset > 0 && date.getTime() > (t.sunrise ? t.sunrise.getTime() : 0)
    };
  }

  global.Astro = {
    sunPosition: sunPosition,
    sunTimes: sunTimes,
    moonPosition: moonPosition,
    moonIllumination: moonIllumination,
    phaseName: phaseName,
    daylightRemaining: daylightRemaining
  };
})(window);
