/* Vane — multi-model ensemble analysis.
 *
 * A single deterministic forecast tells you what one model thinks. Five models
 * from five agencies, run on different physics, tell you something a single
 * line cannot: how *confident* that forecast is. Where they agree, the forecast
 * is worth planning around; where they diverge, it isn't yet.
 *
 * This is the honest version of the accuracy complaint in the research (F1) —
 * rather than claiming to be more accurate, show the user the uncertainty. */
(function (global) {
  'use strict';

  var C = global.VaneConfig, U = global.U;

  function seriesFor(hourly, variable) {
    return C.MODELS.map(function (m) {
      return { model: m, values: hourly[variable + '_' + m.id] || null };
    }).filter(function (s) {
      return s.values && s.values.some(function (v) { return v !== null; });
    });
  }

  function stats(values) {
    var v = values.filter(function (x) { return x !== null && x !== undefined; });
    if (!v.length) return null;
    var min = Math.min.apply(null, v), max = Math.max.apply(null, v);
    var mean = v.reduce(function (a, b) { return a + b; }, 0) / v.length;
    var variance = v.reduce(function (a, b) { return a + (b - mean) * (b - mean); }, 0) / v.length;
    return { min: min, max: max, mean: mean, spread: max - min, sd: Math.sqrt(variance), n: v.length };
  }

  /* Build a per-hour ensemble summary for one variable. */
  function analyse(data, variable) {
    if (!data || !data.hourly) return null;
    var h = data.hourly;
    var series = seriesFor(h, variable);
    if (series.length < 2) return null;

    var tz = data.utc_offset_seconds || 0;
    var out = [];
    for (var i = 0; i < h.time.length; i++) {
      var vals = series.map(function (s) { return s.values[i]; });
      var st = stats(vals);
      if (!st) continue;
      out.push({
        time: U.parseLocal(h.time[i]),
        epoch: U.epochOf(h.time[i], tz),
        values: vals,
        min: st.min, max: st.max, mean: st.mean, spread: st.spread, sd: st.sd, n: st.n
      });
    }
    return { variable: variable, series: series, hours: out, tz: tz };
  }

  /* Agreement on a yes/no question ("will it rain this hour?") is more useful
   * than spread for precipitation, because the distribution is not Gaussian —
   * most models say zero and one says 4 mm. */
  function precipAgreement(data, thresholdMm) {
    var t = thresholdMm === undefined ? C.PRECIP.trace : thresholdMm;
    var an = analyse(data, 'precipitation');
    if (!an) return null;
    an.hours.forEach(function (hr) {
      var wet = hr.values.filter(function (v) { return v !== null && v >= t; }).length;
      hr.wetCount = wet;
      hr.agreement = hr.n ? wet / hr.n : 0;
    });
    return an;
  }

  /* Confidence banding. Spread thresholds are in the variable's own units:
   * °C for temperature. Chosen so "high" corresponds to a forecast the models
   * effectively agree on within normal observation error. */
  function confidence(spread, variable) {
    var bands = variable === 'temperature_2m'
      ? [1.5, 3.0, 5.0]
      : [0.5, 2.0, 5.0];
    if (spread <= bands[0]) return { level: 'high', label: 'High confidence' };
    if (spread <= bands[1]) return { level: 'good', label: 'Good agreement' };
    if (spread <= bands[2]) return { level: 'fair', label: 'Models diverge' };
    return { level: 'low', label: 'Low confidence' };
  }

  /* A one-line, plain-English read on the next 24 hours — the same principle as
   * the nowcast headline: answer first, chart second. */
  function summary(tempAnalysis, precipAnalysis, opts) {
    if (!tempAnalysis) return null;
    var imperial = !!(opts && opts.imperial);
    var now = Date.now();
    var next = tempAnalysis.hours.filter(function (h) {
      return h.epoch >= now - 3600000 && h.epoch <= now + 24 * 3600000;
    });
    if (!next.length) return null;

    var avgSpread = next.reduce(function (a, h) { return a + h.spread; }, 0) / next.length;
    var conf = confidence(avgSpread, 'temperature_2m');
    // A spread is a temperature *difference*, so it scales by 9/5 with no
    // offset. Report it in whatever unit the rest of the app is showing.
    var shownSpread = imperial ? avgSpread * 9 / 5 : avgSpread;
    var parts = [conf.label + ' — ' + tempAnalysis.series.length +
      ' models agree within ' + shownSpread.toFixed(1) +
      (imperial ? '°F' : '°C') + ' on average over 24 h'];

    if (precipAnalysis) {
      var wetHours = precipAnalysis.hours.filter(function (h) {
        return h.epoch >= now && h.epoch <= now + 24 * 3600000 && h.agreement > 0;
      });
      if (!wetHours.length) {
        parts.push('no model produces rain in that window');
      } else {
        var unanimous = wetHours.filter(function (h) { return h.agreement >= 0.99; }).length;
        var split = wetHours.filter(function (h) { return h.agreement < 0.6; }).length;
        if (unanimous) {
          parts.push('all models produce rain in ' + unanimous + ' hour' +
            (unanimous === 1 ? '' : 's'));
        } else if (split) {
          parts.push('rain is a minority signal — only some models produce it');
        } else {
          parts.push('most models produce rain at some point');
        }
      }
    }
    return { text: parts.join('; ') + '.', confidence: conf, avgSpread: avgSpread };
  }

  /* Which model currently sits furthest from the pack — useful context when a
   * headline forecast looks like an outlier. */
  function outlier(analysis) {
    if (!analysis || !analysis.hours.length) return null;
    var totals = analysis.series.map(function () { return 0; });
    var counted = 0;
    analysis.hours.forEach(function (hr) {
      if (hr.mean === null) return;
      counted++;
      hr.values.forEach(function (v, i) {
        if (v !== null) totals[i] += Math.abs(v - hr.mean);
      });
    });
    if (!counted) return null;
    var worst = 0;
    totals.forEach(function (t, i) { if (t > totals[worst]) worst = i; });
    return {
      model: analysis.series[worst].model,
      meanDeviation: totals[worst] / counted
    };
  }

  global.Models = {
    analyse: analyse,
    precipAgreement: precipAgreement,
    confidence: confidence,
    summary: summary,
    outlier: outlier,
    stats: stats
  };
})(window);
