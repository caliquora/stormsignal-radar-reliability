/* StormSignal integration. Metadata transparency, not operational validation.
 * Observation age and fetch time are distinct. A feed-wide timestamp cannot
 * establish pixel-level freshness. Thresholds below are UI policy only. */
(function (root) {
  'use strict';
  var POLICY = { staleMinutes: 15, futureToleranceMinutes: 2 };
  function epoch(value) {
    if (typeof value === 'number') return isFinite(value) && value > 0 ? value : null;
    if (typeof value !== 'string' || !/Z$|[+-]\d\d:\d\d$/.test(value)) return null;
    var n = Date.parse(value); return isFinite(n) ? n : null;
  }
  function assess(input, now) {
    input = input || {}; now = now === undefined ? Date.now() : now;
    var at = epoch(input.observedAt), age = at === null ? null : (now - at) / 60000;
    var status = age === null ? 'unknown' : age < -POLICY.futureToleranceMinutes ? 'clock-error'
      : input.cached ? 'cached' : age > POLICY.staleMinutes ? 'stale' : 'recent';
    return { status: status, source: input.source || 'Radar source', observedAt: at,
      checkedAt: epoch(input.checkedAt), ageMinutes: age === null ? null : Math.max(0, age),
      canEstimateMotion: status === 'recent' && input.frameTimesVerified === true,
      spatialFreshness: 'unknown', policyMinutes: POLICY.staleMinutes,
      frameTimesVerified: input.frameTimesVerified === true };
  }
  function text(s) {
    var age = s.ageMinutes === null ? 'age unknown' : Math.floor(s.ageMinutes) + ' min old';
    var labels = { unknown: 'Timestamp unavailable', 'clock-error': 'Source clock inconsistent',
      cached: 'Cached metadata', stale: 'Delayed source', recent: 'Recent source metadata' };
    return s.source + ': ' + labels[s.status] + ' · ' + age + '. ' +
      'This describes the source index, not every radar pixel. Local freshness is unknown.';
  }
  // Session-only bounded metadata history. No telemetry or persisted locations.
  function createTimeline(limit) {
    var entries = [], last = null;
    return { add: function (state, now) {
      var key = [state.source, state.observedAt, state.status].join('|');
      if (key === last) return false;
      last = key;
      entries.unshift({ at: now, source: state.source, sourceTime: state.observedAt,
        status: state.status, description: text(state) });
      entries = entries.slice(0, limit || 20); return true;
    }, entries: function () { return entries.slice(); } };
  }
  var timeline = createTimeline(20);
  function iso(t) { return t === null || t === undefined ? 'Unknown' : new Date(t).toISOString(); }
  function frameDescription(frame) {
    if (!frame) return 'No frame selected';
    var kind = frame.forecast ? 'MODEL FORECAST' : frame.archive ? 'ARCHIVE' : 'OBSERVATION IMAGE';
    return kind + ' · ' + (frame.timeBasis === 'request' ? 'Nominal requested time, not verified scan time: ' : 'Provider-labelled valid time: ') +
      iso(frame.time ? frame.time * 1000 : null) + (frame.forecast ? '. Not an observation.' : '. Pixel-level age unavailable.');
  }
  function showFrame(frame) {
    var el = root.document && root.document.getElementById('stormsignal-frame');
    if (el) el.textContent = frameDescription(frame);
  }
  function paintTimeline() {
    var el = root.document && root.document.getElementById('stormsignal-timeline');
    if (!el) return;
    el.textContent = '';
    timeline.entries().forEach(function (entry) {
      var li = root.document.createElement('li');
      var when = root.document.createElement('time'); when.dateTime = iso(entry.at);
      when.textContent = iso(entry.at).slice(11, 19) + ' UTC · ';
      li.appendChild(when); li.appendChild(root.document.createTextNode(entry.description));
      el.appendChild(li);
    });
  }
  function render(input, now) {
    var s = assess(input, now), el = root.document && root.document.getElementById('stormsignal-status');
    if (el) { el.textContent = text(s); el.setAttribute('data-status', s.status); }
    now = now === undefined ? Date.now() : now;
    timeline.add(s, now); paintTimeline();
    var stamp = root.document && root.document.getElementById('stormsignal-source-time');
    var checked = root.document && root.document.getElementById('stormsignal-checked-time');
    if (stamp) stamp.textContent = iso(s.observedAt);
    if (checked) checked.textContent = iso(s.checkedAt);
    return s;
  }
  var api = { policy: POLICY, epoch: epoch, assess: assess, describe: text, render: render, createTimeline: createTimeline, frameDescription: frameDescription, showFrame: showFrame };
  root.StormSignal = api;
  if (typeof module !== 'undefined') module.exports = api;
})(typeof window !== 'undefined' ? window : globalThis);
