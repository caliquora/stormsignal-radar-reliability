/* Vane — shot planning: where to stand to actually film the thing.
 *
 * Every radar app answers "where is the storm". A chaser after footage has a
 * different question, and it is a harder one: *what will this look like from
 * where I am standing, and where should I be standing instead.* Two chasers
 * the same distance from the same supercell get completely different days —
 * one gets a backlit grey smudge through rain, the other gets a sunlit
 * striated updraft against a dark core. The difference is geometry, and
 * geometry is computable.
 *
 * Four things decide whether there is a shot, and this module solves all four
 * from measurements the app already has:
 *
 *   LIGHT.      Where the sun is relative to the storm, from the observer's
 *               position. Sun behind you lights the tower; sun behind the
 *               storm gives you a silhouette. Meeus solar position, so this is
 *               exact rather than "check the time".
 *   STRUCTURE.  Whether the interesting part is visible at all. A high-
 *               precipitation storm wraps its own updraft in rain and there is
 *               nothing to see from any angle; VIL density and core height
 *               against echo top separate that from a classic storm with a
 *               bare base.
 *   FRAMING.    How big it is in the frame. Echo top height and range give a
 *               real angular size, which converts to a focal length. A 17 km
 *               tower at 30 km needs a wide lens; the same tower at 90 km is a
 *               telephoto subject.
 *   POSITION.   Where to move to. The classic vantage is in the inflow sector,
 *               off the storm's right-rear flank in the northern hemisphere,
 *               far enough out that the base is above the horizon and the core
 *               is not on top of you. Bias that toward the sunlit side and you
 *               have a target you can drive to.
 *
 * WHAT THIS IS NOT. It is not a safety system and it does not route you. It
 * assumes roads exist where they may not, it cannot see terrain or trees, and
 * a storm can change character in one volume scan. Every number here is
 * geometry over a snapshot that is already up to six minutes old. The one
 * genuinely safety-relevant output — whether the suggested position is on the
 * wrong side of the storm's track — is stated as a refusal rather than a
 * caveat: this module will not hand you a target in the path of the core. */
(function (global) {
  'use strict';

  var U = global.U;

  var KFT_TO_KM = 0.3048;

  /* ── Light ──────────────────────────────────────────────────────────── */

  /* Angle between where you are looking (at the storm) and where the sun is.
   * Zero means the sun is directly behind the storm — a silhouette. 180 means
   * it is directly behind you — the storm is fully lit. */
  function relativeAzimuth(stormBearing, sunAzimuth) {
    var d = Math.abs(((stormBearing - sunAzimuth) % 360 + 360) % 360);
    return d > 180 ? 360 - d : d;
  }

  var LIGHT = [
    { max: 45,  key: 'backlit',   label: 'Backlit',
      note: 'Sun behind the storm. Expect a silhouette — dramatic for structure, but no colour and no detail in the base.' },
    { max: 110, key: 'side',      label: 'Side-lit',
      note: 'Sun off to one side. The best light for showing depth in the updraft.' },
    { max: 180, key: 'frontlit',  label: 'Front-lit',
      note: 'Sun behind you, on the storm. Full colour and detail; the core reads dark against a lit tower.' }
  ];

  /* Golden hour is not a clock time, it is a solar altitude. Below the horizon
   * there is no shot worth planning for beyond lightning. */
  function lightQuality(sunAltitude) {
    if (sunAltitude < -6) return { key: 'night', label: 'Night', note: 'Below civil twilight. Lightning only — plan for long exposures, not structure.' };
    if (sunAltitude < 0) return { key: 'twilight', label: 'Twilight', note: 'Sun below the horizon. Silhouette and afterglow; structure is going fast.' };
    if (sunAltitude < 10) return { key: 'golden', label: 'Golden hour', note: 'Low warm light. This is the hour that makes the shot — and it is short.' };
    if (sunAltitude < 25) return { key: 'low', label: 'Low sun', note: 'Warm, raking light with long shadows on the updraft.' };
    return { key: 'high', label: 'High sun', note: 'Flat overhead light. Structure reads, colour does not.' };
  }

  function light(cell, lat, lon, date) {
    var a = global.Cells.approach(cell, lat, lon);
    var sun = global.Astro.sunPosition(date || new Date(), lat, lon);
    var rel = relativeAzimuth(a.bearing, sun.azimuth);
    var dir = LIGHT[0];
    for (var i = 0; i < LIGHT.length; i++) { if (rel <= LIGHT[i].max) { dir = LIGHT[i]; break; } }
    return {
      sunAzimuth: sun.azimuth,
      sunAltitude: sun.altitude,
      stormBearing: a.bearing,
      relative: rel,
      direction: dir,
      quality: lightQuality(sun.altitude)
    };
  }

  /* ── Structure ──────────────────────────────────────────────────────── */

  /* Whether there is anything to see.
   *
   * VIL density is the discriminator. A storm carrying a lot of liquid for its
   * depth is precipitation-loaded — the updraft is wrapped and the base is
   * hidden behind curtains of rain, which is why HP supercells photograph so
   * badly however close you get. A tall storm holding its core high with
   * modest VIL density has a bare, visible base under it.
   *
   * Core height as a fraction of echo top is the second signal: a core held
   * high aloft is a strong updraft still lofting; a core collapsed to the
   * bottom of the storm is precipitation falling out and an outflow-dominant,
   * visually mushy storm. */
  function structure(cell) {
    var d = cell.vilDensity;
    var coreFraction = cell.top > 0 ? cell.maxDbzHeight / cell.top : null;
    var reasons = [];
    var visibility;

    if (d === null) {
      visibility = { key: 'unknown', label: 'Unknown', score: 0.5 };
    } else if (d >= 4.0) {
      visibility = { key: 'wrapped', label: 'Rain-wrapped', score: 0.15 };
      reasons.push('VIL density ' + d.toFixed(1) + ' g/m³ — precipitation-loaded, the updraft is likely wrapped');
    } else if (d >= 3.0) {
      visibility = { key: 'murky', label: 'Partly obscured', score: 0.45 };
      reasons.push('VIL density ' + d.toFixed(1) + ' g/m³ — heavy precipitation near the updraft');
    } else {
      visibility = { key: 'clear', label: 'Likely visible', score: 0.85 };
      reasons.push('VIL density ' + d.toFixed(1) + ' g/m³ — not precipitation-loaded, the base should be exposed');
    }

    if (coreFraction !== null) {
      if (coreFraction >= 0.55) {
        reasons.push('Core held at ' + Math.round(coreFraction * 100) + '% of echo top — updraft still lofting');
        visibility.score = Math.min(1, visibility.score + 0.1);
      } else if (coreFraction <= 0.3) {
        reasons.push('Core collapsed to ' + Math.round(coreFraction * 100) + '% of echo top — likely outflow-dominant and visually soft');
        visibility.score = Math.max(0, visibility.score - 0.15);
      }
    }

    if (cell.top >= 45) reasons.push('Echo top ' + cell.top.toFixed(0) + ' kft — a tall tower, visible from a long way out');

    return {
      visibility: visibility,
      coreFraction: coreFraction,
      vilDensity: d,
      topKm: cell.top * KFT_TO_KM,
      coreKm: cell.maxDbzHeight * KFT_TO_KM,
      reasons: reasons
    };
  }

  /* ── Framing ────────────────────────────────────────────────────────── */

  /* Angular size of the storm from where you stand, and the lens that fits it.
   * Uses a 36 mm full-frame horizontal sensor; the vertical figure is what
   * usually matters, since a supercell is taller than it is wide in frame. */
  function framing(cell, distanceKm) {
    if (!distanceKm || distanceKm <= 0) return null;
    var topKm = cell.top * KFT_TO_KM;
    // Elevation angle to the overshooting top. Earth curvature is worth
    // including: at 100 km the horizon drops the base of a storm by ~800 m.
    var drop = (distanceKm * distanceKm) / (2 * 6371 * 1.21);   // 4/3-earth refraction
    var apparentTop = topKm - drop;
    var elevation = Math.atan2(apparentTop, distanceKm) * 180 / Math.PI;
    // A supercell's visible width is of order its echo top height.
    var widthKm = topKm;
    var angularWidth = 2 * Math.atan2(widthKm / 2, distanceKm) * 180 / Math.PI;
    // Focal length that puts the storm across the full 36 mm frame width.
    var focal = 18 / Math.tan(U.toRad(angularWidth / 2));
    return {
      distanceKm: distanceKm,
      elevationDeg: elevation,
      angularWidthDeg: angularWidth,
      focalMm: focal,
      baseBelowHorizon: apparentTop <= 0,
      lens: focal < 20 ? 'ultra-wide' : focal < 35 ? 'wide' : focal < 70 ? 'normal' : focal < 150 ? 'short telephoto' : 'telephoto'
    };
  }

  /* ── Position ───────────────────────────────────────────────────────── */

  /* The classic photographic vantage on a right-moving supercell in the
   * northern hemisphere is in the inflow sector: off the storm's right-rear
   * flank, looking back up into the base with the precipitation core beyond
   * it. That puts you in warm inflow air rather than in the rain, and it is
   * where the wall cloud, striations and any tornado are actually visible.
   *
   * Taking the storm's motion vector as the reference, that sector sits
   * roughly 90–150° clockwise of the direction of travel. Within that arc this
   * picks the bearing that also puts the sun at your back, which is the
   * difference between a lit tower and a grey silhouette.
   *
   * Standoff is set by two competing limits: close enough that the storm fills
   * the frame, far enough that the base is not above your head and the core
   * cannot reach you before you can leave. */
  function target(cell, lat, lon, opts) {
    opts = opts || {};
    var date = opts.date || new Date();
    var m = global.Cells.motionVector(cell);
    if (m.speedKmh < 1) return null;                 // a stationary cell has no flank

    var towardDeg = (Math.atan2(m.east, m.north) * 180 / Math.PI + 360) % 360;
    var sun = global.Astro.sunPosition(date, cell.lat, cell.lon);

    // Candidate bearings FROM the storm TO the observer, across the inflow arc.
    var best = null;
    for (var off = 90; off <= 150; off += 5) {
      var bearing = (towardDeg + off) % 360;
      // Standing at `bearing` from the storm means looking back along
      // bearing+180. The sun is at your back when the sun's azimuth is close
      // to that same outward bearing.
      var sunScore = sunAtBack(bearing, sun.azimuth, sun.altitude);
      // Prefer the middle of the arc when light gives no reason to choose.
      var arcScore = 1 - Math.abs(off - 120) / 60;
      var total = sunScore * 0.7 + arcScore * 0.3;
      if (!best || total > best.total) best = { bearing: bearing, total: total, sunScore: sunScore, off: off };
    }

    var standoff = standoffKm(cell);
    var pt = offset(cell.lat, cell.lon, best.bearing, standoff);

    // Refuse to place anyone in front of the core. The arc above should never
    // do this, but a target is a thing people drive to, so it is checked
    // rather than assumed.
    var fromTargetToStorm = (best.bearing + 180) % 360;
    var inPath = angularGap(towardDeg, fromTargetToStorm) < 45;

    var a = global.Cells.approach(cell, pt.lat, pt.lon);
    var travel = global.Cells.approach(cell, lat, lon);

    return {
      lat: pt.lat,
      lon: pt.lon,
      standoffKm: standoff,
      bearingFromStorm: best.bearing,
      lookBearing: fromTargetToStorm,
      stormTowardDeg: towardDeg,
      sunFavourable: best.sunScore > 0.5,
      inCorePath: inPath,
      // How far the chaser has to move, and how long the storm gives them.
      moveKm: U.haversine(lat, lon, pt.lat, pt.lon),
      stormEtaMin: a.etaMin,
      currentDistanceKm: travel.distance
    };
  }

  // 1 when the sun is directly behind an observer looking inward, 0 when it is
  // behind the storm. Worthless once the sun is down, so it flattens there and
  // lets the arc preference decide instead.
  function sunAtBack(bearingFromStorm, sunAzimuth, sunAltitude) {
    if (sunAltitude < 0) return 0.5;
    var gap = angularGap(bearingFromStorm, sunAzimuth);
    return 1 - (gap / 180);
  }

  function angularGap(a, b) {
    var d = Math.abs(((a - b) % 360 + 360) % 360);
    return d > 180 ? 360 - d : d;
  }

  /* Standoff distance. Close enough to fill a frame, far enough to see the
   * whole tower and to have somewhere to go. Scales with the storm: a 60 kft
   * monster needs more room than a 25 kft cell to fit in shot at all. */
  function standoffKm(cell) {
    var topKm = cell.top * KFT_TO_KM;
    var d = Math.max(12, Math.min(40, topKm * 1.6));
    return Math.round(d);
  }

  function offset(lat, lon, bearingDeg, km) {
    var kmPerDegLat = 111.32;
    var kmPerDegLon = 111.32 * Math.cos(U.toRad(lat));
    var rad = U.toRad(bearingDeg);
    return {
      lat: lat + (km * Math.cos(rad)) / kmPerDegLat,
      lon: lon + (km * Math.sin(rad)) / kmPerDegLon
    };
  }

  /* ── The whole solve ────────────────────────────────────────────────── */

  function plan(cell, lat, lon, opts) {
    opts = opts || {};
    var date = opts.date || new Date();
    var here = global.Cells.approach(cell, lat, lon);
    var l = light(cell, lat, lon, date);
    var s = structure(cell);
    var f = framing(cell, here.distance);
    var t = target(cell, lat, lon, opts);

    var fromTarget = t ? {
      light: light(cell, t.lat, t.lon, date),
      framing: framing(cell, t.standoffKm)
    } : null;

    return {
      cell: cell,
      from: { distanceKm: here.distance, bearing: here.bearing, light: l, framing: f },
      structure: s,
      target: t,
      atTarget: fromTarget,
      verdict: verdict(s, l, f, here)
    };
  }

  /* One sentence, because a chaser reads this at 70 mph. Leads with whatever
   * is currently ruling the shot in or out. */
  function verdict(s, l, f, here) {
    if (s.visibility.key === 'wrapped') {
      return { key: 'no-shot', text: 'Rain-wrapped — there is unlikely to be anything to see from any angle on this one.' };
    }
    if (f && f.baseBelowHorizon) {
      return { key: 'too-far', text: 'Below the horizon at ' + Math.round(here.distance) + ' km. Close the distance before judging it.' };
    }
    if (here.distance < 8) {
      return { key: 'too-close', text: 'Too close at ' + here.distance.toFixed(1) + ' km — you are under the base and probably in the precipitation.' };
    }
    if (l.quality.key === 'night') {
      return { key: 'night', text: 'Dark. Lightning work only — structure will not read.' };
    }
    if (l.direction.key === 'backlit' && l.sunAltitude > 0) {
      return { key: 'silhouette', text: 'Backlit from here. Move around the storm to put the sun behind you, or shoot it as a silhouette deliberately.' };
    }
    if (l.quality.key === 'golden' && s.visibility.key === 'clear') {
      return { key: 'go', text: 'Golden hour on an exposed base. This is the shot — go now, it will not last.' };
    }
    if (s.visibility.key === 'clear') {
      return { key: 'good', text: l.direction.label + ' with an exposed base. Workable structure from here.' };
    }
    return { key: 'marginal', text: 'Partly obscured. Worth repositioning rather than shooting from here.' };
  }

  global.Shot = {
    plan: plan,
    light: light,
    lightQuality: lightQuality,
    relativeAzimuth: relativeAzimuth,
    structure: structure,
    framing: framing,
    target: target,
    standoffKm: standoffKm,
    sunAtBack: sunAtBack,
    angularGap: angularGap,
    offset: offset,
    verdict: verdict,
    LIGHT: LIGHT,
    KFT_TO_KM: KFT_TO_KM
  };
})(window);
