/* Vane — unit conversion, formatting and small DOM helpers.
 * Internal representation is always SI; convert only when rendering. */
(function (global) {
  'use strict';

  var C = global.VaneConfig;

  function el(id) { return document.getElementById(id); }

  function make(tag, cls, text) {
    var n = document.createElement(tag);
    if (cls) n.className = cls;
    if (text !== undefined && text !== null) n.textContent = String(text);
    return n;
  }

  function clear(node) { while (node && node.firstChild) node.removeChild(node.firstChild); }

  /* ── Conversions (SI in, display out) ─────────────────────── */
  function cToF(c) { return c * 9 / 5 + 32; }
  function msToMph(ms) { return ms * 2.236936; }
  function msToKph(ms) { return ms * 3.6; }
  function msToKt(ms) { return ms * 1.943844; }
  function mmToIn(mm) { return mm / 25.4; }
  function mToFt(m) { return m * 3.28084; }
  function kmToMi(km) { return km * 0.621371; }

  function temp(c, imperial, digits) {
    if (c === null || c === undefined || isNaN(c)) return '--';
    var v = imperial ? cToF(c) : c;
    return v.toFixed(digits === undefined ? 0 : digits) + '°';
  }

  function speed(ms, imperial) {
    if (ms === null || ms === undefined || isNaN(ms)) return '--';
    return imperial ? Math.round(msToMph(ms)) + ' mph' : Math.round(msToKph(ms)) + ' km/h';
  }

  function knots(ms) {
    if (ms === null || ms === undefined || isNaN(ms)) return '--';
    return Math.round(msToKt(ms)) + ' kt';
  }

  function precip(mm, imperial) {
    if (mm === null || mm === undefined || isNaN(mm)) return '--';
    return imperial ? mmToIn(mm).toFixed(2) + '"' : mm.toFixed(1) + ' mm';
  }

  function height(m, imperial) {
    if (m === null || m === undefined || isNaN(m)) return '--';
    return imperial ? Math.round(mToFt(m)).toLocaleString() + ' ft'
                    : Math.round(m).toLocaleString() + ' m';
  }

  function distance(km, imperial) {
    if (km === null || km === undefined || isNaN(km)) return '--';
    return imperial ? kmToMi(km).toFixed(1) + ' mi' : km.toFixed(1) + ' km';
  }

  /* ── Time ─────────────────────────────────────────────────── */
  // Open-Meteo returns local-to-the-location ISO strings without a zone suffix.
  // Parsing them as local wall-clock keeps the displayed hour correct for the
  // forecast location rather than the viewer's device.
  function parseLocal(iso) {
    if (!iso) return null;
    /* The time part is optional, and that mattered: Open-Meteo's daily series
     * is date-only ("2026-08-15"), which the old THH:MM-required regex passed
     * through to new Date() — and a bare date parses as UTC midnight, which is
     * the previous evening everywhere in the United States. Every weekday
     * label in the 7-day card ran one day behind: August 15th, a Saturday,
     * captioned "Fri". A date without a time is local midnight, full stop. */
    var m = /^(\d{4})-(\d{2})-(\d{2})(?:T(\d{2}):(\d{2}))?/.exec(iso);
    if (!m) return new Date(iso);
    return new Date(+m[1], +m[2] - 1, +m[3], +(m[4] || 0), +(m[5] || 0));
  }

  // Open-Meteo timestamps are wall-clock in the *forecast location's* timezone,
  // with no zone suffix. Rendering them with parseLocal shows the right local
  // hour, but comparing them to Date.now() is wrong whenever the viewer's device
  // is in a different timezone from the location — which is the normal case for
  // a chaser targeting another state. Convert to a true epoch for comparisons.
  function epochOf(iso, utcOffsetSeconds) {
    var m = /^(\d{4})-(\d{2})-(\d{2})T(\d{2}):(\d{2})/.exec(iso || '');
    if (!m) return NaN;
    var asUtc = Date.UTC(+m[1], +m[2] - 1, +m[3], +m[4], +m[5]);
    return asUtc - (utcOffsetSeconds || 0) * 1000;
  }

  // Format a true epoch as wall-clock time at the given UTC offset, so radar
  // frame times read in the same timezone as the rest of the forecast.
  /* IEM's archived mosaic layers are named by UTC minute, floored to the
   * 5-minute scan cadence: ridge::USCOMP-N0Q-YYYYMMDDHHMM. */
  function iemStamp(epochMs) {
    var t = Math.floor(epochMs / 300000) * 300000;
    var d = new Date(t);
    var p = function (n) { return (n < 10 ? '0' : '') + n; };
    return '' + d.getUTCFullYear() + p(d.getUTCMonth() + 1) + p(d.getUTCDate()) +
           p(d.getUTCHours()) + p(d.getUTCMinutes());
  }

  function fmtEpoch(epochMs, utcOffsetSeconds, hour12) {
    var d = new Date(epochMs + (utcOffsetSeconds || 0) * 1000);
    var h = d.getUTCHours(), mm = String(d.getUTCMinutes()).padStart(2, '0');
    if (!hour12) return String(h).padStart(2, '0') + ':' + mm;
    var ap = h >= 12 ? 'PM' : 'AM', h12 = h % 12 || 12;
    return h12 + ':' + mm + ' ' + ap;
  }

  function fmtTime(d, hour12) {
    if (!d) return '--';
    var h = d.getHours(), mm = String(d.getMinutes()).padStart(2, '0');
    if (!hour12) return String(h).padStart(2, '0') + ':' + mm;
    var ap = h >= 12 ? 'PM' : 'AM', h12 = h % 12 || 12;
    return h12 + ':' + mm + ' ' + ap;
  }

  function fmtHour(d, hour12) {
    if (!d) return '--';
    var h = d.getHours();
    if (!hour12) return String(h).padStart(2, '0') + ':00';
    return (h % 12 || 12) + (h >= 12 ? 'p' : 'a');
  }

  function fmtDay(d) {
    return ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'][d.getDay()];
  }

  function relative(ms) {
    var s = Math.round(ms / 1000);
    if (s < 60) return s + 's ago';
    var m = Math.round(s / 60);
    if (m < 60) return m + ' min ago';
    var h = Math.round(m / 60);
    if (h < 24) return h + ' hr ago';
    return Math.round(h / 24) + ' d ago';
  }

  /* ── Geometry ─────────────────────────────────────────────── */
  function toRad(d) { return d * Math.PI / 180; }

  function haversine(a, b, c, d) {
    var R = 6371, dLat = toRad(c - a), dLon = toRad(d - b);
    var s = Math.sin(dLat / 2) * Math.sin(dLat / 2) +
      Math.cos(toRad(a)) * Math.cos(toRad(c)) * Math.sin(dLon / 2) * Math.sin(dLon / 2);
    return 2 * R * Math.atan2(Math.sqrt(s), Math.sqrt(1 - s));
  }

  function compass(deg) {
    if (deg === null || deg === undefined || isNaN(deg)) return '--';
    var pts = ['N', 'NNE', 'NE', 'ENE', 'E', 'ESE', 'SE', 'SSE',
               'S', 'SSW', 'SW', 'WSW', 'W', 'WNW', 'NW', 'NNW'];
    return pts[Math.round(((deg % 360) + 360) % 360 / 22.5) % 16];
  }

  // Meteorological convention: direction is where wind comes FROM.
  function windToUV(speedMs, dirDeg) {
    var r = toRad(dirDeg);
    return { u: -speedMs * Math.sin(r), v: -speedMs * Math.cos(r) };
  }

  function uvToWind(u, v) {
    var spd = Math.sqrt(u * u + v * v);
    var dir = (Math.atan2(-u, -v) * 180 / Math.PI + 360) % 360;
    return { speed: spd, dir: dir };
  }

  function wmo(code) {
    return C.WMO[code] || ['—', '•'];
  }

  function clamp(v, lo, hi) { return Math.max(lo, Math.min(hi, v)); }

  function lerp(a, b, t) { return a + (b - a) * t; }

  global.U = {
    el: el, make: make, clear: clear,
    cToF: cToF, msToMph: msToMph, msToKph: msToKph, msToKt: msToKt,
    mmToIn: mmToIn, mToFt: mToFt, kmToMi: kmToMi,
    temp: temp, speed: speed, knots: knots, precip: precip,
    height: height, distance: distance,
    parseLocal: parseLocal, epochOf: epochOf, fmtEpoch: fmtEpoch, iemStamp: iemStamp,
    fmtTime: fmtTime, fmtHour: fmtHour, fmtDay: fmtDay,
    relative: relative,
    haversine: haversine, compass: compass, windToUV: windToUV, uvToWind: uvToWind,
    wmo: wmo, clamp: clamp, lerp: lerp, toRad: toRad
  };
})(window);
