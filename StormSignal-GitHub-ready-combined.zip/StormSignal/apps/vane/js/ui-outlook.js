/* Vane — Outlook rendering: model agreement, the local scorecard, the
 * extended outlook, the forecaster's discussion, the meteogram, and the SPC
 * outlook and storm reports cards. Loaded on first entry to the Outlook tab
 * (js/lazy.js). */
(function (global) {
  'use strict';

  var C = global.VaneConfig, U = global.U, D = global.Derive;
  var UI = global.UI;
  // Shared helpers from js/ui-core.js.
  var svg = UI.svg;
  /* ── Model ensemble ─────────────────────────────────────────────────── */

  function renderModels(state) {
    var M = global.Models;
    var summaryEl = U.el('models-summary');
    var legend = U.el('model-legend');
    var chart = U.el('spread-chart');
    var agree = U.el('agreement');
    U.clear(legend); U.clear(chart); U.clear(agree);
    // The scorecard stands on its own data; a missing ensemble comparison
    // must not hide the leaderboard already learned.
    renderScorecard(state);

    if (!state.ensemble) {
      summaryEl.textContent = 'Comparing models…';
      return;
    }

    var temp = M.analyse(state.ensemble, 'temperature_2m');
    var precip = M.precipAgreement(state.ensemble);
    if (!temp) {
      summaryEl.textContent = 'Model comparison is unavailable for this location.';
      return;
    }

    var s = M.summary(temp, precip, { imperial: state.imperial });
    summaryEl.textContent = s ? s.text : '';
    if (s) summaryEl.style.borderLeftColor = {
      high: '#5fe08a', good: '#7fd3ff', fair: '#ffc453', low: '#ff6b8a'
    }[s.confidence.level];

    // Legend doubles as the outlier callout — useful context when a headline
    // number looks wrong.
    var out = M.outlier(temp);
    temp.series.forEach(function (ser) {
      var pill = U.make('span', 'model-pill');
      var sw = U.make('span', 'model-swatch');
      sw.style.background = ser.model.color;
      pill.appendChild(sw);
      pill.appendChild(U.make('span', null, ser.model.short));
      if (out && out.model.id === ser.model.id) {
        pill.appendChild(U.make('span', 'model-dev', '±' + out.meanDeviation.toFixed(1) + '° outlier'));
      }
      pill.title = ser.model.name;
      legend.appendChild(pill);
    });

    drawSpread(chart, temp, state);
    drawAgreement(agree, precip, state);
  }

  /* The local scorecard: each agency's day-ahead highs and lows, verified
   * against the nearest station's own thermometer, ranked by mean absolute
   * error. Learned on this device — nobody else has YOUR leaderboard.
   * Before enough days have been verified, the card says what it is doing
   * rather than showing a rank built on one lucky afternoon. */
  function renderScorecard(state) {
    var box = U.el('scorecard');
    if (!box || !global.Verify) return;
    U.clear(box);
    var sc = global.Verify.scorecard();
    if (!sc.rows.length && !sc.pendingDays && !sc.days) { box.hidden = true; return; }
    box.hidden = false;

    box.appendChild(U.make('h3', 'scorecard-head', 'Local scorecard'));

    if (!sc.rows.length) {
      box.appendChild(U.make('p', 'scorecard-note',
        'Vane is verifying each agency’s day-ahead forecast against ' +
        (sc.station || 'the nearest station') + '’s own thermometer. ' +
        'First rankings appear after ' + global.Verify.MIN_DAYS +
        ' verified days — learned on this device, sent nowhere.'));
      return;
    }

    var degErr = function (c) {
      var v = state.imperial ? c * 9 / 5 : c;
      return '±' + v.toFixed(1) + '°';
    };
    sc.rows.forEach(function (r, i) {
      var row = U.make('div', 'scorecard-row' + (i === 0 ? ' best' : ''));
      row.appendChild(U.make('span', 'scorecard-rank', String(i + 1)));
      var dot = U.make('span', 'model-swatch');
      dot.style.background = r.color;
      row.appendChild(dot);
      var name = U.make('span', 'scorecard-name', r.short);
      name.title = r.name;
      row.appendChild(name);
      row.appendChild(U.make('span', 'scorecard-mae', degErr(r.mae)));
      row.appendChild(U.make('span', 'scorecard-detail',
        'highs ' + degErr(r.maeHi) + ' · lows ' + degErr(r.maeLo) +
        ' · ' + r.n + ' day' + (r.n === 1 ? '' : 's')));
      box.appendChild(row);
    });
    box.appendChild(U.make('p', 'scorecard-note',
      'Day-ahead forecasts only, verified against ' +
      (sc.station || 'the nearest station') + '’s own METAR extremes over ' +
      sc.days + ' day' + (sc.days === 1 ? '' : 's') +
      '. Learned on this device — a leaderboard for this exact spot.'));
  }

  // One line per model over the envelope, so divergence is visible directly
  // rather than described.
  function drawSpread(container, temp, state) {
    var W = 1000, H = 150, PAD_L = 36, PAD_R = 10, PAD_T = 10, PAD_B = 20;
    var now = Date.now();
    var hours = temp.hours.filter(function (h) {
      return h.epoch >= now - 3600000 && h.epoch <= now + 72 * 3600000;
    });
    if (hours.length < 2) return;

    var vals = [];
    hours.forEach(function (h) { vals.push(h.min, h.max); });
    var lo = Math.min.apply(null, vals), hi = Math.max.apply(null, vals);
    var pad = Math.max(1, (hi - lo) * 0.12);
    lo -= pad; hi += pad;

    var x = function (i) { return PAD_L + (i / (hours.length - 1)) * (W - PAD_L - PAD_R); };
    var y = function (t) { return PAD_T + (1 - (t - lo) / (hi - lo || 1)) * (H - PAD_T - PAD_B); };

    var s = svg('svg', { viewBox: '0 0 ' + W + ' ' + H, class: 'spread-chart',
      preserveAspectRatio: 'none', role: 'img',
      'aria-label': 'Temperature forecast from ' + temp.series.length + ' models' });

    // Envelope
    var top = [], bottom = [];
    hours.forEach(function (h, i) {
      top.push(x(i).toFixed(1) + ',' + y(h.max).toFixed(1));
      bottom.unshift(x(i).toFixed(1) + ',' + y(h.min).toFixed(1));
    });
    s.appendChild(svg('polygon', {
      class: 'sp-band', points: top.concat(bottom).join(' '),
      fill: 'rgba(255,255,255,0.16)'
    }));

    // Axis labels
    [lo + (hi - lo) * 0.15, (lo + hi) / 2, hi - (hi - lo) * 0.15].forEach(function (t) {
      s.appendChild(svg('line', { class: 'sp-axis', x1: PAD_L, y1: y(t), x2: W - PAD_R, y2: y(t) }));
      var lbl = svg('text', { x: PAD_L - 5, y: y(t) + 4, class: 'sp-label', 'text-anchor': 'end' });
      lbl.textContent = U.temp(t, state.imperial);
      s.appendChild(lbl);
    });

    // One polyline per model
    temp.series.forEach(function (ser, si) {
      var pts = [];
      hours.forEach(function (h, i) {
        var v = h.values[si];
        if (v !== null && v !== undefined) pts.push(x(i).toFixed(1) + ',' + y(v).toFixed(1));
      });
      if (pts.length < 2) return;
      var line = svg('polyline', {
        class: 'sp-line', points: pts.join(' '), stroke: ser.model.color
      });
      var t = svg('title');
      t.textContent = ser.model.name;
      line.appendChild(t);
      s.appendChild(line);
    });

    container.appendChild(s);
  }

  // How many models produce rain each hour — a clearer signal than a single
  // probability, because you can see whether it's unanimous or one outlier.
  function drawAgreement(container, precip, state) {
    if (!precip) return;
    var now = Date.now();
    var hours = precip.hours.filter(function (h) {
      return h.epoch >= now - 3600000 && h.epoch <= now + 24 * 3600000;
    }).slice(0, 24);
    if (!hours.length) return;

    var head = U.make('p', 'settings-h', 'Rain agreement, next 24 hours');
    container.appendChild(head);

    // An empty strip looks like a failed render. Say plainly that no model
    // produces rain instead.
    var anyWet = hours.some(function (h) { return h.wetCount > 0; });
    if (!anyWet) {
      container.appendChild(U.make('p', 'muted',
        'None of the ' + hours[0].n + ' models produce measurable rain in the next 24 hours.'));
      return;
    }

    var strip = U.make('div', 'agreement-strip');
    var axis = U.make('div', 'agreement-axis');
    hours.forEach(function (h, i) {
      var cell = U.make('div', 'ag-cell');
      if (h.agreement > 0) {
        var fill = U.make('span', 'ag-fill');
        fill.style.height = Math.round(h.agreement * 100) + '%';
        fill.style.background = h.agreement >= 0.99 ? '#0a84ff'
          : h.agreement >= 0.6 ? '#7fd3ff' : 'rgba(127,211,255,.55)';
        cell.appendChild(fill);
      }
      cell.title = U.fmtHour(h.time, state.hour12) + ' — ' +
        h.wetCount + ' of ' + h.n + ' models produce rain';
      strip.appendChild(cell);
      axis.appendChild(U.make('span', null, i % 4 === 0 ? U.fmtHour(h.time, state.hour12) : ''));
    });
    container.appendChild(strip);
    container.appendChild(axis);
  }

  /* ── Extended outlook ───────────────────────────────────────────────── */

  function renderOutlook(state) {
    var summary = U.el('outlook-summary');
    var chart = U.el('outlook-chart');
    var key = U.el('outlook-key');
    var note = U.el('outlook-note');
    var O = global.Outlook;
    U.clear(key);

    if (state.outlookError) {
      summary.textContent = state.outlookError;
      U.clear(chart);
      note.textContent = '';
      return;
    }
    if (!state.outlook) {
      summary.textContent = 'Loading the ensemble…';
      return;
    }

    var o = state.outlook;
    // The card names its own length from the ensemble that actually arrived,
    // rather than promising sixteen days and drawing fourteen.
    U.el('outlook-title').textContent = o.days.length + '-day outlook';
    summary.textContent = O.summary(o, state.imperial);
    global.OutlookChart.render(chart, o, { imperial: state.imperial });

    function chip(cls, label) {
      var c = U.make('span', 'ol-key ' + cls);
      c.appendChild(U.make('span', 'ol-key-mark'));
      c.appendChild(U.make('span', null, label));
      key.appendChild(c);
    }
    chip('ol-key-box', 'Middle half of members');
    chip('ol-key-whisker', '10th–90th percentile');
    chip('ol-key-det', 'Single deterministic run');
    if (o.hasNormals) {
      chip('ol-key-normal', o.normalYears + '-year normal range');
      chip('ol-key-popnormal', 'Usual chance of a wet day');
    }

    var horizonText = o.horizon > 0
      ? 'For this location and this run the marker falls at ' +
        O.lastLabel(o.days[o.horizon]) + '; a different pattern, or a different ' +
        'part of the world, puts it somewhere else.'
      : (o.horizon === 0
        ? 'For this run the ensemble is already as spread out as the climate record, so treat the whole range as pattern only.'
        : 'For this run the ensemble stays informative across the entire range.');

    note.textContent = horizonText + ' ' + O.caveat(o);

    U.el('outlook-src').textContent = (o.days[0] ? o.days[0].members : 0) + ' members · ECMWF IFS';
  }

  /* ── Forecaster's discussion ────────────────────────────────────────── */

  /* Highlighting a quote inside the raw product is not a plain substring
   * search: the source is hard-wrapped, so the quote the model returned has
   * its line breaks somewhere else. Matching each space as \s+ puts the
   * highlight back exactly where the forecaster's words are. */
  function quoteRegex(quote) {
    var escaped = quote.replace(/[.*+?^${}()|[\]\\]/g, '\\$&').replace(/\s+/g, '\\s+');
    return new RegExp(escaped, 'i');
  }

  function highlighted(text, quotes, onMark) {
    var frag = document.createDocumentFragment();
    var spans = [];

    quotes.forEach(function (q, i) {
      var m = quoteRegex(q).exec(text);
      if (m) spans.push({ start: m.index, end: m.index + m[0].length, index: i });
    });
    spans.sort(function (a, b) { return a.start - b.start; });

    var pos = 0;
    spans.forEach(function (s) {
      if (s.start < pos) return;                 // overlapping quotes: first wins
      if (s.start > pos) frag.appendChild(document.createTextNode(text.slice(pos, s.start)));
      var mark = U.make('mark', 'afd-mark', text.slice(s.start, s.end));
      mark.id = 'afd-q' + s.index;
      if (onMark) onMark(mark, s.index);
      frag.appendChild(mark);
      pos = s.end;
    });
    if (pos < text.length) frag.appendChild(document.createTextNode(text.slice(pos)));
    return frag;
  }

  var KIND_LABEL = { hazard: 'Hazard', timing: 'Timing', uncertainty: 'Uncertainty', context: 'Context' };

  function renderDiscussion(state, handlers) {
    handlers = handlers || {};
    var card = U.el('afd-card');
    var briefBox = U.el('afd-brief');
    var body = U.el('afd-body');
    var B = global.Brief;
    U.clear(briefBox);
    U.clear(body);

    var product = state.afd;
    if (!product) { card.hidden = true; return; }
    card.hidden = false;

    var parsed = B.parse(product.text);
    var src = U.el('afd-src');
    src.textContent = (parsed.office ? parsed.office + ' · ' : '') +
      (parsed.issued || (product.issued ? U.fmtTime(new Date(product.issued), state.hour12) : ''));

    /* The forecaster's own KEY MESSAGES are the summary — free, theirs,
     * and needing no key of any kind. Where the browser carries its own
     * on-device summarizer, a plain-English version is offered beside
     * them, every point pinned to the forecaster's sentence it rests on. */

    var km = B.keyMessages(parsed);
    if (km.length) {
      briefBox.appendChild(U.make('h3', 'afd-km-head', 'The forecaster\'s key messages'));
      var ul = U.make('ul', 'afd-km');
      km.forEach(function (m) { ul.appendChild(U.make('li', null, m)); });
      briefBox.appendChild(ul);
    }
    var quotes = renderLocalSummary(state, product, parsed, briefBox, function () {
      renderDiscussion(state, handlers);
    });

    /* ── The product itself, always ──────────────────────────────────── */

    var sections = B.ordered(parsed, state.mode);
    if (!sections.length) {
      body.appendChild(U.make('pre', 'afd-raw', product.text));
      return;
    }

    // Which section to open by default. If the key messages are already
    // reproduced above, opening them again just repeats the same three
    // sentences, so start on the next one down.
    var lead = 0;
    if (sections.length > 1 && /^KEY MESSAGES/.test(sections[0].name) &&
        briefBox.querySelector('.afd-km')) {
      lead = 1;
    }

    sections.forEach(function (s, i) {
      var det = U.make('details', 'afd-section');
      // Plus anything a verified quote landed in — a summary that points at a
      // collapsed box is not evidence.
      var hasQuote = quotes.some(function (q) { return quoteRegex(q).test(s.text); });
      det.open = i === lead || hasQuote;
      var sum = U.make('summary');
      sum.appendChild(U.make('strong', null, s.name));
      if (s.issued) sum.appendChild(U.make('span', 'muted', ' issued ' + s.issued));
      det.appendChild(sum);
      var pre = U.make('pre', 'afd-raw');
      pre.appendChild(highlighted(s.text, quotes));
      det.appendChild(pre);
      body.appendChild(det);
    });

    var foot = U.make('p', 'muted afd-foot',
      'Area Forecast Discussion, issued about four times a day by the local ' +
      'NWS forecast office. Public domain, unedited above.');
    body.appendChild(foot);
  }

  /* ── Plain English, made on this device ──────────────────────────────
   *
   * Chrome's built-in Summarizer (desktop Chrome 138+, on capable hardware)
   * runs a model on the device itself: no key, no account, nothing sent
   * anywhere. It is offered, never assumed — the button exists only where
   * the browser says the model is available or downloadable, and the first
   * use may download it (Chrome manages that, once). Nothing it writes is
   * shown on its own say-so: js/brief.js groundPoint() keeps only points
   * whose numbers and words are the forecaster's, each shown with the
   * sentence it rests on, and the count of dropped points is printed.
   * Returns the sentences to highlight in the product below. */
  var SUMMARY_CONTEXT = 'A US National Weather Service Area Forecast Discussion, written by a ' +
    'meteorologist. Summarize for members of the public in plain words. Keep every number exactly ' +
    'as written.';
  var SKIP_SECTIONS = /^(AVIATION|PRELIMINARY POINT|WFO|.*WATCHES\/WARNINGS)/;

  function summaryKey(product) { return (product.issued || '') + '|' + product.text.length; }

  function renderLocalSummary(state, product, parsed, box, rerender) {
    var B = global.Brief;
    var S = state.afdSummary && state.afdSummary.key === summaryKey(product) ? state.afdSummary : null;
    if (S) {
      box.appendChild(U.make('h3', 'afd-km-head', 'In plain English'));
      if (S.points.length) {
        var ul = U.make('ul', 'afd-local');
        S.points.forEach(function (p) {
          var li = U.make('li');
          li.appendChild(U.make('span', 'afd-local-point', p.text));
          li.appendChild(U.make('q', 'afd-local-quote', p.quote));
          ul.appendChild(li);
        });
        box.appendChild(ul);
      }
      box.appendChild(U.make('p', 'muted afd-local-note',
        (S.points.length
          ? 'Summarized by your browser’s built-in model, on this device — nothing was sent ' +
            'anywhere and no key was used. Each point is shown with the forecaster’s sentence it ' +
            'rests on, highlighted in the discussion below'
          : 'None of the summary’s points could be matched to the forecaster’s words, so none is shown') +
        (S.dropped ? '; ' + S.dropped + ' point' + (S.dropped === 1 ? '' : 's') +
          ' that could not be matched to the discussion ' + (S.dropped === 1 ? 'was' : 'were') + ' left out' : '') +
        '. The forecaster’s own text is the authority.'));
      return S.points.map(function (p) { return p.sentence; });
    }

    if (!('Summarizer' in global)) return [];
    var wrap = U.make('div', 'afd-local-offer');
    var btn = U.make('button', 'ghost-btn', 'Plain-English version, made on this device');
    var msg = U.make('p', 'muted afd-local-msg');
    btn.hidden = true;
    wrap.appendChild(btn); wrap.appendChild(msg);
    box.appendChild(wrap);
    var opts = { type: 'key-points', format: 'plain-text', length: 'medium',
                 expectedInputLanguages: ['en'], outputLanguage: 'en' };
    Promise.resolve().then(function () { return global.Summarizer.availability(opts); })
      .then(function (av) {
        if (av === 'unavailable') return;
        btn.hidden = false;
        msg.textContent = 'Uses your browser’s own on-device model — no key, nothing sent anywhere.' +
          (av === 'available' ? '' : ' The first time, the browser downloads that model (a few GB, once).');
      }).catch(function () { /* not offered */ });

    btn.addEventListener('click', function () {
      btn.disabled = true;
      msg.textContent = 'Preparing the on-device model…';
      var o = Object.assign({ sharedContext: SUMMARY_CONTEXT, monitor: function (m) {
        m.addEventListener('downloadprogress', function (e) {
          msg.textContent = 'Downloading the on-device model: ' + Math.round(e.loaded * 100) + '%';
        });
      } }, opts);
      global.Summarizer.create(o).then(function (sm) {
        msg.textContent = 'Summarizing…';
        var secs = B.ordered(parsed, state.mode).filter(function (x) { return !SKIP_SECTIONS.test(x.name); });
        var fit = function (list) {
          var text = list.map(function (x) { return x.name + '\n' + x.text; }).join('\n\n');
          if (!sm.measureInputUsage || !sm.inputQuota || list.length <= 1) {
            return Promise.resolve(text.slice(0, 12000));
          }
          return sm.measureInputUsage(text).then(function (n) {
            return n <= sm.inputQuota ? text : fit(list.slice(0, -1));
          });
        };
        return fit(secs).then(function (text) { return sm.summarize(text); })
          .then(function (out) {
            if (sm.destroy) sm.destroy();
            var points = [], dropped = 0;
            B.bullets(out).forEach(function (pt) {
              var g = B.groundPoint(pt, product.text);
              if (g.ok) points.push({ text: pt, quote: g.quote, sentence: g.sentence });
              else dropped++;
            });
            state.afdSummary = { key: summaryKey(product), points: points, dropped: dropped };
            rerender();
          });
      }).catch(function (e) {
        btn.disabled = false;
        msg.textContent = 'Your browser’s on-device model could not run here (' +
          (e && e.message ? e.message : 'unavailable') + '). The forecaster’s text below is unchanged.';
      });
    });
    return [];
  }

  /* ── SPC outlook (chase planning) ───────────────────────────────────── */

  function renderSpc(state) {
    var box = U.el('spc');
    U.clear(box);
    var S = global.SPC;
    var risk = S.riskAt(state.location.lat, state.location.lon);

    var head = U.make('div', 'spc-head');
    if (risk) {
      var chip = U.make('span', 'spc-chip', risk.code);
      chip.style.background = risk.color;
      chip.style.color = risk.rank >= 3 ? '#12161b' : '#fff';
      head.appendChild(chip);
      head.appendChild(U.make('span', 'spc-label', risk.label +
        (S.state.hazard === 'cat' ? '' : ' (' + S.state.hazard + ')')));
    } else {
      head.appendChild(U.make('span', 'spc-label muted',
        S.state.features.length
          ? 'This location is outside any Day ' + S.state.day + ' risk area.'
          : 'No SPC outlook loaded (US only).'));
    }
    box.appendChild(head);

    if (risk && risk.forecaster) {
      var meta = U.make('p', 'muted',
        'Issued ' + (risk.issued ? U.fmtTime(new Date(risk.issued), state.hour12) : '—') +
        ' UTC by ' + risk.forecaster +
        (risk.expires ? ' · valid until ' + new Date(risk.expires).toUTCString().slice(5, 22) + ' UTC' : ''));
      box.appendChild(meta);
    }

    // Legend doubles as the key for the map overlay.
    var legend = U.make('div', 'spc-legend');
    Object.keys(C.SPC_RISK).forEach(function (dn) {
      var info = C.SPC_RISK[dn];
      var present = S.state.features.some(function (f) {
        return f.properties && f.properties.DN === +dn;
      });
      var item = U.make('span', 'spc-legend-item' + (present ? ' present' : ''));
      var sw = U.make('span', 'spc-swatch');
      sw.style.background = info.color;
      item.appendChild(sw);
      item.appendChild(U.make('span', null, info.code));
      item.title = info.label + (present ? ' — in today\'s outlook' : ' — not issued today');
      legend.appendChild(item);
    });
    box.appendChild(legend);
  }

  function renderReports(state) {
    var box = U.el('reports');
    U.clear(box);
    var S = global.SPC;
    var counts = S.summary(), total = 0;
    C.REPORT_ORDER.forEach(function (k) { total += counts[k] || 0; });

    var bar = U.make('div', 'report-counts');
    C.REPORT_ORDER.forEach(function (k) {
      // Tornado, wind and hail always show, zero or not; the rest only when present.
      if (!counts[k] && ['tornado', 'wind', 'hail'].indexOf(k) === -1) return;
      var style = C.STORM_REPORT_STYLE[k];
      var chip = U.make('span', 'report-chip');
      var dot = U.make('span', 'report-dot');
      dot.style.background = style.color;
      chip.appendChild(dot);
      chip.appendChild(U.make('span', null, counts[k] + ' ' + style.label.toLowerCase()));
      bar.appendChild(chip);
    });
    box.appendChild(bar);

    if (!total) {
      box.appendChild(U.make('p', 'muted', 'No NWS storm reports in the last 24 hours (US).'));
      return;
    }

    var near = S.reportsNear(state.location.lat, state.location.lon, 400);
    if (!near.length) {
      box.appendChild(U.make('p', 'muted', total + ' reports nationally, none within 400 km.'));
      return;
    }
    var list = U.make('div', 'report-list');
    near.slice(0, 25).forEach(function (r) {
      var style = C.STORM_REPORT_STYLE[r.category];
      var row = U.make('div', 'report-row');
      var dot = U.make('span', 'report-dot');
      dot.style.background = style.color;
      row.appendChild(dot);
      row.appendChild(U.make('span', 'report-time', r.time + 'Z'));
      row.appendChild(U.make('span', 'report-loc', (r.kind ? r.kind + ' · ' : '') + r.location + ', ' + r.state));
      row.appendChild(U.make('span', 'report-mag', r.magnitude));
      row.appendChild(U.make('span', 'report-dist', U.distance(r.distance, state.imperial)));
      row.title = r.comments || '';
      list.appendChild(row);
    });
    box.appendChild(list);
  }

  /* The combined forecast chart (js/meteogram.js) lives on this tab and
   * loads with it, so the app reaches it through here. */
  function renderMeteogram(state) {
    global.Meteogram.render(U.el('meteogram'), state, { hours: state.mgHours });
  }

  UI.renderModels = renderModels;
  UI.renderMeteogram = renderMeteogram;
  UI.renderSpc = renderSpc;
  UI.renderReports = renderReports;
  UI.renderDiscussion = renderDiscussion;
  UI.renderOutlook = renderOutlook;
  UI.quoteRegex = quoteRegex;
  UI.highlighted = highlighted;
})(window);
