/* Vane — Now tab rendering: alerts, hero, the observed and motion lines,
 * Insight, the nowcast, hourly, the week with its microclimate note,
 * details, air quality, sun and moon. */
(function (global) {
  'use strict';

  var C = global.VaneConfig, U = global.U, D = global.Derive;
  var UI = global.UI;
  /* ── Alerts ─────────────────────────────────────────────────────────── */

  function renderAlerts(alerts, onOpenChase) {
    var box = U.el('alerts');
    U.clear(box);
    if (!alerts || !alerts.length) { box.hidden = true; return; }
    box.hidden = false;

    alerts.slice(0, 4).forEach(function (a) {
      var sev = (a.severity || 'Unknown').toLowerCase();
      var row = U.make('div', 'alert alert-' + sev);
      var head = U.make('div', 'alert-head');
      head.appendChild(U.make('span', 'alert-event', a.event));
      if (a.expires) {
        var exp = new Date(a.expires);
        head.appendChild(U.make('span', 'alert-until', 'until ' + U.fmtTime(exp, true)));
      }
      row.appendChild(head);
      if (a.headline) row.appendChild(U.make('p', 'alert-headline', a.headline));
      box.appendChild(row);
    });

    // F5: the lens zooms itself when the situation warrants it.
    var worst = alerts[0];
    if ((C.ALERT_RANK[worst.severity] || 0) >= 3 && document.body.dataset.mode !== 'chase') {
      var nudge = U.make('button', 'alert-nudge', 'Severe weather active — open Chase mode →');
      nudge.addEventListener('click', onOpenChase);
      box.appendChild(nudge);
    }
  }

  function renderAlertsFull(alerts, status) {
    var box = U.el('alerts-full');
    U.clear(box);
    if (status && global.WarningEvidence && global.WarningEvidence.feedState(status, Date.now()) !== 'current') {
      box.appendChild(U.make('p', 'muted', 'Current official warning status is unknown. The feed is unavailable, cached or out of date; consult NWS.'));
      if (!alerts || !alerts.length) return;
    }
    if (!alerts || !alerts.length) {
      box.appendChild(U.make('p', 'muted', 'No active NWS alerts for this point. (US coverage only.)'));
      return;
    }
    alerts.forEach(function (a) {
      var d = U.make('details', 'alert-full alert-' + (a.severity || 'unknown').toLowerCase());
      var s = U.make('summary');
      s.appendChild(U.make('strong', null, a.event));
      s.appendChild(U.make('span', 'muted', '  ' + [a.severity, a.urgency, a.certainty].filter(Boolean).join(' · ')));
      d.appendChild(s);
      if (a.headline) d.appendChild(U.make('p', 'alert-headline', a.headline));
      if (a.description) d.appendChild(U.make('pre', 'alert-text', a.description));
      if (a.instruction) {
        d.appendChild(U.make('p', 'alert-instruction-label', 'Instruction'));
        d.appendChild(U.make('pre', 'alert-text', a.instruction));
      }
      d.appendChild(U.make('p', 'muted', 'Issued by ' + (a.sender || 'NWS')));
      box.appendChild(d);
    });
  }

  /* ── Hero ───────────────────────────────────────────────────────────── */

  function renderHero(state) {
    var d = state.data, loc = state.location, imp = state.imperial;
    var cur = d.current, daily = d.daily;

    U.el('hero').setAttribute('aria-busy', 'false');
    U.el('place-name').textContent = loc.name;
    var sub = [loc.admin, d.elevation !== undefined ? U.height(d.elevation, imp) + ' elev' : null]
      .filter(Boolean).join(' · ');
    U.el('place-sub').textContent = sub;

    /* The condition and the icon follow the observation when there is one that
     * contradicts the model. A sun captioned "Clear" beside a line reading
     * "Light rain now" is the same broken promise as the nowcast making the
     * claim — moved up one line. When the station says rain is falling, the
     * whole card says rain is falling.
     *
     * Only precipitation overrides. The model's cloud-cover judgement is fine
     * and the station has nothing better to say about it. */
    var obs = D.observedPrecip({
      observation: state.observation,
      overhead: state.overhead,
      current: cur
    });
    var observedCode = obs && obs.station && obs.station.raining && obs.station.code !== null
      ? obs.station.code : null;
    var code = observedCode !== null ? observedCode : cur.weather_code;

    var w = U.wmo(code);
    global.Icons.into(U.el('now-icon'), code, cur.is_day !== 0, 108);
    U.el('now-temp').textContent = U.temp(cur.temperature_2m, imp).replace('°', '');
    U.el('now-unit').textContent = imp ? '°F' : '°C';
    U.el('now-cond').textContent = w[0];

    var feels = U.temp(cur.apparent_temperature, imp);
    var wind = U.speed(cur.wind_speed_10m, imp) + ' ' + U.compass(cur.wind_direction_10m);
    var gust = cur.wind_gusts_10m > cur.wind_speed_10m * 1.4
      ? ', gusting ' + U.speed(cur.wind_gusts_10m, imp) : '';
    U.el('now-feels').textContent = 'Feels like ' + feels + ' · Wind ' + wind + gust;

    if (daily && daily.temperature_2m_max) {
      U.el('now-range').textContent = 'Today ' + U.temp(daily.temperature_2m_max[0], imp) +
        ' / ' + U.temp(daily.temperature_2m_min[0], imp);
    }
  }

  // F6: show the real observation next to the model, and say which is which.
  function renderObservation(obs, state) {
    var box = U.el('now-obs');
    if (!obs || obs.temperature === null) { box.hidden = true; return; }
    box.hidden = false;
    var age = obs.time ? U.relative(Date.now() - new Date(obs.time).getTime()) : '';
    var bits = [U.temp(obs.temperature, state.imperial)];
    if (obs.text) bits.push(obs.text);
    if (obs.windSpeed !== null) {
      bits.push(U.speed(obs.windSpeed, state.imperial) + ' ' + U.compass(obs.windDirection));
    }
    U.el('now-obs-text').textContent = bits.join(' · ') +
      '  —  ' + (obs.station || 'station') + (age ? ', ' + age : '');
    U.el('now-obs-text').title = obs.raw || obs.name || '';
  }

  /* ── Nowcast (F4) ───────────────────────────────────────────────────── */

  /* The same finding twice, at two lengths: a glanceable clause beside the
   * temperature, and the full sentence over the chart that evidences it. */
  function heroRain(short, cls) {
    var line = U.el('hero-rain');
    if (!line) return;
    if (!short) { line.hidden = true; return; }
    line.hidden = false;
    line.textContent = short;
    line.className = 'hero-rain ' + cls;
  }

  /* What the sky says, in a line under the forecast.
   *
   * Printed whenever there is an observation to print, not only when it
   * disagrees — a reader who has been told once that the model missed a shower
   * needs to see, next time, that the two now agree. A note that only ever
   * appears when something is wrong is a note people learn to dread. */
  function observedNote(obs, disagrees, hedged) {
    var box = U.el('nowcast-observed');
    if (!box) return;
    U.clear(box);
    if (!obs || (!obs.station && !obs.radar)) { box.hidden = true; return; }
    box.hidden = false;
    box.className = 'nowcast-observed' + (disagrees ? ' conflict' : '');

    var bits = [];
    if (obs.station) {
      bits.push(obs.station.raining
        ? (obs.station.label || 'Precipitation') + ' at ' + (obs.station.station || 'the nearest station') +
          ', ' + (obs.station.ageMin < 1 ? 'just now' : obs.station.ageMin + ' min ago')
        : 'Nothing falling at ' + (obs.station.station || 'the nearest station') +
          ', ' + (obs.station.ageMin < 1 ? 'just now' : obs.station.ageMin + ' min ago'));
    }
    if (obs.radar) {
      bits.push(obs.radar.raining
        ? 'radar shows ' + obs.radar.dbz + ' dBZ overhead'
        : obs.radar.trace
          ? 'radar shows a weak ' + obs.radar.dbz + ' dBZ overhead, which may not be reaching the ground'
          : 'radar is clear overhead');
    }

    box.appendChild(U.make('span', 'obs-label', disagrees ? 'But' : 'Observed'));
    var text = bits.join(' · ');
    if (hedged) {
      /* Radar wet, fresh station dry: genuinely ambiguous. A shower may
       * have started since the station reported, or the beam may be seeing
       * rain that dries up on the way down. Say that, instead of siding
       * flatly with either instrument. */
      text += '. A shower may have started since the station reported, or ' +
        'this may be rain evaporating before it reaches the ground. Radar ' +
        'is the thing to watch.';
    } else if (disagrees) {
      text += '. The minute-by-minute model missed this, so the radar — not ' +
        'the model — is what says when it ends.';
    }
    box.appendChild(U.make('span', null, text));
  }

  /* VaneMotion's line. Every number in it was learned client-side by
   * js/motion.js — a block-match across the last hour of mosaic frames and
   * a least-squares fit through the displacements — and the line says so,
   * because a reader deserves to know this is Vane's own on-device fit and
   * not a product some agency published. No fit, no line: the box hides
   * rather than hedge about motion it could not measure. */
  function renderMotion(state) {
    var box = U.el('nowcast-motion');
    if (!box) return;
    var m = state.motion;
    if (!m && state.radarCoverage === false) {
      // Said once, plainly, rather than leaving the reader to wonder why
      // the radar lines are missing here and present at home.
      box.hidden = false;
      U.clear(box);
      box.appendChild(U.make('span', 'obs-label', 'Radar'));
      box.appendChild(U.make('span', null, 'No public weather radar covers this ' +
        'location, so there is no radar reading overhead and nothing for ' +
        'VaneMotion to learn from. Rain timing here comes from the model alone.'));
      return;
    }
    if (!m) { box.hidden = true; return; }
    box.hidden = false;
    U.clear(box);
    box.appendChild(U.make('span', 'obs-label', 'Motion'));

    var text;
    var spd = U.speed(m.vector.speed / 3.6, state.imperial);
    if (m.stationary) {
      text = m.overheadNow
        ? 'The precipitation overhead is close to stationary — expect it to sit rather than sweep through.'
        : 'Echoes nearby are close to stationary.';
    } else if (m.overheadNow) {
      text = 'The precipitation overhead is moving ' + m.vector.toward +
        ' at about ' + spd + '.';
    } else if (m.eta) {
      text = 'Echoes are moving ' + m.vector.toward + ' at about ' + spd +
        '. On that track, the nearest rain (' + m.eta.dbz + ' dBZ, ' +
        U.distance(m.eta.distanceKm, state.imperial) + ' to the ' + m.eta.dir +
        ') reaches you in about ' + m.eta.minutes + ' minutes.';
      var cal = m.eta.calibration;
      if (cal) {
        // Said every time it applies: a corrected number must never pass
        // for the raw fit's.
        text += ' That is ' + Math.abs(cal.biasMin) + ' min ' +
          (cal.biasMin > 0 ? 'later' : 'earlier') + ' than the raw fit said, because ' +
          'over ' + cal.n + ' graded calls here rain has arrived a median ' +
          Math.abs(cal.biasMin) + ' min ' + (cal.biasMin > 0 ? 'after' : 'before') +
          ' the fit\'s time.';
      }
    } else {
      text = 'Echoes nearby are moving ' + m.vector.toward + ' at about ' + spd +
        '; nothing on that track is headed for you within the next hour.';
    }
    text += m.source === 'rainviewer'
      ? ' Learned in your browser from the last hour of RainViewer\'s global radar composite.'
      : ' Learned in your browser from the last hour of radar.';
    // And how its arrival calls have actually fared here, once graded.
    if (m.eta && !m.overheadNow && global.MotionSkill && global.Insight) {
      var rec = global.Insight.skillText(global.MotionSkill.summary(state.location));
      if (rec) text += ' ' + rec;
    }
    box.appendChild(U.make('span', null, text));
  }

  /* ── Vane Insight ─────────────────────────────────────────────────────
   * The card assembles primitives from state and the learners, and
   * Insight.compose (pure, unit-tested) turns them into ordered lines.
   * Every line carries a tag naming the learner that produced it. */
  function renderInsight(state) {
    var box = U.el('insight-card'), list = U.el('insight-lines');
    if (!box || !list || !global.Insight) return;
    var imp = state.imperial;

    var fmt = {
      temp: function (c) { return U.temp(c, imp); },
      // A temperature DIFFERENCE (spread, error): converted, never offset.
      temp0: function (c) { return Math.max(1, Math.round(imp ? c * 9 / 5 : c)) + '°'; },
      dist: function (km) { return U.distance(km, imp); },
      speed: function (kmh) { return U.speed(kmh / 3.6, imp); },
      clock: function (ms) {
        return U.fmtEpoch(ms, state.data ? state.data.utc_offset_seconds : 0, state.hour12);
      }
    };

    /* The latest rain-related change between the two most recent forecast
     * snapshots the decision layer kept. Read without creating an entry —
     * Intelligence.location() would make one, and could evict another
     * saved place's history to do it. */
    var change = null;
    if (global.Intelligence && state.data && !state.stale) {
      var entry = global.Intelligence.read().locations[global.Intelligence.key(state.location)];
      var snaps = entry ? entry.snapshots : [];
      if (snaps.length >= 2) {
        change = global.Intelligence.changes(snaps[snaps.length - 2], snaps[snaps.length - 1], Date.now())
          .filter(function (c) { return c.kind === 'timing' || c.kind === 'rain-signal'; })[0] || null;
      }
    }

    // The loudest active alert, if any survived the family filters.
    var alert = null;
    global.Settings.filterAlerts(state.alerts).forEach(function (a) {
      if (!alert || (C.ALERT_RANK[a.severity] || 0) > (C.ALERT_RANK[alert.severity] || 0)) alert = a;
    });

    var nc = state.data ? D.nowcast(state.data) : null;
    var ncLine = null;
    if (nc) {
      ncLine = { state: nc.state };
      if (nc.state === 'starting') {
        ncLine.headline = 'Rain starting around ' + U.fmtTime(nc.startTime, state.hour12) + '.';
      } else if (nc.state === 'stopping') {
        ncLine.headline = 'Rain now, easing off around ' + U.fmtTime(nc.stopTime, state.hour12) + '.';
      } else if (nc.state === 'ongoing') {
        ncLine.headline = 'Rain continuing through the next 2 hours.';
      }
    }

    var sc = global.Verify.scorecard();
    var official = null, cons = null;
    if (state.data && state.data.daily && state.data.daily.temperature_2m_max) {
      official = { hi: state.data.daily.temperature_2m_max[0],
                   lo: state.data.daily.temperature_2m_min[0] };
    }
    if (state.modelDaily) {
      cons = global.Insight.consensus(state.modelDaily, 0, sc.rows, global.Verify.climate(todayRegime(state)));
    }

    // The day's highest rain chance, beside what such chances have meant
    // here — only once that chance's bin has earned it, and only when there
    // is a chance worth talking about.
    var rainCal = null;
    if (global.RainCal && state.data && state.data.hourly && state.data.hourly.precipitation_probability) {
      var hh = state.data.hourly, i0 = currentHourIndex(state.data.hourly, state.data.utc_offset_seconds), best = -1;
      for (var hi = i0; hi < Math.min(hh.time.length, i0 + 24); hi++) {
        if (best < 0 || hh.precipitation_probability[hi] > hh.precipitation_probability[best]) best = hi;
      }
      var topPop = best >= 0 ? hh.precipitation_probability[best] : null;
      if (typeof topPop === 'number' && topPop >= 20) {
        var calib = global.RainCal.calibrateAt(state.location, topPop);
        if (calib) {
          rainCal = { cal: calib, station: global.RainCal.summary(state.location).station,
                      at: U.epochOf(hh.time[best], state.data.utc_offset_seconds) };
        }
      }
    }

    var lines = global.Insight.compose({
      rainCal: rainCal,
      rainTiming: state.rainTiming,
      blendSkill: global.MotionSkill ? global.MotionSkill.skillBy(state.location, 'blend') : null,
      alert: alert ? { event: alert.event, until: null } : null,
      threat: state.threat,
      motion: state.motion,
      motionSkill: global.MotionSkill ? global.MotionSkill.summary(state.location) : null,
      nowcast: ncLine,
      change: change,
      consensus: cons,
      consensusLabel: 'today',
      official: official,
      bestModel: sc.rows.length ? sc.rows[0] : null
    }, fmt);

    // The Vane AI card reads the same moment; keep the two in step.
    if (global.AiHub) global.AiHub.render(state);
    U.clear(list);
    if (!lines.length) { box.hidden = true; return; }
    box.hidden = false;
    lines.forEach(function (l) {
      var li = U.make('li', 'insight-line');
      li.appendChild(U.make('span', 'insight-tag', l.tag));
      li.appendChild(U.make('span', 'insight-text', l.text));
      list.appendChild(li);
    });
  }

  function renderNowcast(state) {
    var nc = D.nowcast(state.data);
    var head = U.el('nowcast-headline');
    var chart = U.el('nowcast-chart');
    var axis = U.el('nowcast-axis');
    U.clear(chart); U.clear(axis);

    /* The observation outranks the forecast. Open-Meteo's 15-minute field is
     * model output, and when it has missed a shower this card was telling
     * somebody standing in the rain that no rain was expected. */
    var obs = D.observedPrecip({
      observation: state.observation,
      overhead: state.overhead,
      current: state.data && state.data.current
    });

    if (!nc) {
      // No minute-scale model here — but an observation may still exist, and
      // it is worth more than the model that is missing.
      if (obs && obs.raining) {
        head.textContent = 'It is raining now.';
        head.className = 'nowcast-headline wet';
        heroRain('Raining now', 'wet');
      } else {
        head.textContent = 'Minute-scale precipitation is not available for this location.';
        head.className = 'nowcast-headline dry';
        // Say nothing rather than say "dry": no data is not the same as no rain.
        heroRain(null);
      }
      observedNote(obs, false);
      renderMotion(state);
      return;
    }

    // Plain English first, chart second — the chart is the evidence, not the answer.
    var text, cls, short;
    if (nc.state === 'dry') {
      text = nc.maxProb >= 30
        ? 'No rain expected in the next 2 hours (' + nc.maxProb + '% chance at most).'
        : 'No rain expected in the next 2 hours.';
      short = 'No rain for at least 2 hours';
      cls = 'dry';
    } else if (nc.state === 'starting') {
      var kind = D.intensityLabel(nc.peak.mm);
      var noun = kind === 'heavy' ? 'Heavy rain' : kind === 'moderate' ? 'Rain' : 'Light rain';
      text = noun + ' starting around ' + U.fmtTime(nc.startTime, state.hour12) +
        (nc.continues ? ', continuing past 2 hours.'
                      : ', lasting about ' + nc.durationMin + ' minutes.');
      short = noun + ' from about ' + U.fmtTime(nc.startTime, state.hour12);
      cls = 'wet';
    } else if (nc.state === 'stopping') {
      text = 'Precipitation now, easing off around ' + U.fmtTime(nc.stopTime, state.hour12) + '.';
      short = 'Raining, easing off around ' + U.fmtTime(nc.stopTime, state.hour12);
      cls = 'wet';
    } else {
      text = 'Precipitation now, continuing through the next 2 hours.';
      short = 'Raining, and set to continue';
      cls = 'wet';
    }
    /* Reconcile. The only case that needs overriding is the one that broke
     * trust: the sky is wet and the model says dry. The reverse — model says
     * rain, nothing is falling yet — is a forecast doing its job, not an
     * error, so it stands. */
    var disagrees = !!(obs && obs.raining && nc.state === 'dry');
    /* Radar-only rain against a fresh dry station report is a hedge, not a
     * verdict — asserting "falling now" over both the station and the model
     * was photographed and questioned. */
    var hedged = disagrees && obs.why === 'radar' &&
      obs.station && !obs.station.raining;
    if (hedged) {
      text = 'Radar shows precipitation overhead — the nearest station last reported nothing falling.';
      short = 'Radar shows rain overhead';
      cls = 'wet';
    } else if (disagrees) {
      var what = (obs.station && obs.station.label) ||
        (obs.why === 'radar' ? 'Precipitation' : 'Rain');
      text = what + ' is falling now.';
      short = what.charAt(0).toUpperCase() + what.slice(1) + ' now';
      cls = 'wet';
    }

    head.textContent = text;
    head.className = 'nowcast-headline ' + cls;
    heroRain(short, cls);
    observedNote(obs, disagrees, hedged);
    renderMotion(state);

    var maxMm = Math.max(C.PRECIP.moderate, nc.blocks.reduce(function (a, b) {
      return Math.max(a, b.mm);
    }, 0));

    nc.blocks.forEach(function (b, i) {
      var col = U.make('div', 'nc-col');
      var bar = U.make('div', 'nc-bar level-' + D.intensityLabel(b.mm));
      bar.style.height = Math.max(2, (b.mm / maxMm) * 100) + '%';
      bar.title = U.fmtTime(b.time, state.hour12) + ' — ' + U.precip(b.mm, state.imperial) +
        (b.prob !== null ? ' (' + b.prob + '%)' : '');
      col.appendChild(bar);
      chart.appendChild(col);

      var lab = U.make('span', 'nc-tick', i % 2 === 0 ? U.fmtTime(b.time, state.hour12) : '');
      axis.appendChild(lab);
    });
  }

  /* ── Hourly ─────────────────────────────────────────────────────────── */

  function renderHourly(state) {
    var box = U.el('hourly');
    U.clear(box);
    var h = state.data.hourly, imp = state.imperial;
    var tz = state.data.utc_offset_seconds || 0;
    var now = Date.now();
    var start = 0;
    for (var i = 0; i < h.time.length; i++) {
      if (U.epochOf(h.time[i], tz) >= now - 3600000) { start = i; break; }
    }
    var count = document.body.dataset.mode === 'chase' ? 48 : 24;

    for (var j = start; j < Math.min(start + count, h.time.length); j++) {
      var t = U.parseLocal(h.time[j]);
      var cell = U.make('div', 'hour');
      cell.appendChild(U.make('span', 'hour-t', j === start ? 'Now' : U.fmtHour(t, state.hour12)));
      var hIcon = U.make('span', 'hour-icon');
      // Day/night from the sun's real altitude, so a 5am icon isn't sunlit.
      var hIsDay = global.Astro
        ? global.Astro.sunPosition(new Date(U.epochOf(h.time[j], tz)),
            state.location.lat, state.location.lon).altitude > -0.833
        : true;
      var p = h.precipitation_probability ? h.precipitation_probability[j] : null;
      var hCode = D.likelyIcon(h.weather_code[j], p, h.precipitation ? h.precipitation[j] : null,
        h.cloud_cover ? h.cloud_cover[j] : null, true);
      global.Icons.into(hIcon, hCode, hIsDay, 30);
      cell.appendChild(hIcon);
      cell.appendChild(U.make('span', 'hour-temp', U.temp(h.temperature_2m[j], imp)));

      var pop = U.make('span', 'hour-pop' + (p >= 30 ? ' on' : ''), p === null ? '' : p + '%');
      cell.appendChild(pop);

      cell.appendChild(U.make('span', 'hour-wind',
        U.speed(h.wind_speed_10m[j], imp).replace(' mph', '').replace(' km/h', '') +
        ' ' + U.compass(h.wind_direction_10m[j])));

      // Chase mode wants gusts visible without a tap.
      if (document.body.dataset.mode === 'chase' && h.wind_gusts_10m) {
        cell.appendChild(U.make('span', 'hour-gust', 'G' +
          Math.round(imp ? U.msToMph(h.wind_gusts_10m[j]) : U.msToKph(h.wind_gusts_10m[j]))));
      }
      cell.title = U.fmtTime(t, state.hour12) + ' — ' + U.wmo(hCode)[0] +
        ', ' + U.precip(h.precipitation[j], imp);
      box.appendChild(cell);
    }
    U.el('hourly-src').textContent = 'Next ' + count + ' hours';
  }

  /* ── Daily ──────────────────────────────────────────────────────────── */

  function renderDaily(state) {
    var box = U.el('daily');
    U.clear(box);
    var d = state.data.daily, imp = state.imperial;

    // The payload runs 16 days so the extended outlook can share it; this card
    // is the week, and the range bars are scaled to the week alone.
    var days = d.time.slice(0, 7);
    var lo = Math.min.apply(null, d.temperature_2m_min.slice(0, 7));
    var hi = Math.max.apply(null, d.temperature_2m_max.slice(0, 7));
    var span = (hi - lo) || 1;

    days.forEach(function (iso, i) {
      var day = U.parseLocal(iso);
      var row = U.make('div', 'day');
      // Weekday plus date. The card once ran a weekday behind (a date-only
      // string parsed as UTC midnight); with the number printed, a wrong
      // label can never hide behind a plausible-looking weekday again.
      row.appendChild(U.make('span', 'day-name',
        i === 0 ? 'Today' : U.fmtDay(day) + ' ' + day.getDate()));
      var pp = d.precipitation_probability_max ? d.precipitation_probability_max[i] : null;
      // Rain only when rain is likely (Derive.likelyIcon): not a trace at 1%.
      var dCode = D.likelyIcon(d.weather_code[i], pp, d.precipitation_sum[i],
        d.cloud_cover_mean ? d.cloud_cover_mean[i] : null, false);
      var dIcon = U.make('span', 'day-icon');
      global.Icons.into(dIcon, dCode, true, 24);
      row.appendChild(dIcon);

      row.appendChild(U.make('span', 'day-pop' + (pp >= 30 ? ' on' : ''), pp === null ? '' : pp + '%'));

      row.appendChild(U.make('span', 'day-lo', U.temp(d.temperature_2m_min[i], imp)));

      // Range bar makes the week's trend readable at a glance without a chart.
      var track = U.make('span', 'day-track');
      var fill = U.make('span', 'day-fill');
      fill.style.left = ((d.temperature_2m_min[i] - lo) / span * 100) + '%';
      fill.style.width = Math.max(4, (d.temperature_2m_max[i] - d.temperature_2m_min[i]) / span * 100) + '%';
      track.appendChild(fill);
      row.appendChild(track);

      row.appendChild(U.make('span', 'day-hi', U.temp(d.temperature_2m_max[i], imp)));
      row.title = U.wmo(dCode)[0] + ' · ' + U.precip(d.precipitation_sum[i], imp) +
        ' · wind to ' + U.speed(d.wind_gusts_10m_max[i], imp);
      box.appendChild(row);
    });

    renderMicroclimate(state);
  }

  /* The microclimate correction, under the week it corrects. The learned
   * lean is OFFERED next to the official numbers, never silently applied —
   * a forecast that quietly edits itself is a forecast nobody can check.
   * When there is no lean worth correcting, that is said too: "running
   * true" is the finding people learn to trust the card by. */
  // Today's weather regime as the forecast pictures it, for the
  // weather-aware microclimate correction (js/verify.js).
  function todayRegime(state) {
    var d = state.data && state.data.daily;
    if (!d) return null;
    return { sky: d.cloud_cover_mean ? d.cloud_cover_mean[0] : null,
             wdir: d.wind_direction_10m_dominant ? d.wind_direction_10m_dominant[0] : null };
  }

  function renderMicroclimate(state) {
    var box = U.el('microclimate');
    if (!box || !global.Verify) return;
    var m = global.Verify.climate(todayRegime(state));
    if (!m) {
      /* Invisible-until-day-three turned out to mean undiscoverable: a
       * feature nobody can find might as well not exist. While the fit is
       * still earning its minimum days, the card says what it is doing
       * and when it will speak. */
      var sc = global.Verify.scorecard();
      if (!sc.pendingDays && !sc.days) { box.hidden = true; return; }
      box.hidden = false;
      U.clear(box);
      box.appendChild(U.make('span', 'obs-label', 'Your microclimate'));
      box.appendChild(U.make('span', null,
        'Vane is learning how the forecast leans at this exact spot, ' +
        'verifying each day-ahead high and low against ' +
        (sc.station || 'the nearest station') + '’s own thermometer. ' +
        'First reading after ' + global.Verify.MIN_DAYS + ' verified days — ' +
        (sc.days || 0) + ' so far. Learned on this device, sent nowhere.'));
      return;
    }
    box.hidden = false;
    U.clear(box);
    box.appendChild(U.make('span', 'obs-label', 'Your microclimate'));

    var imp = state.imperial;
    var dd = function (c) {          // a temperature DIFFERENCE, not a reading
      return Math.abs(imp ? c * 9 / 5 : c).toFixed(1) + '°';
    };
    var lean = function (bias) { return bias > 0 ? 'warm' : 'cool'; };
    var vs = ' (' + m.n + ' verified day' + (m.n === 1 ? '' : 's') +
      ' vs ' + (m.station || 'the nearest station') + '’s thermometer)';

    var text;
    if (m.meaningful) {
      text = 'At this spot the day-ahead forecast has run ' +
        dd(m.biasHi) + ' ' + lean(m.biasHi) + ' on highs and ' +
        dd(m.biasLo) + ' ' + lean(m.biasLo) + ' on lows' + vs + '.';
      var d = state.data && state.data.daily;
      var rg = m.regime;
      if (rg && rg.top) {
        // The weather-aware correction earned its place: say what about
        // today moves it, and how much better it has proved here.
        var what = rg.top.factor === 'sky' ? rg.top.level + ' days' : rg.top.level + '-wind days';
        text += ' On ' + what + ' like today it leans further: highs ' + dd(rg.top.rawHi) + ' ' +
          (rg.top.rawHi > 0 ? 'warmer' : 'cooler') + ' and lows ' + dd(rg.top.rawLo) + ' ' +
          (rg.top.rawLo > 0 ? 'warmer' : 'cooler') + ' than its usual lean (' + rg.top.n + ' days).';
      }
      if (d && d.temperature_2m_max) {
        text += ' Adjusted for ' + (rg ? 'today’s weather' : 'that lean') + ', today reads closer to ' +
          U.temp(d.temperature_2m_max[0] + m.corrHi, imp) + ' / ' +
          U.temp(d.temperature_2m_min[0] + m.corrLo, imp) + '.';
      }
      if (rg) {
        text += ' (Weather-aware: tested day by day on the ' + rg.n + ' verified days here, it cut the ' +
          'typical miss from ' + dd(rg.looPlain) + ' to ' + dd(rg.looAware) + '.)';
      }
    } else {
      text = 'At this spot the day-ahead forecast has been running true — ' +
        'highs within ±' + dd(m.maeHi) + ', lows within ±' + dd(m.maeLo) +
        vs + '. Nothing to correct.';
    }
    text += ' Learned on this device.';
    box.appendChild(U.make('span', null, text));
  }

  /* ── Details ────────────────────────────────────────────────────────── */

  function renderDetails(state) {
    var box = U.el('details');
    U.clear(box);
    var c = state.data.current, d = state.data.daily, h = state.data.hourly, imp = state.imperial;
    var hourIdx = currentHourIndex(h, state.data.utc_offset_seconds || 0);

    var items = [
      ['Humidity', c.relative_humidity_2m + '%'],
      ['Dew point', U.temp(c.dew_point_2m, imp)],
      ['Wind gusts', U.speed(c.wind_gusts_10m, imp)],
      ['Pressure', imp ? (c.pressure_msl * 0.02953).toFixed(2) + ' inHg'
                       : Math.round(c.pressure_msl) + ' hPa'],
      ['Cloud cover', c.cloud_cover + '%'],
      ['UV index', d.uv_index_max ? Math.round(d.uv_index_max[0]) : '--'],
      ['Visibility', h.visibility && h.visibility[hourIdx] !== null
        ? U.distance(h.visibility[hourIdx] / 1000, imp) : '--'],
      ['Sunrise', U.fmtTime(U.parseLocal(d.sunrise[0]), state.hour12)],
      ['Sunset', U.fmtTime(U.parseLocal(d.sunset[0]), state.hour12)],
      ['Precip today', U.precip(d.precipitation_sum[0], imp)]
    ];

    items.forEach(function (it) {
      var cell = U.make('div', 'detail');
      cell.appendChild(U.make('span', 'detail-label', it[0]));
      cell.appendChild(U.make('span', 'detail-value', it[1]));
      box.appendChild(cell);
    });
  }

  // `tz` is the forecast location's UTC offset in seconds; without it this
  // picks the wrong hour whenever the viewer is in a different timezone.
  function currentHourIndex(h, tz) {
    var now = Date.now();
    for (var i = 0; i < h.time.length; i++) {
      if (U.epochOf(h.time[i], tz || 0) >= now - 1800000) return i;
    }
    return 0;
  }

  /* ── Air quality ────────────────────────────────────────────────────── */

  // US AQI breakpoints, with the EPA's own category names and colours.
  var AQI_BANDS = [
    [50, 'Good', '#00e400'],
    [100, 'Moderate', '#ffff00'],
    [150, 'Unhealthy for sensitive groups', '#ff7e00'],
    [200, 'Unhealthy', '#ff0000'],
    [300, 'Very unhealthy', '#8f3f97'],
    [1000, 'Hazardous', '#7e0023']
  ];

  function aqiBand(v) {
    for (var i = 0; i < AQI_BANDS.length; i++) if (v <= AQI_BANDS[i][0]) return AQI_BANDS[i];
    return AQI_BANDS[AQI_BANDS.length - 1];
  }

  function renderAirQuality(aq) {
    var card = U.el('air-card'), box = U.el('air');
    if (!aq || !aq.current || aq.current.us_aqi === null || aq.current.us_aqi === undefined) {
      card.hidden = true;
      return;
    }
    card.hidden = false;
    U.clear(box);
    var c = aq.current;
    var band = aqiBand(c.us_aqi);

    var head = U.make('div', 'aqi-head');
    var dial = U.make('div', 'aqi-dial', Math.round(c.us_aqi));
    dial.style.borderColor = band[2];
    head.appendChild(dial);
    var lab = U.make('div', 'aqi-labels');
    lab.appendChild(U.make('span', 'aqi-cat', band[1]));
    lab.appendChild(U.make('span', 'muted', 'US AQI'));
    head.appendChild(lab);
    box.appendChild(head);

    var grid = U.make('div', 'aqi-grid');
    [['PM2.5', c.pm2_5, 'µg/m³'], ['PM10', c.pm10, 'µg/m³'],
     ['Ozone', c.ozone, 'µg/m³'], ['NO₂', c.nitrogen_dioxide, 'µg/m³'],
     ['SO₂', c.sulphur_dioxide, 'µg/m³'], ['Dust', c.dust, 'µg/m³']
    ].forEach(function (p) {
      if (p[1] === null || p[1] === undefined) return;
      var cell = U.make('div', 'detail');
      cell.appendChild(U.make('span', 'detail-label', p[0]));
      cell.appendChild(U.make('span', 'detail-value', Math.round(p[1] * 10) / 10));
      cell.appendChild(U.make('span', 'detail-label', p[2]));
      grid.appendChild(cell);
    });
    box.appendChild(grid);
  }

  /* ── Sun & moon (F7: usable light left; casual: sunrise/sunset) ─────── */

  function renderAstro(state) {
    var box = U.el('astro');
    U.clear(box);
    var A = global.Astro;
    var lat = state.location.lat, lon = state.location.lon;
    var now = new Date();
    var t = A.sunTimes(now, lat, lon);
    var remaining = A.daylightRemaining(now, lat, lon);
    var pos = A.sunPosition(now, lat, lon);
    var illum = A.moonIllumination(now);
    var moonPos = A.moonPosition(now, lat, lon);
    var ph = A.phaseName(illum.phase);

    // Astro returns true epochs. They must be rendered on the *forecast
    // location's* clock, not the viewer's device clock, or sunrise for an
    // Oklahoma target reads as 8:49 PM to someone in Tokyo.
    var tz = state.data ? (state.data.utc_offset_seconds || 0) : 0;
    function fmt(d) { return d ? U.fmtEpoch(d.getTime(), tz, state.hour12) : '—'; }

    var items = [
      ['Sunrise', fmt(t.sunrise)],
      ['Sunset', fmt(t.sunset)],
      ['Golden hour', fmt(t.goldenHourStart)],
      ['Civil dusk', fmt(t.dusk)],
      ['Sun altitude', Math.round(pos.altitude) + '° ' + U.compass(pos.azimuth)],
      ['Moon', ph[1] + ' ' + ph[2]],
      ['Moon illum.', Math.round(illum.fraction * 100) + '%'],
      ['Moon altitude', Math.round(moonPos.altitude) + '°']
    ];

    items.forEach(function (it) {
      var cell = U.make('div', 'detail');
      cell.appendChild(U.make('span', 'detail-label', it[0]));
      cell.appendChild(U.make('span', 'detail-value', it[1]));
      box.appendChild(cell);
    });

    // The number a chaser actually wants: how long the storm stays visible.
    var note = U.el('astro-note');
    if (remaining && remaining.isDaylight && remaining.minutesToSunset > 0) {
      var h = Math.floor(remaining.minutesToSunset / 60), m = remaining.minutesToSunset % 60;
      note.textContent = (h ? h + ' hr ' : '') + m + ' min of daylight left' +
        (remaining.minutesToDark !== null
          ? ' · ' + Math.round(remaining.minutesToDark / 60 * 10) / 10 + ' hr until full dark.'
          : '.');
      note.hidden = false;
    } else if (remaining) {
      note.textContent = 'After sunset — storm structure will not be visually resolvable.';
      note.hidden = false;
    } else {
      note.hidden = true;
    }
  }

  /* ── The storm threat banner ───────────────────────────────────────────
   * Above every tab, not only Chase, so it lives here rather than with the
   * cell list — the Chase renderers load on first entry to that tab, and a
   * storm heading for you must not wait for that. */

  function cellHeadline(cell, state) {
    var a = cell.approach;
    var what = cell.tvs ? 'Tornado vortex signature'
      : cell.mesoRank >= 5 ? 'Rotating storm'
      : cell.mesoRank > 0 ? 'Weak rotation'
      : cell.maxSize >= 0.75 ? 'Hail-producing storm'
      : cell.band.label + ' cell';
    var dist = U.distance(a.distance, state.imperial) + ' ' + U.compass(a.bearing);
    var move = a.stationary ? 'nearly stationary'
      : 'moving ' + U.compass(a.towardDeg) + ' at ' +
        (state.imperial ? Math.round(a.speedKmh * 0.621371) + ' mph'
                        : Math.round(a.speedKmh) + ' km/h') +
        // The trained track correction (js/stormmodel.js), named where used.
        (cell.modelMotion ? ', model track' : '');
    var eta = a.etaMin !== null && a.etaMin <= 180
      ? ' · closest approach in ~' + Math.round(a.etaMin) + ' min'
      : '';
    return what + ' ' + dist + ', ' + move + eta;
  }

  // Simple mode gets one sentence, not a table: casual users want to know
  // whether something is about to arrive, not to triage a cell list.
  function renderThreat(state) {
    var box = U.el('threat');
    U.clear(box);
    var cell = state.threat;
    if (!cell) { box.hidden = true; return; }
    box.hidden = false;
    box.className = 'threat threat-' + cell.band.key;

    var a = cell.approach;
    var row = U.make('div', 'threat-row');
    var icon = U.make('span', 'threat-icon', cell.tvs ? '⚠' : cell.mesoRank > 0 ? '🌀' : '⛈');
    row.appendChild(icon);

    var body = U.make('div', 'threat-body');
    var lead = cell.tvs ? 'Tornado vortex signature'
      : cell.mesoRank >= 5 ? 'Rotating storm'
      : cell.mesoRank > 0 ? 'Storm with weak rotation'
      : 'Storm';
    body.appendChild(U.make('p', 'threat-lead',
      lead + ' heading your way — closest approach in about ' +
      Math.round(a.etaMin) + ' minutes.'));
    body.appendChild(U.make('p', 'threat-sub',
      U.distance(a.distance, state.imperial) + ' ' + U.compass(a.bearing) +
      ' of you, tracking ' + U.compass(a.towardDeg) + ' at ' +
      (state.imperial ? Math.round(a.speedKmh * 0.621371) + ' mph'
                      : Math.round(a.speedKmh) + ' km/h') +
      ' · passing within ' + U.distance(a.closest, state.imperial) +
      ' · detected by ' + cell.site + ' radar'));
    row.appendChild(body);

    var btn = U.make('button', 'threat-btn', 'Show on radar');
    btn.addEventListener('click', function () {
      if (state.onFocusCell) state.onFocusCell(cell);
    });
    row.appendChild(btn);
    box.appendChild(row);
  }

  UI.renderAirQuality = renderAirQuality;
  UI.renderThreat = renderThreat;
  UI.cellHeadline = cellHeadline;
  UI.renderAstro = renderAstro;
  UI.aqiBand = aqiBand;
  UI.renderAlerts = renderAlerts;
  UI.renderAlertsFull = renderAlertsFull;
  UI.renderHero = renderHero;
  UI.renderObservation = renderObservation;
  UI.renderNowcast = renderNowcast;
  UI.renderHourly = renderHourly;
  UI.renderInsight = renderInsight;
  UI.renderDaily = renderDaily;
  UI.renderDetails = renderDetails;
  UI.currentHourIndex = currentHourIndex;
})(window);
