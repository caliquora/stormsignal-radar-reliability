/* Vane — map field overlays.
 *
 * Radar shows what is happening. These show what is *driving* it: an animated
 * wind field, a smooth temperature field, and CAPE — the instability a storm
 * feeds on, drawn under the radar so a cell can be read against its fuel —
 * all sampled from a coarse grid of
 * Open-Meteo points across the visible map and interpolated client-side.
 *
 * Open-Meteo has no tile service, so this is built rather than fetched: one
 * multi-coordinate request returns the grid, inverse-distance weighting fills
 * the gaps, and the result is drawn to a canvas over the map. */
(function (global) {
  'use strict';

  var U = global.U;

  var state = {
    active: null,          // 'wind' | 'temp' | 'cape' | null
    grid: [],
    bounds: null,
    bbox: null,            // lat/lon extent the grid actually sampled
    loading: false,
    fetchedAt: 0,
    validAt: null,         // the model time the sampled values are for
    failed: false,         // the last fetch failed (offline, rate-limited)
    source: null,          // CAPE only: 'hrrr' (3 km tiles) or 'grid' (sampled)
    oddsTimes: [],         // Storm Odds: the hours each grid point carries
    oddsIdx: 0,            // ...and the one on screen
    oddsLead: 0            // hours ahead the reader asked for: 0, 3, 6 or 9
  };

  // The fields drawn as a coloured surface from the sampled grid.
  function scalarOnGrid() {
    return state.active === 'temp' || state.active === 'odds' ||
      (state.active === 'cape' && state.source === 'grid');
  }

  /* Open-Meteo's "current" values move every 15 minutes. A field left on
   * screen used to keep its first values until the map was panned out of
   * the sampled box — "CAPE didn't update" — so an active field now
   * re-samples on this cadence while it is visible, and on return to the
   * app if it went stale meanwhile. */
  var REFRESH_MS = 15 * 60 * 1000;
  var listeners = [];
  function onUpdate(fn) { listeners.push(fn); }
  function changed() { listeners.forEach(function (fn) { try { fn(); } catch (e) { /* ignore */ } }); }

  var canvas = null, ctx = null, raf = null, particles = [], map = null;
  // Temperature and CAPE draw BENEATH the radar, so an echo reads against
  // the field it sits in instead of being tinted by it: their canvas lives
  // in a map pane between the base map (200) and the radar (400). The wind
  // particles stay on the top canvas, where motion over everything reads.
  var under = null, uctx = null;
  var field = null;        // offscreen canvas for the temperature field

  /* ── Grid sampling ──────────────────────────────────────────────────── */

  /* 7×6 = 42 points across a local view: enough to see a front or a
   * dryline without a request the API would rightly throttle (Open-Meteo
   * counts every point as a call). Across a regional or national view 42
   * points are hundreds of kilometres apart — measured against a dense
   * 320-point truth over the central US at zoom 4, the 42-point CAPE field
   * put a third of the map in the wrong band (under 100 / to 1000 / to
   * 2500 / above). 10×8 = 80 got 78% right; 154 points only 81%. So
   * regional and national views get 80. A desktop map at the default zoom
   * (about 18° × 8° once padded) keeps 42: doubling every user's calls to
   * fix a view they are not looking at would only bring the rate limit on. */
  var NX = 7, NY = 6, WIDE_NX = 10, WIDE_NY = 8;
  var WIDE_LAT = 12, WIDE_LON = 24;     // a padded view past either is "wide"

  function gridDims(bounds) {
    var sw = bounds.getSouthWest(), ne = bounds.getNorthEast();
    var wide = ne.lat - sw.lat > WIDE_LAT || ne.lng - sw.lng > WIDE_LON;
    return wide ? { nx: WIDE_NX, ny: WIDE_NY } : { nx: NX, ny: NY };
  }

  function gridPoints(bounds) {
    var d = gridDims(bounds), nx = d.nx, ny = d.ny;
    var sw = bounds.getSouthWest(), ne = bounds.getNorthEast();
    var pts = [];
    for (var iy = 0; iy < ny; iy++) {
      for (var ix = 0; ix < nx; ix++) {
        pts.push({
          lat: sw.lat + (ne.lat - sw.lat) * (iy / (ny - 1)),
          lon: sw.lng + (ne.lng - sw.lng) * (ix / (nx - 1))
        });
      }
    }
    return pts;
  }

  /* A sampled field is only real inside the box it was sampled over. IDW
   * happily extrapolates a 42-point grid across the hemisphere — a user
   * zoomed out to continental scale photographed the result: giant blobs
   * of "rain" over oceans the request never asked about. Half a grid cell
   * of margin keeps the drawn edge soft without inventing weather. */
  function gridBBox(g, nx, ny) {
    if (!g.length) return null;
    nx = nx || NX; ny = ny || NY;
    var b = { minLat: 90, maxLat: -90, minLon: 180, maxLon: -180 };
    for (var i = 0; i < g.length; i++) {
      if (g[i].lat < b.minLat) b.minLat = g[i].lat;
      if (g[i].lat > b.maxLat) b.maxLat = g[i].lat;
      if (g[i].lon < b.minLon) b.minLon = g[i].lon;
      if (g[i].lon > b.maxLon) b.maxLon = g[i].lon;
    }
    var mLat = (b.maxLat - b.minLat) / (ny - 1) / 2;
    var mLon = (b.maxLon - b.minLon) / (nx - 1) / 2;
    b.minLat -= mLat; b.maxLat += mLat;
    b.minLon -= mLon; b.maxLon += mLon;
    return b;
  }

  function inBBox(b, lat, lon) {
    return !!b && lat >= b.minLat && lat <= b.maxLat &&
           lon >= b.minLon && lon <= b.maxLon;
  }

  /* One fetch at a time. A pan that lands while a fetch is in flight used
   * to be answered with the grid for the OLD view and then forgotten — so
   * a field could stay stale until the next big pan. Now it is remembered,
   * and the view is re-sampled once the in-flight fetch lands. */
  var inflight = null, again = false, inflightKind = null;

  /* Wind, temperature and the CAPE grid share one fetch; Storm Odds has its
   * own data. A layer switched while the OTHER kind of fetch was out used to
   * be handed that fetch's rows — CAPE drawn from Storm Odds rows, which
   * carry no CAPE: a blank map. Now it waits that fetch out and asks for
   * its own. */
  function dataKind(k) { return k === 'odds' ? 'odds' : 'grid'; }

  function load(bounds) {
    var want = dataKind(state.active);
    if (state.loading) {
      if (inflightKind === want) { again = true; return inflight; }
      return inflight.then(function () {
        return state.active && dataKind(state.active) === want ? load(bounds) : [];
      });
    }
    inflightKind = want;
    state.loading = true;
    state.failed = false;
    // Sample a fifth beyond the view so small pans stay inside the grid
    // instead of triggering a refetch — and so the clipped edge sits
    // offscreen rather than exactly at the viewport border.
    bounds = bounds.pad(0.2);
    var dims = gridDims(bounds);
    var fetchRows = state.active === 'odds' ? loadOdds(gridPoints(bounds)) : global.API.grid(gridPoints(bounds));
    inflight = fetchRows
      .then(function (rows) {
        // The layer changed kind while this was out: these rows are not its.
        if (dataKind(state.active) !== inflightKind) { state.loading = false; return []; }
        state.grid = rows.map(function (r) {
          if (r.odds) return r;
          var uv = U.windToUV(r.speed, r.dir);
          return { lat: r.lat, lon: r.lon, u: uv.u, v: uv.v, temp: r.temp, speed: r.speed,
                   cape: r.cape };
        });
        state.bbox = gridBBox(state.grid, dims.nx, dims.ny);
        // The lattice the points were ASKED for, in order (Open-Meteo answers
        // in request order) — the frame bilinear sampling reads.
        var sw = bounds.getSouthWest(), ne = bounds.getNorthEast();
        state.lattice = state.grid.length === dims.nx * dims.ny
          ? { s: sw.lat, n: ne.lat, w: sw.lng, e: ne.lng, nx: dims.nx, ny: dims.ny } : null;
        state.bounds = bounds;
        state.fetchedAt = Date.now();
        state.validAt = rows.length ? rows[0].validAt : null;
        state.loading = false;
        return state.grid;
      })
      .catch(function () {
        state.loading = false;
        state.failed = true;
        return [];
      })
      .then(function (rows) {
        if (again) {
          again = false;
          if (map && state.active && rows.length && !state.bounds.contains(map.getBounds())) {
            setTimeout(reload, 0);
          }
        }
        return rows;
      });
    return inflight;
  }

  /* Bilinear, between the four lattice points around (lat, lon). The grid
   * is sampled on a regular lattice, so this is the honest interpolation:
   * straight lines between known values. The inverse-distance weighting it
   * replaces (power 4, to stay "local") made a flat plateau around every
   * point with a step between them — a field of blocks and pillars, which a
   * user photographed over Mexico. Accuracy was measured the same both ways;
   * the look was not. Values a point lacks (no CAPE, or Storm Odds outside
   * its trained domain) are left out and the rest re-weighted; where most of
   * the weight is missing, nothing is drawn. */
  function sampleLattice(lat, lon) {
    var L = state.lattice, g = state.grid;
    var fx = (lon - L.w) / (L.e - L.w) * (L.nx - 1), fy = (lat - L.s) / (L.n - L.s) * (L.ny - 1);
    if (!(fx >= 0 && fy >= 0 && fx <= L.nx - 1 && fy <= L.ny - 1)) return null;
    var x0 = Math.min(L.nx - 2, Math.floor(fx)), y0 = Math.min(L.ny - 2, Math.floor(fy));
    var tx = fx - x0, ty = fy - y0, k = state.oddsIdx;
    var corners = [[x0, y0, (1 - tx) * (1 - ty)], [x0 + 1, y0, tx * (1 - ty)],
                   [x0, y0 + 1, (1 - tx) * ty], [x0 + 1, y0 + 1, tx * ty]];
    var su = 0, sv = 0, st = 0, sc = 0, scw = 0, so = 0, sow = 0;
    for (var i = 0; i < 4; i++) {
      var p = g[corners[i][1] * L.nx + corners[i][0]], w = corners[i][2];
      su += p.u * w; sv += p.v * w; st += p.temp * w;
      if (typeof p.cape === 'number') { sc += p.cape * w; scw += w; }
      var o = p.odds ? p.odds[k] : null;
      if (typeof o === 'number') { so += o * w; sow += w; }
    }
    return { u: su, v: sv, temp: st, cape: scw > 0.5 ? sc / scw : null, odds: sow > 0.5 ? so / sow : null };
  }

  function sample(lat, lon) {
    var g = state.grid;
    if (!g.length) return null;
    if (state.lattice) return sampleLattice(lat, lon);
    // No lattice (a short answer): inverse-distance weighting, as before.
    if (!inBBox(state.bbox, lat, lon)) return null;
    var su = 0, sv = 0, st = 0, sw = 0, sc = 0, scw = 0, so = 0, sow = 0, k = state.oddsIdx;
    for (var i = 0; i < g.length; i++) {
      var dx = lon - g[i].lon, dy = lat - g[i].lat;
      var d2 = dx * dx + dy * dy;
      var o = g[i].odds ? g[i].odds[k] : null;
      if (d2 < 1e-8) return { u: g[i].u, v: g[i].v, temp: g[i].temp, cape: g[i].cape, odds: o };
      var w = 1 / (d2 * d2);          // ^-4 keeps the field local rather than mushy
      su += g[i].u * w; sv += g[i].v * w; st += g[i].temp * w; sw += w;
      // A point the model gave no CAPE for is skipped, not counted as zero.
      if (typeof g[i].cape === 'number') { sc += g[i].cape * w; scw += w; }
      if (typeof o === 'number') { so += o * w; sow += w; }
    }
    return { u: su / sw, v: sv / sw, temp: st / sw, cape: scw ? sc / scw : null, odds: sow ? so / sow : null };
  }

  /* ── Canvas plumbing ────────────────────────────────────────────────── */

  function ensureCanvas(m) {
    map = m;
    if (canvas) return;
    canvas = document.createElement('canvas');
    canvas.className = 'map-field';
    m.getContainer().appendChild(canvas);
    ctx = canvas.getContext('2d');
    resize();
    m.on('move zoom resize', onMove);
    m.on('moveend zoomend', onMoveEnd);
  }

  function resize() {
    if (!canvas || !map) return;
    var size = map.getSize();
    var dpr = Math.min(global.devicePixelRatio || 1, 2);
    canvas.width = size.x * dpr;
    canvas.height = size.y * dpr;
    canvas.style.width = size.x + 'px';
    canvas.style.height = size.y + 'px';
    ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
  }

  function ensureUnder() {
    if (under || !map) return;
    var pane = map.getPane('fieldUnder') || map.createPane('fieldUnder');
    pane.style.zIndex = 350;
    pane.style.pointerEvents = 'none';
    under = document.createElement('canvas');
    under.className = 'map-field-under';
    pane.appendChild(under);
    uctx = under.getContext('2d');
  }

  /* The pane moves with the map while it is dragged, so the canvas is
   * pinned back to the container's top-left on every redraw. */
  function placeUnder() {
    var size = map.getSize();
    var dpr = Math.min(global.devicePixelRatio || 1, 2);
    if (under.width !== size.x * dpr || under.height !== size.y * dpr) {
      under.width = size.x * dpr;
      under.height = size.y * dpr;
      under.style.width = size.x + 'px';
      under.style.height = size.y + 'px';
    }
    uctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    global.L.DomUtil.setPosition(under, map.containerPointToLayerPoint([0, 0]));
  }

  // Particles are anchored in pixel space, so any pan or zoom invalidates them.
  function onMove() {
    resize();
    if (state.active === 'wind') seedParticles();
    if (scalarOnGrid()) drawScalarField();
  }

  function onMoveEnd() {
    if (!state.active) return;
    if (state.active === 'cape') {
      // Crossing the edge of HRRR coverage switches source, both ways.
      var c = map.getCenter(), inside = inHrrr(c.lat, c.lng);
      if (state.source === 'hrrr') { if (!inside) showCapeGrid(); return; }
      if (inside && !hrrrResting() && !state.loading) { showCape(); return; }
    }
    var b = map.getBounds();
    // Refetch when the view has moved far enough that the old grid no longer
    // covers it, or when the data is simply old.
    var stale = Date.now() - state.fetchedAt > REFRESH_MS;
    if (stale || !state.bounds || !state.bounds.contains(b)) reload();
  }

  function reload() {
    if (!map || !state.active) return Promise.resolve(false);
    return load(map.getBounds()).then(function (rows) {
      if (!state.active) return false;
      if (rows.length) {
        if (scalarOnGrid()) drawScalarField();
        if (state.active === 'wind') seedParticles();
      }
      changed();
      return !!rows.length;
    });
  }

  /* Re-sample if the field on screen is older than REFRESH_MS — or if the
   * last fetch failed and left the view uncovered. A pan whose fetch failed
   * (a dropped signal, a busy API) used to keep the old grid, which only
   * covers where the map WAS: the new view went blank with no word why,
   * and stayed blank until the next pan or fifteen minutes. Called on a
   * one-minute timer and when the app comes back into view, so a failure
   * is retried a minute later, not hammered. */
  function needsRefresh(now) {
    if ((now || Date.now()) - state.fetchedAt >= REFRESH_MS) return true;
    return state.failed && !!map && (!state.bounds || !state.bounds.contains(map.getBounds()));
  }

  function refreshIfStale(now) {
    if (!state.active || state.loading) return Promise.resolve(false);
    if (state.active === 'cape' && state.source === 'hrrr') {
      // A new hour, or a newer run published, every quarter hour checked.
      now = now || Date.now();
      if (validHour(now) === hrrr.validAt && now - hrrr.checkedAt < REFRESH_MS) return Promise.resolve(false);
      var t = ++hrrr.token;
      return findRun(hrrr.kind, now).then(function (r) {
        if (t !== hrrr.token || state.active !== 'cape') return false;
        hrrr.checkedAt = Date.now();
        if (r.run === hrrr.run && r.validAt === hrrr.validAt) return false;
        mountHrrr(r); changed(); return true;
      }, function () { hrrr.checkedAt = Date.now(); return false; });
    }
    // On the fallback grid inside coverage: once the rest is over, try HRRR again.
    if (state.active === 'cape' && state.source === 'grid' && map && !hrrrResting(now) &&
        inHrrr(map.getCenter().lat, map.getCenter().lng)) {
      return showCape();
    }
    if (!needsRefresh(now)) return Promise.resolve(false);
    return reload();
  }

  // The view on screen lies (partly) outside the grid the field was drawn from.
  function uncovered() {
    return !!map && !!state.bounds && !state.bounds.contains(map.getBounds());
  }

  if (typeof setInterval === 'function') {
    setInterval(function () {
      if (typeof document === 'undefined' || !document.hidden) refreshIfStale();
    }, 60 * 1000);
  }
  if (typeof document !== 'undefined' && document.addEventListener) {
    document.addEventListener('visibilitychange', function () {
      if (!document.hidden) refreshIfStale();
    });
  }

  /* The sampled field's extreme inside the visible map, for the legend:
   * a blank CAPE layer over stable air must say that is what it is. */
  function maxInView(key) {
    if (!map || !state.grid.length) return null;
    if (key === 'cape' && state.source !== 'grid') return null;   // tiles carry no values
    var b = map.getBounds(), best = null;
    state.grid.forEach(function (p) {
      // Storm Odds carries an hour series; read the hour on screen.
      var v = key === 'odds' ? (p.odds ? p.odds[state.oddsIdx] : null) : p[key];
      if (typeof v !== 'number' || !b.contains([p.lat, p.lon])) return;
      if (best === null || v > best) best = v;
    });
    return best;
  }

  /* ── Wind particles ─────────────────────────────────────────────────── */

  var COUNT = 900;

  function seedParticles() {
    if (!map) return;
    var size = map.getSize();
    particles = [];
    for (var i = 0; i < COUNT; i++) {
      particles.push(newParticle(size));
    }
  }

  function newParticle(size) {
    return {
      x: Math.random() * size.x,
      y: Math.random() * size.y,
      age: Math.random() * 90
    };
  }

  function windStep(dt) {
    var size = map.getSize();
    // Scale pixel movement by zoom so the field looks equally fast at any scale.
    var scale = Math.pow(2, map.getZoom()) * 0.00042;

    ctx.globalCompositeOperation = 'destination-in';
    ctx.fillStyle = 'rgba(0,0,0,0.90)';       // trail fade
    ctx.fillRect(0, 0, size.x, size.y);
    ctx.globalCompositeOperation = 'source-over';

    ctx.lineWidth = 1.15;
    ctx.lineCap = 'round';

    for (var i = 0; i < particles.length; i++) {
      var p = particles[i];
      var ll = map.containerPointToLatLng([p.x, p.y]);
      var s = sample(ll.lat, ll.lng);
      if (!s) continue;

      var nx = p.x + s.u * scale * dt * 60;
      var ny = p.y - s.v * scale * dt * 60;    // screen y is inverted vs north

      var speed = Math.sqrt(s.u * s.u + s.v * s.v);
      ctx.strokeStyle = windColor(speed);
      ctx.beginPath();
      ctx.moveTo(p.x, p.y);
      ctx.lineTo(nx, ny);
      ctx.stroke();

      p.x = nx; p.y = ny;
      p.age -= dt * 60;

      if (p.age <= 0 || p.x < 0 || p.y < 0 || p.x > size.x || p.y > size.y) {
        particles[i] = newParticle(size);
      }
    }
  }

  function windColor(ms) {
    // Calm → white, gale → warm. Deliberately low-alpha so radar stays readable
    // underneath when both layers are on.
    if (ms < 3) return 'rgba(255,255,255,0.34)';
    if (ms < 7) return 'rgba(180,230,255,0.44)';
    if (ms < 12) return 'rgba(120,220,200,0.52)';
    if (ms < 18) return 'rgba(255,214,10,0.58)';
    if (ms < 25) return 'rgba(255,159,10,0.62)';
    return 'rgba(255,55,95,0.70)';
  }

  var lastT = 0;
  function frame(now) {
    raf = requestAnimationFrame(frame);
    if (document.hidden || !map) return;
    var dt = Math.min((now - lastT) / 1000, 0.05);
    lastT = now;
    if (state.active === 'wind') windStep(dt);
  }

  /* ── Temperature field ──────────────────────────────────────────────── */

  // Standard meteorological ramp, °C.
  var TEMP_STOPS = [
    [-30, [90, 40, 140]], [-20, [70, 70, 190]], [-10, [60, 130, 220]],
    [0, [90, 200, 230]], [8, [80, 200, 140]], [16, [200, 220, 90]],
    [24, [250, 190, 60]], [32, [245, 120, 50]], [40, [225, 50, 60]],
    [48, [160, 30, 90]]
  ];

  function tempColor(t) {
    if (t <= TEMP_STOPS[0][0]) return TEMP_STOPS[0][1];
    for (var i = 0; i < TEMP_STOPS.length - 1; i++) {
      var a = TEMP_STOPS[i], b = TEMP_STOPS[i + 1];
      if (t >= a[0] && t <= b[0]) {
        var f = (t - a[0]) / (b[0] - a[0]);
        return [
          Math.round(U.lerp(a[1][0], b[1][0], f)),
          Math.round(U.lerp(a[1][1], b[1][1], f)),
          Math.round(U.lerp(a[1][2], b[1][2], f))
        ];
      }
    }
    return TEMP_STOPS[TEMP_STOPS.length - 1][1];
  }

  /* CAPE, J/kg. Below 100 the field is left clear: there is no fuel to
   * show, and painting the whole stable map pale would read as a hazard.
   * The breaks are the conventional ones forecasters talk in — marginal,
   * moderate (1000), strong (2500), extreme (4000). */
  var CAPE_STOPS = [
    [100, [120, 200, 120]], [500, [190, 225, 90]], [1000, [250, 215, 60]],
    [1750, [250, 150, 50]], [2500, [230, 70, 50]], [3250, [200, 40, 120]],
    [4000, [150, 50, 170]], [5000, [110, 40, 150]]
  ];
  var CAPE_MIN = 100;

  /* The field fades in from 50 to 150 J/kg instead of switching on at 100.
   * A hard cut, drawn on the coarse field canvas and scaled up, painted the
   * edge of every unstable patch as a staircase of blocks; a ramp draws it
   * as the gradient it is. Below 50 stays clear. */
  var CAPE_FADE = [50, 150];

  function capeAlpha(v) {
    if (v === null || v === undefined || !(v > CAPE_FADE[0])) return 0;
    return Math.min(1, (v - CAPE_FADE[0]) / (CAPE_FADE[1] - CAPE_FADE[0]));
  }

  function capeColor(v) {
    if (v === null || v === undefined || v < CAPE_MIN) return null;
    for (var i = 0; i < CAPE_STOPS.length - 1; i++) {
      var a = CAPE_STOPS[i], b = CAPE_STOPS[i + 1];
      if (v >= a[0] && v <= b[0]) {
        var f = (v - a[0]) / (b[0] - a[0]);
        return [
          Math.round(U.lerp(a[1][0], b[1][0], f)),
          Math.round(U.lerp(a[1][1], b[1][1], f)),
          Math.round(U.lerp(a[1][2], b[1][2], f))
        ];
      }
    }
    return CAPE_STOPS[CAPE_STOPS.length - 1][1];
  }

  /* ── Storm Odds (js/stormodds.js): Vane's own model, as a field ──────
   * The chance of a severe report within 40 km in three hours. Under half
   * a percent stays clear — the odds of the quiet majority of the map —
   * fading in to full at 1%; the breaks are the ones the card talks in. */
  // Tops out at 20%: after calibration the model never claims more (its
  // top pooled band verified at about 12% on unseen days).
  var ODDS_STOPS = [
    [0.005, [140, 200, 140]], [0.01, [90, 180, 90]], [0.02, [200, 210, 70]], [0.05, [250, 190, 50]],
    [0.10, [245, 120, 40]], [0.15, [225, 45, 55]], [0.20, [190, 40, 150]]
  ];

  function oddsColor(p) {
    if (p === null || p === undefined || !(p >= ODDS_STOPS[0][0])) return null;
    for (var i = 0; i < ODDS_STOPS.length - 1; i++) {
      var a = ODDS_STOPS[i], b = ODDS_STOPS[i + 1];
      if (p <= b[0]) {
        var f = (p - a[0]) / (b[0] - a[0]);
        return [0, 1, 2].map(function (c) { return Math.round(U.lerp(a[1][c], b[1][c], f)); });
      }
    }
    return ODDS_STOPS[ODDS_STOPS.length - 1][1];
  }

  function oddsAlpha(p) {
    if (!(p > 0.003)) return 0;
    return Math.min(1, (p - 0.003) / 0.007);
  }

  /* The model, run on every grid point for the next ten hours. A point the
   * forecast could not fill is left out rather than counted as zero. */
  function loadOdds(points) {
    // The domain mask first: no mask, no field — never an unmasked one.
    var mask = null;
    return global.PopGrid.load().then(function (g) {
      mask = g;
      return global.API.stormEnv(points, 10);
    }).then(function (rows) {
      var times = rows.length && rows[0].hourly ? rows[0].hourly.time.map(function (t) { return Date.parse(t + 'Z'); }) : [];
      state.oddsTimes = times;
      // The hour on screen follows the clock: re-pick "now" on every load.
      var lead = state.oddsLead || 0, want = Date.now() + lead * 3600000, best = 0;
      times.forEach(function (t, i) { if (Math.abs(t - want) < Math.abs(times[best] - want)) best = i; });
      state.oddsIdx = best;
      /* Every row is kept, in order — the lattice needs them all. Points
       * outside the US carry no odds: the model learned US weather against
       * US storm reports, and has no business painting Mexico or the sea. */
      var outside = 0;
      var out = rows.map(function (r, i) {
        var at = points[i] || r;
        if (!global.PopGrid.inUS(mask, at.lat, at.lon)) {
          outside++;
          return { lat: r.lat, lon: r.lon, u: 0, v: 0, temp: 0, cape: null, odds: times.map(function () { return null; }) };
        }
        var ser = global.StormOdds.series(r.hourly, r.lon), byAt = {};
        ser.forEach(function (x) { byAt[x.at] = x.p; });
        return { lat: r.lat, lon: r.lon, u: 0, v: 0, temp: 0, cape: null,
                 odds: times.map(function (t) { return byAt[t] === undefined ? null : byAt[t]; }) };
      });
      state.oddsOutside = outside;
      return out;
    });
  }

  // Hours ahead on screen: 0 (now), 3, 6 or 9.
  function setOddsLead(h) {
    state.oddsLead = h;
    var want = Date.now() + h * 3600000, best = 0, times = state.oddsTimes;
    times.forEach(function (t, i) { if (Math.abs(t - want) < Math.abs(times[best] - want)) best = i; });
    state.oddsIdx = best;
    if (state.active === 'odds') drawScalarField();
    changed();
  }

  // Rendered small then scaled up, which is both fast and gives free smoothing.
  function drawScalarField() {
    var cape = state.active === 'cape', oddsK = state.active === 'odds';
    if (!map || !state.grid.length) return;
    var size = map.getSize();
    // A map not yet laid out (its tab only just shown) is 0 px wide: the
    // field would be NaN rows tall and drawing throws. Leaflet fires
    // 'resize' once it has a size, and onMove redraws then.
    if (!size.x || !size.y) return;
    ensureUnder();
    placeUnder();
    var FW = 64, FH = Math.max(8, Math.round(64 * size.y / size.x));

    if (!field) field = document.createElement('canvas');
    field.width = FW; field.height = FH;
    var fctx = field.getContext('2d');
    var img = fctx.createImageData(FW, FH);

    for (var yy = 0; yy < FH; yy++) {
      for (var xx = 0; xx < FW; xx++) {
        var cx = (xx + 0.5) / FW * size.x;
        var cy = (yy + 0.5) / FH * size.y;
        var ll = map.containerPointToLatLng([cx, cy]);
        var s = sample(ll.lat, ll.lng);
        var o = (yy * FW + xx) * 4;
        var a = !s ? 0 : cape ? capeAlpha(s.cape) : oddsK ? oddsAlpha(s.odds) : 1;
        var c = !a ? null : cape ? capeColor(Math.max(CAPE_MIN, s.cape))
          : oddsK ? oddsColor(Math.max(ODDS_STOPS[0][0], s.odds)) : tempColor(s.temp);
        if (!c) { img.data[o + 3] = 0; continue; }
        img.data[o] = c[0]; img.data[o + 1] = c[1]; img.data[o + 2] = c[2];
        img.data[o + 3] = Math.round((cape || oddsK ? 140 : 150) * a);
      }
    }
    fctx.putImageData(img, 0, 0);

    uctx.clearRect(0, 0, size.x, size.y);
    uctx.imageSmoothingEnabled = true;
    uctx.imageSmoothingQuality = 'high';
    uctx.drawImage(field, 0, 0, size.x, size.y);
  }


  /* ── CAPE at 3 km: HRRR tiles over the US ───────────────────────────
   * The sampled grid can never look like a CAPE map: 42–80 points, each
   * hundreds of kilometres from the next at regional zoom, against the
   * 3 km fields chasers read on SPC's mesoanalysis. Over the US the layer
   * now shows the HRRR's own field, rendered by Unidata's public THREDDS
   * server — and in all three parcels a chaser asks for. The sampled grid
   * stays as the fallback outside HRRR coverage or when THREDDS is down,
   * and the legend says which is on screen. */
  var C = global.VaneConfig;
  var HOUR = 3600000;
  var CAPE_KINDS = {
    sb: { label: 'Surface', layer: 'Convective_available_potential_energy_surface', elevation: null,
          help: 'A parcel lifted from the ground: what a storm rooted at the surface can use.' },
    ml: { label: 'Mixed-layer', layer: 'Convective_available_potential_energy_pressure_difference_layer', elevation: 4500,
          help: 'The lowest 90 hPa mixed together: SPC’s go-to for surface-based severe storms.' },
    // 255–0 hPa above ground, centred at 127.5 hPa: the most unstable parcel.
    mu: { label: 'Most unstable', layer: 'Convective_available_potential_energy_pressure_difference_layer', elevation: 12750,
          help: 'The most unstable parcel in the lowest 255 hPa: it shows the elevated instability ' +
                'that feeds storms at night above a cool, stable surface — where the other two read zero.' }
  };
  var CAPE_ORDER = ['sb', 'ml', 'mu'];
  var CAPE_RANGE = [100, 4000];
  var CAPE_PALETTE = 'div-Spectral-inv';
  // The server's palette (ColorBrewer Spectral, reversed), for the legend.
  var CAPE_SPECTRAL = ['#5e4fa2', '#3288bd', '#66c2a5', '#abdda4', '#e6f598', '#ffffbf',
                       '#fee08b', '#fdae61', '#f46d43', '#d53e4f', '#9e0142'];
  var RUN_LOOKBACK = 6;           // THREDDS publishes a run ~2¼ h after its start
  var HRRR_RETRY_MS = 10 * 60 * 1000;

  var hrrr = { kind: 'ml', run: null, validAt: null, layer: null,
               down: false, checkedAt: 0, token: 0 };

  function inHrrr(lat, lon) { return lat >= 21.5 && lat <= 52.5 && lon >= -130 && lon <= -61; }

  function runName(ms) {
    var d = new Date(ms), p = function (n) { return (n < 10 ? '0' : '') + n; };
    return d.getUTCFullYear() + p(d.getUTCMonth() + 1) + p(d.getUTCDate()) + '_' + p(d.getUTCHours()) + '00';
  }

  // HRRR output is hourly: the hour nearest now.
  function validHour(now) { return Math.round(now / HOUR) * HOUR; }

  function capeWmsUrl(run) { return C.HRRR_CAPE_WMS.replace('{run}', run); }

  function capeWmsParams(kind, validAt) {
    var k = CAPE_KINDS[kind] || CAPE_KINDS.ml;
    var p = {
      layers: k.layer, styles: 'raster/' + CAPE_PALETTE, format: 'image/png', transparent: true,
      version: '1.3.0', time: new Date(validAt).toISOString(),
      colorscalerange: CAPE_RANGE.join(','), belowmincolor: 'transparent', abovemaxcolor: 'extend',
      numcolorbands: 40
    };
    if (k.elevation !== null) p.elevation = k.elevation;
    return p;
  }

  /* A run is usable when THREDDS will draw the hour we want from it. The
   * catalog that lists runs has no CORS header, but an image needs none:
   * ask each recent run for an 8-pixel map and take the first that comes
   * back as one. A run not yet published answers with an error page. */
  function probeUrl(run, kind, validAt) {
    var p = capeWmsParams(kind, validAt), q = [];
    p.request = 'GetMap'; p.service = 'WMS'; p.crs = 'EPSG:3857';
    p.bbox = '-10900000,4100000,-10800000,4200000'; p.width = 8; p.height = 8;
    Object.keys(p).forEach(function (k) { q.push(k + '=' + encodeURIComponent(p[k])); });
    return capeWmsUrl(run) + '?' + q.join('&');
  }

  function probe(url) {
    return new Promise(function (resolve, reject) {
      var img = new Image(), done = false;
      var t = setTimeout(function () { if (!done) { done = true; reject(new Error('timeout')); } }, 12000);
      img.onload = function () { if (!done) { done = true; clearTimeout(t); resolve(); } };
      img.onerror = function () { if (!done) { done = true; clearTimeout(t); reject(new Error('no image')); } };
      img.src = url;
    });
  }

  function findRun(kind, now) {
    var valid = validHour(now), base = Math.floor(now / HOUR) * HOUR, k = 1;
    function next() {
      if (k > RUN_LOOKBACK) return Promise.reject(new Error('no HRRR run'));
      var run = runName(base - k++ * HOUR);
      return probe(probeUrl(run, kind, valid)).then(function () {
        return { run: run, validAt: valid };
      }, next);
    }
    return next();
  }

  /* Swap in a new HRRR layer without blanking the old one: the new one
   * loads unseen and replaces it on 'load', as the forecast radar does. */
  function mountHrrr(r) {
    ensureUnder();
    if (under) uctx.clearRect(0, 0, under.width, under.height);
    var old = hrrr.layer;
    var layer = global.L.tileLayer.wms(capeWmsUrl(r.run), global.L.extend(capeWmsParams(hrrr.kind, r.validAt), {
      pane: 'fieldUnder', opacity: old ? 0 : 0.62, maxNativeZoom: 10, className: 'hrrr-cape',
      attribution: 'CAPE: NOAA HRRR via <a href="https://www.unidata.ucar.edu/software/tds/">Unidata THREDDS</a>'
    }));
    hrrr.layer = layer;
    if (old) {
      layer.once('load', function () {
        if (hrrr.layer !== layer) return;
        layer.setOpacity(0.62);
        if (map && map.hasLayer(old)) map.removeLayer(old);
      });
    }
    layer.addTo(map);
    hrrr.run = r.run; hrrr.validAt = r.validAt; hrrr.checkedAt = Date.now(); hrrr.down = false;
    state.source = 'hrrr';
    state.validAt = r.validAt;
    state.fetchedAt = Date.now();
    state.failed = false;
  }

  function unmountHrrr() {
    hrrr.token++;
    if (hrrr.layer && map && map.hasLayer(hrrr.layer)) map.removeLayer(hrrr.layer);
    hrrr.layer = null;
  }

  function hrrrResting(now) { return hrrr.down && (now || Date.now()) - hrrr.checkedAt < HRRR_RETRY_MS; }

  /* → Promise: true once the HRRR field is on screen, false if THREDDS
   * could not serve it, SUPERSEDED if a newer attempt took over meanwhile.
   * The distinction matters: every zoom fires moveend AND zoomend, so two
   * attempts race on every zoom back into coverage — and treating the
   * superseded one as a failure fell back to the grid, cancelling the
   * attempt that was about to succeed. */
  var SUPERSEDED = 'superseded';

  function showHrrr() {
    var t = ++hrrr.token;
    return findRun(hrrr.kind, Date.now()).then(function (r) {
      if (t !== hrrr.token || state.active !== 'cape') return SUPERSEDED;
      mountHrrr(r);
      changed();
      return true;
    }, function () {
      if (t !== hrrr.token) return SUPERSEDED;
      hrrr.down = true; hrrr.checkedAt = Date.now();
      return false;
    });
  }

  /* The sampled grid, for CAPE outside HRRR coverage or with THREDDS down. */
  function showCapeGrid() {
    unmountHrrr();
    state.source = 'grid';
    return load(map.getBounds()).then(function (rows) {
      if (!rows.length || state.active !== 'cape') return false;
      if (under) under.style.display = '';
      drawScalarField();
      changed();
      return true;
    });
  }

  function showCape(force) {
    var c = map.getCenter();
    if (inHrrr(c.lat, c.lng) && (force || !hrrrResting())) {
      return showHrrr().then(function (ok) {
        // Superseded: the newer attempt owns the outcome; the layer stays on.
        return ok === SUPERSEDED ? true : ok || showCapeGrid();
      });
    }
    return showCapeGrid();
  }

  // The parcel shown. Over the grid the choice waits for HRRR coverage.
  function setCapeKind(kind) {
    if (!CAPE_KINDS[kind] || kind === hrrr.kind) return Promise.resolve(false);
    hrrr.kind = kind;
    if (state.active !== 'cape' || state.source !== 'hrrr' || !hrrr.run) { changed(); return Promise.resolve(false); }
    mountHrrr({ run: hrrr.run, validAt: hrrr.validAt });
    changed();
    return Promise.resolve(true);
  }

  function capeInfo() {
    return { source: state.source, kind: hrrr.kind, run: hrrr.run, validAt: hrrr.validAt,
             down: hrrr.down, inCoverage: !!map && inHrrr(map.getCenter().lat, map.getCenter().lng) };
  }

  /* ── Public control ─────────────────────────────────────────────────── */

  var showToken = 0;
  function show(kind, m, opts) {
    if (!m) return Promise.resolve(false);
    ensureCanvas(m);
    state.active = kind;
    canvas.style.display = kind === 'wind' ? '' : 'none';
    if (under) under.style.display = kind === 'wind' ? 'none' : '';
    canvas.classList.toggle('map-field-wind', kind === 'wind');
    if (opts && CAPE_KINDS[opts.capeKind]) hrrr.kind = opts.capeKind;
    if (kind !== 'cape') { unmountHrrr(); state.source = null; }
    else {
      stopAnim();
      if (under) uctx.clearRect(0, 0, under.width, under.height);
      // Asked for by hand: try HRRR afresh even if it was down a minute ago.
      var mineC = ++showToken;
      return showCape(true).then(function (ok) {
        if (mineC !== showToken || state.active !== 'cape') return state.active === 'cape';
        if (!ok) hide();
        return ok;
      });
    }

    var mine = ++showToken;
    return load(m.getBounds()).then(function (rows) {
      // Another show() since: it owns the outcome — never hide its layer.
      if (mine !== showToken || state.active !== kind) return state.active === kind;
      if (!rows.length) { hide(); return false; }
      if (kind === 'wind') {
        if (opts && opts.reduceMotion) {
          // Without motion, draw a static barb-free streamline snapshot instead.
          seedParticles();
          ctx.clearRect(0, 0, m.getSize().x, m.getSize().y);
          windStep(0.5);
          return true;
        }
        seedParticles();
        if (!raf) { lastT = performance.now(); raf = requestAnimationFrame(frame); }
      } else {
        stopAnim();
        drawScalarField();
        under.style.display = '';
      }
      return true;
    });
  }

  function stopAnim() {
    if (raf) { cancelAnimationFrame(raf); raf = null; }
  }

  function hide() {
    state.active = null;
    state.source = null;
    unmountHrrr();
    stopAnim();
    if (ctx && map) {
      var s = map.getSize();
      ctx.clearRect(0, 0, s.x, s.y);
      if (uctx) uctx.clearRect(0, 0, s.x, s.y);
    }
    if (canvas) canvas.style.display = 'none';
    if (under) under.style.display = 'none';
  }

  function toggle(kind, m, opts) {
    if (state.active === kind) { hide(); return Promise.resolve(false); }
    return show(kind, m, opts);
  }

  function active() { return state.active; }

  global.Layers = {
    show: show, hide: hide, toggle: toggle, active: active,
    tempColor: tempColor, windColor: windColor, capeColor: capeColor, capeAlpha: capeAlpha,
    sample: sample, gridDims: gridDims, CAPE_FADE: CAPE_FADE, sampleLattice: sampleLattice,
    oddsColor: oddsColor, oddsAlpha: oddsAlpha, ODDS_STOPS: ODDS_STOPS, setOddsLead: setOddsLead,
    setCapeKind: setCapeKind, capeInfo: capeInfo, CAPE_KINDS: CAPE_KINDS, CAPE_ORDER: CAPE_ORDER,
    CAPE_RANGE: CAPE_RANGE, CAPE_SPECTRAL: CAPE_SPECTRAL,
    hrrr: { inCoverage: inHrrr, runName: runName, validHour: validHour, params: capeWmsParams,
            url: capeWmsUrl, probeUrl: probeUrl },
    onUpdate: onUpdate, refreshIfStale: refreshIfStale, uncovered: uncovered, maxInView: maxInView, REFRESH_MS: REFRESH_MS,
    CAPE_STOPS: CAPE_STOPS, CAPE_MIN: CAPE_MIN,
    state: state
  };
})(window);
