/* Vane — VaneMotion: learning how the sky is moving, on the device.
 *
 * Every radar app shows the last hour as an animation and leaves the reader
 * to eyeball where the echoes are headed. Vane fits the motion instead. The
 * browser samples the national mosaic around the pin at six times over the
 * last fifty minutes — the same CORS-open Iowa State tiles the map draws and
 * the same pixel-exact dBZ inversion the 3D view uses — and then LEARNS a
 * motion model from those observations: an integer block-match finds the
 * displacement between each consecutive pair of fields, and a least-squares
 * fit through those displacements gives one velocity with a residual that
 * says how much to trust it. From the velocity and the latest field it
 * answers the question the animation only gestures at: when does that echo
 * reach me.
 *
 * Outside the US, where there is no NEXRAD, the same fit runs on RainViewer's
 * global composite (learn({ frames })): its tiles decode exactly through its
 * published palette, and its ten-minute frames carry their real times.
 *
 * All of it runs client-side. No server, no key, no third-party model —
 * the training data is the last hour of radar over your own head, and the
 * fit is re-learned every scan cycle. The UI labels it exactly that way.
 *
 * HONESTY RULES. A flat correlation surface (uniform rain, or almost no
 * echo) is reported as no verdict, never as "stationary". A fit whose pairs
 * disagree with each other beyond the residual gate is discarded, not
 * averaged into confidence. And the search is bounded at 120 km/h — faster
 * than any real echo motion — so a bogus match cannot invent a sprinting
 * storm.
 */
(function (global) {
  'use strict';

  var C = global.VaneConfig;
  var U = global.U;

  // Minutes ago for each sampled field, oldest first. IEM publishes the
  // composite plus rolling 5-minute archives; 10-minute spacing keeps the
  // per-pair search box small while still spanning most of the hour.
  var OFFSETS = [50, 40, 30, 20, 10, 0];

  var GRID = 48;             // sample lattice per field
  var HALF_KM = 56;          // ~112 km box: room to see an hour of travel
  var ZOOM = 7;
  var W_FLOOR = 15;          // dBZ below the trace band carries no weight
  var W_CAP = 30;            // a hail core must not outvote the whole field
  var MAX_KMH = 120;         // physical cap on echo motion for the search
  var MIN_CELLS = 6;         // fewer echo cells than this is not a field
  var PEAK_RATIO = 1.4;      // best/mean correlation below this is ambiguous
  var MIN_PAIRS = 3;
  var STATIONARY_KMH = 6;
  var ETA_MAX_MIN = 75;
  var RESID_MAX_KMH = 25;

  function productFor(minAgo) {
    return minAgo === 0
      ? 'nexrad-n0q-900913'
      : 'nexrad-n0q-m' + (minAgo < 10 ? '0' + minAgo : minAgo) + 'm';
  }

  /* dBZ grid → flat weight field. Weight rises with intensity above the
   * trace floor and is capped, so the match tracks the shape of the echo
   * rather than its single brightest pixel. */
  function weights(grid, n) {
    var w = new Float32Array(n * n), cells = 0;
    for (var j = 0; j < n; j++) {
      for (var i = 0; i < n; i++) {
        var d = grid[j][i];
        if (d !== null && d >= W_FLOOR) {
          w[j * n + i] = Math.min(W_CAP, d - W_FLOOR + 1);
          cells++;
        }
      }
    }
    return { w: w, cells: cells };
  }

  /* The displacement taking field a onto field b: the integer (dx, dy), in
   * grid cells, that maximises the cross-correlation of the two weight
   * fields. dx is east, dy is south (row 0 is the north edge).
   *
   * Returns null when the surface has no real peak — a uniform field scores
   * nearly the same everywhere (the small zero-shift bias is pure window
   * overlap), and calling that "stationary" would be learning from nothing. */
  function bestShift(a, b, n, maxShift) {
    var best = -Infinity, bx = 0, by = 0, sum = 0, count = 0;
    for (var dy = -maxShift; dy <= maxShift; dy++) {
      for (var dx = -maxShift; dx <= maxShift; dx++) {
        var s = 0;
        var j0 = Math.max(0, -dy), j1 = Math.min(n, n - dy);
        var i0 = Math.max(0, -dx), i1 = Math.min(n, n - dx);
        for (var j = j0; j < j1; j++) {
          var ra = j * n, rb = (j + dy) * n + dx;
          for (var i = i0; i < i1; i++) {
            var av = a[ra + i];
            if (av) s += av * b[rb + i];
          }
        }
        sum += s; count++;
        if (s > best) { best = s; bx = dx; by = dy; }
      }
    }
    if (best <= 0) return null;
    var mean = sum / count;
    if (best < PEAK_RATIO * mean) return null;
    return { dx: bx, dy: by, score: best, ratio: best / mean };
  }

  /* Least-squares fit of one straight-line velocity through the observed
   * pair displacements (constrained through the origin: zero time means
   * zero displacement). The residual is the RMS disagreement of the
   * per-pair velocities with the fit, in km/h — the fit's own report of
   * how believable it is. */
  function fitVelocity(pairs) {
    if (!pairs.length) return null;
    var nx = 0, ny = 0, den = 0, k, t;
    for (k = 0; k < pairs.length; k++) {
      t = pairs[k].dtMin / 60;
      nx += pairs[k].eastKm * t;
      ny += pairs[k].northKm * t;
      den += t * t;
    }
    if (!den) return null;
    var vx = nx / den, vy = ny / den, r2 = 0;
    for (k = 0; k < pairs.length; k++) {
      t = pairs[k].dtMin / 60;
      var ex = pairs[k].eastKm / t - vx, ey = pairs[k].northKm / t - vy;
      r2 += ex * ex + ey * ey;
    }
    return {
      east: vx, north: vy,
      speed: Math.sqrt(vx * vx + vy * vy),
      residualKmh: Math.sqrt(r2 / pairs.length)
    };
  }

  /* Given the latest field and the fitted velocity, find the nearest rain
   * (at or above the same dBZ floor the nowcast calls rain) whose track
   * actually passes over the pin, and when it gets here. The corridor
   * widens with distance because the fit's direction error does too. */
  function eta(field, vec) {
    if (!vec || vec.speed < STATIONARY_KMH) return null;
    var n = field.size, cell = field.kmPerCell, c = (n - 1) / 2;
    var ux = vec.east / vec.speed, uy = vec.north / vec.speed;
    var best = null;
    for (var j = 0; j < n; j++) {
      for (var i = 0; i < n; i++) {
        var d = field.grid[j][i];
        if (d === null || d < C.OBSERVED.RADAR_RAIN_DBZ) continue;
        var east = (i - c) * cell, north = (c - j) * cell;
        var along = -(east * ux + north * uy);   // km upstream of the pin
        if (along < 1.5) continue;               // overhead or already past
        var cross = Math.abs(east * uy - north * ux);
        if (cross > 4 + 0.2 * along) continue;   // track misses the pin
        var minutes = along / vec.speed * 60;
        if (minutes > ETA_MAX_MIN) continue;
        if (!best || minutes < best.minutes) {
          best = {
            minutes: Math.round(minutes),
            distanceKm: Math.round(Math.sqrt(east * east + north * north)),
            dbz: d,
            dir: U.compass(Math.atan2(east, north) * 180 / Math.PI)
          };
        }
      }
    }
    return best;
  }

  /* Sampled fields → verdict. Split out from learn() so the whole decision
   * path is testable without a network or a canvas.
   *
   * opts.times — each field's valid time in ms, oldest first. Without it the
   * fields are taken to be IEM's fixed OFFSETS, ending now. With it, every
   * pair's interval is the real one (RainViewer's frames are ten minutes
   * apart, and a skipped frame makes one pair twenty), and the arrival time
   * is counted from now, not from the frame: rain the latest frame put 25
   * minutes out, in a frame 8 minutes old, is 17 minutes out. */
  function fromFields(fields, opts) {
    opts = opts || {};
    var latest = fields[fields.length - 1];
    if (!latest || !latest.grid) return null;
    var n = latest.size, cellKm = latest.kmPerCell;
    var now = opts.now || Date.now();
    var times = opts.times || OFFSETS.map(function (m) { return now - m * 60000; });
    var ageMin = Math.max(0, (now - times[times.length - 1]) / 60000);

    var ws = fields.map(function (f) {
      return f && f.grid ? weights(f.grid, n) : null;
    });

    // Consecutive pairs only: each search stays small, and every pair is an
    // independent observation for the fit to agree or disagree on.
    var pairs = [];
    for (var k = 1; k < fields.length; k++) {
      var a = ws[k - 1], b = ws[k];
      if (!a || !b || a.cells < MIN_CELLS || b.cells < MIN_CELLS) continue;
      var dtMin = (times[k] - times[k - 1]) / 60000;
      if (!(dtMin > 0)) continue;
      var maxShift = Math.ceil(MAX_KMH * (dtMin / 60) / cellKm);
      var s = bestShift(a.w, b.w, n, maxShift);
      if (!s) continue;
      pairs.push({ eastKm: s.dx * cellKm, northKm: -s.dy * cellKm, dtMin: dtMin });
    }
    if (pairs.length < MIN_PAIRS) return null;

    var vec = fitVelocity(pairs);
    if (!vec) return null;
    // Pairs that disagree with each other beyond this are noise, not motion.
    if (vec.residualKmh > Math.max(RESID_MAX_KMH, 0.5 * vec.speed)) return null;

    var c = (n - 1) / 2, overheadNow = false;
    for (var j = Math.floor(c); j <= Math.ceil(c); j++) {
      for (var i = Math.floor(c); i <= Math.ceil(c); i++) {
        var d = latest.grid[j][i];
        if (d !== null && d >= C.OBSERVED.RADAR_RAIN_DBZ) overheadNow = true;
      }
    }

    var stationary = vec.speed < STATIONARY_KMH;
    var arrival = stationary ? null : eta(latest, vec);
    if (arrival && ageMin) arrival.minutes = Math.max(1, Math.round(arrival.minutes - ageMin));
    var towardDeg = (Math.atan2(vec.east, vec.north) * 180 / Math.PI + 360) % 360;
    return {
      vector: {
        east: vec.east, north: vec.north,
        speed: Math.round(vec.speed),
        toward: U.compass(towardDeg),
        towardDeg: Math.round(towardDeg)
      },
      residualKmh: Math.round(vec.residualKmh),
      pairs: pairs.length,
      spanMin: Math.round((times[times.length - 1] - times[0]) / 60000),
      source: opts.source || 'nexrad',
      observedAt: times[times.length - 1],
      stationary: stationary,
      overheadNow: overheadNow,
      eta: arrival
    };
  }

  /* One learned fit per 5-minute scan cycle per place — the archive products
   * only change that often, so anything more is bandwidth for nothing. */
  var lastKey = null, lastResult = null;

  /* opts.frames switches the source to RainViewer, for everywhere NEXRAD
   * does not reach: [{ t, url }] past frames, oldest first, each url a tile
   * template. The six newest are used — fifty minutes at RainViewer's
   * ten-minute cadence, the same span the IEM path covers. */
  function learn(opts) {
    if (!global.Reflectivity || !C) return Promise.resolve(null);
    // StormSignal: nominal rolling URLs do not prove actual scan times.
    // Keep the imagery, but withhold a derived arrival estimate until each
    // sampled frame has source metadata. No arbitrary 'now' timestamp.
    if (global.StormSignal) {
      if (!opts.frames || !opts.frames.length) return Promise.resolve(null);
      var previous = -Infinity;
      for (var f = 0; f < opts.frames.length; f++) {
        var t = opts.frames[f].t;
        if (typeof t !== 'number' || !isFinite(t) || t <= previous) return Promise.resolve(null);
        previous = t;
      }
      if (!global.StormSignal.assess({ observedAt: previous, frameTimesVerified: true }).canEstimateMotion)
        return Promise.resolve(null);
    }
    var lat = opts.lat, lon = opts.lon;
    if (opts.frames) return learnFrames(lat, lon, opts.frames.slice(-OFFSETS.length));
    var bucket = Math.floor(Date.now() / 300000);
    var key = lat.toFixed(2) + '|' + lon.toFixed(2) + '|' + bucket;
    if (key === lastKey) return Promise.resolve(lastResult);

    var jobs = OFFSETS.map(function (m) {
      var url = C.NEXRAD_TILES.replace('{product}', productFor(m));
      return global.Reflectivity.sample({
        lat: lat, lon: lon, halfKm: HALF_KM, grid: GRID, zoom: ZOOM,
        reportClear: true,
        urlFor: function (z, x, y) {
          // The vm parameter busts the sampler's per-URL cache once per scan
          // cycle; IEM's tile server ignores parameters it does not know.
          return url.replace('{z}', z).replace('{x}', x).replace('{y}', y) +
            '?vm=' + bucket;
        }
      });
    });

    return Promise.all(jobs).then(function (fields) {
      /* Free the stitched tiles. This runs for the life of a chase session
       * and each cycle's URLs are new, so the sampler's cache would
       * otherwise hold every 5-minute generation of tiles in memory. */
      global.Reflectivity.clearCache();
      lastKey = key;
      lastResult = fromFields(fields);
      return lastResult;
    }).catch(function () {
      global.Reflectivity.clearCache();
      return null;
    });
  }

  function learnFrames(lat, lon, frames) {
    if (frames.length < MIN_PAIRS + 1) return Promise.resolve(null);
    var key = lat.toFixed(2) + '|' + lon.toFixed(2) + '|rv' + frames[frames.length - 1].t;
    if (key === lastKey) return Promise.resolve(lastResult);
    var jobs = frames.map(function (f) {
      return global.Reflectivity.sample({
        lat: lat, lon: lon, halfKm: HALF_KM, grid: GRID, zoom: ZOOM,
        decode: 'rainviewer', reportClear: true,
        urlFor: function (z, x, y) {
          return f.url.replace('{z}', z).replace('{x}', x).replace('{y}', y);
        }
      });
    });
    return Promise.all(jobs).then(function (fields) {
      global.Reflectivity.clearCache();
      lastKey = key;
      lastResult = fromFields(fields, {
        times: frames.map(function (f) { return f.t; }),
        source: 'rainviewer'
      });
      return lastResult;
    }).catch(function () {
      global.Reflectivity.clearCache();
      return null;
    });
  }

  global.Motion = {
    learn: learn,
    // Exposed for the test suite: the maths must hold on synthetic fields
    // before it is allowed to speak about real ones.
    weights: weights,
    bestShift: bestShift,
    fitVelocity: fitVelocity,
    eta: eta,
    fromFields: fromFields,
    OFFSETS: OFFSETS,
    GRID: GRID,
    HALF_KM: HALF_KM
  };
})(window);

