/* Vane — the population grid: how many people live near any point of the
 * lower 48 (US Census 2020, built by scripts/train/popgrid.js into
 * data/popgrid.png).
 *
 * Two uses. It is the domain mask for Vane's US-trained models — Storm
 * Odds learned from US weather and US storm reports, so it must not paint
 * Mexico or the open Pacific (a user photographed it doing exactly that) —
 * and it is the "would anyone see it?" half of Ground Truth.
 *
 * 0.1° cells from 24°N to 50°N, 125°W to 66°W. Red: people within 10 km,
 * green: within 40 km, each as log10(1 + people) scaled so 255 = 10^7.5. */
(function (global) {
  'use strict';

  var GRID = { lat0: 24, lon0: -125, step: 0.1, rows: 260, cols: 590, scale: 7.5 };

  /* grid: { data } — RGBA bytes, row 0 at the north edge. → { p10, p40 }
   * as log10(1 + people), or null off the grid. */
  function at(grid, lat, lon) {
    if (!grid || !grid.data) return null;
    var r = GRID.rows - 1 - Math.floor((lat - GRID.lat0) / GRID.step);
    var c = Math.floor((lon - GRID.lon0) / GRID.step);
    if (r < 0 || r >= GRID.rows || c < 0 || c >= GRID.cols) return null;
    var o = (r * GRID.cols + c) * 4;
    return { p10: grid.data[o] / 255 * GRID.scale, p40: grid.data[o + 1] / 255 * GRID.scale };
  }

  /* Inside the US-trained models' domain: on the grid, with US residents
   * within 40 km — the lower 48 and its coastal fringe, not Mexico, Canada
   * or open water. */
  function inUS(grid, lat, lon) {
    var v = at(grid, lat, lon);
    return !!v && v.p40 > 0;
  }

  // Decoded once from the PNG (same origin, so the canvas can be read).
  var promise = null, loaded = null;
  function load() {
    if (promise) return promise;
    promise = new Promise(function (resolve, reject) {
      var img = new Image();
      img.onload = function () {
        try {
          var c = document.createElement('canvas');
          c.width = GRID.cols; c.height = GRID.rows;
          var ctx = c.getContext('2d');
          ctx.drawImage(img, 0, 0);
          loaded = { data: ctx.getImageData(0, 0, GRID.cols, GRID.rows).data };
          resolve(loaded);
        } catch (e) { reject(e); }
      };
      img.onerror = function () { reject(new Error('population grid unavailable')); };
      img.src = 'data/popgrid.png';
    });
    promise.catch(function () { promise = null; });         // retry on the next ask
    return promise;
  }

  global.PopGrid = { GRID: GRID, at: at, inUS: inUS, load: load, loaded: function () { return loaded; } };
})(typeof window !== 'undefined' ? window : globalThis);
