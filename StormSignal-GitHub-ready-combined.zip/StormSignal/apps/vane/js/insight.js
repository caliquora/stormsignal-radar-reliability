/* Vane — Insight: everything the learners know, read out as sentences.
 *
 * Four learners run on this device: VaneMotion (where the rain is going),
 * the local scorecard (which agency has been least wrong HERE), the
 * microclimate fit (how the forecast leans HERE), and the per-cell trends
 * (which storm is organising). Each answers its own question in its own
 * card. Insight is the fifth layer: it fuses them into the read a sharp
 * meteorologist friend would give you in four sentences — and into one
 * number nobody else can compute.
 *
 * THE NUMBER. Every agency publishes a forecast for your point; Vane knows
 * which of them have actually been right there, and by how much. The
 * consensus weights each agency's day-ahead high and low by the inverse of
 * its measured local error, then applies the learned microclimate
 * correction. That is a forecast tuned to one location by evidence gathered
 * at that location — not a blend anyone else ships.
 *
 * HONESTY RULES. Every line names the learner it came from. The consensus
 * says whether its weights are earned (verified days) or provisional (equal
 * weights, no history yet). The official forecast is never replaced — the
 * card offers Vane's number beside it. No line is fabricated to fill space:
 * a quiet day reads as a quiet day. */
(function (global) {
  'use strict';

  var C = global.VaneConfig;

  var BASE_MAE = 0.5;            // °C — stops one lucky agency taking the pot
  var MENTION_DIFF_C = 0.8;      // consensus vs official worth pointing out

  /* ── Vane's number ───────────────────────────────────────────────────
   * dayIndex into the multi-model daily payload. boardRows come from
   * Verify.board (mae in °C per agency); climate from Verify.climate.
   * Pure: no storage, no clock. */
  function consensus(md, dayIndex, boardRows, climate) {
    var d = md && md.daily;
    if (!d || !d.time || dayIndex >= d.time.length) return null;

    var mae = {};
    (boardRows || []).forEach(function (r) { mae[r.id] = r.mae; });

    var swHi = 0, swLo = 0, wsum = 0, n = 0, scored = 0;
    var his = [], los = [];
    (C.MODELS_DAILY || []).forEach(function (m) {
      var hi = (d['temperature_2m_max_' + m.id] || [])[dayIndex];
      var lo = (d['temperature_2m_min_' + m.id] || [])[dayIndex];
      if (hi === null || hi === undefined || lo === null || lo === undefined) return;
      var w = 1;
      if (mae[m.id] !== undefined) { w = 1 / (mae[m.id] + BASE_MAE); scored++; }
      swHi += hi * w; swLo += lo * w; wsum += w; n++;
      his.push(hi); los.push(lo);
    });
    if (!n || !wsum) return null;

    /* Weights are only EARNED once at least two agencies carry a local
     * record — one scored agency against unweighted peers is a thumb on
     * the scale, not a consensus. */
    var weighted = scored >= 2;
    if (!weighted) {
      swHi = 0; swLo = 0; wsum = 0;
      his.forEach(function (v) { swHi += v; });
      los.forEach(function (v) { swLo += v; });
      swHi /= n; swLo /= n; wsum = 1;
    } else {
      swHi /= wsum; swLo /= wsum;
    }

    var corrected = !!(climate && climate.meaningful);
    if (corrected) { swHi += climate.corrHi; swLo += climate.corrLo; }

    return {
      date: d.time[dayIndex],
      hi: swHi, lo: swLo,
      agencies: n,
      scored: scored,
      weighted: weighted,
      corrected: corrected,
      spreadHi: Math.max.apply(null, his) - Math.min.apply(null, his),
      spreadLo: Math.max.apply(null, los) - Math.min.apply(null, los)
    };
  }

  /* VaneMotion's graded record, in one sentence. Null until there are
   * enough settled calls to say anything — a record of two is an anecdote.
   * Shared by the nowcast's motion line and Insight so both say it the
   * same way. */
  function skillText(sk) {
    if (!sk || !sk.ready) return null;
    var off = [];
    if (sk.early) off.push(sk.early + ' early');
    if (sk.late) off.push(sk.late + ' late');
    if (sk.misses) off.push(sk.misses + ' never came');
    var out = 'Its record here: ' + sk.hits + ' of ' + sk.n + ' arrival calls landed within ±' +
      sk.hitMin + ' min' + (off.length ? ' (' + off.join(', ') + ')' : '') + '.';
    // The self-correction's own audit, win or lose.
    var cal = sk.calibration;
    if (cal && cal.disabled) {
      out += ' Its learned timing correction made calls here worse (' + cal.audit.calMaeMin +
        ' vs ' + cal.audit.rawMaeMin + ' min typical error), so it has switched it off.';
    } else if (cal && cal.audit && cal.audit.calMaeMin < cal.audit.rawMaeMin) {
      out += ' Its learned timing correction has cut the typical error from ' +
        cal.audit.rawMaeMin + ' to ' + cal.audit.calMaeMin + ' min over ' + cal.audit.n + ' calls.';
    }
    return out;
  }

  /* ── The situational read ────────────────────────────────────────────
   * Takes prepared primitives, returns ordered lines of {text, tag}.
   * Formatting (units, clock) is done by the caller's helpers `fmt` so
   * the logic here stays pure and unit-testable:
   *   fmt.temp(c)     → '95°'      fmt.dist(km) → '11 mi'
   *   fmt.speed(kmh)  → '20 mph'   fmt.clock(epochMs) → '5:10 PM'
   */
  function compose(inp, fmt) {
    var lines = [];

    // 1. The official word always outranks everything Vane derives.
    if (inp.alert) {
      lines.push({
        tag: 'NWS',
        text: inp.alert.event + (inp.alert.until ? ' until ' + inp.alert.until : '') +
          '. Follow official guidance first — everything below is context.'
      });
    }

    // 2. A tracked storm actually coming here, with its fitted tendency.
    if (inp.threat && inp.threat.approach && inp.threat.approach.etaMin !== null) {
      var t = inp.threat;
      var trendBit = '';
      if (t.trend && t.trend.dir !== 'steady') {
        trendBit = t.trend.dir === 'strengthening'
          ? ', and it is strengthening (' + t.trend.firstDbz + '→' + t.trend.lastDbz +
            ' dBZ over ' + t.trend.scans + ' scans)'
          : ', though it is weakening (' + t.trend.firstDbz + '→' + t.trend.lastDbz +
            ' dBZ over ' + t.trend.scans + ' scans)';
      }
      lines.push({
        tag: 'Radar · Trend',
        text: 'Cell ' + t.stormId + ' passes within ' + fmt.dist(t.approach.closest) +
          ' in about ' + Math.round(t.approach.etaMin) + ' min' + trendBit + '.'
      });
    }

    // 3. Rain timing: the motion fit outranks the model nowcast, and the
    //    nowcast speaks only when the fit has nothing.
    if (inp.motion && inp.motion.eta) {
      var rec = skillText(inp.motionSkill);
      lines.push({
        tag: 'VaneMotion',
        text: 'Rain reaches you in about ' + inp.motion.eta.minutes + ' min — ' +
          inp.motion.eta.dbz + ' dBZ now ' + fmt.dist(inp.motion.eta.distanceKm) +
          ' to the ' + inp.motion.eta.dir + ', moving ' + inp.motion.vector.toward +
          ' at ' + fmt.speed(inp.motion.vector.speed) + '.' + (rec ? ' ' + rec : '')
      });
    } else if (inp.nowcast) {
      if (inp.nowcast.state === 'dry' && !inp.alert && !inp.threat) {
        lines.push({ tag: 'Nowcast',
          text: 'No rain expected for at least 2 hours.' });
      } else if (inp.nowcast.state !== 'dry' && inp.nowcast.headline) {
        lines.push({ tag: 'Nowcast', text: inp.nowcast.headline });
      }
    }

    // 3b. The forecast moved under you. Rain changes only — the decision
    //     card carries the full list; this is the one worth a headline.
    if (inp.change && fmt.clock) {
      var ch = inp.change, chText = null;
      if (ch.kind === 'timing') {
        var hrs = Math.abs(ch.delta / 60);
        chText = 'Since the previous forecast, first modeled rain moved from ' + fmt.clock(ch.before) +
          ' to ' + fmt.clock(ch.after) + ' (' + (hrs >= 1 ? hrs.toFixed(1) + ' h' : Math.round(Math.abs(ch.delta)) + ' min') +
          ' ' + (ch.delta < 0 ? 'earlier' : 'later') + ').';
      } else if (ch.kind === 'rain-signal') {
        chText = ch.added
          ? 'The latest forecast added rain around ' + fmt.clock(ch.at) + ' that the previous one did not have.'
          : 'The rain the previous forecast showed around ' + fmt.clock(ch.at) + ' has dropped out.';
      }
      if (chText) lines.push({ tag: 'Forecast change', text: chText });
    }

    // 4. Vane's number: the locally-weighted, microclimate-corrected
    //    consensus, offered beside the official figure.
    if (inp.consensus && inp.official) {
      var cn = inp.consensus;
      var diff = Math.max(Math.abs(cn.hi - inp.official.hi),
                          Math.abs(cn.lo - inp.official.lo));
      if (cn.weighted || cn.corrected || diff >= MENTION_DIFF_C) {
        var how = [];
        if (cn.weighted) how.push(cn.scored + ' agencies weighted by their record here');
        else how.push(cn.agencies + ' agencies, equal weights until they earn a record here');
        if (cn.corrected) how.push('adjusted for your microclimate');
        lines.push({
          tag: 'Consensus',
          text: 'Vane’s number for ' + (inp.consensusLabel || 'today') + ': ' +
            fmt.temp(cn.hi) + ' / ' + fmt.temp(cn.lo) +
            ' (official ' + fmt.temp(inp.official.hi) + ' / ' + fmt.temp(inp.official.lo) +
            ') — ' + how.join(', ') + '.'
        });
      } else {
        lines.push({
          tag: 'Consensus',
          text: 'All ' + cn.agencies + ' agencies agree with the official ' +
            fmt.temp(inp.official.hi) + ' / ' + fmt.temp(inp.official.lo) +
            ' within ' + fmt.temp0(Math.max(cn.spreadHi, cn.spreadLo)) + '.'
        });
      }
    }

    // 4a. Two clocks for the next rain, and how they are weighed here.
    var rt = inp.rainTiming;
    if (rt && rt.motionMin !== null && rt.modelMin !== null && rt.blendMin !== null) {
      var clk = function (min) { return fmt.clock(rt.at + min * 60000); };
      var wt = rt.w.ready
        ? 'weighted ' + Math.round(rt.w.wMotion * 100) + '/' + Math.round(rt.w.wModel * 100) +
          ' by their records here'
        : 'equal weights until both have a record here';
      var line = 'Rain around ' + clk(rt.blendMin) + ': the radar fit says ' + clk(rt.motionMin) +
        ', the forecast model ' + clk(rt.modelMin) + ' — ' + wt + '.';
      var bs = inp.blendSkill;
      if (bs && bs.ready) {
        line += ' Blended calls here: ' + bs.hits + ' of ' + bs.n + ' within ±' + bs.hitMin + ' min' +
          (inp.motionSkill && inp.motionSkill.ready ? ' (radar fit alone ' + inp.motionSkill.hits + ' of ' + inp.motionSkill.n + ')' : '') + '.';
      }
      lines.push({ tag: 'Rain timing', text: line });
    }

    // 4b. What the day's highest rain chance has meant here (js/raincal.js).
    var rc = inp.rainCal;
    if (rc && rc.cal) {
      var gap = rc.cal.observed - rc.cal.pop;
      lines.push({
        tag: 'Rain chances',
        text: 'The forecast gives ' + rc.cal.pop + '% around ' + fmt.clock(rc.at) + '. ' +
          (Math.abs(gap) < 6
            ? 'Chances like that have verified about right here: rain in ' + rc.cal.observed + '%'
            : 'Here, hours given that chance have ' + (gap < 0 ? 'only ' : '') + 'seen rain ' +
              rc.cal.observed + '% of the time') +
          ' (' + rc.cal.n + ' hours checked against ' + (rc.station || 'the nearest station') + ').'
      });
    }

    // 5. Who to trust here, once somebody has earned it.
    if (inp.bestModel) {
      lines.push({
        tag: 'Scorecard',
        text: inp.bestModel.short + ' has been the most accurate agency at your ' +
          'location — within ' + fmt.temp0(inp.bestModel.mae) + ' on average over ' +
          inp.bestModel.n + ' verified days.'
      });
    }

    return lines.slice(0, 5);
  }

  global.Insight = {
    consensus: consensus,
    compose: compose,
    skillText: skillText,
    BASE_MAE: BASE_MAE,
    MENTION_DIFF_C: MENTION_DIFF_C
  };
})(window);
