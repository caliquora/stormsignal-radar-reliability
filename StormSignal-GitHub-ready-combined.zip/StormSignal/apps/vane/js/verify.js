/* Vane — the local scorecard: which agency is actually best HERE.
 * And the microclimate correction: how the forecast ITSELF runs at this
 * exact spot — the systematic warm or cool lean of the day-ahead numbers
 * against the nearest station's thermometer, learned over verified days
 * and offered back as a correction, never silently applied.
 *
 * Every weather argument ("the Euro nailed it, the GFS blew it") is usually
 * fought from memory. Vane keeps score instead, and keeps it for your exact
 * location: each day it records what every agency's model said tomorrow's
 * high and low would be, and once the day has happened it verifies those
 * numbers against the nearest station's OWN thermometer — the daily extremes
 * computed from its METARs, not another model's opinion of the day. The
 * running mean absolute error per agency is the leaderboard.
 *
 * Statistical learning in the same spirit as VaneMotion: observations in,
 * a fitted summary out, error bars visible, everything on-device. The
 * scores live in localStorage, keyed to the location — a leaderboard
 * learned in Oklahoma City says nothing about Denver, so moving the pin
 * starts a fresh one rather than blending two climates.
 *
 * HONESTY RULES. Only day-ahead forecasts are scored (the last one Vane
 * saw before the day began — leads are not mixed, so a 7-day miss never
 * pollutes a 1-day score). A day with too few observations to trust its
 * extremes (station outage, app offline) is discarded, not guessed. No
 * ranking is shown before three verified days per model. */
(function (global) {
  'use strict';

  var C = global.VaneConfig;
  var KEY = 'vane.scorecard.v1';
  var MIN_OBS_PER_DAY = 12;      // fewer METARs than this cannot bound a day
  var MIN_DAYS = 3;              // no leaderboard before this many verified days
  var MAX_RESULTS = 60;          // ~two months of memory is plenty
  var MAX_PENDING_DAYS = 5;      // unverifiable predictions eventually expire

  function emptyStore(locKey) {
    return { loc: locKey, pending: {}, results: [] };
  }

  function loadStore() {
    try {
      var s = JSON.parse(localStorage.getItem(KEY));
      if (s && s.pending && s.results) return s;
    } catch (e) { /* corrupt — start over */ }
    return emptyStore(null);
  }

  function saveStore(s) {
    try { localStorage.setItem(KEY, JSON.stringify(s)); } catch (e) { /* full — fine */ }
  }

  function locKeyOf(loc) {
    return loc.lat.toFixed(2) + ',' + loc.lon.toFixed(2);
  }

  /* Local calendar date at the forecast location, from the same UTC offset
   * the forecast payload carries. */
  function localDate(epochMs, offSec) {
    return new Date(epochMs + (offSec || 0) * 1000).toISOString().slice(0, 10);
  }

  /* ── Recording: what each model says about days still to come ────────
   * Future dates are overwritten on every call, so what finally sticks for
   * a date is the last prediction Vane saw before that day began — the
   * day-ahead forecast, by construction. Pure: the store goes in and comes
   * back changed, with no clock or storage touched. */
  function recordInto(store, locKey, md, todayISO) {
    if (store.loc !== locKey) store = emptyStore(locKey);
    var d = md && md.daily;
    if (!d || !d.time) return store;
    var off = md.utc_offset_seconds || 0;

    d.time.forEach(function (date, i) {
      if (date <= todayISO) return;              // only days still to come
      var models = {};
      (C.MODELS_DAILY || []).forEach(function (m) {
        var hi = (d['temperature_2m_max_' + m.id] || [])[i];
        var lo = (d['temperature_2m_min_' + m.id] || [])[i];
        if (hi === null || hi === undefined || lo === null || lo === undefined) return;
        models[m.id] = { hi: hi, lo: lo };
      });
      if (Object.keys(models).length) {
        // A blend prediction recorded earlier for this date rides along.
        var prev = store.pending[date];
        store.pending[date] = { models: models, off: off,
                                blend: prev && prev.blend };
      }
    });
    return store;
  }

  /* The app's own displayed forecast (Open-Meteo's best-match blend) gets
   * the same treatment as the agencies: its day-ahead highs and lows are
   * recorded so the microclimate fit can learn how the number the user
   * actually read leans at this spot. Same overwrite-until-the-day-begins
   * semantics, same location reset. */
  function recordBlendInto(store, locKey, data, todayISO) {
    if (store.loc !== locKey) store = emptyStore(locKey);
    var d = data && data.daily;
    if (!d || !d.time || !d.temperature_2m_max) return store;
    var off = data.utc_offset_seconds || 0;

    d.time.forEach(function (date, i) {
      if (date <= todayISO) return;
      var hi = d.temperature_2m_max[i], lo = d.temperature_2m_min[i];
      if (hi === null || hi === undefined || lo === null || lo === undefined) return;
      var p = store.pending[date] || (store.pending[date] = { models: {}, off: off });
      p.blend = { hi: hi, lo: lo,
        // The forecast's own picture of the day, for the regime-aware fit.
        sky: d.cloud_cover_mean ? d.cloud_cover_mean[i] : null,
        wdir: d.wind_direction_10m_dominant ? d.wind_direction_10m_dominant[i] : null };
      p.off = off;
    });
    return store;
  }

  /* ── Verifying: the day happened; what did the thermometer say ───────
   * Pure again: obs is {hi, lo, n} in °C from the station's own METARs. */
  function settleResult(store, date, station, obs) {
    var p = store.pending[date];
    if (!p) return false;
    delete store.pending[date];
    if (!obs || obs.n < MIN_OBS_PER_DAY) return false;   // discard, never guess

    /* Errors are stored SIGNED (forecast minus observed): the leaderboard
     * takes the magnitude, but the microclimate fit needs the direction —
     * a model that alternates 2° warm and 2° cool has no bias to correct,
     * and only the sign can tell that apart from one that is always warm. */
    var err = {};
    Object.keys(p.models).forEach(function (id) {
      err[id] = {
        hi: p.models[id].hi - obs.hi,
        lo: p.models[id].lo - obs.lo
      };
    });
    var result = { date: date, station: station, obsHi: obs.hi, obsLo: obs.lo,
                   n: obs.n, err: err };
    if (p.blend) {
      result.blendErr = { hi: p.blend.hi - obs.hi, lo: p.blend.lo - obs.lo };
      var rg = regimeOf(p.blend.sky, p.blend.wdir);
      if (rg) result.regime = rg;
    }
    store.results.push(result);
    if (store.results.length > MAX_RESULTS) {
      store.results = store.results.slice(-MAX_RESULTS);
    }
    return true;
  }

  /* Drop pending dates too old to ever verify (the app was closed for a
   * week; the observations API only reaches back so far usefully). */
  function prunePending(store, todayISO) {
    Object.keys(store.pending).forEach(function (date) {
      var age = (new Date(todayISO) - new Date(date)) / 86400000;
      if (age > MAX_PENDING_DAYS) delete store.pending[date];
    });
  }

  /* ── The leaderboard itself ──────────────────────────────────────────
   * Mean absolute error of day-ahead highs and lows, per agency, over
   * every verified day that agency appeared in. Ranked by the combined
   * error; nothing ranked under MIN_DAYS days. */
  function board(results) {
    var acc = {};
    (results || []).forEach(function (r) {
      Object.keys(r.err).forEach(function (id) {
        var a = acc[id] || (acc[id] = { n: 0, hi: 0, lo: 0, sHi: 0, sLo: 0 });
        // The rank is by magnitude; the signed sums say which way it leans.
        a.n++; a.hi += Math.abs(r.err[id].hi); a.lo += Math.abs(r.err[id].lo);
        a.sHi += r.err[id].hi; a.sLo += r.err[id].lo;
      });
    });
    var rows = [];
    (C.MODELS_DAILY || []).forEach(function (m) {
      var a = acc[m.id];
      if (!a || a.n < MIN_DAYS) return;
      rows.push({
        id: m.id, short: m.short, name: m.name, color: m.color,
        n: a.n,
        maeHi: a.hi / a.n,
        maeLo: a.lo / a.n,
        mae: (a.hi + a.lo) / (2 * a.n),
        biasHi: a.sHi / a.n,
        biasLo: a.sLo / a.n
      });
    });
    rows.sort(function (x, y) { return x.mae - y.mae; });
    return { rows: rows, days: (results || []).length };
  }

  /* ── The microclimate fit ────────────────────────────────────────────
   * Mean signed error of the displayed forecast's day-ahead highs and
   * lows: the systematic lean of the model at this exact spot. The offered
   * correction is the negated bias SHRUNK toward zero by n/(n+K) — with
   * three days of data the fit only trusts itself about 40%, and it earns
   * the rest by being right for weeks. A small sample can therefore never
   * fling a wild correction at the card, and a genuine, persistent lean
   * converges to its full size. */

  var SHRINK_K = 4;
  var CORR_MIN_C = 0.5;          // corrections under half a degree stay quiet

  function microclimate(results) {
    var n = 0, hi = 0, lo = 0, absHi = 0, absLo = 0;
    (results || []).forEach(function (r) {
      if (!r.blendErr) return;
      n++;
      hi += r.blendErr.hi; lo += r.blendErr.lo;
      absHi += Math.abs(r.blendErr.hi); absLo += Math.abs(r.blendErr.lo);
    });
    if (n < MIN_DAYS) return null;
    var shrink = n / (n + SHRINK_K);
    var biasHi = hi / n, biasLo = lo / n;
    return {
      n: n,
      biasHi: biasHi, biasLo: biasLo,
      corrHi: -biasHi * shrink, corrLo: -biasLo * shrink,
      maeHi: absHi / n, maeLo: absLo / n,
      // A correction worth mentioning, or a forecast running true?
      meaningful: Math.abs(biasHi * shrink) >= CORR_MIN_C ||
                  Math.abs(biasLo * shrink) >= CORR_MIN_C
    };
  }

  /* ── The weather-aware version ───────────────────────────────────────
   *
   * A spot's lean is rarely one number. A valley runs cold on clear calm
   * nights and true under cloud; a lake shore runs cool on onshore wind.
   * So each verified day also carries the forecast's own picture of it —
   * sky (clear / partly / cloudy, from mean cloud cover) and the dominant
   * wind's quarter — and the correction becomes the overall lean plus a
   * per-regime adjustment, each adjustment shrunk toward zero as if
   * REGIME_K days had shown no difference.
   *
   * It has to earn its place. Over the verified days, each day is
   * predicted leave-one-out — corrected by a fit made WITHOUT it — once by
   * the plain correction and once by the weather-aware one. Only if the
   * weather-aware version leaves the smaller typical miss is it used, and
   * the card says by how much. Until then the plain correction stands. */
  var REGIME_K = 6, REGIME_MIN_DAYS = 10, REGIME_MIN_LEVEL = 4;

  function skyOf(pct) {
    if (typeof pct !== 'number') return null;
    return pct < 30 ? 'clear' : pct <= 70 ? 'partly cloudy' : 'cloudy';
  }

  function windOf(deg) {
    if (typeof deg !== 'number') return null;
    return ['north', 'east', 'south', 'west'][Math.floor(((deg + 45) % 360) / 90)];
  }

  function regimeOf(sky, wdir) {
    var a = skyOf(sky), b = windOf(wdir);
    return a || b ? { sky: a, wind: b } : null;
  }

  // Fit on a set of days: overall shrunk lean, plus per-level deviations.
  function regimeModel(days) {
    var n = days.length, bHi = 0, bLo = 0;
    days.forEach(function (r) { bHi += r.blendErr.hi; bLo += r.blendErr.lo; });
    bHi /= n || 1; bLo /= n || 1;
    var shrink = n / (n + SHRINK_K);
    var dev = { sky: {}, wind: {} };
    ['sky', 'wind'].forEach(function (f) {
      var acc = {};
      days.forEach(function (r) {
        var L = r.regime && r.regime[f];
        if (!L) return;
        var a = acc[L] || (acc[L] = { n: 0, hi: 0, lo: 0 });
        a.n++; a.hi += r.blendErr.hi - bHi; a.lo += r.blendErr.lo - bLo;
      });
      Object.keys(acc).forEach(function (L) {
        var a = acc[L], k = a.n / (a.n + REGIME_K);
        dev[f][L] = { n: a.n, hi: a.hi / a.n * k, lo: a.lo / a.n * k,
                      rawHi: a.hi / a.n, rawLo: a.lo / a.n };
      });
    });
    return { n: n, bHi: bHi, bLo: bLo, shrink: shrink, dev: dev };
  }

  // The correction a model offers for a day of a given regime.
  function correctFor(m, regime, aware) {
    var cHi = -m.bHi * m.shrink, cLo = -m.bLo * m.shrink;
    if (aware && regime) {
      ['sky', 'wind'].forEach(function (f) {
        var d = regime[f] && m.dev[f][regime[f]];
        if (d) { cHi -= d.hi; cLo -= d.lo; }
      });
    }
    return { hi: cHi, lo: cLo };
  }

  function regimeFit(results) {
    var days = (results || []).filter(function (r) { return r.blendErr && r.regime; });
    if (days.length < REGIME_MIN_DAYS) return { ready: false, n: days.length, need: REGIME_MIN_DAYS };
    var plain = 0, aware = 0;
    days.forEach(function (r, i) {
      var others = days.filter(function (_, j) { return j !== i; });
      var m = regimeModel(others);
      var cp = correctFor(m, r.regime, false), ca = correctFor(m, r.regime, true);
      plain += Math.abs(r.blendErr.hi + cp.hi) + Math.abs(r.blendErr.lo + cp.lo);
      aware += Math.abs(r.blendErr.hi + ca.hi) + Math.abs(r.blendErr.lo + ca.lo);
    });
    var model = regimeModel(days);
    return {
      ready: true, n: days.length, model: model,
      looPlain: plain / (2 * days.length), looAware: aware / (2 * days.length),
      wins: aware / (2 * days.length) < plain / (2 * days.length) - 0.05
    };
  }

  /* The weather-aware correction for a day of this regime, or null when
   * it has not earned its place. Names the adjustment that matters most. */
  function regimeCorrection(fit, regime) {
    if (!fit || !fit.ready || !fit.wins || !regime) return null;
    var c = correctFor(fit.model, regime, true), top = null;
    ['sky', 'wind'].forEach(function (f) {
      var d = regime[f] && fit.model.dev[f][regime[f]];
      if (!d || d.n < REGIME_MIN_LEVEL) return;
      var size = Math.max(Math.abs(d.hi), Math.abs(d.lo));
      if (!top || size > top.size) top = { factor: f, level: regime[f], n: d.n, size: size,
                                           rawHi: d.rawHi, rawLo: d.rawLo };
    });
    return { corrHi: c.hi, corrLo: c.lo, top: top,
             looPlain: fit.looPlain, looAware: fit.looAware, n: fit.n };
  }

  /* ── Wiring: storage + network around the pure core ────────────────── */

  function record(loc, md) {
    if (!loc || !md) return;
    var off = md.utc_offset_seconds || 0;
    var store = recordInto(loadStore(), locKeyOf(loc), md, localDate(Date.now(), off));
    saveStore(store);
  }

  function recordBlend(loc, data) {
    if (!loc || !data) return;
    var off = data.utc_offset_seconds || 0;
    var store = recordBlendInto(loadStore(), locKeyOf(loc), data, localDate(Date.now(), off));
    saveStore(store);
  }

  /* today: optional { sky: cloud %, wdir: degrees } for the day being
   * corrected. When the weather-aware fit has earned its place, its
   * correction replaces the plain one and m.regime explains it. */
  function climate(today) {
    var store = loadStore();
    var m = microclimate(store.results);
    if (m) {
      m.station = store.results.length
        ? store.results[store.results.length - 1].station : null;
      var rg = today ? regimeOf(today.sky, today.wdir) : null;
      var rc = rg ? regimeCorrection(regimeFit(store.results), rg) : null;
      if (rc) {
        m.plainHi = m.corrHi; m.plainLo = m.corrLo;
        m.corrHi = rc.corrHi; m.corrLo = rc.corrLo;
        m.regime = rc;
        m.meaningful = m.meaningful || Math.abs(rc.corrHi) >= CORR_MIN_C || Math.abs(rc.corrLo) >= CORR_MIN_C;
      }
    }
    return m;
  }

  /* Verify every pending past date against the station's real day. Resolves
   * true when anything changed, so the caller can re-render the card. */
  function settle(loc, obsInfo) {
    if (!loc || !obsInfo || !obsInfo.station) return Promise.resolve(false);
    var store = loadStore();
    if (store.loc !== locKeyOf(loc)) return Promise.resolve(false);

    var dates = Object.keys(store.pending).filter(function (date) {
      var off = store.pending[date].off || 0;
      return date < localDate(Date.now(), off);      // the day is over, locally
    });
    if (!dates.length) return Promise.resolve(false);

    var jobs = dates.map(function (date) {
      var off = store.pending[date].off || 0;
      // The station's local day, expressed in UTC for the API.
      var start = new Date(new Date(date + 'T00:00:00Z').getTime() - off * 1000);
      var end = new Date(start.getTime() + 86400000);
      // A US station's day comes from weather.gov; anywhere else, the same
      // METARs out of Iowa State's archive (obsInfo.archive === 'iem').
      var dayOf = obsInfo.archive === 'iem'
        ? global.API.metarDayExtremes : global.API.stationDayExtremes;
      return dayOf(obsInfo.station,
        start.toISOString(), end.toISOString()
      ).then(function (obs) {
        return settleResult(store, date, obsInfo.station, obs);
      }).catch(function () { return false; });       // retry next load
    });

    return Promise.all(jobs).then(function (changed) {
      prunePending(store, localDate(Date.now(), 0));
      saveStore(store);
      return changed.indexOf(true) !== -1;
    });
  }

  function scorecard() {
    var store = loadStore();
    var b = board(store.results);
    b.station = store.results.length
      ? store.results[store.results.length - 1].station : null;
    b.pendingDays = Object.keys(store.pending).length;
    return b;
  }

  function reset() {
    try { localStorage.removeItem(KEY); } catch (e) { /* nothing to clear */ }
  }

  global.Verify = {
    record: record,
    recordBlend: recordBlend,
    settle: settle,
    scorecard: scorecard,
    climate: climate,
    reset: reset,
    regimeOf: regimeOf,
    regimeFit: regimeFit,
    regimeCorrection: regimeCorrection,
    // The pure core, exported for the test suite.
    recordInto: recordInto,
    recordBlendInto: recordBlendInto,
    settleResult: settleResult,
    prunePending: prunePending,
    board: board,
    microclimate: microclimate,
    emptyStore: emptyStore,
    MIN_OBS_PER_DAY: MIN_OBS_PER_DAY,
    MIN_DAYS: MIN_DAYS
  };
})(window);
