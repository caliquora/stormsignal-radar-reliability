/* Vane — Storm Prediction Center products.
 *
 * F7: chasers plan the day off the SPC outlook before they ever look at radar.
 * This module owns the outlook overlay, the risk read-out for the current
 * point, and today's storm reports. All feeds are public and keyless. */
(function (global) {
  'use strict';

  var C = global.VaneConfig, U = global.U;

  var state = {
    day: 1,
    hazard: 'cat',
    features: [],
    reports: [],
    layer: null,
    reportLayer: null,
    visible: true,
    reportsVisible: true,
    reportTypes: null              // { category: false } hides one; null shows all
  };

  /* ── Point-in-polygon so we can say what risk *this* location is in ─── */

  function pointInRing(lat, lon, ring) {
    var inside = false;
    for (var i = 0, j = ring.length - 1; i < ring.length; j = i++) {
      var xi = ring[i][0], yi = ring[i][1];
      var xj = ring[j][0], yj = ring[j][1];
      var hit = ((yi > lat) !== (yj > lat)) &&
        (lon < (xj - xi) * (lat - yi) / ((yj - yi) || 1e-12) + xi);
      if (hit) inside = !inside;
    }
    return inside;
  }

  function pointInGeometry(lat, lon, geom) {
    if (!geom) return false;
    var polys = geom.type === 'Polygon' ? [geom.coordinates]
      : geom.type === 'MultiPolygon' ? geom.coordinates : [];
    for (var p = 0; p < polys.length; p++) {
      var rings = polys[p];
      if (!rings.length) continue;
      if (!pointInRing(lat, lon, rings[0])) continue;
      // Subtract holes.
      var inHole = false;
      for (var h = 1; h < rings.length; h++) {
        if (pointInRing(lat, lon, rings[h])) { inHole = true; break; }
      }
      if (!inHole) return true;
    }
    return false;
  }

  // Outlook polygons nest, so the answer is the highest-ranked one containing
  // the point — not simply the first match. `riskIn` is the pure form, so the
  // notifier can point-test a freshly fetched day without touching whatever
  // day the map is showing.
  function riskIn(features, lat, lon, hazard) {
    var best = null;
    (features || []).forEach(function (f) {
      var p = f.properties || {};
      var info = C.SPC_RISK[p.DN];
      if (!pointInGeometry(lat, lon, f.geometry)) return;
      var rank = info ? info.rank : 0;
      if (!best || rank > best.rank) {
        best = {
          rank: rank,
          code: info ? info.code : p.LABEL,
          label: info ? info.label : (p.LABEL2 || p.LABEL),
          color: info ? info.color : (p.fill || '#888'),
          probability: (hazard || 'cat') === 'cat' ? null : p.LABEL,
          issued: p.ISSUE_ISO,
          valid: p.VALID_ISO,
          expires: p.EXPIRE_ISO,
          forecaster: p.FORECASTER
        };
      }
    });
    return best;
  }

  function riskAt(lat, lon) {
    return riskIn(state.features, lat, lon, state.hazard);
  }

  /* ── Loading ────────────────────────────────────────────────────────── */

  function load(day, hazard) {
    state.day = day || state.day;
    state.hazard = hazard || state.hazard;
    // SPC only issues probabilistic hazard breakdowns for days 1-2.
    if (state.day > 2 && state.hazard !== 'cat') state.hazard = 'cat';
    return global.API.spcOutlook(state.day, state.hazard).then(function (features) {
      state.features = features;
      return features;
    });
  }

  function loadReports() {
    return global.API.stormReports().then(function (r) {
      state.reports = r;
      return r;
    });
  }

  /* ── Map overlay ────────────────────────────────────────────────────── */

  function draw(map) {
    if (!map || typeof global.L === 'undefined') return;
    if (state.layer) { map.removeLayer(state.layer); state.layer = null; }
    if (!state.visible || !state.features.length) return;

    state.layer = L.geoJSON({ type: 'FeatureCollection', features: state.features }, {
      style: function (f) {
        var p = f.properties || {};
        var info = C.SPC_RISK[p.DN];
        return {
          color: p.stroke || (info && info.color) || '#888',
          fillColor: p.fill || (info && info.color) || '#888',
          weight: 1.5, fillOpacity: 0.16, opacity: 0.85
        };
      },
      onEachFeature: function (f, layer) {
        var p = f.properties || {};
        var info = C.SPC_RISK[p.DN];
        // Radar.tapPopup, not bindPopup: on touch, the tap's synthesized
        // second click read Leaflet's stock toggle as open-then-close.
        global.Radar.tapPopup(layer, '<strong>SPC Day ' + state.day + ' ' + state.hazard.toUpperCase() +
          '</strong><br>' + esc((info && info.label) || p.LABEL2 || p.LABEL || '') +
          '<br><span style="opacity:.7">Forecaster: ' + esc(p.FORECASTER || '—') + '</span>');
      }
    });
    state.layer.addTo(map);
    state.layer.bringToBack();
  }

  function drawReports(map) {
    if (!map || typeof global.L === 'undefined') return;
    if (state.reportLayer) { map.removeLayer(state.reportLayer); state.reportLayer = null; }
    if (!state.reportsVisible || !state.reports.length) return;

    state.reportLayer = L.layerGroup();
    var now = Date.now(), types = state.reportTypes || {}, ctx = context(now);
    // Tornadoes last, so they draw on top of the wind and hail around them.
    var order = C.REPORT_ORDER.slice().reverse();
    state.reports.slice().sort(function (a, b) {
      return order.indexOf(a.category) - order.indexOf(b.category);
    }).forEach(function (r) {
      if (types[r.category] === false) return;
      var style = C.STORM_REPORT_STYLE[r.category] || C.STORM_REPORT_STYLE.other;
      // Older reports fade: the last hour is what is happening now.
      var ageH = r.at ? (now - r.at) / 3600000 : 0;
      var opacity = Math.max(0.45, Math.min(1, 1 - (ageH - 1) / 30));
      var big = r.category === 'tornado';
      var icon = L.divIcon({
        className: 'lsr-icon lsr-' + r.category + (big ? ' lsr-big' : ''),
        html: '<span style="background:' + style.color + ';opacity:' + opacity.toFixed(2) + '">' +
          esc(style.glyph) + '</span>',
        iconSize: big ? [22, 22] : [18, 18], iconAnchor: big ? [11, 11] : [9, 9]
      });
      var m = L.marker([r.lat, r.lon], { icon: icon, pane: 'features', keyboard: false,
        title: (r.kind || style.label) + (r.magnitude ? ' ' + r.magnitude : '') });
      global.Radar.tapPopup(m, reportDetail(r, ctx), { className: 'lsr-popup' });
      state.reportLayer.addLayer(m);
    });
    state.reportLayer.addTo(map);
  }

  /* ── A report, in full ──────────────────────────────────────────────
   * What the NWS office logged, read the way a chaser needs it: how big
   * against the familiar yardsticks, whether it met severe criteria, where
   * it was relative to you, and two ways to dig further — the radar at
   * that moment, and the office's own report text. */

  // The NWS spotter-training yardsticks, inches.
  var HAIL_SIZES = [
    [0.25, 'pea'], [0.5, 'marble'], [0.75, 'penny'], [0.88, 'nickel'], [1, 'quarter'],
    [1.25, 'half dollar'], [1.5, 'ping pong ball'], [1.75, 'golf ball'], [2, 'hen egg'],
    [2.5, 'tennis ball'], [2.75, 'baseball'], [3, 'teacup'], [4, 'softball'], [4.5, 'grapefruit']
  ];

  function hailSize(inches) {
    if (!(inches > 0)) return null;
    var best = null;
    HAIL_SIZES.forEach(function (h) { if (inches >= h[0] - 0.02) best = h; });
    if (!best) return 'smaller than a pea';
    return Math.abs(inches - best[0]) <= 0.02 ? best[1] + ' size' : 'larger than ' + best[1] + ' size';
  }

  /* SPC's thresholds: severe is 1" hail or a 58 mph (50 kt) thunderstorm
   * gust; significant is 2" hail or 75 mph (65 kt). Gusts with no storm
   * behind them (a gradient wind, a sustained-wind reading) are logged but
   * are not severe thunderstorm reports, so they get no tag. */
  function severity(r) {
    if (r.category === 'tornado') return { level: 'tornado', text: 'Tornado' };
    var v = r.magValue;
    if (!(v > 0)) return null;
    if (r.category === 'hail' && r.magUnit === 'in') {
      return v >= 2 ? { level: 'sig', text: 'Significant severe hail (2″+)' }
        : v >= 1 ? { level: 'severe', text: 'Severe hail (1″+)' } : null;
    }
    if (r.category === 'wind' && !/non-thunderstorm|sustained/i.test(r.kind || '')) {
      var mph = r.magUnit === 'kt' ? v * 1.15078 : r.magUnit === 'mph' ? v : null;
      if (mph === null) return null;
      return mph >= 74.5 ? { level: 'sig', text: 'Significant severe wind (75 mph+)' }
        : mph >= 57.5 ? { level: 'severe', text: 'Severe wind (58 mph+)' } : null;
    }
    return null;
  }

  function bearingDeg(lat1, lon1, lat2, lon2) {
    var r = Math.PI / 180, y = Math.sin((lon2 - lon1) * r) * Math.cos(lat2 * r);
    var x = Math.cos(lat1 * r) * Math.sin(lat2 * r) -
      Math.sin(lat1 * r) * Math.cos(lat2 * r) * Math.cos((lon2 - lon1) * r);
    return (Math.atan2(y, x) / r + 360) % 360;
  }

  // The app's location, units and clock, read when the reports are drawn.
  function context(now) {
    var s = global.Vane && global.Vane.state;
    return {
      now: now || Date.now(),
      from: s && s.location ? { lat: s.location.lat, lon: s.location.lon, name: s.location.name } : null,
      imperial: s ? s.imperial !== false : true,
      hour12: s ? s.hour12 : (global.Settings && global.Settings.get('hour12')),
      offset: s && s.data ? s.data.utc_offset_seconds : null
    };
  }

  var IEM_PRODUCT = 'https://mesonet.agron.iastate.edu/p.php?pid=';

  function reportDetail(r, ctx) {
    ctx = ctx || context();
    var style = C.STORM_REPORT_STYLE[r.category] || C.STORM_REPORT_STYLE.other;
    var out = '<div class="lsr-detail">';
    out += '<div class="lsr-head"><span class="lsr-glyph" style="background:' + style.color +
      (/^(tornado|wind|winter)$/.test(r.category) ? ';color:#fff' : '') + '">' +
      esc(style.glyph) + '</span><strong>' + esc(r.kind || style.label) + '</strong></div>';

    var mag = r.magnitude ? esc(r.magnitude) : '';
    var size = r.category === 'hail' && r.magUnit === 'in' ? hailSize(r.magValue) : null;
    if (mag) out += '<div class="lsr-mag">' + mag + (size ? ' — ' + esc(size) : '') + '</div>';
    var sev = severity(r);
    if (sev) out += '<div class="lsr-sev lsr-sev-' + sev.level + '">' + esc(sev.text) + '</div>';

    var place = [r.location, r.county ? r.county + ' County' : '', r.state].filter(Boolean).join(', ');
    if (place) out += '<div>' + esc(place) + '</div>';
    if (ctx.from && isFinite(r.lat) && isFinite(r.lon)) {
      var km = U.haversine(ctx.from.lat, ctx.from.lon, r.lat, r.lon);
      out += '<div class="lsr-dim">' + (km < 1.5 ? 'At your location'
        : U.distance(km, ctx.imperial).replace(/\.\d /, ' ') + ' ' +
          U.compass(bearingDeg(ctx.from.lat, ctx.from.lon, r.lat, r.lon)) + ' of ' +
          esc(ctx.from.name || 'you')) + '</div>';
    }

    var when = r.at
      ? (ctx.offset !== null && ctx.offset !== undefined
          ? U.fmtEpoch(r.at, ctx.offset, ctx.hour12) : U.fmtTime(new Date(r.at), ctx.hour12)) +
        ' (' + U.relative(ctx.now - r.at) + ')'
      : esc(r.time) + 'Z';
    var who = [r.source ? 'Reported by ' + r.source : '', r.wfo ? 'NWS ' + r.wfo : '']
      .filter(Boolean).join(' · ');
    out += '<div class="lsr-dim">' + when + (who ? ' · ' + esc(who) : '') + '</div>';
    if (r.comments) out += '<p class="lsr-remark">' + esc(r.comments) + '</p>';

    var actions = '';
    if (r.at) actions += '<button type="button" class="lsr-action" data-radar-at="' + r.at + '">Radar at this time</button>';
    if (r.productId) actions += '<a class="lsr-action" href="' + IEM_PRODUCT + encodeURIComponent(r.productId) +
      '" target="_blank" rel="noopener">NWS report ↗</a>';
    if (actions) out += '<div class="lsr-actions">' + actions + '</div>';
    return out + '</div>';
  }

  function esc(s) {
    return String(s === undefined || s === null ? '' : s).replace(/[&<>"']/g, function (c) {
      return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c];
    });
  }

  function reportsNear(lat, lon, radiusKm) {
    return state.reports.map(function (r) {
      return Object.assign({}, r, { distance: U.haversine(lat, lon, r.lat, r.lon) });
    }).filter(function (r) { return r.distance <= (radiusKm || 200); })
      .sort(function (a, b) { return a.distance - b.distance; });
  }

  function summary() {
    var counts = {};
    C.REPORT_ORDER.forEach(function (k) { counts[k] = 0; });
    state.reports.forEach(function (r) { counts[r.category] = (counts[r.category] || 0) + 1; });
    return counts;
  }

  global.SPC = {
    state: state,
    load: load,
    loadReports: loadReports,
    draw: draw,
    drawReports: drawReports,
    riskAt: riskAt,
    riskIn: riskIn,
    reportsNear: reportsNear,
    reportDetail: reportDetail,
    hailSize: hailSize,
    severity: severity,
    summary: summary,
    pointInGeometry: pointInGeometry
  };
})(window);
