/* Vane — the extended outlook chart.
 *
 * A box plot per day, because that is what the data is: fifty members, not one
 * number. The whisker is p10–p90, the box is the middle half, the bar is the
 * median. Behind them, a shaded band showing what this location's temperature
 * normally does at this time of year, and the single deterministic run drawn
 * as a thin line so you can see how often it wanders outside its own
 * ensemble's middle half at long leads.
 *
 * The one element that matters most is the vertical rule: the skill horizon,
 * placed where Outlook measured the spread reaching the climatological range.
 * Everything to the right of it is drawn deliberately quieter — no numbers,
 * lower contrast — because that is what it is worth. */
(function (global) {
  'use strict';

  var NS = 'http://www.w3.org/2000/svg';
  var U = global.U;

  var W = 980, H = 330;
  var PAD = { l: 46, r: 14, t: 16, b: 74 };
  var TEMP = { y: 16, h: 178 };
  var POP = { y: 212, h: 44 };

  function e(tag, attrs, kids) {
    var n = document.createElementNS(NS, tag);
    Object.keys(attrs || {}).forEach(function (k) { n.setAttribute(k, attrs[k]); });
    (kids || []).forEach(function (c) { n.appendChild(c); });
    return n;
  }

  function text(str, attrs) {
    var t = e('text', attrs);
    t.textContent = str;
    return t;
  }

  function render(container, outlook, opts) {
    opts = opts || {};
    var imp = !!opts.imperial;
    U.clear(container);
    if (!outlook || !outlook.days.length) {
      container.appendChild(U.make('p', 'muted', 'No extended ensemble data for this location.'));
      return;
    }

    var days = outlook.days;
    var n = days.length;
    var plotW = W - PAD.l - PAD.r;
    var step = plotW / n;
    var boxW = Math.min(20, step * 0.46);
    var conv = function (c) { return imp ? c * 9 / 5 + 32 : c; };

    // Vertical range covers the ensemble *and* the climatological band, so the
    // two are always comparable rather than one being clipped off.
    var lo = Infinity, hi = -Infinity;
    days.forEach(function (d) {
      [d.tmax && d.tmax.p10, d.tmax && d.tmax.p90,
       d.normal && d.normal.tmax && d.normal.tmax.p10,
       d.normal && d.normal.tmax && d.normal.tmax.p90,
       d.deterministic && d.deterministic.tmax].forEach(function (v) {
        if (v === null || v === undefined || isNaN(v)) return;
        lo = Math.min(lo, v); hi = Math.max(hi, v);
      });
    });
    if (!isFinite(lo)) { lo = 0; hi = 1; }
    var pad = (hi - lo) * 0.12 || 1;
    lo -= pad; hi += pad;

    var x = function (i) { return PAD.l + step * (i + 0.5); };
    var y = function (v) { return TEMP.y + TEMP.h - ((v - lo) / (hi - lo)) * TEMP.h; };

    var svg = e('svg', {
      viewBox: '0 0 ' + W + ' ' + H,
      class: 'outlook-chart',
      preserveAspectRatio: 'none',
      role: 'img',
      'aria-label': 'Sixteen day ensemble outlook with skill horizon'
    });

    /* ── Climatological band ─────────────────────────────────────────── */

    if (outlook.hasNormals) {
      var top = [], bottom = [], mid = [];
      days.forEach(function (d, i) {
        if (!d.normal || !d.normal.tmax) return;
        top.push(x(i) + ',' + y(d.normal.tmax.p90));
        bottom.unshift(x(i) + ',' + y(d.normal.tmax.p10));
        mid.push(x(i) + ',' + y(d.normal.tmax.mean));
      });
      if (top.length) {
        svg.appendChild(e('polygon', { class: 'ol-normal-band', points: top.concat(bottom).join(' ') }));
        svg.appendChild(e('polyline', { class: 'ol-normal-line', points: mid.join(' ') }));
      }
    }

    /* ── Temperature axis ────────────────────────────────────────────── */

    var ticks = 4;
    for (var t = 0; t <= ticks; t++) {
      var v = lo + (hi - lo) * (t / ticks);
      svg.appendChild(e('line', {
        class: 'ol-grid', x1: PAD.l, x2: W - PAD.r, y1: y(v), y2: y(v)
      }));
      svg.appendChild(text(Math.round(conv(v)) + '°', {
        class: 'ol-axis-label', x: PAD.l - 8, y: y(v) + 4, 'text-anchor': 'end'
      }));
    }

    /* ── Skill horizon ───────────────────────────────────────────────── */

    if (outlook.horizon > 0) {
      var hx = PAD.l + step * outlook.horizon;
      svg.appendChild(e('rect', {
        class: 'ol-beyond', x: hx, y: TEMP.y, width: (W - PAD.r) - hx, height: POP.y + POP.h - TEMP.y
      }));
      svg.appendChild(e('line', {
        class: 'ol-horizon', x1: hx, x2: hx, y1: TEMP.y - 6, y2: POP.y + POP.h
      }));
      svg.appendChild(text('skill horizon', {
        class: 'ol-horizon-label', x: hx + 6, y: TEMP.y + 4
      }));
    }

    /* ── Per-day boxes ───────────────────────────────────────────────── */

    days.forEach(function (d, i) {
      if (!d.tmax) return;
      var cx = x(i);
      var g = e('g', { class: 'ol-day ol-band-' + (d.band ? d.band.key : 'unknown') });

      // Whisker: p10 to p90.
      g.appendChild(e('line', { class: 'ol-whisker', x1: cx, x2: cx, y1: y(d.tmax.p10), y2: y(d.tmax.p90) }));
      g.appendChild(e('line', {
        class: 'ol-cap', x1: cx - boxW / 3, x2: cx + boxW / 3, y1: y(d.tmax.p90), y2: y(d.tmax.p90)
      }));
      g.appendChild(e('line', {
        class: 'ol-cap', x1: cx - boxW / 3, x2: cx + boxW / 3, y1: y(d.tmax.p10), y2: y(d.tmax.p10)
      }));
      // Box: the middle half of the members.
      g.appendChild(e('rect', {
        class: 'ol-box', x: cx - boxW / 2, y: y(d.tmax.p75),
        width: boxW, height: Math.max(2, y(d.tmax.p25) - y(d.tmax.p75)), rx: 3
      }));
      g.appendChild(e('line', {
        class: 'ol-median', x1: cx - boxW / 2, x2: cx + boxW / 2, y1: y(d.tmax.median), y2: y(d.tmax.median)
      }));

      var tip = U.fmtDay(U.parseLocal(d.date)) + ' — median ' + Math.round(conv(d.tmax.median)) + '°, ' +
        'middle half ' + Math.round(conv(d.tmax.p25)) + '–' + Math.round(conv(d.tmax.p75)) + '°, ' +
        d.members + ' members' +
        (d.band ? ' · ' + d.band.label : '');
      g.appendChild(e('title', {}, [text(tip, {})]));
      svg.appendChild(g);
    });

    /* ── Deterministic run for comparison ────────────────────────────── */

    var det = days.filter(function (d) { return d.deterministic && d.deterministic.tmax !== null; });
    if (det.length > 1) {
      svg.appendChild(e('polyline', {
        class: 'ol-deterministic',
        points: det.map(function (d) { return x(d.lead) + ',' + y(d.deterministic.tmax); }).join(' ')
      }));
    }

    /* ── Precipitation probability ───────────────────────────────────── */

    svg.appendChild(text('Chance of a wet day', {
      class: 'ol-section-label', x: PAD.l, y: POP.y - 6
    }));
    days.forEach(function (d, i) {
      if (d.precipProbability === null) return;
      var h = d.precipProbability * POP.h;
      svg.appendChild(e('rect', {
        class: 'ol-pop' + (outlook.horizon > 0 && i >= outlook.horizon ? ' ol-pop-dim' : ''),
        x: x(i) - boxW / 2, y: POP.y + POP.h - h, width: boxW, height: Math.max(1, h), rx: 2
      }));
      // The climatological wet-day frequency as a notch: the honest reference
      // for "is rain more likely than usual", which is the only precipitation
      // statement that survives past the horizon.
      if (d.normal && d.normal.wetFrequency !== null) {
        var ny = POP.y + POP.h - d.normal.wetFrequency * POP.h;
        svg.appendChild(e('line', {
          class: 'ol-pop-normal',
          x1: x(i) - boxW / 2 - 2, x2: x(i) + boxW / 2 + 2, y1: ny, y2: ny
        }));
      }
    });

    /* ── Day axis ────────────────────────────────────────────────────── */

    days.forEach(function (d, i) {
      var date = U.parseLocal(d.date);
      var beyond = outlook.horizon > 0 && i >= outlook.horizon;
      svg.appendChild(text(i === 0 ? 'Today' : U.fmtDay(date), {
        class: 'ol-axis-day' + (beyond ? ' ol-dim' : ''), x: x(i), y: POP.y + POP.h + 20,
        'text-anchor': 'middle'
      }));
      // Past the horizon a precise number is not knowledge, so it is not shown.
      if (!beyond && d.tmax) {
        svg.appendChild(text(Math.round(conv(d.tmax.median)) + '°', {
          class: 'ol-axis-temp', x: x(i), y: POP.y + POP.h + 38, 'text-anchor': 'middle'
        }));
      } else if (d.anomaly !== null) {
        svg.appendChild(text(anomalyGlyph(d.anomaly), {
          class: 'ol-axis-anom ' + (d.anomaly > 0 ? 'ol-warm' : 'ol-cool'),
          x: x(i), y: POP.y + POP.h + 38, 'text-anchor': 'middle'
        }));
      }
    });

    container.appendChild(svg);
  }

  /* Past the horizon the only honest statement is which side of normal the
   * pattern leans, and how hard. Arrows, not numbers. */
  function anomalyGlyph(anomalyC) {
    var a = Math.abs(anomalyC);
    var arrow = anomalyC > 0 ? '▲' : '▼';
    if (a < 1) return '–';
    if (a < 3) return arrow;
    if (a < 6) return arrow + arrow;
    return arrow + arrow + arrow;
  }

  global.OutlookChart = { render: render, anomalyGlyph: anomalyGlyph };
})(window);
