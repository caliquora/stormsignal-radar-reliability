/* Vane — the storm in three dimensions.
 *
 * WHAT THIS IS BUILT FROM, because a 3D storm render is exactly the kind of
 * thing that is usually decorative. Every dimension here is a measurement:
 *
 *   height        echo top, from the WSR-88D storm attribute table (kft)
 *   core height   the height of maximum reflectivity, same source
 *   core strength max dBZ, same source
 *   base          lifting condensation level, derived from the surface
 *                 temperature and dewpoint Vane already has
 *   tilt          the 0–6 km shear vector, derived from pressure-level winds:
 *                 a sheared storm leans downshear, and that lean is the whole
 *                 reason a supercell's updraft and downdraft stay separated
 *   motion        the cell's own tracked motion vector
 *   sun           Meeus solar position for the location and moment
 *
 * There is no volumetric data behind this and the app does not pretend there
 * is. Only the 0.5° tilt is published as tiles; the higher tilts that would
 * let you actually reconstruct a storm's interior return 503 from every
 * keyless endpoint tried. So this is a *structure diagram at true scale*, not
 * a rendering of the radar volume — the silhouette is schematic, the numbers
 * driving it are not. The panel says so on screen.
 *
 * Two viewpoints matter and they are the same scene with the camera moved.
 * "From here" puts the camera at the chaser's position at eye height, which
 * answers the only question that matters for footage: what will this look
 * like through the lens. "Orbit" lifts it up and away so the geometry — the
 * lean, the core aloft, where the sun is, where you are — reads at a glance. */
(function (global) {
  'use strict';

  var U = global.U;
  var KFT_TO_KM = 0.3048;

  /* Vertical exaggeration. A supercell is genuinely about three times wider
   * than it is tall, so a true-scale render is a pancake you cannot read
   * structure off. Every operational 3D radar display exaggerates the vertical
   * for exactly this reason. The factor is applied in one place, so the height
   * ruler stretches with the storm and the two never disagree — and the panel
   * states the number rather than leaving the reader to infer scale from a
   * picture that does not have it. */
  var VERTICAL_EXAGGERATION = 2.5;

  /* ── Projection ─────────────────────────────────────────────────────── */

  /* World frame is east/north/up in kilometres, origin at the storm. The
   * camera orbits the origin at (azimuth, elevation, range); a perspective
   * divide does the rest. Hand-rolled because a matrix library for six
   * vertices is not worth a dependency the app would then have to vendor. */
  function camera(opts) {
    var az = U.toRad(opts.azimuth);
    var el = U.toRad(opts.elevation);
    var r = opts.range;
    // Camera position in world space.
    var cx = opts.targetE + r * Math.cos(el) * Math.sin(az);
    var cy = opts.targetN + r * Math.cos(el) * Math.cos(az);
    var cz = opts.targetU + r * Math.sin(el);

    // Basis: forward toward the target, right, and true up.
    var fx = opts.targetE - cx, fy = opts.targetN - cy, fz = opts.targetU - cz;
    var fl = Math.sqrt(fx * fx + fy * fy + fz * fz) || 1;
    fx /= fl; fy /= fl; fz /= fl;
    // right = forward × worldUp, normalised
    var rx = fy * 1 - fz * 0, ry = fz * 0 - fx * 1, rz = fx * 0 - fy * 0;
    rx = fy; ry = -fx; rz = 0;
    var rl = Math.sqrt(rx * rx + ry * ry) || 1;
    rx /= rl; ry /= rl;
    // up = right × forward
    var ux = ry * fz - rz * fy;
    var uy = rz * fx - rx * fz;
    var uz = rx * fy - ry * fx;

    return {
      pos: [cx, cy, cz],
      fwd: [fx, fy, fz],
      right: [rx, ry, rz],
      up: [ux, uy, uz],
      fov: opts.fov || 45
    };
  }

  function project(cam, p, W, H) {
    var dx = p[0] - cam.pos[0], dy = p[1] - cam.pos[1], dz = p[2] - cam.pos[2];
    var depth = dx * cam.fwd[0] + dy * cam.fwd[1] + dz * cam.fwd[2];
    if (depth <= 0.05) return null;                        // behind the camera
    var sx = dx * cam.right[0] + dy * cam.right[1] + dz * cam.right[2];
    var sy = dx * cam.up[0] + dy * cam.up[1] + dz * cam.up[2];
    var f = (H / 2) / Math.tan(U.toRad(cam.fov) / 2);
    return { x: W / 2 + (sx * f) / depth, y: H / 2 - (sy * f) / depth, depth: depth };
  }

  /* ── The storm body ─────────────────────────────────────────────────── */

  /* Built from the radar image itself. js/reflectivity.js reads the real 0.5°
   * reflectivity field out of the tiles and inverts every pixel to dBZ through
   * IEM's published colour table, so the plan view here is the actual echo —
   * the hook, the notch, the ragged forward flank — rather than a circle.
   *
   * The vertical is the modelled part, and it is anchored on two measurements
   * rather than invented: the column under the strongest return reaches the
   * measured echo top, and everything weaker is proportionally shallower down
   * to a floor. Columns lean downshear with height by the derived shear
   * vector, which is why a sheared storm's anvil sits displaced from its base.
   *
   * That split — measured footprint, measured extremes, modelled distribution
   * between them — is stated in the panel rather than left for the reader to
   * assume one way or the other. */

  var DBZ_FLOOR = 15;          // absolute floor: below this is drizzle and clutter

  /* The drawn floor is relative to what this storm is actually producing, not
   * a fixed number. A 70 dBZ supercell and a 35 dBZ shower both have a shape
   * worth seeing, and a fixed 15 dBZ cut renders the second one as a handful
   * of scattered blocks. Taking the top 35 dB of whatever is present keeps the
   * echo's outline intact at either end of the scale. */
  function floorFor(field) {
    return Math.max(DBZ_FLOOR, field.maxDbz - 35);
  }

  function columns(model, field) {
    if (!field || !field.grid) return [];
    var out = [];
    var n = field.size;
    var span = field.halfKm * 2;
    var DBZ_FLOOR = floorFor(field);
    var top = Math.max(field.maxDbz, DBZ_FLOOR + 1);

    for (var j = 0; j < n; j++) {
      for (var i = 0; i < n; i++) {
        var dbz = field.grid[j][i];
        if (dbz === null || dbz < DBZ_FLOOR) continue;

        // Grid node -> local east/north km. Row 0 is the north edge.
        var e = -field.halfKm + span * (i / (n - 1));
        var nn = field.halfKm - span * (j / (n - 1));

        var frac = (dbz - DBZ_FLOOR) / (top - DBZ_FLOOR);
        frac = Math.max(0.04, Math.min(1, frac));
        var h = model.baseKm + (model.topKm - model.baseKm) * frac;
        var lean = (h - model.baseKm) * model.tiltPerKm;

        out.push({
          e: e, n: nn, dbz: dbz,
          z0: model.baseKm,
          z1: h,
          le: model.shearEast * lean,
          ln: model.shearNorth * lean
        });
      }
    }
    return out;
  }

  /* The fallback silhouette's geometry: a stack of horizontal slabs from cloud
   * base to echo top, each offset downshear in proportion to its height, with a
   * radius profile that widens into the anvil. Used only when the reflectivity
   * field could not be read — see drawStorm below. */
  function slabs(model, n) {
    n = n || 18;
    var out = [];
    var baseKm = model.baseKm;
    var topKm = model.topKm;
    if (topKm <= baseKm) return out;

    for (var i = 0; i <= n; i++) {
      var t = i / n;                              // 0 at base, 1 at top
      var z = baseKm + (topKm - baseKm) * t;
      var coreT = model.coreFraction === null ? 0.6 : model.coreFraction;
      var rad;
      if (t < coreT) rad = 0.55 + 0.55 * (t / Math.max(coreT, 0.01));
      else rad = 1.1 + 1.5 * Math.pow((t - coreT) / Math.max(1 - coreT, 0.01), 1.7);
      rad *= model.widthKm / 2.2;

      var lean = (z - baseKm) * model.tiltPerKm;
      out.push({ z: z, r: rad, e: model.shearEast * lean, n: model.shearNorth * lean, t: t });
    }
    return out;
  }

  /* Build the physical model of the storm from measurements. Kept separate
   * from drawing so it can be asserted in the test suite without a canvas. */
  function model(cell, env) {
    env = env || {};
    var topKm = (cell.top || 0) * KFT_TO_KM;
    var coreKm = (cell.maxDbzHeight || 0) * KFT_TO_KM;
    // Cloud base: the LCL if the environment gives us one, otherwise a plain
    // convective default rather than an invented precision.
    var baseKm = env.lclKm !== undefined && env.lclKm !== null
      ? env.lclKm : Math.min(1.5, topKm * 0.12);
    if (baseKm >= topKm) baseKm = topKm * 0.1;

    // Shear direction as a unit vector, and how hard the storm leans. 30 m/s
    // of deep-layer shear is a strongly tilted updraft; zero is a pulse storm
    // standing straight up and collapsing into itself.
    var se = 0, sn = 0, shear = env.shearMs || 0;
    if (env.shearEast !== undefined && env.shearNorth !== undefined) {
      var mag = Math.sqrt(env.shearEast * env.shearEast + env.shearNorth * env.shearNorth) || 1;
      se = env.shearEast / mag;
      sn = env.shearNorth / mag;
    }
    var tiltPerKm = Math.min(0.55, shear / 60);

    return {
      topKm: topKm,
      coreKm: coreKm,
      baseKm: baseKm,
      coreFraction: topKm > 0 ? coreKm / topKm : null,
      widthKm: Math.max(6, topKm * 0.85),
      shearEast: se,
      shearNorth: sn,
      shearMs: shear,
      tiltPerKm: tiltPerKm,
      maxDbz: cell.maxDbz || 0,
      vilDensity: cell.vilDensity,
      hasLcl: env.lclKm !== undefined && env.lclKm !== null
    };
  }

  /* ── Drawing ────────────────────────────────────────────────────────── */

  var state = { azimuth: 210, elevation: 12, zoom: 1, mode: 'orbit' };

  function ringPoints(slab, segments) {
    var pts = [];
    for (var i = 0; i < segments; i++) {
      var a = (i / segments) * Math.PI * 2;
      pts.push([slab.e + slab.r * Math.cos(a), slab.n + slab.r * Math.sin(a), slab.z]);
    }
    return pts;
  }

  function render(canvas, cell, env, opts) {
    opts = opts || {};
    var ctx = canvas.getContext('2d');
    var dpr = global.devicePixelRatio || 1;
    var W = canvas.clientWidth || 640;
    var H = canvas.clientHeight || 380;
    canvas.width = W * dpr; canvas.height = H * dpr;
    ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    ctx.clearRect(0, 0, W, H);

    var m = model(cell, env);
    if (!m.topKm) return null;

    var observerE = opts.observerE || 0, observerN = opts.observerN || 0;
    var cam;
    if (opts.mode === 'observer') {
      // Eye height, looking at the middle of the storm from where you stand.
      var dist = Math.sqrt(observerE * observerE + observerN * observerN) || 20;
      var azToStorm = (Math.atan2(-observerE, -observerN) * 180 / Math.PI + 360) % 360;

      /* Field of view is chosen to frame the storm, not fixed — which is the
       * whole point of the view. At 200 km a 28 kft tower subtends about two
       * degrees; rendering it at a fixed 42° gives a technically correct and
       * completely useless speck. Framing it instead makes this a preview
       * through the lens the read-out is recommending, and the focal length is
       * reported so the relationship is explicit rather than hidden. */
      var subtend = 2 * Math.atan2(m.topKm * VERTICAL_EXAGGERATION / 2, dist) * 180 / Math.PI;
      // Pinch and wheel work in the observer view too, by changing the lens
      // rather than the distance — you cannot walk closer to a storm 60 km
      // away, but you can put a longer lens on.
      var fov = Math.max(2, Math.min(70, subtend / 0.62 / (state.zoom || 1)));
      m.observerFovDeg = fov;
      m.observerFocalMm = 18 / Math.tan(U.toRad(fov / 2));
      m.observerDistanceKm = dist;

      cam = camera({
        azimuth: (azToStorm + 180) % 360,
        elevation: Math.atan2(m.topKm * 0.45 - 0.002, dist) * 180 / Math.PI,
        range: dist,
        targetE: 0, targetN: 0, targetU: m.topKm * 0.45 * VERTICAL_EXAGGERATION,
        fov: fov
      });
    } else {
      // Framed on the echo when there is one: a storm 80 km across does not
      // fit in a camera placed for a 14 km tower, and half of it ends up
      // outside the canvas.
      var extentKm = opts.field ? opts.field.halfKm : m.topKm * 1.2;
      cam = camera({
        azimuth: state.azimuth,
        elevation: state.elevation,
        range: Math.max(34, extentKm * 3.1) / (state.zoom || 1),
        targetE: 0, targetN: 0, targetU: m.topKm * 0.34 * VERTICAL_EXAGGERATION,
        fov: 42
      });
    }

    // Applied at projection time: everything in the scene — storm, ruler,
    // sight line, sun — is stretched by the same factor, so the ruler remains
    // a correct reading of the geometry it sits beside.
    var vx = opts.exaggeration === undefined ? VERTICAL_EXAGGERATION : opts.exaggeration;
    m.exaggeration = vx;
    var P = function (p) { return project(cam, [p[0], p[1], p[2] * vx], W, H); };

    drawGround(ctx, P, m, W, H, opts);
    if (opts.field) {
      m.fromRadar = true;
      m.coverage = opts.field.coverage;
      drawField(ctx, P, m, opts.field, cam, opts);
    } else {
      m.fromRadar = false;
      drawStorm(ctx, P, m, opts);
      drawCore(ctx, P, m);
    }
    drawScale(ctx, P, m, opts);
    if (opts.mode !== 'observer') drawObserver(ctx, P, observerE, observerN, m);
    drawSun(ctx, P, m, opts);
    drawMotion(ctx, P, cell, m);

    return m;
  }

  // A ground grid at 10 km spacing gives the whole scene its sense of scale;
  // without it a storm render is just an abstract shape.
  function drawGround(ctx, P, m, W, H, opts) {
    var half = Math.max(40, m.topKm * 3);
    var step = 10;
    ctx.lineWidth = 1;
    for (var g = -half; g <= half; g += step) {
      strokeLine(ctx, P, [g, -half, 0], [g, half, 0], 'rgba(255,255,255,0.07)');
      strokeLine(ctx, P, [-half, g, 0], [half, g, 0], 'rgba(255,255,255,0.07)');
    }
    // Cardinal spokes, so orientation is never ambiguous while orbiting.
    strokeLine(ctx, P, [0, 0, 0], [0, half, 0], 'rgba(255,255,255,0.22)');
    strokeLine(ctx, P, [0, 0, 0], [half, 0, 0], 'rgba(255,255,255,0.13)');
    label(ctx, P([0, half, 0]), 'N', 'rgba(255,255,255,0.5)');
    label(ctx, P([half, 0, 0]), 'E', 'rgba(255,255,255,0.32)');
  }

  /* Painter's algorithm over the sampled columns: far to near, so nearer
   * returns occlude the ones behind them. Each column is drawn as a lit top
   * face plus the two side faces that can be seen from this camera, which is
   * enough to read depth without the cost of a real z-buffer. */
  function drawField(ctx, P, m, field, cam, opts) {
    var cols = columns(m, field);
    if (!cols.length) { drawStorm(ctx, P, m, opts); drawCore(ctx, P, m); return; }

    var half = field.kmPerCell * 0.58;
    var sunAz = opts.sunAzimuth === undefined ? 225 : opts.sunAzimuth;
    var sunUp = opts.sunAltitude === undefined ? 20 : opts.sunAltitude;
    var lit = sunUp > -6;

    cols.forEach(function (c) {
      var dx = c.e - cam.pos[0], dy = c.n - cam.pos[1];
      c.depth = dx * dx + dy * dy;
    });
    cols.sort(function (a, b) { return b.depth - a.depth; });

    for (var k = 0; k < cols.length; k++) {
      var c = cols[k];
      var col = global.Reflectivity.colourFor(c.dbz);
      // Top face, displaced downshear; the base stays put.
      var tx = c.e + c.le, ty = c.n + c.ln;

      var topQuad = [
        P([tx - half, ty - half, c.z1]), P([tx + half, ty - half, c.z1]),
        P([tx + half, ty + half, c.z1]), P([tx - half, ty + half, c.z1])
      ];
      if (topQuad.some(function (q) { return !q; })) continue;

      // Sides: only the two facing the camera are worth drawing.
      var sides = [];
      if (cam.pos[1] < c.n) {
        sides.push([[c.e - half, c.n - half, c.z0], [c.e + half, c.n - half, c.z0],
                    [tx + half, ty - half, c.z1], [tx - half, ty - half, c.z1]]);
      } else {
        sides.push([[c.e - half, c.n + half, c.z0], [c.e + half, c.n + half, c.z0],
                    [tx + half, ty + half, c.z1], [tx - half, ty + half, c.z1]]);
      }
      if (cam.pos[0] < c.e) {
        sides.push([[c.e - half, c.n - half, c.z0], [c.e - half, c.n + half, c.z0],
                    [tx - half, ty + half, c.z1], [tx - half, ty - half, c.z1]]);
      } else {
        sides.push([[c.e + half, c.n - half, c.z0], [c.e + half, c.n + half, c.z0],
                    [tx + half, ty + half, c.z1], [tx + half, ty - half, c.z1]]);
      }

      // Sides are shaded relative to the sun so the tower reads as solid; the
      // top keeps the true ramp colour so it still matches the radar legend.
      var shade = lit ? 0.62 : 0.5;
      sides.forEach(function (quad) {
        var pts = quad.map(P);
        if (pts.some(function (q) { return !q; })) return;
        fillPoly(ctx, pts, 'rgba(' + Math.round(col.r * shade) + ',' +
          Math.round(col.g * shade) + ',' + Math.round(col.b * shade) + ',0.92)');
      });
      fillPoly(ctx, topQuad, 'rgb(' + col.r + ',' + col.g + ',' + col.b + ')');
    }
  }

  function fillPoly(ctx, pts, fill) {
    ctx.beginPath();
    ctx.moveTo(pts[0].x, pts[0].y);
    for (var i = 1; i < pts.length; i++) ctx.lineTo(pts[i].x, pts[i].y);
    ctx.closePath();
    ctx.fillStyle = fill;
    ctx.fill();
  }

  /* Fallback silhouette, used only when the reflectivity field could not be
   * read — offline, outside NEXRAD coverage, or a tile host that stopped
   * sending CORS headers. Drawn back to front as stacked rings. Colour runs from the warm
   * sunlit side to the shadowed side using the real solar azimuth, which is
   * the one piece of styling that is also information: it shows you which
   * flank will be lit when you get there. */
  function drawStorm(ctx, P, m, opts) {
    var st = slabs(m, 20);
    var sunAz = opts.sunAzimuth === undefined ? 225 : opts.sunAzimuth;
    var sunUp = opts.sunAltitude === undefined ? 20 : opts.sunAltitude;
    var lit = sunUp > -6;
    var segs = 26;

    for (var i = 0; i < st.length - 1; i++) {
      var a = st[i], b = st[i + 1];
      var ra = ringPoints(a, segs), rb = ringPoints(b, segs);
      for (var j = 0; j < segs; j++) {
        var k = (j + 1) % segs;
        var quad = [P(ra[j]), P(ra[k]), P(rb[k]), P(rb[j])];
        if (quad.some(function (q) { return !q; })) continue;

        // Facet normal azimuth, for the lighting term.
        var faceAz = ((j + 0.5) / segs) * 360;
        var gap = Math.abs(((faceAz - sunAz) % 360 + 360) % 360);
        if (gap > 180) gap = 360 - gap;
        var shade = lit ? 0.30 + 0.62 * (1 - gap / 180) : 0.26;

        // Anvil thins out; the base is the densest part of the tower.
        var alpha = 0.045 + 0.10 * (1 - a.t) + (a.t > 0.82 ? 0.02 : 0);
        var warm = lit && sunUp < 12 ? 1 : 0;
        var r = Math.round(255 * shade * (warm ? 1 : 0.86));
        var g = Math.round(255 * shade * (warm ? 0.86 : 0.90));
        var bl = Math.round(255 * shade * (warm ? 0.78 : 1));

        ctx.beginPath();
        ctx.moveTo(quad[0].x, quad[0].y);
        for (var q = 1; q < 4; q++) ctx.lineTo(quad[q].x, quad[q].y);
        ctx.closePath();
        ctx.fillStyle = 'rgba(' + r + ',' + g + ',' + bl + ',' + alpha.toFixed(3) + ')';
        ctx.fill();
      }
    }

    // Base disc, drawn solid: this is the part a chaser is actually looking at.
    var base = st[0];
    if (base) {
      var ring = ringPoints(base, segs).map(P);
      if (!ring.some(function (p) { return !p; })) {
        ctx.beginPath();
        ctx.moveTo(ring[0].x, ring[0].y);
        ring.slice(1).forEach(function (p) { ctx.lineTo(p.x, p.y); });
        ctx.closePath();
        ctx.fillStyle = 'rgba(10,14,22,0.55)';
        ctx.fill();
        ctx.strokeStyle = 'rgba(255,255,255,0.30)';
        ctx.lineWidth = 1.2;
        ctx.stroke();
      }
    }
  }

  /* The reflectivity core at its measured height, as a bright band. Where this
   * sits relative to the tower is the single most diagnostic thing in the
   * picture: held high means a strong updraft, collapsed to the base means
   * the storm is raining itself out. */
  function drawCore(ctx, P, m) {
    var frac = m.coreFraction;
    if (frac === null || !isFinite(frac)) return;
    var z = m.baseKm + (m.topKm - m.baseKm) * Math.max(0, Math.min(1, frac));
    var lean = (z - m.baseKm) * m.tiltPerKm;
    var slab = { z: z, r: m.widthKm / 2.4, e: m.shearEast * lean, n: m.shearNorth * lean, t: frac };
    var ring = ringPoints(slab, 30).map(P);
    if (ring.some(function (p) { return !p; })) return;

    ctx.beginPath();
    ctx.moveTo(ring[0].x, ring[0].y);
    ring.slice(1).forEach(function (p) { ctx.lineTo(p.x, p.y); });
    ctx.closePath();
    // Warmer as the core gets stronger, on the same intuition as a dBZ ramp.
    var hot = Math.max(0, Math.min(1, (m.maxDbz - 40) / 25));
    ctx.fillStyle = 'rgba(' + Math.round(255) + ',' + Math.round(210 - 130 * hot) + ',' + Math.round(90 - 80 * hot) + ',0.30)';
    ctx.fill();
    ctx.strokeStyle = 'rgba(255,' + Math.round(200 - 120 * hot) + ',80,0.85)';
    ctx.lineWidth = 1.6;
    ctx.stroke();
  }

  // A vertical ruler in kft, because that is the unit the attribute table and
  // every chaser conversation use.
  function drawScale(ctx, P, m, opts) {
    var x = -m.widthKm * 1.5;
    var topKft = m.topKm / KFT_TO_KM;
    strokeLine(ctx, P, [x, 0, 0], [x, 0, m.topKm], 'rgba(255,255,255,0.28)');
    for (var kft = 0; kft <= topKft; kft += 10) {
      var z = kft * KFT_TO_KM;
      strokeLine(ctx, P, [x, 0, z], [x + m.widthKm * 0.10, 0, z], 'rgba(255,255,255,0.28)');
      var p = P([x - m.widthKm * 0.06, 0, z]);
      if (p) label(ctx, p, kft + ' kft', 'rgba(255,255,255,0.45)', 'right');
    }
    var tp = P([x, 0, m.topKm]);
    if (tp) label(ctx, tp, Math.round(topKft) + ' kft top', 'rgba(255,255,255,0.8)', 'right', 600);
  }

  function drawObserver(ctx, P, e, n, m) {
    var p = P([e, n, 0]);
    if (!p) return;
    ctx.beginPath();
    ctx.arc(p.x, p.y, 4.5, 0, Math.PI * 2);
    ctx.fillStyle = '#7fd3ff';
    ctx.fill();
    ctx.strokeStyle = 'rgba(255,255,255,0.85)';
    ctx.lineWidth = 1.4;
    ctx.stroke();
    label(ctx, { x: p.x + 8, y: p.y + 4 }, 'you', '#7fd3ff', 'left', 600);
    // Line of sight to the base, which is what the lens will actually see.
    strokeLine(ctx, P, [e, n, 0], [0, 0, m.baseKm], 'rgba(127,211,255,0.45)');
  }

  /* The sun as a direction, drawn at the storm's own scale. Whether this
   * arrow points toward the camera or away from it is exactly the difference
   * between a silhouette and a lit tower. */
  function drawSun(ctx, P, m, opts) {
    if (opts.sunAltitude === undefined || opts.sunAltitude < -6) return;
    var az = U.toRad(opts.sunAzimuth), al = U.toRad(Math.max(2, opts.sunAltitude));
    var d = m.topKm * 2.6;
    var e = d * Math.cos(al) * Math.sin(az);
    var n = d * Math.cos(al) * Math.cos(az);
    var z = d * Math.sin(al) + m.topKm * 0.3;
    var p = P([e, n, z]);
    if (!p) return;
    var glow = ctx.createRadialGradient(p.x, p.y, 0, p.x, p.y, 26);
    glow.addColorStop(0, 'rgba(255,206,120,0.95)');
    glow.addColorStop(1, 'rgba(255,206,120,0)');
    ctx.fillStyle = glow;
    ctx.beginPath(); ctx.arc(p.x, p.y, 26, 0, Math.PI * 2); ctx.fill();
    label(ctx, { x: p.x, y: p.y - 20 }, 'sun', 'rgba(255,206,120,0.95)', 'center', 600);
  }

  function drawMotion(ctx, P, cell, m) {
    var mv = global.Cells.motionVector(cell);
    var mag = Math.sqrt(mv.east * mv.east + mv.north * mv.north);
    if (mag < 1) return;
    var len = Math.max(12, m.topKm * 1.5);
    var e = (mv.east / mag) * len, n = (mv.north / mag) * len;
    strokeLine(ctx, P, [0, 0, 0], [e, n, 0], 'rgba(255,157,178,0.9)', 2);
    var tip = P([e, n, 0]);
    if (tip) label(ctx, { x: tip.x + 6, y: tip.y }, Math.round(cell.speedKt) + ' kt', 'rgba(255,157,178,0.95)', 'left', 600);
  }

  /* ── Helpers ────────────────────────────────────────────────────────── */

  function strokeLine(ctx, P, a, b, colour, width) {
    var pa = P(a), pb = P(b);
    if (!pa || !pb) return;
    ctx.beginPath();
    ctx.moveTo(pa.x, pa.y);
    ctx.lineTo(pb.x, pb.y);
    ctx.strokeStyle = colour;
    ctx.lineWidth = width || 1;
    ctx.stroke();
  }

  function label(ctx, p, text, colour, align, weight) {
    if (!p) return;
    ctx.fillStyle = colour;
    ctx.font = (weight || 400) + ' 11px ui-monospace, Menlo, Consolas, monospace';
    ctx.textAlign = align || 'center';
    ctx.fillText(text, p.x, p.y);
    ctx.textAlign = 'left';
  }

  function orbit(dAz, dEl) {
    state.azimuth = (state.azimuth + dAz + 360) % 360;
    state.elevation = Math.max(-4, Math.min(72, state.elevation + dEl));
  }

  function zoom(factor) {
    state.zoom = Math.max(0.45, Math.min(2.6, (state.zoom || 1) * factor));
  }

  /* ── Touch and drag ─────────────────────────────────────────────────── */

  /* Buttons alone are not a 3D control. Anyone who has used a mapping or
   * modelling tool reaches for the object and drags it, and on a phone that
   * is the only gesture that feels like anything. Pointer events cover mouse,
   * pen and touch in one path; a second finger pinches to zoom.
   *
   * `touch-action: none` on the canvas is required, or the browser claims the
   * drag for page scrolling and the model never moves. That is a real trade —
   * it means a finger starting on the canvas cannot scroll the page — so it
   * is scoped to the canvas alone and the surrounding card scrolls normally. */
  function attach(canvas, onChange) {
    if (!canvas || canvas.__vaneOrbit) return;
    canvas.__vaneOrbit = true;
    canvas.style.touchAction = 'none';

    var points = {};        // active pointers by id
    var last = null;        // last single-pointer position
    var lastPinch = null;   // last two-finger separation

    function positions() {
      return Object.keys(points).map(function (k) { return points[k]; });
    }

    canvas.addEventListener('pointerdown', function (e) {
      points[e.pointerId] = { x: e.clientX, y: e.clientY };
      if (canvas.setPointerCapture) {
        try { canvas.setPointerCapture(e.pointerId); } catch (err) { /* not capturable */ }
      }
      last = { x: e.clientX, y: e.clientY };
      lastPinch = null;
      canvas.classList.add('dragging');
    });

    canvas.addEventListener('pointermove', function (e) {
      if (!points[e.pointerId]) return;
      points[e.pointerId] = { x: e.clientX, y: e.clientY };
      var p = positions();

      if (p.length >= 2) {
        var dx = p[0].x - p[1].x, dy = p[0].y - p[1].y;
        var sep = Math.sqrt(dx * dx + dy * dy);
        if (lastPinch) zoom(sep / lastPinch);
        lastPinch = sep;
        last = null;
      } else if (last) {
        // A drag across the full canvas width sweeps most of a full turn,
        // which is roughly what a map or a 3D viewer does.
        orbit((e.clientX - last.x) * -0.45, (e.clientY - last.y) * 0.28);
        last = { x: e.clientX, y: e.clientY };
      }
      if (onChange) onChange();
      e.preventDefault();
    });

    function end(e) {
      delete points[e.pointerId];
      if (!positions().length) { last = null; canvas.classList.remove('dragging'); }
      lastPinch = null;
    }
    canvas.addEventListener('pointerup', end);
    canvas.addEventListener('pointercancel', end);
    canvas.addEventListener('pointerleave', end);

    // Wheel zooms, matching every other 3D view the user has ever used.
    canvas.addEventListener('wheel', function (e) {
      zoom(e.deltaY > 0 ? 1.08 : 1 / 1.08);
      if (onChange) onChange();
      e.preventDefault();
    }, { passive: false });
  }

  global.Storm3D = {
    render: render,
    model: model,
    columns: columns,
    floorFor: floorFor,
    VERTICAL_EXAGGERATION: VERTICAL_EXAGGERATION,
    DBZ_FLOOR: DBZ_FLOOR,
    slabs: slabs,
    camera: camera,
    project: project,
    orbit: orbit,
    zoom: zoom,
    attach: attach,
    state: state,
    KFT_TO_KM: KFT_TO_KM
  };
})(window);
