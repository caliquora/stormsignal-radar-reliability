/* Vane — data layer. Every endpoint here is public and keyless.
 * Core forecast and Chase-only sounding data are separate requests so that
 * Simple mode never pays for pressure-level payloads it won't render. */
(function (global) {
  'use strict';

  var C = global.VaneConfig;

  function qs(params) {
    return Object.keys(params).map(function (k) {
      return encodeURIComponent(k) + '=' + encodeURIComponent(params[k]);
    }).join('&');
  }

  function getJSON(url, opts) {
    opts = opts || {};
    /* HTTP 429 is a minute-quota refusal, not a failure: the same request
     * a moment later succeeds. Every caller gets two patient retries, so a
     * heavy neighbour (the model chart's lattice) rate-limiting the API
     * costs other requests seconds, never an error banner. */
    var tries = opts.retries429 === undefined ? 2 : opts.retries429;
    function attempt(left) {
      var ctrl = typeof AbortController !== 'undefined' ? new AbortController() : null;
      var timer = ctrl ? setTimeout(function () { ctrl.abort(); }, opts.timeout || 15000) : null;
      return fetch(url, { signal: ctrl ? ctrl.signal : undefined, headers: opts.headers })
        .then(function (r) {
          if (timer) clearTimeout(timer);
          if (r.status === 429 && left > 0) {
            return new Promise(function (res) {
              setTimeout(res, left === tries ? 8000 : 20000);
            }).then(function () { return attempt(left - 1); });
          }
          if (!r.ok) throw new Error('HTTP ' + r.status + ' from ' + new URL(url).host);
          // The service worker stamps responses it serves from its offline cache.
          // Carry that through so the UI can say the data is stale instead of
          // presenting hours-old weather as current.
          var stamp = r.headers.get('X-Vane-Cached-At');
          return r.json().then(function (j) {
            if (stamp && j && typeof j === 'object') j.__cachedAt = parseInt(stamp, 10);
            return j;
          });
        })
        .catch(function (e) {
          if (timer) clearTimeout(timer);
          throw e.name === 'AbortError' ? new Error('Timed out contacting ' + new URL(url).host) : e;
        });
    }
    return attempt(tries);
  }

  /* ── Geocoding ───────────────────────────────────────────── */

  // Accepts "35.2,-97.4" directly so chasers can paste coordinates (F8).
  function parseCoords(text) {
    var m = /^\s*(-?\d{1,3}(?:\.\d+)?)\s*[, ]\s*(-?\d{1,3}(?:\.\d+)?)\s*$/.exec(text);
    if (!m) return null;
    var lat = parseFloat(m[1]), lon = parseFloat(m[2]);
    if (Math.abs(lat) > 90 || Math.abs(lon) > 180) return null;
    return { lat: lat, lon: lon, name: lat.toFixed(3) + ', ' + lon.toFixed(3), admin: 'Coordinates' };
  }

  function geocode(text) {
    var direct = parseCoords(text);
    if (direct) return Promise.resolve([direct]);
    return getJSON(C.OM_GEOCODE + '?' + qs({ name: text, count: 8, language: 'en', format: 'json' }))
      .then(function (j) {
        return (j.results || []).map(function (r) {
          return {
            lat: r.latitude, lon: r.longitude, name: r.name,
            admin: [r.admin1, r.country].filter(Boolean).join(', '),
            elevation: r.elevation
          };
        });
      });
  }

  /* ── Core forecast (Simple + Chase share this) ───────────── */

  var CURRENT = ['temperature_2m', 'apparent_temperature', 'relative_humidity_2m',
    'dew_point_2m', 'precipitation', 'weather_code', 'cloud_cover', 'pressure_msl',
    'surface_pressure', 'wind_speed_10m', 'wind_direction_10m', 'wind_gusts_10m', 'is_day'];

  var HOURLY = ['temperature_2m', 'apparent_temperature', 'precipitation_probability',
    'precipitation', 'weather_code', 'wind_speed_10m', 'wind_direction_10m',
    'wind_gusts_10m', 'relative_humidity_2m', 'dew_point_2m', 'visibility', 'uv_index',
    'cloud_cover'];

  var DAILY = ['weather_code', 'temperature_2m_max', 'temperature_2m_min', 'sunrise',
    'sunset', 'precipitation_sum', 'precipitation_probability_max', 'wind_speed_10m_max',
    'wind_gusts_10m_max', 'uv_index_max',
    // The day's weather regime, for the regime-aware microclimate fit.
    'cloud_cover_mean', 'wind_direction_10m_dominant'];

  function forecast(lat, lon) {
    return getJSON(C.OM_FORECAST + '?' + qs({
      latitude: lat.toFixed(4),
      longitude: lon.toFixed(4),
      current: CURRENT.join(','),
      minutely_15: 'precipitation,precipitation_probability,weather_code',
      hourly: HOURLY.join(','),
      daily: DAILY.join(','),
      // 16 days in one request: the 7-day card slices the front of it and the
      // extended outlook uses the whole thing, so the longer range costs no
      // extra round trip.
      forecast_days: C.OUTLOOK.DAYS,
      forecast_minutely_15: 12,          // 12 × 15 min = 3 h, covers the 2 h nowcast
      timezone: 'auto',
      wind_speed_unit: 'ms',             // SI internally — see util.js
      temperature_unit: 'celsius',
      precipitation_unit: 'mm'
    }));
  }

  /* ── Chase-only: convective + pressure-level winds ───────── */

  function sounding(lat, lon) {
    var vars = ['cape', 'convective_inhibition', 'lifted_index',
      'freezing_level_height', 'boundary_layer_height'];
    C.LEVELS.forEach(function (p) {
      vars.push('wind_speed_' + p + 'hPa', 'wind_direction_' + p + 'hPa',
        'geopotential_height_' + p + 'hPa', 'temperature_' + p + 'hPa');
    });
    return getJSON(C.OM_FORECAST + '?' + qs({
      latitude: lat.toFixed(4),
      longitude: lon.toFixed(4),
      hourly: vars.join(','),
      // Two days: tomorrow evening's environment feeds the chase-day odds.
      forecast_hours: 48,
      timezone: 'auto',
      wind_speed_unit: 'ms',
      temperature_unit: 'celsius'
      // No `elevation` override: passing elevation=nan makes the endpoint hang
      // rather than return. The response carries the model surface elevation
      // used for AGL heights anyway.
    }));
  }

  /* ── Vane Storm Odds inputs (js/stormodds.js) ───────────────
   * The hourly environment the model reads — CAPE, CIN, lifted index,
   * dewpoint, precipitable water, wind at 10 m / 850 / 500 hPa — at one
   * point (the Vane AI card) or many at once (the map layer). UTC times. */
  function stormEnv(points, hours) {
    if (!points.length) return Promise.resolve([]);
    return getJSON(C.OM_FORECAST + '?' + qs({
      latitude: points.map(function (p) { return p.lat.toFixed(3); }).join(','),
      longitude: points.map(function (p) { return p.lon.toFixed(3); }).join(','),
      hourly: global.StormOdds.HOURLY_VARS.join(','),
      forecast_hours: hours || 12,
      timezone: 'UTC',
      wind_speed_unit: 'ms',
      temperature_unit: 'celsius'
    })).then(function (j) {
      return (Array.isArray(j) ? j : [j]).map(function (r) {
        return { lat: r.latitude, lon: r.longitude, hourly: r.hourly };
      });
    });
  }

  /* ── Extended outlook: ensemble members + local normals ─── */

  /* The ensemble endpoint returns one series per member, named
   * `temperature_2m_max_member01` … `_member50`, plus the control run under the
   * bare name. Reshaped here into `{ day: [values across members] }` so nothing
   * downstream has to know about the naming. */
  function ensembleDaily(lat, lon) {
    var O = C.OUTLOOK;
    return getJSON(C.OM_ENSEMBLE + '?' + qs({
      latitude: lat.toFixed(4),
      longitude: lon.toFixed(4),
      daily: 'temperature_2m_max,temperature_2m_min,precipitation_sum',
      models: O.MODEL,
      forecast_days: O.DAYS,
      timezone: 'auto',
      temperature_unit: 'celsius',
      precipitation_unit: 'mm'
    }), { timeout: 25000 }).then(function (j) {
      var d = j.daily || {};
      function members(base) {
        var keys = Object.keys(d).filter(function (k) {
          return k === base || k.indexOf(base + '_member') === 0;
        });
        return (d.time || []).map(function (_, i) {
          var out = [];
          keys.forEach(function (k) {
            var v = d[k][i];
            // Trailing days are ragged: not every member runs the full length.
            if (v !== null && v !== undefined && !isNaN(v)) out.push(v);
          });
          return out;
        });
      }
      return {
        model: O.MODEL,
        time: d.time || [],
        utcOffsetSeconds: j.utc_offset_seconds || 0,
        tmax: members('temperature_2m_max'),
        tmin: members('temperature_2m_min'),
        precip: members('precipitation_sum')
      };
    });
  }

  // Twenty years of ERA5 daily values at this point. ~200 KB, so it is fetched
  // once per location and only when the outlook is actually opened.
  function normals(lat, lon) {
    var O = C.OUTLOOK;
    var end = new Date(Date.now() - 10 * 86400000);   // ERA5 lags real time
    var endYear = end.getUTCFullYear() - 1;
    return getJSON(C.OM_ARCHIVE + '?' + qs({
      latitude: lat.toFixed(4),
      longitude: lon.toFixed(4),
      start_date: (endYear - O.NORMAL_YEARS + 1) + '-01-01',
      end_date: endYear + '-12-31',
      daily: 'temperature_2m_max,temperature_2m_min,precipitation_sum',
      timezone: 'auto',
      temperature_unit: 'celsius',
      precipitation_unit: 'mm'
    }), { timeout: 30000 }).then(function (j) {
      var d = j.daily || {};
      return {
        years: O.NORMAL_YEARS,
        from: (endYear - O.NORMAL_YEARS + 1),
        to: endYear,
        time: d.time || [],
        tmax: d.temperature_2m_max || [],
        tmin: d.temperature_2m_min || [],
        precip: d.precipitation_sum || []
      };
    });
  }

  /* ── NWS: alerts + nearest real observation (US only) ────── */

  function alertsWithStatus(lat, lon) {
    var url = C.NWS_BASE + '/alerts/active?' + qs({ point: lat.toFixed(4) + ',' + lon.toFixed(4) });
    return getJSON(url, { headers: { Accept: 'application/geo+json' } })
      .then(function (j) {
        var list = (j.features || []).map(function (f) {
          var p = f.properties || {};
          return {
            id: f.id,
            sent: p.sent,
            messageType: p.messageType,
            event: p.event,
            severity: p.severity || 'Unknown',
            urgency: p.urgency,
            certainty: p.certainty,
            headline: p.headline,
            description: p.description,
            instruction: p.instruction,
            sender: p.senderName,
            onset: p.onset || p.effective,
            expires: p.ends || p.expires,
            geometry: f.geometry
          };
        }).sort(function (a, b) {
          return (C.ALERT_RANK[b.severity] || 0) - (C.ALERT_RANK[a.severity] || 0);
        });
        return { alerts: list, available: true, stale: !!j.__cachedAt,
          receivedAt: j.__cachedAt || Date.now() };
      })
      .catch(function () { return { alerts: [], available: false, stale: false, receivedAt: null }; });
  }

  function alerts(lat, lon) {
    return alertsWithStatus(lat, lon).then(function (r) { return r.alerts; });
  }

  // Warning polygons for the whole visible map, not just the point (F7).
  function alertsInArea() {
    return getJSON(C.NWS_BASE + '/alerts/active?status=actual&message_type=alert',
      { headers: { Accept: 'application/geo+json' } })
      .then(function (j) { return (j.features || []).filter(function (f) { return f.geometry; }); })
      .catch(function () { return []; });
  }

  // F6: users trust observations over model output. Fetch the real thing and
  // let the UI label it as such.
  function observation(lat, lon) {
    return getJSON(C.NWS_BASE + '/points/' + lat.toFixed(4) + ',' + lon.toFixed(4))
      .then(function (pt) {
        var url = pt.properties && pt.properties.observationStations;
        if (!url) throw new Error('no stations');
        return getJSON(url);
      })
      .then(function (st) {
        var first = st.features && st.features[0];
        if (!first) throw new Error('no station');
        var id = first.properties.stationIdentifier;
        var name = first.properties.name;
        return getJSON(C.NWS_BASE + '/stations/' + id + '/observations/latest')
          .then(function (o) {
            var p = o.properties || {};
            return {
              station: id,
              name: name,
              lat: first.geometry && first.geometry.coordinates[1],
              lon: first.geometry && first.geometry.coordinates[0],
              cached: !!o.__cachedAt,
              time: p.timestamp,
              temperature: p.temperature && p.temperature.value,
              dewpoint: p.dewpoint && p.dewpoint.value,
              windSpeed: p.windSpeed && p.windSpeed.value !== null
                ? p.windSpeed.value / 3.6 : null,          // km/h → m/s
              windDirection: p.windDirection && p.windDirection.value,
              windGust: p.windGust && p.windGust.value !== null ? p.windGust.value / 3.6 : null,
              visibility: p.visibility && p.visibility.value,
              text: p.textDescription,
              /* The structured present-weather groups. This is what says
               * whether it is actually raining on the ground, which no model
               * field can tell you — it is the observation the nowcast
               * reconciles itself against. */
              presentWeather: p.presentWeather || [],
              raw: p.rawMessage
            };
          });
      })
      .catch(function () { return null; });   // non-US or station outage
  }

  /* One station's real day, as its own METARs measured it: every
   * observation in the window, reduced to the true daily extremes. This is
   * the ground truth the local scorecard verifies each agency against —
   * a thermometer, not another model's opinion of the day. */
  function stationDayExtremes(stationId, startISO, endISO) {
    return getJSON(C.NWS_BASE + '/stations/' + stationId + '/observations?' + qs({
      start: startISO, end: endISO, limit: 250
    })).then(function (j) {
      var hi = -Infinity, lo = Infinity, n = 0;
      (j.features || []).forEach(function (f) {
        var t = f.properties && f.properties.temperature && f.properties.temperature.value;
        if (t === null || t === undefined) return;
        n++;
        if (t > hi) hi = t;
        if (t < lo) lo = t;
      });
      return n ? { hi: hi, lo: lo, n: n } : null;
    });
  }

  /* ── The same ground truth, outside the US ─────────────────
   *
   * weather.gov only knows American stations, so abroad the scorecard used
   * to have nothing to verify against and silently never filled. METARs
   * are global, and Iowa State archives them all. Finding the nearest one
   * takes two hops: the network directory (one ASOS network per country,
   * each with the bounding box of its stations — cached for a month, it is
   * ~200 KB), then the stations of the networks whose box holds the pin. */

  var NET_KEY = 'vane.iemnets.v1', NET_TTL = 30 * 86400000;
  var STN_KEY = 'vane.metarstation.v1';
  var METAR_MAX_KM = 50;          // farther than this is not "your" station

  /* PostGIS hands extents over as hex EWKB polygons: byte order, type,
   * SRID, ring count, point count, then little-endian x/y doubles. */
  function ewkbBox(hex) {
    if (!hex || hex.length < 34) return null;
    var bytes = new Uint8Array(hex.length / 2);
    for (var i = 0; i < bytes.length; i++) bytes[i] = parseInt(hex.substr(i * 2, 2), 16);
    var dv = new DataView(bytes.buffer), le = bytes[0] === 1;
    var n = dv.getUint32(13, le), w = Infinity, s = Infinity, e = -Infinity, nn = -Infinity;
    for (var k = 0; k < n && 17 + 16 * k + 16 <= bytes.length; k++) {
      var x = dv.getFloat64(17 + 16 * k, le), y = dv.getFloat64(25 + 16 * k, le);
      if (x < w) w = x; if (x > e) e = x; if (y < s) s = y; if (y > nn) nn = y;
    }
    return w === Infinity ? null : [w, s, e, nn];
  }

  function iemNetworks() {
    try {
      var c = JSON.parse(localStorage.getItem(NET_KEY));
      if (c && Date.now() - c.at < NET_TTL && c.nets.length) return Promise.resolve(c.nets);
    } catch (e) { /* refetch */ }
    return getJSON(C.IEM_NETWORKS, { timeout: 30000 }).then(function (j) {
      // International networks only: American stations come from weather.gov.
      var nets = (j.data || []).filter(function (x) { return /^[A-Z]{2}__ASOS$/.test(x.id); })
        .map(function (x) { var b = ewkbBox(x.extent); return b ? [x.id].concat(b) : null; })
        .filter(Boolean);
      try { localStorage.setItem(NET_KEY, JSON.stringify({ at: Date.now(), nets: nets })); }
      catch (e) { /* full */ }
      return nets;
    });
  }

  function kmBetween(lat1, lon1, lat2, lon2) {
    var r = Math.PI / 180, dLat = (lat2 - lat1) * r, dLon = (lon2 - lon1) * r;
    var a = Math.sin(dLat / 2) * Math.sin(dLat / 2) +
      Math.cos(lat1 * r) * Math.cos(lat2 * r) * Math.sin(dLon / 2) * Math.sin(dLon / 2);
    return 6371 * 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
  }

  /* Pure: online stations within METAR_MAX_KM, nearest first. */
  function pickStation(stations, lat, lon) {
    var out = [];
    (stations || []).forEach(function (st) {
      if (st.online === false || typeof st.latitude !== 'number') return;
      var d = kmBetween(lat, lon, st.latitude, st.longitude);
      if (d <= METAR_MAX_KM) {
        out.push({ station: st.id, name: st.name, network: st.network,
                   lat: st.latitude, lon: st.longitude,
                   distanceKm: Math.round(d), archive: 'iem' });
      }
    });
    return out.sort(function (a, b) { return a.distanceKm - b.distanceKm; });
  }

  /* The nearest station is not always a usable one: a heliport filing nine
   * reports a day cannot bound a day's high and low, and the scorecard
   * would discard every day it settled. So the nearest three are tried in
   * turn against their own last 24 hours, and the first that reports often
   * enough wins — once per location, then remembered. */
  var METAR_MIN_PER_DAY = 12;     // matches js/verify.js MIN_OBS_PER_DAY

  function firstActive(cands) {
    var end = new Date(), start = new Date(end.getTime() - 86400000), failed = 0;
    function next(i) {
      if (i >= cands.length) {
        // Every probe failing is an outage, not "no station" — and must not
        // be remembered as one.
        return failed && failed === cands.length
          ? Promise.reject(new Error('METAR archive unreachable')) : Promise.resolve(null);
      }
      return metarDayExtremes(cands[i].station, start.toISOString(), end.toISOString())
        .then(function (d) { return d && d.n >= METAR_MIN_PER_DAY ? cands[i] : next(i + 1); },
              function () { failed++; return next(i + 1); });
    }
    return next(0);
  }

  /* Resolves the station record (shaped like observation()'s station
   * fields, plus archive: 'iem'), or null when no METAR station is near. */
  function nearestMetar(lat, lon) {
    var k = lat.toFixed(2) + ',' + lon.toFixed(2), memo = {};
    try { memo = JSON.parse(localStorage.getItem(STN_KEY)) || {}; } catch (e) { /* fresh */ }
    if (memo.k === k) return Promise.resolve(memo.st);
    return iemNetworks().then(function (nets) {
      var pad = 0.5;
      var hits = nets.filter(function (b) {
        return lon >= b[1] - pad && lon <= b[3] + pad && lat >= b[2] - pad && lat <= b[4] + pad;
      }).sort(function (a, b) {        // smallest box first: the country, not its overseas reach
        return (a[3] - a[1]) * (a[4] - a[2]) - (b[3] - b[1]) * (b[4] - b[2]);
      }).slice(0, 4);
      return Promise.all(hits.map(function (b) {
        return getJSON(C.IEM_NETWORK.replace('{id}', b[0]), { timeout: 30000 })
          .then(function (j) { return j.data || []; })
          .catch(function () { return []; });
      }));
    }).then(function (lists) {
      return firstActive(pickStation([].concat.apply([], lists), lat, lon).slice(0, 3));
    }).then(function (st) {
      try { localStorage.setItem(STN_KEY, JSON.stringify({ k: k, st: st })); } catch (e) { /* full */ }
      return st;
    });
  }

  /* Pure: Iowa State's asos.py CSV (station,valid,tmpc) → {hi, lo, n} °C. */
  function parseAsosTemps(text) {
    var hi = -Infinity, lo = Infinity, n = 0;
    String(text || '').split(/\r?\n/).forEach(function (line) {
      var cols = line.split(',');
      if (cols.length < 3 || cols[0] === 'station') return;
      var t = parseFloat(cols[2]);
      if (isNaN(t)) return;
      n++;
      if (t > hi) hi = t;
      if (t < lo) lo = t;
    });
    return n ? { hi: hi, lo: lo, n: n } : null;
  }

  /* stationDayExtremes, from the METAR archive instead of weather.gov:
   * every routine and special report in the window. */
  function metarDayExtremes(stationId, startISO, endISO) {
    var url = C.IEM_ASOS + '?' + qs({
      station: stationId, data: 'tmpc', tz: 'Etc/UTC', format: 'onlycomma',
      latlon: 'no', missing: 'M', report_type: 3,
      sts: startISO.slice(0, 16) + 'Z', ets: endISO.slice(0, 16) + 'Z'
    }) + '&report_type=4';
    return fetch(url).then(function (r) {
      if (!r.ok) throw new Error('HTTP ' + r.status);
      return r.text();
    }).then(parseAsosTemps);
  }

  /* Every report's present weather and measured hourly precipitation for
   * one station over a window, as Iowa State's CSV — what js/raincal.js
   * verifies rain chances against. Works for weather.gov ids (KOUN) and
   * international ICAO ids alike. */
  function metarWeather(stationId, startISO, endISO) {
    var url = C.IEM_ASOS + '?' + qs({
      station: stationId, data: 'wxcodes', tz: 'Etc/UTC', format: 'onlycomma',
      latlon: 'no', missing: 'M', report_type: 3,
      sts: startISO.slice(0, 16) + 'Z', ets: endISO.slice(0, 16) + 'Z'
    }) + '&data=p01m&report_type=4';
    return fetch(url).then(function (r) {
      if (!r.ok) throw new Error('HTTP ' + r.status);
      return r.text();
    });
  }

  /* ── NWS text products: the Area Forecast Discussion ─────── */

  /* The AFD is the forecaster's own reasoning — why they went the way they
   * went, what they are unsure about, which model they distrusted this cycle.
   * It is the single most information-dense free weather product published,
   * and none of it is in any gridded API.
   *
   * Two hops: the point tells us which Weather Forecast Office owns the
   * ground (`cwa`), then that office's product list gives the latest issuance.
   * Offices publish roughly four AFDs a day plus updates. */

  var officeCache = {};

  function forecastOffice(lat, lon) {
    var k = lat.toFixed(2) + ',' + lon.toFixed(2);
    if (officeCache[k]) return Promise.resolve(officeCache[k]);
    return getJSON(C.NWS_BASE + '/points/' + lat.toFixed(4) + ',' + lon.toFixed(4))
      .then(function (pt) {
        var cwa = pt.properties && pt.properties.cwa;
        if (!cwa) throw new Error('no forecast office for this point');
        officeCache[k] = cwa;
        return cwa;
      });
  }

  // Product listings are newest-first, so the head of the graph is current.
  function afdList(office) {
    return getJSON(C.NWS_BASE + '/products/types/AFD/locations/' + office)
      .then(function (j) {
        return (j['@graph'] || []).map(function (g) {
          return {
            id: g.id,
            office: g.issuingOffice,
            issued: g.issuanceTime,
            name: g.productName
          };
        });
      });
  }

  function afdText(id) {
    return getJSON(C.NWS_BASE + '/products/' + id).then(function (j) {
      return {
        id: j.id,
        office: j.issuingOffice,
        issued: j.issuanceTime,
        name: j.productName,
        text: j.productText || ''
      };
    });
  }

  // Null rather than a rejection: outside the US there is no AFD, and that is
  // an ordinary condition, not a failure.
  function afd(lat, lon) {
    return forecastOffice(lat, lon)
      .then(function (office) {
        return afdList(office).then(function (list) {
          if (!list.length) throw new Error('office ' + office + ' has published no AFD');
          return afdText(list[0].id).then(function (p) {
            p.priorCount = list.length - 1;
            return p;
          });
        });
      })
      .catch(function () { return null; });
  }

  /* ── Radar freshness probes (js/live.js) ─────────────────────
   * Each answers one question — "when is your newest data from?" — as
   * cheaply as that source allows, and answers null when it cannot say. */

  function mosaicValid() {
    return getJSON(C.TMS_INDEX).then(function (j) {
      if (j.__cachedAt) return null; // A cached index cannot establish current feed status.
      var s = j.services || [];
      for (var i = 0; i < s.length; i++) {
        if (s[i].id === 'ridge_uscomp_n0q') return s[i].utc_valid || null;
      }
      return null;
    });
  }

  function siteScanTime(id) {
    return getJSON(C.NWS_BASE + '/radar/stations/' + id).then(function (j) {
      if (j.__cachedAt) return null;
      var lat = j.properties && j.properties.latency;
      return (lat && lat.levelTwoLastReceivedTime) || null;
    });
  }

  /* ── RainViewer radar index ──────────────────────────────── */

  function radarIndex() {
    return getJSON(C.RAINVIEWER_INDEX).then(function (j) {
      var host = j.host;
      var past = (j.radar && j.radar.past || []).map(function (f) {
        return { time: f.time, path: f.path, forecast: false };
      });
      var future = (j.radar && j.radar.nowcast || []).map(function (f) {
        return { time: f.time, path: f.path, forecast: true };
      });
      return { host: host, frames: past.concat(future), generated: j.generated };
    });
  }

  /* RainViewer's past frames as tile templates the reflectivity sampler can
   * read back as dBZ — VaneMotion's and the overhead reading's source
   * outside NEXRAD. Oldest first; times in ms. Memoised for two minutes:
   * the overhead read, the motion fit and the grader all ask on one load,
   * and RainViewer only adds a frame every ten. */
  var sampleFrames = null;

  function radarSampleFrames() {
    if (sampleFrames && Date.now() - sampleFrames.at < 120000) return sampleFrames.p;
    var p = radarIndex().then(function (ix) {
      return ix.frames.filter(function (f) { return !f.forecast; }).map(function (f) {
        return { t: f.time * 1000, url: ix.host + f.path + C.RAINVIEWER_SAMPLE };
      });
    });
    sampleFrames = { at: Date.now(), p: p };
    p.catch(function () { sampleFrames = null; });
    return p;
  }

  /* ── Multi-model ensemble ────────────────────────────────
   * Open-Meteo can return several NWP models in one request, each as its own
   * suffixed series. Comparing them is how you get a confidence signal rather
   * than a single deterministic line that might be wrong. */

  function multiModel(lat, lon, hours) {
    return getJSON(C.OM_FORECAST + '?' + qs({
      latitude: lat.toFixed(4),
      longitude: lon.toFixed(4),
      hourly: 'temperature_2m,precipitation,wind_speed_10m,cloud_cover',
      models: C.MODELS.map(function (m) { return m.id; }).join(','),
      forecast_hours: hours || 72,
      timezone: 'auto',
      wind_speed_unit: 'ms',
      temperature_unit: 'celsius',
      precipitation_unit: 'mm'
    }));
  }

  /* Each agency's own daily numbers, side by side — the "what does the Euro
   * say" request, answered from the same endpoint with per-model columns. */
  function modelDaily(lat, lon) {
    return getJSON(C.OM_FORECAST + '?' + qs({
      latitude: lat.toFixed(4),
      longitude: lon.toFixed(4),
      daily: 'temperature_2m_max,temperature_2m_min,precipitation_sum,weather_code',
      models: C.MODELS_DAILY.map(function (m) { return m.id; }).join(','),
      forecast_days: 10,
      timezone: 'auto',
      temperature_unit: 'celsius',
      precipitation_unit: 'mm'
    }));
  }

  /* One agency's hourly precipitation at every grid point, 49 hours deep —
   * the "future radar" overlay. One request per model per viewport; the
   * lead-time slider then scrubs the cached series for free. */
  /* The model chart's CONUS lattice, split into row-band requests because
   * the API caps URL length, not locations. Bands run south to north, so
   * the concatenation is already row-major from the south-west corner. */
  function chartDomain(modelId) {
    var dom = null;
    (C.CHART_MODELS || []).forEach(function (m) {
      if (m.id === modelId && m.domain) dom = m.domain;
    });
    return dom || { LAT0: C.CHART.LAT0, LAT1: C.CHART.LAT1,
                    LON0: C.CHART.LON0, LON1: C.CHART.LON1 };
  }

  function chartPoints(chunk, dom) {
    var CH = C.CHART, pts = [];
    dom = dom || chartDomain(null);
    var start = chunk * CH.CHUNK_ROWS;
    var end = Math.min(start + CH.CHUNK_ROWS, CH.NY);
    for (var iy = start; iy < end; iy++) {
      for (var ix = 0; ix < CH.NX; ix++) {
        pts.push({
          lat: dom.LAT0 + (dom.LAT1 - dom.LAT0) * iy / (CH.NY - 1),
          lon: dom.LON0 + (dom.LON1 - dom.LON0) * ix / (CH.NX - 1)
        });
      }
    }
    return pts;
  }

  // The HRRR run behind the future radar: IEM's sidecar names the init.
  function hrrrMeta() {
    return getJSON(C.HRRR_META).then(function (j) {
      return { init: Date.parse(j.model_init_utc) };
    });
  }

  function chartGrid(modelId) {
    var dom = chartDomain(modelId);
    var fetchChunk = function (pts) {
      return getJSON(C.OM_FORECAST + '?' + qs({
        latitude: pts.map(function (p) { return p.lat.toFixed(2); }).join(','),
        longitude: pts.map(function (p) { return p.lon.toFixed(2); }).join(','),
        hourly: 'precipitation,pressure_msl',
        /* Two days: the chart is scrubbed hour by hour, the API's quota
         * weighs data volume, and a seven-day payload once held ~1M live
         * numbers on a phone. 48 hours is what hourly scrubbing is for. */
        forecast_days: 2,
        models: modelId,
        timezone: 'UTC',
        precipitation_unit: 'mm'
      })).then(function (j) {
        var arr = Array.isArray(j) ? j : [j];
        return arr.map(function (r) {
          /* Typed arrays: a quarter of the footprint of number Arrays, and
           * nulls become NaN, which the samplers treat as missing. */
          return {
            times: r.hourly.time,
            precip: Float32Array.from(r.hourly.precipitation,
              function (v) { return v === null ? NaN : v; }),
            mslp: Float32Array.from(r.hourly.pressure_msl,
              function (v) { return v === null ? NaN : v; })
          };
        });
      });
    };
    /* Three lanes, not nine at once: the API bills by location, and this
     * is the heaviest thing the app requests. 429s are handled inside
     * getJSON, patiently, for every caller alike. */
    var total = Math.ceil(C.CHART.NY / C.CHART.CHUNK_ROWS);
    var results = new Array(total);
    var next = 0;
    var lane = function () {
      if (next >= total) return Promise.resolve();
      var k = next++;
      return fetchChunk(chartPoints(k, dom)).then(function (rows) {
        results[k] = rows;
        return lane();
      });
    };
    return Promise.all([lane(), lane(), lane()]).then(function () {
      return [].concat.apply([], results);
    });
  }

  function grid(points, vars) {
    if (!points.length) return Promise.resolve([]);
    return getJSON(C.OM_FORECAST + '?' + qs({
      latitude: points.map(function (p) { return p.lat.toFixed(3); }).join(','),
      longitude: points.map(function (p) { return p.lon.toFixed(3); }).join(','),
      // CAPE rides along in the same request: one more number per point,
      // and the CAPE layer needs no fetch of its own.
      current: (vars || ['temperature_2m', 'wind_speed_10m', 'wind_direction_10m', 'cape']).join(','),
      timezone: 'UTC',
      wind_speed_unit: 'ms',
      temperature_unit: 'celsius'
    })).then(function (j) {
      var arr = Array.isArray(j) ? j : [j];
      return arr.map(function (r) {
        return {
          lat: r.latitude, lon: r.longitude,
          temp: r.current.temperature_2m,
          speed: r.current.wind_speed_10m,
          dir: r.current.wind_direction_10m,
          cape: typeof r.current.cape === 'number' ? r.current.cape : null,
          // The model's valid time for these values (UTC: timezone=UTC above).
          validAt: r.current.time ? Date.parse(r.current.time + 'Z') : null
        };
      });
    });
  }

  /* ── NEXRAD storm attributes (US) ────────────────────────
   * Rotation detections come from the radar's own algorithms rather than
   * anything inferred here — see js/cells.js for why that matters. */

  function radarStations() {
    return getJSON(C.NWS_RADAR_STATIONS, { headers: { Accept: 'application/geo+json' } })
      .then(function (j) { return j.features || []; });
  }

  function stormCells() {
    return getJSON(C.STORM_CELLS).then(function (j) {
      return { features: j.features || [], generatedAt: j.generated_at || null };
    });
  }

  /* ── Air quality (keyless, global) ──────────────────────── */

  function airQuality(lat, lon) {
    return getJSON(C.OM_AIR + '?' + qs({
      latitude: lat.toFixed(4),
      longitude: lon.toFixed(4),
      current: 'us_aqi,pm2_5,pm10,ozone,nitrogen_dioxide,sulphur_dioxide,carbon_monoxide,dust',
      hourly: 'us_aqi,pm2_5',
      forecast_days: 2,
      timezone: 'auto'
    })).catch(function () { return null; });
  }

  /* ── SPC convective outlooks (chase planning, F7) ────────
   * Note: SPC publishes these as `*.lyr.geojson`; the `.nogeom` variants
   * referenced in some older docs return 404. Mesoscale discussions have no
   * public GeoJSON feed — watches arrive through the NWS alerts feed instead. */

  function spcOutlook(day, hazard) {
    var name = 'day' + day + 'otlk_' + (hazard || 'cat');
    return getJSON(C.SPC_BASE + '/products/outlook/' + name + '.lyr.geojson')
      .then(function (j) { return j.features || []; })
      .catch(function () { return []; });
  }

  /* ── Storm reports ───────────────────────────────────────────
   * Every NWS local storm report of the last 24 hours, from Iowa State's
   * feed: tornadoes, funnel clouds, hail, wind, flooding and heavy rain,
   * snow and ice, and the rest (lightning, landslides, dust, wildfire…).
   * If that feed is down, SPC's tornado/wind/hail list stands in. */

  // Pure: an LSR's type text → one of C.REPORT_ORDER.
  function reportCategory(typetext) {
    var t = String(typetext || '').toUpperCase();
    if (/TORNADO|LANDSPOUT/.test(t)) return 'tornado';
    if (/FUNNEL|WATER ?SPOUT/.test(t)) return 'funnel';
    if (/HAIL/.test(t)) return 'hail';
    if (/WIND CHILL/.test(t)) return 'other';
    if (/WND|WIND|GUST|DOWNBURST/.test(t)) return 'wind';
    if (/FREEZING|SLEET|SNOW|ICE|BLIZZARD|AVALANCHE/.test(t)) return 'winter';
    if (/FLOOD|RAIN/.test(t)) return 'flood';
    return 'other';
  }

  // Pure: the measured or estimated size, with its unit and how it was known.
  function magValue(p) {
    var v = typeof p.magf === 'number' ? p.magf : parseFloat(p.magnitude);
    return isFinite(v) && v > 0 ? v : null;
  }

  function magUnit(p) {
    var u = String(p.unit || '').toUpperCase();
    return u === 'INCH' ? 'in' : u === 'MPH' ? 'mph' : (u === 'KNOTS' || u === 'KT') ? 'kt' : null;
  }

  function reportMagnitude(p) {
    var v = typeof p.magf === 'number' ? p.magf : parseFloat(p.magnitude);
    if (!isFinite(v) || v <= 0) return '';
    var unit = String(p.unit || '').toUpperCase(), out;
    if (unit === 'INCH') out = (v < 10 ? v.toFixed(2).replace(/0$/, '') : Math.round(v)) + '″';
    else if (unit === 'MPH') out = Math.round(v) + ' mph';
    else if (unit === 'KNOTS' || unit === 'KT') out = Math.round(v) + ' kt';
    else out = v + (p.unit ? ' ' + String(p.unit).toLowerCase() : '');
    if (p.qualifier === 'E') out += ' (est.)';
    else if (p.qualifier === 'M') out += ' (measured)';
    return out;
  }

  function titleCase(t) {
    var words = { tstm: 'thunderstorm', wnd: 'wind', gst: 'gust', dmg: 'damage', sust: 'sustained' };
    return String(t || '').toLowerCase().replace(/\b(tstm|wnd|gst|dmg|sust)\b/g, function (w) {
      return words[w];
    }).replace(/(^|\s|-|\/)([a-z])/g, function (m, a, b) { return a + b.toUpperCase(); });
  }

  function lsrReports(geo) {
    return (geo.features || []).map(function (f) {
      var p = f.properties || {};
      var at = p.valid ? Date.parse(p.valid) : NaN;
      var lat = typeof p.lat === 'number' ? p.lat : f.geometry && f.geometry.coordinates[1];
      var lon = typeof p.lon === 'number' ? p.lon : f.geometry && f.geometry.coordinates[0];
      if (!isFinite(lat) || !isFinite(lon)) return null;
      return {
        category: reportCategory(p.typetext), kind: titleCase(p.typetext),
        at: isFinite(at) ? at : null,
        time: isFinite(at) ? new Date(at).toISOString().slice(11, 16).replace(':', '') : '',
        magnitude: reportMagnitude(p), location: p.city || '', county: p.county || '',
        state: p.st || p.state || '', lat: lat, lon: lon,
        comments: p.remark || '', source: p.source || '',
        // The raw number and unit, for the popup's size and severity read;
        // the issuing NWS office and its product, for the full text.
        magValue: magValue(p), magUnit: magUnit(p),
        wfo: p.wfo || '', productId: p.product_id || ''
      };
    }).filter(Boolean);
  }

  function stormReports() {
    return getJSON(C.LSR_GEOJSON, { headers: { Accept: 'application/geo+json' } })
      .then(lsrReports)
      .catch(spcReports);
  }

  /* SPC "today's storm reports" CSV, the fallback. The file concatenates
   * three sections (tornado, wind, hail), each restarting with its own
   * header row — so the parser switches category whenever it sees one. */
  function spcReports() {
    return fetch(C.SPC_BASE + '/climo/reports/today.csv')
      .then(function (r) {
        if (!r.ok) throw new Error('HTTP ' + r.status);
        return r.text();
      })
      .then(function (text) {
        var lines = text.split(/\r?\n/).filter(function (l) { return l.trim(); });
        var out = [], category = null;
        lines.forEach(function (line) {
          var cols = splitCsv(line);
          if (cols[1] === 'F_Scale') { category = 'tornado'; return; }
          if (cols[1] === 'Speed') { category = 'wind'; return; }
          if (cols[1] === 'Size') { category = 'hail'; return; }
          if (!category || cols.length < 8) return;
          var lat = parseFloat(cols[5]), lon = parseFloat(cols[6]);
          if (isNaN(lat) || isNaN(lon)) return;
          out.push({
            category: category, kind: C.STORM_REPORT_STYLE[category].label,
            at: null, time: cols[0], magnitude: cols[1],
            location: cols[2], county: cols[3], state: cols[4],
            lat: lat, lon: lon, comments: cols[7], source: 'SPC'
          });
        });
        return out;
      })
      .catch(function () { return []; });
  }

  // Reports embed commas inside quoted comment fields.
  function splitCsv(line) {
    var out = [], cur = '', inQ = false;
    for (var i = 0; i < line.length; i++) {
      var ch = line[i];
      if (ch === '"') { inQ = !inQ; continue; }
      if (ch === ',' && !inQ) { out.push(cur); cur = ''; continue; }
      cur += ch;
    }
    out.push(cur);
    return out;
  }

  global.API = {
    geocode: geocode,
    parseCoords: parseCoords,
    forecast: forecast,
    sounding: sounding,
    alerts: alerts,
    alertsWithStatus: alertsWithStatus,
    alertsInArea: alertsInArea,
    observation: observation,
    stationDayExtremes: stationDayExtremes,
    ensembleDaily: ensembleDaily,
    normals: normals,
    forecastOffice: forecastOffice,
    afd: afd,
    afdList: afdList,
    afdText: afdText,
    radarIndex: radarIndex,
    radarSampleFrames: radarSampleFrames,
    nearestMetar: nearestMetar,
    metarDayExtremes: metarDayExtremes,
    metarWeather: metarWeather,
    pickStation: pickStation,
    parseAsosTemps: parseAsosTemps,
    ewkbBox: ewkbBox,
    mosaicValid: mosaicValid,
    siteScanTime: siteScanTime,
    multiModel: multiModel,
    modelDaily: modelDaily,
    chartGrid: chartGrid,
    hrrrMeta: hrrrMeta,
    chartPoints: chartPoints,
    chartDomain: chartDomain,
    grid: grid,
    stormEnv: stormEnv,
    airQuality: airQuality,
    spcOutlook: spcOutlook,
    stormCells: stormCells,
    radarStations: radarStations,
    stormReports: stormReports,
    reportCategory: reportCategory,
    reportMagnitude: reportMagnitude,
    lsrReports: lsrReports
  };
})(window);

