/* Vane — radar map. F3: radar is the most-loved feature, so it gets a real
 * animation loop, frame scrubbing, and honest colours.
 *
 * Two sources, because neither alone is good enough:
 *
 *  - NEXRAD (Iowa State Mesonet, product N0Q) is true Level III base
 *    reflectivity on the standard NWS dBZ ramp — what a chaser expects to see,
 *    and what F7 actually asked for. US only, 12 frames over the last hour.
 *  - RainViewer covers the whole world and adds forecast frames, but its free
 *    tile cache ignores the colour-scheme parameter entirely: every scheme
 *    returns the same monochrome blue ramp. That is verifiably true (all nine
 *    scheme ids return byte-identical tiles), so the legend for this source
 *    describes blue intensity rather than inventing a dBZ scale it doesn't have.
 *
 * The legend is generated from whichever source is live. A radar legend that
 * doesn't match the pixels is worse than no legend at all. */
(function (global) {
  'use strict';

  var C = global.VaneConfig, U = global.U;

  var map = null, baseLayer = null, labelLayer = null;
  var frames = [], layers = [], idx = 0;
  var timer = null, playing = true, opacity = 0.85;
  var marker = null, accuracyCircle = null, polygons = null;
  var onFrameChange = null, onSourceChange = null, onFutureFrame = null;
  var source = 'nexrad';
  var site = null;              // selected radar site object
  var product = 'N0Q';          // Level III product when in single-site mode
  var rangeRing = null;
  var pair = null;              // the synced velocity pane, when open

  function available() { return typeof global.L !== 'undefined'; }

  /* ── Paired reflectivity / velocity view ────────────────────────────── */

  /* Interrogating a storm means reading two products at once. Reflectivity
   * shows you the hook; velocity shows you whether anything is actually
   * rotating inside it, and a couplet is only meaningful against the structure
   * it sits in. Flipping between them loses the comparison, which is why every
   * tool a chaser actually pays for puts them side by side.
   *
   * This is a second Leaflet map locked to the first. Both are single-site
   * RIDGE products from the same radar and the same scan, so the two panes are
   * genuinely comparable — pairing a site velocity image against the national
   * mosaic would put two different times and two different resolutions beside
   * each other and invite exactly the wrong read. */
  function openPair(containerId, velocityProduct) {
    if (!available() || !map) return null;
    if (pair) { closePair(); }
    var el = U.el(containerId);
    if (!el) return null;

    var pmap = L.map(containerId, {
      center: map.getCenter(), zoom: map.getZoom(),
      zoomControl: false, attributionControl: false,
      preferCanvas: true, worldCopyJump: true
    });
    L.tileLayer(C.OSM_TILES, { maxZoom: 18, maxNativeZoom: 16 }).addTo(pmap);
    pmap.createPane('radar');
    pmap.getPane('radar').style.zIndex = 400;
    pmap.createPane('labels');
    pmap.getPane('labels').style.zIndex = 560;
    pmap.getPane('labels').style.pointerEvents = 'none';
    L.tileLayer(C.OSM_LABELS, { maxZoom: 18, maxNativeZoom: 16, pane: 'labels', opacity: 0.9 }).addTo(pmap);

    pair = {
      map: pmap, layer: null,
      product: velocityProduct || 'N0U',
      syncing: false
    };
    buildPairLayer();

    /* Two-way sync with a re-entry guard: without it each map's move fires the
     * other's setView, which fires move again, and the pair oscillates.
     *
     * The handler is kept so it can be detached on close. The main map outlives
     * the pane, so a listener left bound to it goes on firing against a torn-
     * down `pair` on every pan for the rest of the session. */
    var self = pair;
    self.unlink = [];
    var link = function (from, to) {
      var handler = function () {
        if (self.dead || self.syncing) return;
        self.syncing = true;
        to.setView(from.getCenter(), from.getZoom(), { animate: false });
        self.syncing = false;
      };
      from.on('move zoom', handler);
      self.unlink.push(function () { from.off('move zoom', handler); });
    };
    link(map, pmap);
    link(pmap, map);
    setTimeout(function () { pmap.invalidateSize(); }, 60);
    return pair;
  }

  function buildPairLayer() {
    if (!pair || !site) return;
    if (pair.layer && pair.map.hasLayer(pair.layer)) pair.map.removeLayer(pair.layer);
    // Busted with the same generation as the main pane, so both sides of the
    // comparison advance to the new scan together.
    pair.layer = L.tileLayer(
      bust(C.RIDGE_TILES.replace('{site}', site.id).replace('{product}', pair.product)),
      { opacity: opacity, pane: 'radar', maxNativeZoom: 12, tileSize: 256, crossOrigin: true }
    ).addTo(pair.map);
  }

  function setPairProduct(next) {
    if (!pair) return;
    pair.product = next;
    buildPairLayer();
  }

  function closePair() {
    if (!pair) return;
    pair.dead = true;
    (pair.unlink || []).forEach(function (off) { off(); });
    pair.map.remove();
    pair = null;
  }

  function getPair() { return pair; }

  /* ── Sources ────────────────────────────────────────────────────────── */

  // Iowa State publishes the current composite plus rolling 5-minute archives
  // back to 55 minutes. Oldest first so the animation runs forward in time.
  function nexradFrames() {
    var out = [];
    for (var m = 55; m >= 5; m -= 5) {
      var t = Date.now() - m * 60000;
      out.push({
        url: C.NEXRAD_TILES.replace('{product}', 'nexrad-n0q-m' + (m < 10 ? '0' + m : m) + 'm'),
        mask: maskFor(t),
        time: Math.floor(t / 1000),
        timeBasis: 'request',
        forecast: false
      });
    }
    out.push({
      url: C.NEXRAD_TILES.replace('{product}', 'nexrad-n0q-900913'),
      mask: C.NEXRAD_TILES.replace('{product}', 'q2-hsr'),
      time: Math.floor(Date.now() / 1000),
      timeBasis: 'request',
      forecast: false
    });
    return out;
  }

  /* ── Non-weather echoes ───────────────────────────────────────────────
   * The national mosaic is raw base reflectivity, and the raw radar sees
   * more than rain: the blades of central Iowa's wind farms, and on autumn
   * and spring nights the birds and insects migrating overhead. A user in
   * Des Moines photographed a map speckled with "rain" under a sky every
   * station around reported CLEAR. NOAA's MRMS quality-controlled composite
   * (SeamlessHSR) uses dual-polarisation to throw those echoes out, and Iowa
   * State archives it every two minutes. So each frame is drawn from the raw
   * mosaic — its familiar colours, its legend — but only where MRMS, at the
   * same time, also sees an echo (widened by ~2 km, so a moving storm's edge
   * is not clipped). Where a mask cannot load, the raw frame is shown:
   * never hide rain to hide clutter. */
  var clean = true;

  // MRMS archives every even minute; the 5-minute mosaic is valid at the
  // last 5-minute mark — so the even minute at or before that mark.
  function maskFor(ms) {
    var t = Math.floor((ms - 60000) / 300000) * 300000;
    return C.NEXRAD_TILES.replace('{product}', 'mrms::lcref-' + stamp2(t));
  }

  // YYYYmmddHHMM at the even minute at or before ms (U.iemStamp rounds to 5).
  function stamp2(ms) {
    var d = new Date(Math.floor(ms / 120000) * 120000);
    var p = function (n) { return (n < 10 ? '0' : '') + n; };
    return '' + d.getUTCFullYear() + p(d.getUTCMonth() + 1) + p(d.getUTCDate()) +
           p(d.getUTCHours()) + p(d.getUTCMinutes());
  }

  // Grow the mask by `r` pixels (a square max filter, done separably).
  function dilate(m, w, h, r) {
    var tmp = new Uint8Array(w * h), out = new Uint8Array(w * h), x, y, k, v;
    for (y = 0; y < h; y++) {
      for (x = 0; x < w; x++) {
        v = 0;
        for (k = Math.max(0, x - r); k <= Math.min(w - 1, x + r) && !v; k++) v = m[y * w + k];
        tmp[y * w + x] = v;
      }
    }
    for (x = 0; x < w; x++) {
      for (y = 0; y < h; y++) {
        v = 0;
        for (k = Math.max(0, y - r); k <= Math.min(h - 1, y + r) && !v; k++) v = tmp[k * w + x];
        out[y * w + x] = v;
      }
    }
    return out;
  }

  // ~2 km in pixels at this zoom and latitude.
  function maskRadius(z, lat) {
    var mPerPx = 156543.03 * Math.cos(lat * Math.PI / 180) / Math.pow(2, z);
    return Math.max(1, Math.min(24, Math.ceil(2000 / mPerPx)));
  }

  /* raw, mask: same-size RGBA byte arrays. Clears raw wherever the widened
   * mask is empty; returns how many pixels it cleared. */
  function applyMask(raw, mask, w, h, r) {
    var m = new Uint8Array(w * h), i, cleared = 0;
    for (i = 0; i < w * h; i++) m[i] = mask[i * 4 + 3] > 0 ? 1 : 0;
    var grown = dilate(m, w, h, r);
    for (i = 0; i < w * h; i++) {
      if (!grown[i] && raw[i * 4 + 3] > 0) { raw[i * 4 + 3] = 0; cleared++; }
    }
    return cleared;
  }

  var CleanLayer = typeof L === 'undefined' ? null : L.GridLayer.extend({
    initialize: function (opts) {
      L.GridLayer.prototype.initialize.call(this, opts);
      this._url = opts.rawUrl;                   // the frame it draws, as a TileLayer names it
    },
    createTile: function (coords, done) {
      var tile = document.createElement('canvas'), size = this.getTileSize(), opts = this.options;
      tile.width = size.x; tile.height = size.y;
      var vals = { x: coords.x, y: coords.y, z: coords.z, s: 'a' };
      var raw = new Image(), mask = new Image(), left = 2, rawOk = false, maskOk = false;
      raw.crossOrigin = mask.crossOrigin = 'anonymous';
      var lat = this._map ? this._map.unproject([(coords.x + 0.5) * size.x, (coords.y + 0.5) * size.y], coords.z).lat : 40;
      var finish = function () {
        if (--left) return;
        if (!rawOk) { done(null, tile); return; }
        var ctx = tile.getContext('2d');
        ctx.drawImage(raw, 0, 0, size.x, size.y);
        if (maskOk) {
          try {
            var mc = document.createElement('canvas');
            mc.width = size.x; mc.height = size.y;
            var mctx = mc.getContext('2d');
            mctx.drawImage(mask, 0, 0, size.x, size.y);
            var img = ctx.getImageData(0, 0, size.x, size.y);
            applyMask(img.data, mctx.getImageData(0, 0, size.x, size.y).data, size.x, size.y,
              maskRadius(coords.z, lat));
            ctx.putImageData(img, 0, 0);
          } catch (e) { /* unreadable mask: the raw frame stands */ }
        }
        done(null, tile);
      };
      raw.onload = function () { rawOk = true; finish(); };
      raw.onerror = function () { finish(); };
      mask.onload = function () { maskOk = true; finish(); };
      mask.onerror = function () { finish(); };
      raw.src = L.Util.template(opts.rawUrl, vals);
      tile.setAttribute('data-src', raw.src);
      mask.src = L.Util.template(opts.maskUrl, vals);
      return tile;
    }
  });

  function setClean(on) {
    on = on !== false;
    if (on === clean) return;
    clean = on;
    if (map && (source === 'nexrad' || historyAt)) buildLayers();
    if (onSourceChange) onSourceChange(source, legend());
  }
  function cleanOn() { return clean; }

  /* Single-site RIDGE products. IEM's frame index is ignored by the cache —
   * every value returns the same latest image — so single-site mode is a live
   * snapshot rather than a loop, and the UI says so instead of animating one
   * frame and pretending it is twelve. */
  function siteFrames() {
    if (!site) return [];
    return [{
      url: C.RIDGE_TILES.replace('{site}', site.id).replace('{product}', product),
      time: Math.floor(Date.now() / 1000),
      timeBasis: 'request',
      forecast: false,
      single: true
    }];
  }

  function rainviewerFrames(index) {
    return index.frames.map(function (f) {
      return {
        url: index.host + f.path + '/256/{z}/{x}/{y}/4/1_1.png',
        time: f.time,
        forecast: f.forecast
      };
    });
  }

  // NEXRAD only covers the United States; fall back to the global source
  // rather than showing an empty map.
  function inConus(lat, lon) {
    return lat >= 23 && lat <= 50 && lon >= -126 && lon <= -65;
  }

  function pickSource(lat, lon) {
    return inConus(lat, lon) ? 'nexrad' : 'global';
  }

  /* ── Legends: generated from the live source, never hardcoded ───────── */

  // Standard NWS base-reflectivity ramp. Values are dBZ.
  var DBZ_SCALE = [
    [5,  '#40e8e3', ''],
    [10, '#2ac9df', ''],
    [15, '#1c7fd6', 'light'],
    [20, '#11d518', ''],
    [25, '#0da212', ''],
    [30, '#0b7f0f', 'moderate'],
    [35, '#f9f900', ''],
    [40, '#e5bc00', ''],
    [45, '#fd9500', 'heavy'],
    [50, '#fd0000', ''],
    [55, '#d40000', 'intense'],
    [60, '#bc0000', ''],
    [65, '#f800fd', 'hail likely'],
    [70, '#9854c6', '']
  ];

  /* What RainViewer's cache actually serves, whatever scheme is asked for:
   * its "Universal Blue" palette, which RainViewer publishes per decibel.
   * An earlier key here was a run of blues eyeballed off the tiles and
   * labelled "no dBZ scale is published" — there is one, and the pixels
   * match it exactly (see js/reflectivity.js), so the key is real dBZ now.
   * Below 15 dBZ the tiles are a translucent tan: drizzle and clutter. */
  var RV_SCALE = [
    [10, '#cec087', ''],
    [15, '#88ddee', 'light'],
    [20, '#00a3e0', ''],
    [25, '#0077aa', ''],
    [30, '#005588', 'moderate'],
    [35, '#ffee00', ''],
    [40, '#ffaa00', 'heavy'],
    [45, '#ff4400', ''],
    [50, '#c10000', 'intense'],
    [55, '#ffaaff', ''],
    [60, '#ff77ff', 'hail likely'],
    [65, '#ffffff', '']
  ];

  // Standard NWS radial-velocity ramp: green is motion toward the radar, red
  // is away. Adjacent green and red is a couplet — that is what rotation
  // looks like on a velocity product.
  var VELOCITY_SCALE = [
    ['#00e000', 'toward'],
    ['#00b400', ''],
    ['#008000', ''],
    ['#004f00', ''],
    ['#7f7f7f', 'near zero'],
    ['#6b0000', ''],
    ['#9b0000', ''],
    ['#d00000', ''],
    ['#ff0000', 'away']
  ];

  function productInfo() {
    for (var i = 0; i < C.RADAR_PRODUCTS.length; i++) {
      if (C.RADAR_PRODUCTS[i].id === product) return C.RADAR_PRODUCTS[i];
    }
    return C.RADAR_PRODUCTS[0];
  }

  function legend() {
    if (source === 'site') {
      var info = productInfo();
      if (info.kind === 'velocity') {
        return { kind: 'velocity', scale: VELOCITY_SCALE,
                 note: site ? site.id + ' ' + info.label + ' — ' + info.note : info.note };
      }
      return { kind: 'dbz', scale: DBZ_SCALE,
               note: (site ? site.id + ' ' : '') + info.label + ' (dBZ), latest scan only' };
    }
    return source === 'nexrad'
      ? { kind: 'dbz', scale: DBZ_SCALE, note: 'NEXRAD base reflectivity (dBZ), national mosaic' +
          (clean ? ' · birds, bugs and wind farms filtered out (NOAA MRMS quality control)' : ' · unfiltered') }
      : { kind: 'dbz', scale: RV_SCALE,
          note: 'RainViewer global composite (dBZ), RainViewer\'s published palette' };
  }

  /* ── Setup ──────────────────────────────────────────────────────────── */

  function init(lat, lon, handlers) {
    if (!available()) {
      var m = U.el('map');
      if (m) {
        m.classList.add('map-fallback');
        m.textContent = 'Radar map unavailable — the Leaflet library could not be loaded. ' +
          'Everything else on this page works offline of it.';
      }
      return false;
    }
    onFrameChange = handlers && handlers.onFrameChange;
    onFutureFrame = handlers && handlers.onFutureFrame;
    onSourceChange = handlers && handlers.onSourceChange;
    source = pickSource(lat, lon);

    map = L.map('map', {
      center: [lat, lon], zoom: 7, zoomControl: true,
      /* Below zoom 4 no radar product here means anything — the CONUS
       * composite is a smudge and a hemisphere of basemap invites reading
       * whatever is drawn on it as global weather. */
      minZoom: 4,
      attributionControl: true, preferCanvas: true, worldCopyJump: true,
      /* A finger is not a cursor: without tolerance, tapping a 2px polygon
       * edge or a 8px site dot on the canvas renderer demands pixel accuracy
       * nobody has in a moving vehicle. */
      renderer: L.canvas({ tolerance: 10 })
    });

    baseLayer = L.tileLayer(C.OSM_TILES, {
      attribution: '&copy; <a href="https://www.esri.com/">Esri</a> &copy; OpenStreetMap contributors',
      maxZoom: 18, maxNativeZoom: 16
    }).addTo(map);

    /* Pane order matters and is easy to get wrong: Leaflet's default
     * overlayPane also sits at z-index 400, so anything drawn there ends up
     * *underneath* the radar tiles — which silently hid the warning polygons
     * and storm-cell markers. Everything that must stay readable over the
     * returns gets its own pane above them.
     *
     *   400 radar tiles
     *   500 features   — warning polygons, storm cells, position marker
     *   560 labels     — place names, so you can tell which town is under it */
    map.createPane('radar');
    map.getPane('radar').style.zIndex = 400;

    map.createPane('features');
    map.getPane('features').style.zIndex = 500;

    map.createPane('labels');
    map.getPane('labels').style.zIndex = 560;
    map.getPane('labels').style.pointerEvents = 'none';
    labelLayer = L.tileLayer(C.OSM_LABELS, {
      maxZoom: 18, maxNativeZoom: 16, pane: 'labels', opacity: 0.9
    }).addTo(map);

    polygons = L.layerGroup().addTo(map);
    L.control.scale({ imperial: true, metric: true, position: 'bottomleft' }).addTo(map);
    setMarker(lat, lon);

    map.on('moveend', function () {
      if (handlers && handlers.onMove) handlers.onMove(map.getCenter());
    });
    /* Zoom suspension — see suspendHidden(). Hidden frames unmount for
     * the duration of the gesture and return one at a time afterwards. */
    /* On a phone-width map an open popup fills it, and the zoom buttons
     * sat on top of its first lines (Leaflet's controls outrank its popup
     * pane). They step aside while one is open; pinch still zooms. */
    map.on('popupopen', function () {
      map.getContainer().classList.toggle('popup-narrow', map.getSize().x < 520);
    });
    map.on('popupclose', function () { map.getContainer().classList.remove('popup-narrow'); });
    map.on('zoomstart', suspendHidden);
    map.on('zoomend', function () {
      if (restoreTimer) clearTimeout(restoreTimer);
      restoreTimer = setTimeout(restoreHidden, 300);
    });
    return true;
  }

  /* ── Zoom suspension ─────────────────────────────────────────────────
   * All twelve frames stay mounted at rest so Play never waits on the
   * network — but during a zoom, EVERY mounted tile layer refetches and
   * re-decodes a viewport of tiles, visible or not. Twelve invisible
   * frames plus two WMS buffers times a pinch across a few levels was
   * measured at ~50 tile requests per zoom step on a phone viewport, and
   * iOS answers a burst like that by killing the page — the field report
   * was "the app crashes when I zoom in". So everything invisible
   * unmounts on zoomstart and returns ONE AT A TIME once the zoom
   * settles: the imagery on screen never blinks, the gesture costs one
   * layer's tiles instead of fourteen, and the loop is fully re-armed a
   * couple of seconds later. */
  var restoreTimer = null, restoreToken = 0;
  var RESTORE_STEP_MS = 150;

  function suspendHidden() {
    if (!map) return;
    restoreToken++;                      // cancels any staggered restore
    if (restoreTimer) { clearTimeout(restoreTimer); restoreTimer = null; }
    layers.forEach(function (l, n) {
      if (n !== idx && map.hasLayer(l)) map.removeLayer(l);
    });
    // The future buffers reload their WMS image on every zoom too. Only
    // the one actually on screen may stay.
    [futureA, futureB].forEach(function (buf) {
      if (buf && map.hasLayer(buf) &&
          !(futureMinute !== null && buf === futureFront)) {
        map.removeLayer(buf);
      }
    });
  }

  function restoreHidden() {
    restoreTimer = null;
    if (!map) return;
    var token = ++restoreToken;
    var pending = layers.filter(function (l) { return !map.hasLayer(l); })
      .concat([futureA, futureB].filter(function (buf) {
        return buf && !map.hasLayer(buf);
      }));
    (function next() {
      if (token !== restoreToken || !map || !pending.length) return;
      var l = pending.shift();
      // A rebuild may have retired this layer while it waited its turn.
      if (layers.indexOf(l) !== -1 || l === futureA || l === futureB) {
        l.addTo(map);
      }
      restoreTimer = setTimeout(next, RESTORE_STEP_MS);
    })();
  }

  /* The basemap follows the app's colour scheme: light canvas under the
   * light theme, dark under dark. Labels swap with it — a dark-reference
   * label set over the light canvas is unreadable, and vice versa. */
  function setBaseTheme(light) {
    if (!map || !baseLayer) return;
    map.removeLayer(baseLayer);
    baseLayer = L.tileLayer(light ? C.OSM_TILES_LIGHT : C.OSM_TILES, {
      attribution: '&copy; <a href="https://www.esri.com/">Esri</a> &copy; OpenStreetMap contributors',
      maxZoom: 18, maxNativeZoom: 16
    }).addTo(map);
    baseLayer.bringToBack();
    if (labelLayer) {
      map.removeLayer(labelLayer);
      labelLayer = L.tileLayer(light ? C.OSM_LABELS_LIGHT : C.OSM_LABELS, {
        maxZoom: 18, maxNativeZoom: 16, pane: 'labels', opacity: 0.9
      }).addTo(map);
    }
  }

  function setMarker(lat, lon, accuracyM) {
    if (!map) return;
    if (marker) map.removeLayer(marker);
    // A halo keeps the position dot findable over heavy returns.
    marker = L.circleMarker([lat, lon], {
      radius: 6, color: '#fff', weight: 2.5, fillColor: '#0a84ff', fillOpacity: 1,
      pane: 'features'
    }).addTo(map);
    marker.bringToFront();
    if (accuracyCircle) { map.removeLayer(accuracyCircle); accuracyCircle = null; }
    if (accuracyM && accuracyM < 20000) {
      accuracyCircle = L.circle([lat, lon], {
        radius: accuracyM, color: '#0a84ff', weight: 1, fillOpacity: 0.08,
        pane: 'features'
      }).addTo(map);
    }
  }

  function panTo(lat, lon, zoom) {
    if (!map) return;
    map.setView([lat, lon], zoom || map.getZoom());
  }

  /* ── Frames ─────────────────────────────────────────────────────────── */

  /* Live refresh generation. IEM's mosaic and RIDGE tile URLs are stable —
   * `nexrad-n0q-m05m` always means "five minutes ago" — so the browser has no
   * reason to re-fetch them when new data exists behind the same address. The
   * generation is a cache-busting query param stamped onto those URLs each
   * time a genuinely new composite or volume scan is detected (the server
   * ignores unknown params; verified). RainViewer frames are addressed by
   * absolute timestamp, so new data is a new URL and needs no busting. */
  var generation = 0;

  function bust(u) {
    if (!generation || source === 'global') return u;
    return u + (u.indexOf('?') === -1 ? '?_g=' : '&_g=') + generation;
  }

  function lastPastIndex() {
    var lp = 0;
    frames.forEach(function (f, i) { if (!f.forecast) lp = i; });
    return lp;
  }

  /* Rebuild the current source's frames in place because new data exists.
   * The rule for the playhead: a viewer parked on "latest" is watching the
   * weather and stays pinned to latest; a viewer who scrubbed backward chose
   * a moment and keeps it — for the relative-time mosaic that means the same
   * age offset, for absolute RainViewer frames the same wall-clock frame as
   * long as it still exists. Play state carries through either way. */
  function refresh(opts) {
    opts = opts || {};
    if (!map || !frames.length) return false;
    if (historyAt) return false;         // a new scan cannot update the past
    generation = opts.generation || Date.now();
    if (opts.index) lastIndex = opts.index;
    var atLatest = idx === lastPastIndex();
    var wasIdx = idx;
    var wasTime = frames[idx] && frames[idx].time;
    frames = framesForSource(lastIndex);
    buildLayers();                       // lands on latest past frame
    if (!playing && !atLatest) {
      if (source === 'global') {
        for (var i = 0; i < frames.length; i++) {
          if (frames[i].time === wasTime) { show(i); break; }
        }
      } else {
        show(Math.min(wasIdx, frames.length - 1));
      }
    }
    if (pair) buildPairLayer();
    return true;
  }

  function buildLayers() {
    if (!map) return;
    // Retire any staggered zoom-restore: it holds references to the very
    // layers being replaced here.
    restoreToken++;
    if (restoreTimer) { clearTimeout(restoreTimer); restoreTimer = null; }
    layers.forEach(function (l) { if (map.hasLayer(l)) map.removeLayer(l); });
    layers = frames.map(function (f) {
      // Credit the source actually being displayed. Single-site RIDGE
      // products come from Iowa State the same as the mosaic; only the
      // global source is RainViewer.
      var attribution = source === 'global'
        ? 'Radar: <a href="https://www.rainviewer.com/">RainViewer</a>'
        : 'Radar: <a href="https://mesonet.agron.iastate.edu/">Iowa State Mesonet</a> / NWS NEXRAD' +
          (clean && f.mask && CleanLayer ? ', filtered with NOAA MRMS' : '');
      if (clean && f.mask && CleanLayer) {
        return new CleanLayer({ rawUrl: bust(f.url), maskUrl: bust(f.mask), opacity: 0, pane: 'radar',
          maxNativeZoom: 12, tileSize: 256, attribution: attribution, className: 'radar-clean' });
      }
      return L.tileLayer(bust(f.url), {
        opacity: 0, pane: 'radar', maxNativeZoom: 12, tileSize: 256,
        crossOrigin: true, attribution: attribution
      });
    });
    layers.forEach(function (l) { l.addTo(map); });

    // Start on the most recent observed frame, not a forecast frame.
    var lastPast = 0;
    frames.forEach(function (f, i) { if (!f.forecast) lastPast = i; });
    idx = lastPast;
    show(idx);
    if (playing) play();
    if (onSourceChange) onSourceChange(source, legend());
  }

  /* ── Historical mosaic: the archive, by the minute ────────────────────
   * IEM serves the national composite for any past five-minute stamp under
   * the same tile scheme as the live layers, back years. History mode is
   * one archived hour, scrubbed and looped exactly like the live hour. */
  var historyAt = null;                 // epoch ms the archived hour ends at

  function historyFrames(endMs) {
    var out = [];
    for (var m = 55; m >= 0; m -= 5) {
      var t = Math.floor((endMs - m * 60000) / 300000) * 300000;
      out.push({
        url: C.NEXRAD_TILES.replace('{product}', 'ridge::USCOMP-N0Q-' + U.iemStamp(t)),
        mask: C.NEXRAD_TILES.replace('{product}', 'mrms::lcref-' + stamp2(t)),
        time: Math.floor(t / 1000),
        forecast: false,
        archive: true
      });
    }
    return out;
  }

  function setHistory(endMs) {
    historyAt = endMs || null;
    if (historyAt) {
      // The archive is the CONUS mosaic; other sources hand over to it.
      if (source !== 'nexrad') { source = 'nexrad'; drawSiteMarkers(); }
      clearFuture();
      frames = historyFrames(historyAt);
    } else {
      frames = framesForSource(lastIndex);
    }
    buildLayers();
  }

  function historyShowing() { return historyAt; }

  /* The observed frame nearest a moment, and whether the loaded loop
   * covers it at all (a frame within 5 minutes either side). */
  function frameNear(ms) {
    var best = -1, gap = Infinity;
    frames.forEach(function (f, i) {
      if (f.forecast) return;
      var d = Math.abs(f.time * 1000 - ms);
      if (d < gap) { gap = d; best = i; }
    });
    return best < 0 ? null : { index: best, gapMs: gap };
  }

  function framesForSource(index) {
    if (source === 'site') return siteFrames();
    if (source === 'nexrad') return nexradFrames();
    return index ? rainviewerFrames(index) : [];
  }

  function loadFrames(index) {
    if (!map) return;
    if (index) lastIndex = index;
    if (historyAt) return;              // an archived hour is deliberately frozen
    frames = framesForSource(index);
    buildLayers();
  }

  var lastIndex = null;
  function setSource(next, index) {
    historyAt = null;                   // picking a source returns to the present
    source = next;
    if (index) lastIndex = index;
    frames = framesForSource(lastIndex);
    // A single scan has nothing to animate.
    if (source === 'site') pause();
    buildLayers();
    drawSiteMarkers();
  }

  /* Select a radar site: switches to single-site imagery, draws the coverage
   * ring and centres on it. */
  function setSite(nextSite, nextProduct) {
    // The paired pane follows the same radar; a velocity image from a
    // different site than the reflectivity beside it would be worse than
    // useless.
    if (pair) setTimeout(buildPairLayer, 0);
    site = nextSite;
    if (nextProduct) product = nextProduct;
    source = 'site';
    frames = siteFrames();
    pause();
    buildLayers();
    drawRangeRing();
    drawSiteMarkers();
    if (site) map.setView([site.lat, site.lon], Math.max(map.getZoom(), 7));
  }

  function setProduct(next) {
    product = next;
    if (source !== 'site') return;
    frames = siteFrames();
    buildLayers();
  }

  function getSite() { return site; }
  function getProduct() { return product; }

  /* ── Every other radar, on the map itself ────────────────────────────
   * In single-site mode the question "what does the next radar over see?"
   * used to mean opening the panel and searching. Chasing crosses coverage
   * boundaries constantly, so the sites are on the map: every WSR-88D as a
   * dot coloured by live status — green scanning storms, blue clear-air,
   * grey silent — matching the site list's own colour language. Tap one to
   * switch to it. Drawn only in single-site mode; on the mosaic they would
   * be 159 dots explaining nothing. */
  var siteMarkers = null;
  var onSitePick = null;

  function setSitePicker(fn) { onSitePick = fn; }

  var SITE_STATUS_COLOR = { precip: '#5fe08a', clear: '#7fd3ff' };

  function drawSiteMarkers() {
    if (!map) return;
    if (siteMarkers) { map.removeLayer(siteMarkers); siteMarkers = null; }
    if (source !== 'site' || !global.Sites) return;
    var sites = (global.Sites.state && global.Sites.state.sites) || [];
    if (!sites.length) return;

    siteMarkers = L.layerGroup();
    sites.forEach(function (s) {
      if (site && s.id === site.id) return;      // the active one wears the ring
      var color = s.online ? (SITE_STATUS_COLOR[s.scanMode] || '#8e8e93') : '#8e8e93';
      var m = L.circleMarker([s.lat, s.lon], {
        radius: 7, color: '#0a0e16', weight: 1.5,
        fillColor: color, fillOpacity: s.online ? 0.95 : 0.5, pane: 'features'
      });
      m.bindTooltip(s.id + ' · ' + s.name, { direction: 'top' });
      m.on('click', function () {
        if (onSitePick) onSitePick(s);
      });
      siteMarkers.addLayer(m);
    });
    siteMarkers.addTo(map);
  }

  // The ring makes range folding and the cone of silence legible: returns near
  // the edge are far from the radar and much higher above ground.
  function drawRangeRing() {
    if (!map) return;
    if (rangeRing) { map.removeLayer(rangeRing); rangeRing = null; }
    if (!site || source !== 'site') return;
    rangeRing = L.layerGroup([
      L.circle([site.lat, site.lon], {
        radius: global.Sites.rangeKm(site) * 1000,
        color: '#ffffff', weight: 1, opacity: 0.35, fill: false,
        dashArray: '6 8', pane: 'features'
      }),
      (function () {
        var m = L.circleMarker([site.lat, site.lon], {
          radius: 5, color: '#ffffff', weight: 2,
          fillColor: '#0a84ff', fillOpacity: 1, pane: 'features'
        });
        tapPopup(m, '<strong>' + escapeHtml(site.id) + '</strong> — ' +
          escapeHtml(site.name) + '<br>VCP ' + escapeHtml(site.vcp || 'unknown') +
          ' · ' + (site.scanMode === 'precip' ? 'precipitation mode' :
                   site.scanMode === 'clear' ? 'clear-air mode' : 'mode unknown'));
        return m;
      })()
    ]).addTo(map);
  }

  function getSource() { return source; }

  function show(i) {
    if (!frames.length) return;
    idx = (i + frames.length) % frames.length;
    // A frame asked for while zoom suspension holds it off-map mounts on
    // demand — the user's scrub outranks the staggered restore.
    if (map && layers[idx] && !map.hasLayer(layers[idx])) layers[idx].addTo(map);
    // A live refresh landing mid-future-scrub restores position silently:
    // observed frames stay hidden until the user scrubs back to them.
    layers.forEach(function (l, n) {
      l.setOpacity(futureMinute === null && n === idx ? opacity : 0);
    });
    if (onFrameChange) onFrameChange(frames[idx], idx, frames.length);
  }

  /* ── Future radar: HRRR simulated reflectivity ──────────────────────
   * The one model that genuinely looks like radar — 3 km, convection-
   * allowing — as WMS imagery from IEM, one layer per forecast lead.
   * While a future lead is up the observed frames hide; the timeline tag
   * and badge carry the honesty. Layers are cached per lead so scrubbing
   * back and forth re-shows instead of re-fetching. */

  /* TWO WMS layers, a front and a back buffer — bounded, never one per
   * lead (a thumb dragged across ninety stops fires input per pixel, and
   * a layer per event once killed a phone). The earlier single layer was
   * re-parameterised per lead, but setParams() discards every visible
   * tile before the replacement's have arrived, so each frame advance
   * blanked the radar for as long as the WMS took to answer — measured
   * at zero visible tiles mid-transition, and reported from the field as
   * "the forecast radar is not smooth". Now the next lead loads in the
   * hidden back layer and the buffers swap on its 'load' event: the old
   * frame stays on screen until the new one is ready to be seen. */
  var futureA = null, futureB = null;
  var futureFront = null;               // whichever buffer is visible
  var futureMinute = null;
  var futureReq = 0;                    // a newer request supersedes an in-flight swap

  function pad4(n) { return ('0000' + n).slice(-4); }

  function makeFutureLayer(minute) {
    return L.tileLayer.wms(C.HRRR_WMS, {
      layers: 'refd_' + pad4(minute),
      format: 'image/png', transparent: true, version: '1.3.0',
      opacity: 0, pane: 'tilePane'
    }).addTo(map);
  }

  function showFuture(minute, keepPlaying) {
    if (!map) return;
    if (historyAt) return;              // the archive never shows a forecast
    if (!keepPlaying) stop();           // a scrub interrupts the animation
    layers.forEach(function (l) { l.setOpacity(0); });
    if (pair && pair.layer) pair.layer.setOpacity(0);

    if (minute === futureMinute && futureFront) {
      futureFront.setOpacity(opacity);  // re-entering the lead already loaded
      return;
    }
    futureMinute = minute;

    var back;
    if (!futureA) {
      back = futureA = makeFutureLayer(minute);
    } else if (futureFront === futureA) {
      if (!futureB) back = futureB = makeFutureLayer(minute);
      else { back = futureB; back.setParams({ layers: 'refd_' + pad4(minute) }); }
    } else {
      back = futureA;
      back.setParams({ layers: 'refd_' + pad4(minute) });
    }
    // Zoom suspension may have taken the back buffer off the map; an
    // unmounted layer never fires 'load', so remount before waiting on it.
    if (!map.hasLayer(back)) back.addTo(map);

    var req = ++futureReq;
    var swap = function () {
      back.off('load', swap);
      clearTimeout(guard);
      if (req !== futureReq) return;    // a newer lead superseded this one
      if (futureFront && futureFront !== back) futureFront.setOpacity(0);
      futureFront = back;
      back.setOpacity(opacity);
    };
    // The WMS sends no cache headers and can stall; show whatever arrived.
    var guard = setTimeout(swap, 4000);
    back.on('load', swap);
  }

  function clearFuture() {
    if (futureMinute === null) return;
    futureReq++;                        // cancel any swap still in flight
    if (futureA) futureA.setOpacity(0);
    if (futureB) futureB.setOpacity(0);
    futureMinute = null;
    if (layers[idx]) layers[idx].setOpacity(opacity);
    if (pair && pair.layer) pair.layer.setOpacity(opacity);
  }

  function futureShowing() { return futureMinute; }

  /* The loop crosses "now": after the newest observed frame it keeps going
   * through the HRRR leads (hourly, to +18 h — every future frame is a
   * fresh fetch, so the animation visits fewer stops than the scrubber
   * offers), then wraps back to the oldest observed frame. The field
   * report that drove this: "when I play it it stops before the forecast". */
  /* The future half joins the loop only after a deliberate Play press.
   * The autoplay that starts at boot must stay an observed-frames affair:
   * every future frame is a network fetch, and a page left playing in the
   * background would otherwise stream forecast tiles forever — bandwidth
   * nobody asked for, and a service worker kept so busy that updates
   * never promote. */
  var loopFuture = false;

  function playLeads() {
    /* No future half while replaying an archive: loopFuture is armed by any
     * Play press and stays armed, so without the historyAt gate a played
     * archived hour ran off its twelfth frame into TODAY'S HRRR forecast —
     * months of calendar crossed mid-loop, reported from the field as
     * "the historic radar is showing forecast". */
    return (source === 'global' || historyAt || !loopFuture) ? [] : C.HRRR_PLAY_LEADS;
  }

  function step() {
    var leads = playLeads();
    if (futureMinute === null) {
      if (idx + 1 < frames.length || !leads.length) {
        show(idx + 1 >= frames.length ? 0 : idx + 1);
        return;
      }
      showFuture(leads[0], true);
      if (onFutureFrame) onFutureFrame(leads[0]);
      return;
    }
    // The next play lead past wherever we are (a scrub may have landed
    // between hourly stops).
    var next = null;
    for (var i = 0; i < leads.length; i++) {
      if (leads[i] > futureMinute) { next = leads[i]; break; }
    }
    if (next === null) {
      clearFuture();
      if (onFutureFrame) onFutureFrame(null);
      show(0);
      return;
    }
    showFuture(next, true);
    if (onFutureFrame) onFutureFrame(next);
  }

  function tick() {
    step();
    timer = setTimeout(tick,
      futureMinute !== null ? C.RADAR_FUTURE_FRAME_MS : C.RADAR_FRAME_MS);
  }

  function play() {
    stop();
    playing = true;
    timer = setTimeout(tick, C.RADAR_FRAME_MS);
  }

  function stop() { if (timer) clearTimeout(timer); timer = null; }
  function pause() { stop(); playing = false; }
  function toggle() {
    loopFuture = true;                  // a human pressed Play (or Space)
    if (playing) pause(); else play();
    return playing;
  }
  function isPlaying() { return playing; }

  function setOpacity(v) {
    if (pair && pair.layer) pair.layer.setOpacity(v);
    opacity = v;
    if (futureMinute !== null) {
      if (futureFront) futureFront.setOpacity(v);
      return;                           // observed frames stay hidden
    }
    if (layers[idx]) layers[idx].setOpacity(opacity);
  }

  function goto(i) { pause(); show(i); }

  /* ── NWS warning polygons (F7) ──────────────────────────────────────── */

  var SEVERITY_STYLE = {
    Extreme: { color: '#ff2d55', weight: 2.5, fillOpacity: 0.16 },
    Severe: { color: '#ff9f0a', weight: 2, fillOpacity: 0.12 },
    Moderate: { color: '#ffd60a', weight: 1.5, fillOpacity: 0.08 },
    Minor: { color: '#64d2ff', weight: 1.2, fillOpacity: 0.06 },
    Unknown: { color: '#8e8e93', weight: 1, fillOpacity: 0.05 }
  };

  // Tornado and severe-thunderstorm warnings are what a chaser is looking for;
  // give them the loudest treatment regardless of the CAP severity field.
  function styleFor(props) {
    var ev = (props.event || '').toLowerCase();
    if (ev.indexOf('tornado') !== -1) return { color: '#ff375f', weight: 3, fillOpacity: 0.16 };
    if (ev.indexOf('severe thunderstorm') !== -1) return { color: '#ff9f0a', weight: 2.5, fillOpacity: 0.10 };
    if (ev.indexOf('flash flood') !== -1) return { color: '#30d158', weight: 2, fillOpacity: 0.08 };
    if (ev.indexOf('watch') !== -1) return { color: '#bf5af2', weight: 1.5, fillOpacity: 0.05, dashArray: '6 4' };
    return SEVERITY_STYLE[props.severity] || SEVERITY_STYLE.Unknown;
  }

  /* All of them, deliberately — no viewport culling. The old version culled
   * against map.getBounds() at load time, which was wrong twice over: with
   * sections at every width the polygons usually load while the radar is
   * display:none, where a zero-size map's bounds intersect nothing and every
   * warning silently vanished; and even on a visible map, culling against
   * the load-time viewport meant panning somewhere new never revealed the
   * warnings there. A few hundred polygons is nothing to the canvas
   * renderer, and a tornado warning is the last thing to optimise away. */

  /* Popup opening that survives a finger. A tap on a canvas-rendered layer
   * arrives twice — the pointer gesture, then the browser's synthesized mouse
   * click ~10ms later — and Leaflet's built-in bindPopup toggle reads the
   * pair as open-then-close. On every phone, a warning popup died in the same
   * gesture that asked for it; a mouse only ever sends one click, which is
   * how it shipped. Opening manually with a short duplicate window keeps the
   * toggle (a genuine second tap still closes) while ignoring the ghost.
   * closeOnClick is off because the ghost also lands on the map itself. */
  function tapPopup(layer, html, opts) {
    var popup = L.popup(L.extend({ closeOnClick: false, autoClose: true,
      autoPanPadding: [12, 12] }, opts || {})).setContent(html);
    var openedAt = 0;
    layer.on('click', function (e) {
      if (popup.isOpen()) {
        if (Date.now() - openedAt < 700) return;   // the synthesized ghost
        map.closePopup(popup);                     // a real second tap toggles
        return;
      }
      openedAt = Date.now();
      // Never wider than the map: on a phone the default 300 px ran the
      // popup flush against the map's right edge.
      popup.options.maxWidth = Math.max(160, Math.min(320, map.getSize().x - 56));
      popup.setLatLng(e.latlng).openOn(map);
    });
    return popup;
  }

  var warningsVisible = true;

  /* The layers panel can switch the warning polygons off — for reading the
   * radar under a stack of watch boxes — without forgetting them. */
  function setWarningsVisible(v) {
    warningsVisible = !!v;
    if (!map || !polygons) return;
    if (warningsVisible) { if (!map.hasLayer(polygons)) polygons.addTo(map); }
    else if (map.hasLayer(polygons)) map.removeLayer(polygons);
  }

  function setPolygons(features) {
    if (!map || !polygons) return;
    polygons.clearLayers();
    features.forEach(function (f) {
      var layer;
      try {
        layer = L.geoJSON(f, {
          style: styleFor(f.properties || {}), interactive: true, pane: 'features'
        });
      } catch (e) { return; }             // malformed geometry: skip, not crash
      var p = f.properties || {};
      tapPopup(layer, '<strong>' + escapeHtml(p.event || 'Alert') + '</strong><br>' +
        escapeHtml((p.headline || '').slice(0, 220)));
      polygons.addLayer(layer);
    });
  }

  /* ── Storm cell markers (js/cells.js supplies the detections) ───────── */

  var cellLayer = null;

  var CELL_COLOR = {
    extreme: '#ff2d55', high: '#ff6b8a', elevated: '#ff9f0a',
    moderate: '#ffd60a', low: '#8e8e93'
  };

  function setCells(cells, opts) {
    if (!map || typeof global.L === 'undefined') return;
    if (cellLayer) { map.removeLayer(cellLayer); cellLayer = null; }
    if (!cells || !cells.length || (opts && opts.hidden)) return;

    cellLayer = L.layerGroup();
    var imperial = opts && opts.imperial;

    cells.forEach(function (c) {
      var color = CELL_COLOR[c.band.key] || CELL_COLOR.low;

      // Projected track: where the cell goes over the next 30 minutes.
      if (c.speedKt > 0) {
        var to = global.Cells.project(c, 30);
        cellLayer.addLayer(L.polyline([[c.lat, c.lon], [to.lat, to.lon]], {
          color: color, weight: 2, opacity: 0.8, dashArray: '5 5', pane: 'features'
        }));
        cellLayer.addLayer(L.circleMarker([to.lat, to.lon], {
          radius: 3, color: color, weight: 1.5, fillOpacity: 0.4, pane: 'features'
        }));
      }

      // Rotation gets a ring; a TVS gets two, so it reads at a glance.
      if (c.mesoRank > 0 || c.tvs) {
        cellLayer.addLayer(L.circleMarker([c.lat, c.lon], {
          radius: 13, color: c.tvs ? '#ff2d55' : '#ffd60a',
          weight: 2.5, fill: false, opacity: 1, pane: 'features'
        }));
      }
      if (c.tvs) {
        cellLayer.addLayer(L.circleMarker([c.lat, c.lon], {
          radius: 19, color: '#ff2d55', weight: 1.5, fill: false, opacity: 0.8,
          dashArray: '3 4', pane: 'features'
        }));
      }

      var m = L.circleMarker([c.lat, c.lon], {
        radius: 7, color: '#ffffff', weight: 2,
        fillColor: color, fillOpacity: 1, pane: 'features'
      });
      var reasons = c.reasons.slice(0, 4).map(function (r) {
        return '<li>' + escapeHtml(r.label) + '</li>';
      }).join('');
      tapPopup(m,
        '<strong>' + escapeHtml(c.site + ' cell ' + c.stormId) + '</strong> — ' +
        escapeHtml(c.band.label) + ' (' + c.score + ')<br>' +
        (c.approach ? escapeHtml(
          (imperial ? (c.approach.distance * 0.621371).toFixed(0) + ' mi'
                    : c.approach.distance.toFixed(0) + ' km') +
          ' away, moving ' + Math.round(c.approach.towardDeg) + '°') + '<br>' : '') +
        '<ul style="margin:6px 0 0;padding-left:16px">' + reasons + '</ul>');
      cellLayer.addLayer(m);
    });

    cellLayer.addTo(map);
  }

  /* The suggested vantage, drawn with the line of sight it was solved for.
   * A marker alone would say "go here"; the sight line says "go here and look
   * that way", which is the actual instruction. */
  var vantage = null;
  function setVantage(target) {
    if (!map) return;
    if (vantage) { map.removeLayer(vantage); vantage = null; }
    if (!target) return;
    vantage = L.layerGroup([], { pane: 'features' });

    L.circleMarker([target.lat, target.lon], {
      pane: 'features', radius: 7, color: '#ffce78', weight: 2,
      fillColor: '#ffce78', fillOpacity: 0.35
    }).bindTooltip('Suggested vantage', { direction: 'top' }).addTo(vantage);

    // Sight line back to the cell it was solved against.
    var kmPerDegLat = 111.32;
    var kmPerDegLon = 111.32 * Math.cos(U.toRad(target.lat));
    var rad = U.toRad(target.lookBearing);
    var end = [
      target.lat + (target.standoffKm * Math.cos(rad)) / kmPerDegLat,
      target.lon + (target.standoffKm * Math.sin(rad)) / kmPerDegLon
    ];
    L.polyline([[target.lat, target.lon], end], {
      pane: 'features', color: '#ffce78', weight: 2, dashArray: '5 5', opacity: 0.9
    }).addTo(vantage);

    vantage.addTo(map);
  }

  function focusCell(cell) {
    if (!map) return;
    map.setView([cell.lat, cell.lon], Math.max(map.getZoom(), 9));
  }

  function escapeHtml(s) {
    return String(s).replace(/[&<>"']/g, function (c) {
      return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c];
    });
  }

  /* Both maps, always. The second pane is created inside a container that is
   * often still hidden or mid-resize, and a Leaflet map that never learns its
   * real size renders as an empty rectangle — which reads as a dead feed
   * rather than as a layout problem. */
  function invalidate() {
    setTimeout(function () {
      if (map) map.invalidateSize();
      if (pair) pair.map.invalidateSize();
    }, 60);
  }
  function center() { return map ? map.getCenter() : null; }
  function getMap() { return map; }

  function setFrameInterval(ms) {
    C.RADAR_FRAME_MS = ms;
    if (playing) play();
  }

  global.Radar = {
    available: available, init: init, loadFrames: loadFrames,
    show: show, goto: goto, play: play, pause: pause, toggle: toggle,
    isPlaying: isPlaying, setOpacity: setOpacity,
    refresh: refresh,
    frameIndex: function () { return idx; },
    setMarker: setMarker, panTo: panTo, setPolygons: setPolygons,
    invalidate: invalidate,
    openPair: openPair,
    closePair: closePair,
    setPairProduct: setPairProduct,
    setVantage: setVantage,
    getPair: getPair, center: center, setBaseTheme: setBaseTheme,
    getMap: getMap, setFrameInterval: setFrameInterval,
    setCells: setCells, focusCell: focusCell,
    setSite: setSite, getSite: getSite, setProduct: setProduct, getProduct: getProduct,
    productInfo: productInfo, drawRangeRing: drawRangeRing,
    setSitePicker: setSitePicker, drawSiteMarkers: drawSiteMarkers,
    tapPopup: tapPopup,
    setWarningsVisible: setWarningsVisible,
    VELOCITY_SCALE: VELOCITY_SCALE,
    showFuture: showFuture, clearFuture: clearFuture, futureShowing: futureShowing,
    setHistory: setHistory, historyShowing: historyShowing, frameNear: frameNear,
    setClean: setClean, cleanOn: cleanOn, maskFor: maskFor, applyMask: applyMask, maskRadius: maskRadius,
    setSource: setSource, getSource: getSource, pickSource: pickSource,
    inConus: inConus, legend: legend,
    DBZ_SCALE: DBZ_SCALE, RV_SCALE: RV_SCALE
  };
})(window);

