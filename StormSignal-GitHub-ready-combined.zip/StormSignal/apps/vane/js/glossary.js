/* Vane — tap any term you don't know.
 *
 * A UX audit of the shipped app counted 62 occurrences of meteorological
 * jargon on the Chase tab and 17 in Simple mode. The instinct is to delete it,
 * but the jargon is the product: a chaser needs "0–3 km SRH 340 m²/s²", not
 * "quite twisty". Deleting it would make the app friendlier to someone who
 * would not have opened it and useless to the person who did.
 *
 * So nothing is removed. Instead every term the app uses becomes a button:
 * press it and get one plain sentence saying what it is, and where it helps,
 * one saying what it means for you right now. Depth stays; the wall goes.
 *
 * Two rules the definitions follow:
 *   - No term is defined using another undefined term.
 *   - Where a number has a rough threshold, say the number. "High shear" is
 *     not a definition; "over about 35 kt supports organised storms" is.
 *
 * Nothing here fetches anything, and nothing here is generated. These are
 * written definitions, checked against the sources the app already cites. */
(function (global) {
  'use strict';

  /* Each entry: what it is, then optionally why a user would care.
   * `also` lists surface forms that should resolve to the same entry. */
  var TERMS = {
    /* ── Instability and the storm environment ─────────────────────────── */
    'CAPE': {
      title: 'CAPE',
      what: 'How much energy a rising parcel of air has available — the fuel for a thunderstorm, in joules per kilogram.',
      why: 'Under 500 is weak, 1000–2500 supports strong storms, and over 3000 is a lot of fuel. Fuel alone does not make a storm: something still has to lift the air.'
    },
    'CIN': {
      title: 'CIN (convective inhibition)',
      what: 'The lid. A layer of warmer air aloft that a rising parcel has to punch through before it can build a storm.',
      why: 'Near zero means storms go up easily and often stay messy. Around −50 to −150 holds the fuel back until something strong breaks the lid, which is how isolated, well-organised storms happen.',
      also: ['convective inhibition', 'capped']
    },
    'Lifted index': {
      title: 'Lifted index',
      what: 'How much warmer a rising parcel is than the air around it at about 5.5 km up, in °C.',
      why: 'Negative means the parcel keeps rising on its own. Below −4 is very unstable.',
      also: ['lifted index']
    },
    'Freezing level': {
      title: 'Freezing level',
      what: 'The height where the air first reaches 0 °C.',
      why: 'Hail grows above it and melts below it. A low freezing level lets hail reach the ground intact; a high one melts it on the way down.',
      also: ['freezing level']
    },
    'Mixing height': {
      title: 'Mixing height',
      what: 'The top of the turbulent layer of air stirred up by daytime heating, also called the boundary layer.',
      why: 'Deeper mixing means drier, gustier surface air and a higher cloud base.',
      also: ['mixing height', 'boundary layer']
    },
    'LCL': {
      title: 'LCL (cloud base)',
      what: 'The height where rising air cools enough to condense — in other words, the base of the cloud.',
      why: 'Low cloud bases, under about 1000 m, favour tornadoes and give you a visible wall cloud. High bases mean a storm you can see the structure of from a long way off.',
      also: ['cloud base']
    },

    /* ── Wind structure ────────────────────────────────────────────────── */
    'shear': {
      title: 'Wind shear',
      what: 'How much the wind changes between two heights — in both speed and direction.',
      why: 'Shear is what tilts a storm so its rain falls away from its updraft instead of killing it. Roughly 35 kt or more over 0–6 km supports supercells.',
      also: ['bulk shear', 'wind shear']
    },
    'SRH': {
      title: 'SRH (storm-relative helicity)',
      what: 'How much spin a storm can gather from the winds it moves through, in m²/s². It depends on the storm\'s own motion, which is why it is called storm-relative.',
      why: 'Over about 150 in the lowest 1 km favours rotating storms; over 300 is a strong tornado environment.',
      also: ['storm-relative helicity', 'helicity']
    },
    'Hodograph': {
      title: 'Hodograph',
      what: 'A single plot of the wind at every height, drawn as a curve — each point is the wind at one altitude.',
      why: 'A long curve means lots of shear; a curved (rather than straight) shape means the storm can gather spin. Chasers read the shape, not the numbers.',
      also: ['hodograph']
    },
    'Bunkers': {
      title: 'Bunkers storm motion',
      what: 'A standard method for predicting where a supercell will actually travel, which is not the same as where the wind is blowing.',
      why: 'Supercells deviate off the mean wind — the right mover (RM) turns right of it, the left mover (LM) turns left. RM is the one that usually matters in the US.',
      also: ['right mover', 'left mover', 'storm motion']
    },
    'Supercell index': {
      title: 'Supercell index',
      what: 'Vane\'s own blend of fuel, shear and spin into one number, computed in your browser.',
      why: 'A rough "is this environment supercell-shaped" gauge. It is not the SPC\'s official composite parameter and should not be quoted as one.'
    },

    /* ── Radar ─────────────────────────────────────────────────────────── */
    'dBZ': {
      title: 'dBZ',
      what: 'Radar reflectivity — how much energy is coming back to the radar. It is the number behind every colour on the map.',
      why: 'Around 20 is drizzle, 40 is heavy rain, 50+ usually means hail, and 60+ means large hail.'
    },
    'reflectivity': {
      title: 'Reflectivity',
      what: 'The standard radar picture: how much precipitation the beam is hitting, coloured by intensity.',
      why: 'This is what shows you where the rain is and how heavy. It shows nothing about rotation — for that you need velocity.',
      also: ['base reflectivity']
    },
    'velocity': {
      title: 'Velocity',
      what: 'Radar shows how fast the air is moving toward or away from the radar site — not the full wind, only the part along the beam.',
      why: 'Rotation shows up as strong inbound and outbound speeds right next to each other. That pairing is what a warning meteorologist looks for.',
      also: ['base velocity']
    },
    'storm-relative': {
      title: 'Storm-relative velocity',
      what: 'Velocity with the storm\'s own forward motion subtracted out.',
      why: 'A fast-moving storm can hide its rotation in plain velocity. Removing its travel makes the spin obvious.',
      also: ['storm-relative velocity']
    },
    'echo top': {
      title: 'Echo top',
      what: 'The highest altitude at which the radar still detects the storm, in thousands of feet.',
      why: 'A tall storm has a strong updraft holding it up. Over about 50,000 ft is a serious storm; a collapsing top often precedes a downburst.',
      also: ['echo tops']
    },
    'VIL': {
      title: 'VIL',
      what: 'Vertically integrated liquid — how much water the radar sees stacked up in the whole column above a point.',
      why: 'High VIL over a small area means a lot of water held aloft, which is the hail signature. VIL density (VIL divided by storm height) is the better hail gauge.',
      also: ['vertically integrated liquid', 'VIL density']
    },
    'mesocyclone': {
      title: 'Mesocyclone',
      what: 'A rotating updraft inside a storm, a few kilometres across — the defining feature of a supercell.',
      why: 'The radar network detects and ranks these automatically. A strong, low, persistent one is what precedes most tornadoes.',
      also: ['mesocyclone', 'MDA']
    },
    'TVS': {
      title: 'TVS',
      what: 'Tornado vortex signature — the radar\'s automatic flag for a very tight, very strong rotation couplet.',
      why: 'It is an algorithm, not an observation: a TVS is not a confirmed tornado, and tornadoes occur without one. Treat it as "look here now".'
    },
    'NEXRAD': {
      title: 'NEXRAD',
      what: 'The US national network of about 160 Doppler weather radars.',
      why: 'Vane can point at any one of them individually, or at the stitched national picture.'
    },
    'super-res': {
      title: 'Super-resolution',
      what: 'A finer sampling of the same radar sweep — narrower slices, so small features stay sharp.',
      why: 'Better for picking out a tight couplet or a hook, at the cost of a slightly noisier image.',
      also: ['super-resolution']
    },
    'tilt': {
      title: 'Tilt',
      what: 'The angle the radar dish is pointed above the horizon. Vane shows the lowest one, 0.5°.',
      why: 'The beam climbs as it travels, so far from the radar even the lowest tilt is looking thousands of feet up — it cannot see what is happening at ground level out there.',
      also: ['0.5° tilt']
    },

    /* ── Forecast confidence ───────────────────────────────────────────── */
    'ensemble': {
      title: 'Ensemble',
      what: 'The same forecast model run many times from slightly different starting conditions — 51 runs, in the case used here.',
      why: 'Where the runs agree, the forecast is trustworthy. Where they scatter, the atmosphere itself is undecided, and no amount of model resolution fixes that.'
    },
    'spread': {
      title: 'Spread',
      what: 'How far apart the individual ensemble runs are from each other.',
      why: 'Spread is the honest measure of confidence. Narrow spread means a firm forecast; wide spread means the model is telling you it does not know.'
    },
    'percentile': {
      title: 'Percentiles (p10 / p90)',
      what: 'p10 is the value only 10% of the runs fall below; p90 is the value only 10% exceed. The band between them holds the middle 80%.',
      why: 'It is a plain range: eight runs in ten land inside it.',
      also: ['p10', 'p90', 'percentiles']
    },
    'skill horizon': {
      title: 'Skill horizon',
      what: 'The day beyond which the ensemble stops beating the calendar — where its spread is as wide as the normal range for that date.',
      why: 'Past it, a forecast is not wrong so much as uninformative: you would do as well looking up the average for that day. Vane measures this per location rather than assuming a fixed day.'
    },
    'climatology': {
      title: 'Climatology',
      what: 'What this date normally looks like at this place, worked out from 20 years of past weather.',
      why: 'It is the baseline a forecast has to beat to be worth reading.',
      also: ['climatological', 'normals']
    },
    'anomaly': {
      title: 'Anomaly',
      what: 'The difference between the forecast and what is normal for that date and place.',
      why: '"29 °C" means nothing on its own. "8 °C above normal" tells you it is a heatwave.'
    },
    'ERA5': {
      title: 'ERA5',
      what: 'ECMWF\'s reanalysis — a reconstruction of past global weather, hour by hour, from 1940 onward.',
      why: 'It is where the "normal for this date" figures come from.',
      also: ['reanalysis']
    },
    'deterministic': {
      title: 'Deterministic run',
      what: 'A single model run, as opposed to an ensemble of many.',
      why: 'It is usually the sharpest-looking forecast and gives you no way to tell how much to trust it.'
    },
    'meteogram': {
      title: 'Meteogram',
      what: 'One chart showing temperature, rain, wind and cloud on a shared timeline.',
      why: 'Faster to read than four separate charts, because what matters is usually how they line up.'
    },

    /* ── Products and sources ──────────────────────────────────────────── */
    'AFD': {
      title: 'Area Forecast Discussion',
      what: 'The text a local National Weather Service forecaster writes explaining their reasoning — what they expect, and what they are unsure about.',
      why: 'It is the only place the human thinking behind the forecast is published. It is written for other meteorologists, which is why Vane can translate it.',
      also: ['area forecast discussion', 'forecaster\'s discussion']
    },
    'SPC': {
      title: 'SPC',
      what: 'The Storm Prediction Center — the national office that forecasts severe thunderstorms and tornadoes for the whole US.',
      why: 'Its convective outlook is the standard day-ahead severe weather map.'
    },
    'convective': {
      title: 'Convective',
      what: 'To do with thunderstorms — air rising because it is warmer than its surroundings.',
      why: 'A "convective outlook" is a thunderstorm forecast.',
      also: ['convection']
    },
    'sounding': {
      title: 'Sounding',
      what: 'A vertical slice of the atmosphere at one place: temperature, moisture and wind at every height.',
      why: 'Almost every number on the Chase tab is computed from one.',
      also: ['wind profile']
    },
    'CWA': {
      title: 'CWA',
      what: 'County Warning Area — the patch of ground one National Weather Service office is responsible for.',
      why: 'It decides which office writes the discussion you are reading.'
    },

    /* ── Units ─────────────────────────────────────────────────────────── */
    'kt': {
      title: 'kt (knots)',
      what: 'Nautical miles per hour. One knot is about 1.15 mph or 1.85 km/h.',
      why: 'Aviation and severe-weather work are done in knots, so the chase numbers keep them.',
      also: ['knots', 'knot']
    },
    'hPa': {
      title: 'hPa',
      what: 'Hectopascals, the unit of air pressure. Sea level averages about 1013 hPa.',
      why: 'Upper-air data is labelled by pressure rather than height — 500 hPa is roughly 5.5 km up.'
    },
    'kft': {
      title: 'kft',
      what: 'Thousands of feet. 40 kft is 40,000 ft, about 12 km.',
      why: 'Storm heights are quoted this way by convention.'
    },
    'AGL': {
      title: 'AGL',
      what: 'Above ground level — height measured from the ground beneath you, not from sea level.',
      why: 'For storm structure, height above the ground is what matters.'
    },
    'MSL': {
      title: 'MSL',
      what: 'Above mean sea level — height measured from the sea surface, the same zero everywhere on earth.',
      why: 'Aviation and model levels use it. On high terrain it can read a kilometre or more above the height above the ground beneath you.'
    },
    'dewpoint': {
      title: 'Dewpoint',
      what: 'The temperature air would have to cool to before water condenses out of it. It is a direct measure of how much moisture is present.',
      why: 'Above about 15 °C / 60 °F it feels humid; above 21 °C / 70 °F it is storm fuel.',
      also: ['dew point']
    },
    'geopotential': {
      title: 'Geopotential height',
      what: 'The height of a given pressure level above sea level.',
      why: 'It is how a model reports "how high up is 500 hPa here", which is what turns pressure-level winds into winds at a height.',
      also: ['geopotential height']
    },
    'derived': {
      title: 'Derived',
      what: 'Computed by Vane in your browser from raw model output — not supplied ready-made by a weather vendor.',
      why: 'It means you can check the working, and it means the number may differ slightly from an official product computed a different way. Vane labels these rather than passing them off as observations.'
    }
  };

  /* Longest first, so "storm-relative velocity" wins over "velocity" and
   * "0–6 km shear" is not half-matched by "shear". */
  var INDEX = (function () {
    var out = [];
    Object.keys(TERMS).forEach(function (key) {
      var t = TERMS[key];
      var forms = [key].concat(t.also || []);
      forms.forEach(function (f) { out.push({ form: f, key: key }); });
    });
    return out.sort(function (a, b) { return b.form.length - a.form.length; });
  })();

  function get(key) { return TERMS[key] || null; }
  function has(word) {
    var w = String(word || '').toLowerCase();
    for (var i = 0; i < INDEX.length; i++) if (INDEX[i].form.toLowerCase() === w) return INDEX[i].key;
    return null;
  }

  function esc(s) { return s.replace(/[-/\\^$*+?.()|[\]{}]/g, '\\$&'); }

  /* An acronym must match exactly — "CIN" is a term, "cin" inside a word is
   * not, and "kt" must not fire inside "kite". Multi-word phrases are matched
   * case-insensitively because they appear mid-sentence. */
  function patternFor(form) {
    var acronym = /^[A-Z0-9]{2,5}$/.test(form) || form === 'dBZ' || form === 'kt' || form === 'hPa' || form === 'kft';
    var body = esc(form);
    return new RegExp('(^|[^\\w-])(' + body + ')(?![\\w-])', acronym ? '' : 'i');
  }
  var PATTERNS = INDEX.map(function (e) {
    return { key: e.key, form: e.form, re: patternFor(e.form) };
  });

  /* Headings are excluded along with the obvious ones. A dotted underline
   * through half of "Convective parameters" reads as damage, not as an offer,
   * and the term will be decorated in the card's body a line later anyway.
   * PRE is the raw forecaster's discussion — that is someone else's prose set
   * in a fixed-width teletype grid, and inserting elements into it would
   * break the alignment it depends on. */
  var SKIP = /^(SCRIPT|STYLE|SVG|PRE|CODE|TEXTAREA|INPUT|SELECT|OPTION|BUTTON|SUMMARY|TABLE|H1|H2|H3|H4|LABEL)$/;

  function skippable(node) {
    for (var p = node.parentNode; p && p.nodeType === 1; p = p.parentNode) {
      if (SKIP.test(p.tagName)) return true;
      if (p.classList && (p.classList.contains('gl-term') ||
          p.classList.contains('no-gloss'))) return true;
    }
    return false;
  }

  /* Decorate the first occurrence of each distinct term inside `root`.
   *
   * First occurrence only, deliberately. Turning all nine "dBZ"s on the Chase
   * tab into buttons would replace a wall of jargon with a wall of underlines
   * — the point is that the term is explained once where you meet it, not that
   * every instance is clickable.
   *
   * Safe to call repeatedly on the same element: terms already decorated seed
   * the used-set, so a re-render decorates fresh content and a no-op render
   * adds nothing. Without that, every refresh would underline one more
   * occurrence until the whole card was dotted. */
  function decorate(root) {
    if (!root || !global.document) return 0;
    var used = {}, made = 0;
    Array.prototype.forEach.call(root.querySelectorAll('.gl-term'), function (b) {
      if (b.dataset.term) used[b.dataset.term] = true;
    });
    var walker = document.createTreeWalker(root, NodeFilter.SHOW_TEXT, null, false);
    var texts = [], n;
    while ((n = walker.nextNode())) {
      if (n.nodeValue && /\S/.test(n.nodeValue) && !skippable(n)) texts.push(n);
    }

    texts.forEach(function (node) {
      for (var i = 0; i < PATTERNS.length; i++) {
        var p = PATTERNS[i];
        if (used[p.key]) continue;
        var m = p.re.exec(node.nodeValue);
        if (!m) continue;
        var at = m.index + m[1].length;
        var rest = node.splitText(at);
        rest.nodeValue = rest.nodeValue.slice(m[2].length);
        var btn = document.createElement('button');
        btn.className = 'gl-term';
        btn.type = 'button';
        btn.textContent = m[2];
        btn.dataset.term = p.key;
        btn.setAttribute('aria-label', m[2] + ' — what does this mean?');
        node.parentNode.insertBefore(btn, rest);
        used[p.key] = true;
        made++;
        node = rest;             // keep scanning the tail of the same run
        i = -1;
      }
    });
    return made;
  }

  /* ── The popover ──────────────────────────────────────────────────────
   * One shared element, moved rather than recreated, so there is never more
   * than one definition on screen and nothing accumulates in the DOM. */

  var pop = null, openFor = null;

  function ensurePop() {
    if (pop) return pop;
    pop = document.createElement('div');
    pop.className = 'gl-pop';
    pop.id = 'gl-pop';
    pop.setAttribute('role', 'dialog');
    pop.setAttribute('aria-label', 'Definition');
    pop.hidden = true;
    document.body.appendChild(pop);
    return pop;
  }

  function close() {
    if (!pop || pop.hidden) return;
    pop.hidden = true;
    if (openFor) openFor.setAttribute('aria-expanded', 'false');
    openFor = null;
  }

  function open(btn) {
    var t = get(btn.dataset.term);
    if (!t) return;
    if (openFor === btn) { close(); return; }
    var el = ensurePop();
    el.innerHTML = '';
    var h = document.createElement('strong');
    h.className = 'gl-pop-title';
    h.textContent = t.title;
    el.appendChild(h);
    var w = document.createElement('p');
    w.className = 'gl-pop-what';
    w.textContent = t.what;
    el.appendChild(w);
    if (t.why) {
      var y = document.createElement('p');
      y.className = 'gl-pop-why';
      y.textContent = t.why;
      el.appendChild(y);
    }
    var x = document.createElement('button');
    x.className = 'gl-pop-close';
    x.type = 'button';
    x.setAttribute('aria-label', 'Close');
    x.textContent = '×';
    x.addEventListener('click', close);
    el.appendChild(x);

    el.hidden = false;
    place(el, btn);
    openFor = btn;
    btn.setAttribute('aria-expanded', 'true');
  }

  /* Anchored under the term, nudged back inside the viewport rather than
   * allowed to hang off the edge — on a 390px phone a naive left-align puts
   * half the definition off screen for anything in the right-hand column. */
  function place(el, btn) {
    var r = btn.getBoundingClientRect();
    var vw = global.innerWidth || 360, vh = global.innerHeight || 640;
    el.style.maxWidth = Math.min(340, vw - 24) + 'px';
    el.style.left = '0px'; el.style.top = '0px';
    var w = el.offsetWidth, h = el.offsetHeight;
    var left = Math.min(Math.max(12, r.left - 8), vw - w - 12);
    // Below the term if it fits, above it if not.
    var top = r.bottom + 8 + h < vh ? r.bottom + 8 : Math.max(12, r.top - h - 8);
    el.style.left = Math.round(left) + 'px';
    el.style.top = Math.round(top) + 'px';
  }

  function wire() {
    if (!global.document) return;
    document.addEventListener('click', function (e) {
      var btn = e.target && e.target.closest && e.target.closest('.gl-term');
      if (btn) { e.preventDefault(); e.stopPropagation(); open(btn); return; }
      if (!e.target.closest || !e.target.closest('.gl-pop')) close();
    });
    document.addEventListener('keydown', function (e) {
      if (e.key === 'Escape') close();
    });
    global.addEventListener('resize', close);
    // A popover anchored to an element that has scrolled away is worse than
    // no popover, and re-placing it on every scroll frame is jank.
    document.addEventListener('scroll', close, true);
  }

  /* Per card, not per page. If the whole of `main` were one root, "SRH" would
   * be pressable wherever it happened to appear first in document order —
   * possibly on a tab the reader is not on — and nowhere else. Each card
   * explains the terms it uses. */
  function decorateAll() {
    if (!global.document) return 0;
    var n = 0;
    Array.prototype.forEach.call(
      document.querySelectorAll('main > section, main > footer, #settings-body'),
      function (el) { n += decorate(el); });
    return n;
  }

  /* Terms arrive whenever anything re-renders — a refresh, a mode switch, a
   * new hour on the Chase tab, a storm cell selected — and there are around
   * thirty render functions. Calling decorate from each one is thirty chances
   * to forget, so instead watch the tree.
   *
   * Two things make that safe. Decoration is idempotent, so the pass our own
   * mutations trigger finds nothing to do and the loop settles. And Leaflet
   * mutates the map on every tile load, so map subtrees are filtered out
   * before the debounce — otherwise a radar animation would schedule a DOM
   * walk sixty times a second for content that has no prose in it. */
  var pending = 0;
  function observe() {
    if (!global.MutationObserver || !global.document) return null;
    var mo = new MutationObserver(function (records) {
      for (var i = 0; i < records.length; i++) {
        var t = records[i].target;
        if (t.nodeType === 1 && t.closest && t.closest('#map-pair, .gl-pop')) continue;
        if (pending) return;
        pending = global.setTimeout(function () { pending = 0; decorateAll(); }, 120);
        return;
      }
    });
    mo.observe(document.querySelector('main'), { childList: true, subtree: true, characterData: true });
    return mo;
  }

  global.Glossary = {
    TERMS: TERMS, get: get, has: has, decorate: decorate, decorateAll: decorateAll,
    open: open, close: close, wire: wire, observe: observe,
    count: function () { return Object.keys(TERMS).length; }
  };
})(window);
