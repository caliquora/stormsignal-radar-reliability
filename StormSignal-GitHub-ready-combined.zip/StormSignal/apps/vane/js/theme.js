/* Vane — dynamic sky theming.
 *
 * The 2026 design language for weather apps is "chromatic intelligence": the
 * palette *is* the weather. The background gradient is derived from the current
 * condition and the sun's actual altitude, so an amber late afternoon, a
 * charcoal thunderstorm and a blue-white winter night never look alike.
 *
 * One hard rule: every palette stays dark enough for white text to clear WCAG
 * AA. Legibility on a sunlit windshield (F8) outranks prettiness, so the
 * gradients are deep and saturated rather than pastel. */
(function (global) {
  'use strict';

  var C = global.VaneConfig;

  /* Sun altitude bands, in degrees. These are the same thresholds the astro
   * module uses for civil twilight and golden hour, so the sky changes at the
   * moment the light actually changes. */
  function band(altitude) {
    if (altitude < -12) return 'night';
    if (altitude < -0.833) return 'twilight';
    if (altitude < 8) return 'golden';
    return 'day';
  }

  function group(code) {
    if (code === 0 || code === 1) return 'clear';
    if (code === 2) return 'partly';
    if (code === 3) return 'cloudy';
    if (code === 45 || code === 48) return 'fog';
    if (code >= 51 && code <= 57) return 'drizzle';
    if (code >= 71 && code <= 77) return 'snow';
    if (code === 85 || code === 86) return 'snow';
    if (code >= 95) return 'storm';
    if (code >= 61 && code <= 82) return 'rain';
    return 'cloudy';
  }

  /* Gradient stops run top → bottom: zenith, horizon, ground haze.
   * Accent is the colour used for interactive chrome against that sky. */
  var SKIES = {
    clear: {
      day: ['#0d3667', '#125b9b', '#137abf', '#4da3e8'],
      golden: ['#11284f', '#763620', '#9a570e', '#e8843c'],
      twilight: ['#151b41', '#4c2d6e', '#883f5b', '#8a4a7a'],
      night: ['#090f23', '#192654', '#2a3f7b', '#3b6fb8']
    },
    partly: {
      day: ['#103665', '#215b92', '#3c7aab', '#4d9ad8'],
      golden: ['#162948', '#6b3d2b', '#995725', '#d4884e'],
      twilight: ['#171c3c', '#483164', '#7c4662', '#7f5078'],
      night: ['#0a0f22', '#1a274f', '#2c416d', '#3a68a8']
    },
    cloudy: {
      day: ['#283749', '#475b70', '#5e788f', '#6f93b5'],
      golden: ['#1f293d', '#55444f', '#845f50', '#a8826a'],
      twilight: ['#191e31', '#393a52', '#5f526c', '#6b5f80'],
      night: ['#0c0f1f', '#22293a', '#384257', '#48566b']
    },
    fog: {
      day: ['#32373d', '#525a62', '#6b7681', '#7d909e'],
      golden: ['#282831', '#514742', '#786355', '#96836f'],
      twilight: ['#1d1e27', '#3b3b46', '#5c555e', '#6a6472'],
      night: ['#0f1015', '#262931', '#3d424c', '#4d545e']
    },
    drizzle: {
      day: ['#22384b', '#3f5c74', '#5d788c', '#5d8fa8'],
      golden: ['#1e293b', '#53454f', '#7a625a', '#8f7566'],
      twilight: ['#191e31', '#373b50', '#5d536a', '#5f5a72'],
      night: ['#0c0f1d', '#20293e', '#374356', '#3f5163'],
      precip: 'rain'
    },
    rain: {
      day: ['#22384f', '#395c78', '#597990', '#4a8299'],
      golden: ['#20283f', '#4f4557', '#7a6261', '#7a655c'],
      twilight: ['#181e33', '#383a55', '#59536e', '#524e66'],
      night: ['#0a0f1f', '#1e2841', '#36425a', '#38495c'],
      precip: 'rain'
    },
    storm: {
      day: ['#2e3458', '#525489', '#786e9e', '#7b6bd4'],
      golden: ['#23264a', '#55406a', '#855a77', '#8a6ad0'],
      twilight: ['#1a1c38', '#3b3762', '#5e4f81', '#8060d0'],
      night: ['#0b0f21', '#23264a', '#413e64', '#6f5cc4'],
      precip: 'rain',
      storm: true
    },
    snow: {
      day: ['#2b3746', '#4b5a6d', '#5b7894', '#7fa8cc'],
      golden: ['#22293a', '#4f4652', '#756366', '#9b8fa8'],
      twilight: ['#1a1e30', '#353b54', '#50566e', '#6e7a9c'],
      night: ['#0c0f1e', '#20293a', '#34435b', '#4a6486'],
      precip: 'snow'
    }
  };

  var current = { key: null, precip: null };

  function paletteFor(code, altitude) {
    var g = group(code);
    var b = band(altitude);
    var sky = SKIES[g] || SKIES.cloudy;
    return {
      key: g + '-' + b,
      group: g,
      band: b,
      stops: sky[b],
      precip: sky.precip || null,
      storm: !!sky.storm
    };
  }

  /* Apply a palette by writing CSS custom properties. Everything downstream —
   * cards, borders, accents — is expressed relative to these, so one write
   * re-skins the whole app and the CSS transition animates it. */
  function apply(code, altitude, opts) {
    opts = opts || {};
    var p = paletteFor(code === null || code === undefined ? 3 : code, altitude);
    var root = document.documentElement;

    root.style.setProperty('--sky-0', p.stops[0]);
    root.style.setProperty('--sky-1', p.stops[1]);
    root.style.setProperty('--sky-2', p.stops[2]);
    root.style.setProperty('--accent', p.stops[3]);

    document.body.dataset.sky = p.group;
    document.body.dataset.band = p.band;

    if (p.key !== current.key) {
      current.key = p.key;
      startPrecip(opts.reduceMotion ? null : p.precip, p.storm && !opts.reduceMotion);
    }
    return p;
  }

  /* ── Precipitation overlay ───────────────────────────────────────────
   * A canvas of falling rain or snow, sized to the viewport and paused when
   * the tab is hidden. Purely decorative: it never conveys information the
   * forecast doesn't already state in words, and it is skipped entirely under
   * prefers-reduced-motion. */

  var canvas = null, ctx = null, particles = [], raf = null, mode = null;
  var flashTimer = null, flashAlpha = 0, stormOn = false;

  function ensureCanvas() {
    if (canvas) return;
    canvas = document.createElement('canvas');
    canvas.className = 'sky-precip';
    canvas.setAttribute('aria-hidden', 'true');
    document.body.appendChild(canvas);
    ctx = canvas.getContext('2d');
    global.addEventListener('resize', size);
    size();
  }

  function size() {
    if (!canvas) return;
    var dpr = Math.min(global.devicePixelRatio || 1, 2);
    canvas.width = global.innerWidth * dpr;
    canvas.height = global.innerHeight * dpr;
    canvas.style.width = global.innerWidth + 'px';
    canvas.style.height = global.innerHeight + 'px';
    ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
  }

  function seed(kind) {
    var w = global.innerWidth, h = global.innerHeight;
    var count = kind === 'snow' ? 70 : 120;
    particles = [];
    for (var i = 0; i < count; i++) {
      particles.push(kind === 'snow' ? {
        x: Math.random() * w, y: Math.random() * h,
        r: 1 + Math.random() * 2.4,
        vy: 12 + Math.random() * 24,
        drift: (Math.random() - 0.5) * 18,
        phase: Math.random() * Math.PI * 2
      } : {
        x: Math.random() * w, y: Math.random() * h,
        len: 8 + Math.random() * 16,
        vy: 340 + Math.random() * 260,
        vx: -30 - Math.random() * 25,
        alpha: 0.12 + Math.random() * 0.22
      });
    }
  }

  var last = 0;
  function frame(now) {
    raf = requestAnimationFrame(frame);
    if (document.hidden) return;
    var dt = Math.min((now - last) / 1000, 0.05);
    last = now;
    var w = global.innerWidth, h = global.innerHeight;
    ctx.clearRect(0, 0, w, h);

    if (mode === 'snow') {
      ctx.fillStyle = 'rgba(255,255,255,0.75)';
      particles.forEach(function (p) {
        p.phase += dt * 1.6;
        p.y += p.vy * dt;
        p.x += Math.sin(p.phase) * p.drift * dt;
        if (p.y > h + 4) { p.y = -4; p.x = Math.random() * w; }
        ctx.beginPath();
        ctx.arc(p.x, p.y, p.r, 0, Math.PI * 2);
        ctx.fill();
      });
    } else if (mode === 'rain') {
      ctx.lineCap = 'round';
      particles.forEach(function (p) {
        p.y += p.vy * dt;
        p.x += p.vx * dt;
        if (p.y > h + 20) { p.y = -20; p.x = Math.random() * (w + 120); }
        ctx.strokeStyle = 'rgba(190,220,255,' + p.alpha + ')';
        ctx.lineWidth = 1.1;
        ctx.beginPath();
        ctx.moveTo(p.x, p.y);
        ctx.lineTo(p.x + p.vx * 0.02, p.y + p.len);
        ctx.stroke();
      });
    }

    // Lightning: a rare double-flash, never bright enough to wash out text.
    if (flashAlpha > 0) {
      ctx.fillStyle = 'rgba(200,210,255,' + flashAlpha + ')';
      ctx.fillRect(0, 0, w, h);
      flashAlpha = Math.max(0, flashAlpha - dt * 1.8);
    }
  }

  function scheduleFlash() {
    if (!stormOn) return;
    flashTimer = setTimeout(function () {
      flashAlpha = 0.16;
      setTimeout(function () { if (stormOn) flashAlpha = 0.11; }, 110);
      scheduleFlash();
    }, 5000 + Math.random() * 12000);
  }

  function startPrecip(kind, storm) {
    stormOn = !!storm;
    if (flashTimer) { clearTimeout(flashTimer); flashTimer = null; }
    if (!kind) { stopPrecip(); if (storm) { ensureCanvas(); } else return; }
    mode = kind;
    ensureCanvas();
    if (kind) seed(kind);
    if (!raf) { last = performance.now(); raf = requestAnimationFrame(frame); }
    if (stormOn) scheduleFlash();
  }

  function stopPrecip() {
    mode = null;
    particles = [];
    if (raf) { cancelAnimationFrame(raf); raf = null; }
    if (ctx) ctx.clearRect(0, 0, global.innerWidth, global.innerHeight);
  }

  global.Theme = {
    apply: apply,
    paletteFor: paletteFor,
    group: group,
    band: band,
    stopPrecip: stopPrecip,
    SKIES: SKIES
  };
})(window);
