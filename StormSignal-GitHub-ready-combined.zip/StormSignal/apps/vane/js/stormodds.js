/* Vane — Storm Odds: Vane's own model of where severe storms are likely.
 *
 * The chance that a severe storm is REPORTED — a tornado, hail an inch or
 * larger, a 58 mph gust or thunderstorm wind damage — within 40 km of a
 * point in the next three hours, from the atmosphere at that point: how
 * much fuel (CAPE), how firm the lid (CIN), how unstable aloft (lifted
 * index), how moist (dewpoint, precipitable water), and how the wind
 * changes with height (10 m, 850 hPa, 500 hPa).
 *
 * Trained by scripts/train/storm.js on NOAA's HRRR analyses — the 3 km
 * model's best estimate of the real atmosphere, hour by hour — for April to
 * July of 2023 and 2024, against every NWS severe report in those months.
 * Shipped as plain numbers in js/stormodds-weights.js, and only if it beat
 * CAPE alone and CAPE × shear on days it never saw.
 *
 * In the app it reads the FORECAST for the same variables (Open-Meteo), so
 * its odds are only as good as that forecast, and it never sees the storms
 * themselves: no radar, no model rain. It is the environment's odds — it
 * cannot see whether the cap breaks or a boundary fires a storm.
 *
 * featuresOf() is shared with the training script, so the model is fed in
 * the app exactly what it was fit on. */
(function (global) {
  'use strict';

  var FEATURES = ['logCape', 'cin', 'li', 'td', 'pwat', 'shear', 'w850', 'w500', 'wmax', 'sinHour', 'cosHour'];
  var CLIP = 5;

  function speed(u, v) { return Math.sqrt(u * u + v * v); }

  /* env: { cape J/kg, cin J/kg (either sign), li K, td °C, pwat mm,
   *        u10, v10, u850, v850, u500, v500 m/s }
   * The hour enters as LOCAL SOLAR time — UTC plus longitude / 15 — so
   * "late afternoon" means the same thing in Georgia and in Colorado. */
  function featuresOf(env, utcMs, lon) {
    var cape = Math.max(0, +env.cape || 0);
    var shear = speed(env.u500 - env.u10, env.v500 - env.v10);
    var h = ((new Date(utcMs).getUTCHours() + new Date(utcMs).getUTCMinutes() / 60 + lon / 15) % 24 + 24) % 24;
    return [
      Math.log(1 + cape),
      Math.min(300, Math.abs(+env.cin || 0)),
      Math.max(-15, Math.min(15, +env.li || 0)),
      +env.td || 0,
      Math.max(0, +env.pwat || 0),
      shear,
      speed(env.u850, env.v850),
      speed(env.u500, env.v500),
      Math.sqrt(2 * cape) * shear / 100,             // WMAXSHEAR, scaled
      Math.sin(2 * Math.PI * h / 24),
      Math.cos(2 * Math.PI * h / 24)
    ];
  }

  function weights() { return global.StormOddsWeights || null; }

  // Logistic, or one hidden tanh layer — whichever won on held-out days.
  function score(W, x) {
    var s = x.map(function (v, i) {
      return Math.max(-CLIP, Math.min(CLIP, (v - W.mean[i]) / W.std[i]));
    });
    var z;
    if (W.kind === 'mlp') {
      z = W.b2;
      for (var j = 0; j < W.b1.length; j++) {
        var a = W.b1[j];
        for (var i = 0; i < s.length; i++) a += W.W1[j][i] * s[i];
        z += W.w2[j] * Math.tanh(a);
      }
    } else {
      z = W.b;
      for (var k = 0; k < s.length; k++) z += W.w[k] * s[k];
    }
    var p = 1 / (1 + Math.exp(-z));
    // The isotonic recalibration fitted on validation days (scripts/train/storm.js).
    return W.calib ? isotonic(W.calib, p) : p;
  }

  /* Raw score → calibrated odds: piecewise-linear through the knots, flat
   * beyond the ends, so no score can claim more than the top pooled band
   * verified at. */
  function isotonic(c, p) {
    var x = c.x, y = c.y, n = x.length;
    if (!n) return p;
    if (p <= x[0]) return y[0];
    if (p >= x[n - 1]) return y[n - 1];
    for (var i = 1; i < n; i++) {
      if (p <= x[i]) return y[i - 1] + (y[i] - y[i - 1]) * (p - x[i - 1]) / (x[i] - x[i - 1]);
    }
    return y[n - 1];
  }

  /* → probability 0..1, or null without a shippable model or the inputs. */
  function odds(env, utcMs, lon) {
    var W = weights();
    if (!W || !W.ship || !env || env.cape === null || env.cape === undefined ||
        env.u500 === null || env.u500 === undefined || isNaN(env.u500)) return null;
    return score(W, featuresOf(env, utcMs, lon));
  }

  // Meteorological direction is where the wind comes FROM.
  function uv(speedMs, dirDeg) {
    var r = dirDeg * Math.PI / 180;
    return { u: -speedMs * Math.sin(r), v: -speedMs * Math.cos(r) };
  }

  /* One hour of an Open-Meteo hourly block (wind_speed_unit=ms) → env. */
  function envFromHourly(h, i) {
    function at(k) { var a = h[k]; return a && a[i] !== null && a[i] !== undefined ? a[i] : null; }
    var w10 = uv(at('wind_speed_10m'), at('wind_direction_10m'));
    var w850 = uv(at('wind_speed_850hPa'), at('wind_direction_850hPa'));
    var w500 = uv(at('wind_speed_500hPa'), at('wind_direction_500hPa'));
    if (at('wind_speed_500hPa') === null || at('wind_speed_10m') === null) return null;
    return { cape: at('cape'), cin: at('convective_inhibition'), li: at('lifted_index'),
             td: at('dew_point_2m'), pwat: at('total_column_integrated_water_vapour'),
             u10: w10.u, v10: w10.v, u850: w850.u, v850: w850.v, u500: w500.u, v500: w500.v };
  }

  var HOURLY_VARS = ['cape', 'convective_inhibition', 'lifted_index', 'dew_point_2m',
    'total_column_integrated_water_vapour', 'wind_speed_10m', 'wind_direction_10m',
    'wind_speed_850hPa', 'wind_direction_850hPa', 'wind_speed_500hPa', 'wind_direction_500hPa'];

  /* An hourly block (timezone=UTC) at one point → [{ at, p }], hour by hour. */
  function series(hourly, lon) {
    if (!hourly || !hourly.time) return [];
    var out = [];
    hourly.time.forEach(function (t, i) {
      var at = Date.parse(t + 'Z'), env = envFromHourly(hourly, i);
      var p = env ? odds(env, at, lon) : null;
      if (p !== null) out.push({ at: at, p: p });
    });
    return out;
  }

  // The hour of a series nearest a moment, if it is within 90 minutes.
  function at(seriesArr, ms) {
    var best = null;
    (seriesArr || []).forEach(function (s) {
      if (Math.abs(s.at - ms) <= 90 * 60000 && (!best || Math.abs(s.at - ms) < Math.abs(best.at - ms))) best = s;
    });
    return best;
  }

  global.StormOdds = {
    FEATURES: FEATURES, HOURLY_VARS: HOURLY_VARS,
    featuresOf: featuresOf, odds: odds, score: score, isotonic: isotonic, envFromHourly: envFromHourly, weights: weights,
    series: series, at: at
  };
})(typeof window !== 'undefined' ? window : globalThis);
