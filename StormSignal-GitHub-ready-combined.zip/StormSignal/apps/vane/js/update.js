/* Vane — an installed app that finishes its own updates.
 *
 * The service worker already activates new versions immediately (skipWaiting
 * + clients.claim), so by the time the page hears `controllerchange` the new
 * shell is cached and serving. The missing step was the page itself: it was
 * built from the old shell, and nothing ever reloaded it — so every update
 * cost the user a full close-and-reopen they had no way of knowing they owed.
 *
 * The rule here is about whose moment it is:
 *
 *   - If the user hasn't touched anything yet — or the app isn't even on
 *     screen — the reload is invisible, so take it. Launch is a beat slower
 *     exactly once and the app is simply current.
 *   - If they are mid-session, offer instead. Yanking the radar out from
 *     under someone to deliver an update they didn't ask for is worse than
 *     being one version behind for an hour.
 *
 * Checks run on every return to the app and hourly, because the browser only
 * looks for a new worker on navigation — and a dash-mounted phone in Chase
 * mode can run for six hours without a single navigation.
 *
 * Everything is injected (container, document, clock, reload) so the decision
 * logic is testable without a real service worker. */
(function (global) {
  'use strict';

  function wire(opts) {
    var sw = opts.container;
    var doc = opts.doc;
    var state = { interacted: false, reloaded: false, offered: false };

    /* "Mid-session" means the user has actually done something, not that time
     * has passed. On a slow cellular link the install alone can outlast any
     * fixed grace period, and reloading under someone's first tap is exactly
     * the rudeness this is trying to avoid. */
    ['pointerdown', 'keydown'].forEach(function (ev) {
      doc.addEventListener(ev, function () { state.interacted = true; }, true);
    });

    /* A page that loads uncontrolled is a first install: claim() will flip
     * the controller from null and fire this event, and reloading there would
     * greet every new visitor with a refresh for no reason. */
    var hadController = !!sw.controller;
    sw.addEventListener('controllerchange', function () {
      if (!hadController) { hadController = true; return; }
      if (state.reloaded) return;
      if (!state.interacted || doc.hidden) {
        state.reloaded = true;
        opts.reload();
      } else if (!state.offered) {
        state.offered = true;
        // The accept path carries the same once-guard as every other reload:
        // the hidden-apply below can beat a tap to it.
        opts.offer(function () {
          if (state.reloaded) return;
          state.reloaded = true;
          opts.reload();
        });
      }
    });

    /* An ignored pill must not strand the update. Chrome only promotes a new
     * worker once the old one has been idle ~30s, so in practice the switch
     * lands well into the session and the pill is the common case, not the
     * edge. The moment the app leaves the screen, apply the pending update
     * there — a reload nobody can see is the silent path arriving late. */
    doc.addEventListener('visibilitychange', function () {
      if (doc.hidden && state.offered && !state.reloaded) {
        state.reloaded = true;
        opts.reload();
      }
    });

    return opts.register().then(function (reg) {
      function check() {
        // update() rejects when offline; that is the next check's problem.
        try { reg.update().catch(function () {}); } catch (e) { /* older UAs throw */ }
      }
      doc.addEventListener('visibilitychange', function () { if (!doc.hidden) check(); });
      opts.win.setInterval(check, opts.checkMs);
      return reg;
    });
  }

  /* Ask the controlling worker which version it is. Used by the test suite to
   * prove an update actually landed, and harmless to expose. Resolves null
   * rather than rejecting when there is no controller or no answer — callers
   * are asking a diagnostic question, not performing an operation. */
  function version(container) {
    return new Promise(function (resolve) {
      var c = container && container.controller;
      if (!c || typeof MessageChannel === 'undefined') return resolve(null);
      var ch = new MessageChannel();
      var done = false;
      ch.port1.onmessage = function (e) { if (!done) { done = true; resolve(e.data); } };
      try { c.postMessage('GET_VERSION', [ch.port2]); }
      catch (e) { return resolve(null); }
      setTimeout(function () { if (!done) { done = true; resolve(null); } }, 2000);
    });
  }

  global.Updates = { wire: wire, version: version };
})(typeof window !== 'undefined' ? window : self);
