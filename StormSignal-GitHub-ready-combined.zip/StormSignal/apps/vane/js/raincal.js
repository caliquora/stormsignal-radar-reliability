/* Vane — what "40% chance of rain" means here.
 *
 * A rain chance is a claim about frequency: of all the hours given 40%,
 * rain should fall in about four in ten. Whether it does depends on the
 * place — a coastal pin, a valley, a model with a wet bias over this
 * terrain. This learner keeps the score, hour by hour, at your location.
 *
 *   1. Record. Each time the forecast refreshes, every hour at least LEAD_H
 *      ahead has its rain chance written down, overwriting the last one —
 *      so what sticks for an hour is the chance shown about six hours
 *      before it. Leads are never mixed.
 *   2. Verify. Once an hour has passed, the nearest station's METARs for
 *      that hour say whether precipitation actually fell: any report of
 *      rain, drizzle, snow, ice pellets, hail or unknown precipitation
 *      (not "in the vicinity" — that is not on you), or a measured hour
 *      of 0.25 mm or more where the station measures it. Present-weather
 *      codes are in every METAR in the world; measured amounts mostly
 *      only in American ones. An hour with no report is not dry: it waits,
 *      and is dropped after a few days if none ever comes.
 *   3. Bin. Each verified hour adds one count to its forecast's 10% bin.
 *      The observed frequency per bin is the reliability curve.
 *   4. Calibrate. Once a bin has MIN_BIN verified hours, a chance in that
 *      bin is shown beside how often it has rained in such hours here —
 *      shrunk toward the forecast's own number as if K hours had agreed
 *      with it, so thin evidence cannot swing it far.
 *
 * The official chance is never replaced; the calibrated one is offered
 * beside it, with its evidence. Stored per location in localStorage. */
(function (global) {
  'use strict';

  var U = global.U;
  var KEY = 'vane.raincal.v1';
  var LEAD_H = 6;              // record only what was said this far ahead
  var HORIZON_H = 48;          // and no further ahead than this
  var MIN_BIN = 20;            // verified hours before a bin speaks
  var K = 10;                  // pseudo-hours of agreement with the forecast
  var MAX_PENDING_AGE = 4 * 86400000;
  var HOUR = 3600000;
  var WET_MM = 0.25;

  function locKey(loc) { return loc.lat.toFixed(2) + ',' + loc.lon.toFixed(2); }
  function empty(k) { return { loc: k, pending: {}, bins: [], hours: 0, station: null }; }
  function binOf(pop) { return Math.min(9, Math.max(0, Math.floor(pop / 10))); }

  /* ── Pure core ───────────────────────────────────────────────────── */

  /* One METAR's present weather → did precipitation fall at the station.
   * Codes like "-RA", "TSRA", "+SHSN", "RA BR"; anything prefixed VC is in
   * the vicinity and does not count; bare "TS" is thunder without rain. */
  var PRECIP = /(RA|DZ|SN|SG|PL|GR|GS|UP|IC)/;

  function wetCodes(wx) {
    if (!wx || wx === 'M') return false;
    return String(wx).split(/\s+/).some(function (tok) {
      if (!tok || /^[+-]?VC/.test(tok)) return false;
      return PRECIP.test(tok.replace(/^[+-]/, ''));
    });
  }

  /* Iowa State asos.py CSV (station,valid,wxcodes,p01m; valid in UTC)
   * → { hourEpochMs: true|false } for every hour that has a report. */
  function hourlyWet(text) {
    var out = {};
    String(text || '').split(/\r?\n/).forEach(function (line) {
      var c = line.split(',');
      if (c.length < 4 || c[0] === 'station') return;
      var t = Date.parse(c[1].replace(' ', 'T') + ':00Z');
      if (isNaN(t)) return;
      var h = Math.floor(t / HOUR) * HOUR;
      var mm = parseFloat(c[3]);
      var wet = wetCodes(c[2]) || (!isNaN(mm) && mm >= WET_MM);
      out[h] = !!out[h] || wet;
    });
    return out;
  }

  /* hourly: Open-Meteo { time[], precipitation_probability[] } in the
   * location's wall clock; offsetSec its UTC offset. */
  function recordInto(store, k, hourly, offsetSec, now) {
    if (store.loc !== k) store = empty(k);
    if (!hourly || !hourly.time || !hourly.precipitation_probability) return store;
    for (var i = 0; i < hourly.time.length; i++) {
      var pop = hourly.precipitation_probability[i];
      if (typeof pop !== 'number') continue;
      var t = U.epochOf(hourly.time[i], offsetSec || 0);
      var lead = t - now;
      if (lead < LEAD_H * HOUR || lead > HORIZON_H * HOUR) continue;
      store.pending[t] = pop;
    }
    return store;
  }

  /* Move every pending hour the station has spoken for into its bin.
   * Returns true when anything was settled. */
  function settleInto(store, wetByHour, now, station) {
    var changed = false;
    Object.keys(store.pending).forEach(function (key) {
      var t = +key;
      if (t + HOUR > now) return;                      // not over yet
      if (Object.prototype.hasOwnProperty.call(wetByHour, t)) {
        var b = binOf(store.pending[key]);
        if (!store.bins[b]) store.bins[b] = { n: 0, wet: 0, popSum: 0 };
        store.bins[b].n++;
        store.bins[b].popSum += store.pending[key];
        if (wetByHour[t]) store.bins[b].wet++;
        store.hours++;
        delete store.pending[key];
        changed = true;
      } else if (now - t > MAX_PENDING_AGE) {
        delete store.pending[key];                     // no report ever came
      }
    });
    if (changed && station) store.station = station;
    return changed;
  }

  /* The reliability curve: per 10% bin, forecast mean vs observed. */
  function reliability(store) {
    var rows = [];
    for (var b = 0; b < 10; b++) {
      var x = store.bins[b];
      if (!x || !x.n) continue;
      rows.push({ lo: b * 10, hi: b * 10 + 9 + (b === 9 ? 1 : 0), n: x.n, wet: x.wet,
                  forecast: Math.round(x.popSum / x.n), observed: Math.round(100 * x.wet / x.n),
                  ready: x.n >= MIN_BIN });
    }
    return { rows: rows, hours: store.hours || 0, station: store.station,
             pending: Object.keys(store.pending).length };
  }

  /* A forecast chance → what such chances have meant here, or null when
   * its bin has not earned the right to say. */
  function calibrate(pop, store) {
    if (typeof pop !== 'number') return null;
    var x = store.bins[binOf(pop)];
    if (!x || x.n < MIN_BIN) return null;
    var observed = (x.wet + K * pop / 100) / (x.n + K);
    return { pop: pop, observed: Math.round(100 * observed), n: x.n,
             raw: Math.round(100 * x.wet / x.n) };
  }

  /* ── Storage + network ───────────────────────────────────────────── */

  function load() {
    try {
      var s = JSON.parse(global.localStorage.getItem(KEY));
      if (s && s.pending && Array.isArray(s.bins)) return s;
    } catch (e) { /* corrupt or unavailable */ }
    return empty(null);
  }

  function save(s) {
    try { global.localStorage.setItem(KEY, JSON.stringify(s)); } catch (e) { /* full */ }
  }

  function record(loc, data) {
    if (!loc || !data || !data.hourly) return;
    save(recordInto(load(), locKey(loc), data.hourly, data.utc_offset_seconds, Date.now()));
  }

  /* Ask the station's METAR archive about every finished pending hour, in
   * one request. obsInfo: { station } — a weather.gov station id or an
   * Iowa State one; the archive answers to both. */
  function settle(loc, obsInfo) {
    if (!loc || !obsInfo || !obsInfo.station || !global.API) return Promise.resolve(false);
    var store = load(), now = Date.now();
    if (store.loc !== locKey(loc)) return Promise.resolve(false);
    var due = Object.keys(store.pending).map(Number).filter(function (t) { return t + HOUR <= now; });
    if (!due.length) return Promise.resolve(false);
    var start = new Date(Math.min.apply(null, due)).toISOString();
    var end = new Date(Math.max.apply(null, due) + HOUR).toISOString();
    return global.API.metarWeather(obsInfo.station, start, end).then(function (text) {
      var changed = settleInto(store, hourlyWet(text), Date.now(), obsInfo.station);
      save(store);
      return changed;
    }).catch(function () { return false; });           // retried next load
  }

  function summary(loc) {
    var s = load();
    if (!loc || s.loc !== locKey(loc)) return reliability(empty(null));
    return reliability(s);
  }

  function calibrateAt(loc, pop) {
    var s = load();
    if (!loc || s.loc !== locKey(loc)) return null;
    return calibrate(pop, s);
  }

  function reset() {
    try { global.localStorage.removeItem(KEY); } catch (e) { /* nothing */ }
  }

  global.RainCal = {
    record: record,
    settle: settle,
    summary: summary,
    calibrateAt: calibrateAt,
    reset: reset,
    // Pure core, exported for the test suite.
    wetCodes: wetCodes,
    hourlyWet: hourlyWet,
    recordInto: recordInto,
    settleInto: settleInto,
    reliability: reliability,
    calibrate: calibrate,
    empty: empty,
    MIN_BIN: MIN_BIN,
    LEAD_H: LEAD_H
  };
})(window);
