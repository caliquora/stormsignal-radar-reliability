/* Embedded evidence agents: bounded local tool workflows, not an LLM.
 * Read-only, no network or credentials. The user starts each run; optional
 * watch reruns only while this page is visible. Never a warning service. */
(function (root) {
  'use strict';
  var MIN = 60000, tasks = {
    briefing: { title: 'Brief me on the evidence', tools: ['warnings', 'freshness', 'models'] },
    models: { title: 'Where do models disagree?', tools: ['freshness', 'models'] },
    field: { title: 'Check my field data', tools: ['warnings', 'freshness', 'field'] }
  };
  function epoch(x) { if (typeof x === 'number') return isFinite(x) && x > 0 ? x : null;
    if (typeof x !== 'string' || !/Z$|[+-]\d\d:\d\d$/.test(x)) return null;
    var n = Date.parse(x); return isFinite(n) ? n : null; }
  function stamp(x) { var t = epoch(x); return t === null ? 'unknown' : new Date(t).toISOString(); }
  function finite(n) { return typeof n === 'number' && isFinite(n); }
  function evidence(id, source, at, text, href) {return {id:id,source:source,at:at || null,text:text,href:href || null};}
  function warnings(s, now) {
    var a = s.alertStatus, at = epoch(a && a.receivedAt);
    var current = !!(a && a.available && !a.stale && at && at <= now + 2*MIN && now-at <= 15*MIN);
    var rows = [evidence('warning-feed','NWS point alert response',at,
      current ? 'Response received '+stamp(at)+'. Coverage is the selected point, not your route.' : 'Current official warning status is unavailable, stale or unverified.')];
    (a && a.alerts || []).slice(0,20).forEach(function (v,i) {
      var end = epoch(v.expires), url = typeof v.id === 'string' && /^https:\/\/api\.weather\.gov\/alerts\/[A-Za-z0-9:._%-]+$/.test(v.id) ? v.id : null;
      rows.push(evidence('warning-'+i,'Official alert record',epoch(v.sent),
        (current ? '' : 'Last received record: ')+(v.event || 'Alert')+'. Expires '+stamp(end)+'. '+
        (end && end<=now ? 'Expiry has passed. ' : '')+(v.instruction || 'Read the official record for instructions.'),url));
    });
    var active = (a && a.alerts || []).filter(function (v) { var e=epoch(v.expires);return e===null || e>now; }).length;
    return {summary:current ? active+' potentially active alert record(s) returned. No alerts is not an all-clear.' : 'Warning status needs verification.', evidence:rows, blocked:!current};
  }
  function freshness(s, now) {
    var p = s.radarProvenance || {}, t = epoch(p.observedAt), age=t===null?null:(now-t)/MIN;
    var ok=t!==null && age>=-2 && age<=15 && !p.cached;
    var forecastAt=epoch(s.fetchedAt), freshForecast=!!(s.data && !s.stale && forecastAt && now-forecastAt<=60*MIN && forecastAt<=now+2*MIN);
    return {summary:ok ? 'Radar source metadata is recent; local pixel freshness is still unknown.' : 'Radar age cannot support a fresh-data assumption.', blocked:!ok,
      evidence:[evidence('radar-age',p.source || 'Radar source metadata',t,
        'Source time '+stamp(t)+'; last checked '+stamp(p.checkedAt)+'. '+(age===null?'Age unknown.':Math.max(0,Math.floor(age))+' minutes since source time.')+
        (p.cached?' Cached metadata.':'')+' The 15-minute cutoff is a display policy, not a hazard threshold. Per-pixel freshness is unknown.'),
        evidence('forecast-receipt','Forecast response',forecastAt,(freshForecast?'Recently received':'Missing or old/cached')+' forecast response. Receipt time is not model initialization time.') ]};
  }
  function models(s, now) {
    var data=s.ensemble, h=data && data.hourly, at=epoch(s.ensembleAt);
    var rows=[], offset=data && data.utc_offset_seconds || 0, configs=root.VaneConfig && root.VaneConfig.MODELS || [];
    if (!h || !Array.isArray(h.time)) return {summary:'No model-comparison data loaded.',blocked:true,evidence:[]};
    var outdated=!at || now-at>60*MIN || at>now+2*MIN || !!data.__stale;
    var best=null;
    h.time.forEach(function (t,i) {
      // Open-Meteo timezone-naive forecast labels need the response UTC offset.
      var valid=typeof t==='string'?Date.parse(/Z$|[+-]\d\d:\d\d$/.test(t)?t:t+'Z')-(/Z$|[+-]\d\d:\d\d$/.test(t)?0:offset*1000):NaN;
      if (!isFinite(valid) || valid<now || valid>now+24*60*MIN) return;
      var vals=configs.map(function(m){var v=(h['temperature_2m_'+m.id] || [])[i];return finite(v)?{name:m.name,value:v}:null;}).filter(Boolean);
      if(vals.length<2)return;
      var spread=Math.max.apply(null,vals.map(function(v){return v.value;}))-Math.min.apply(null,vals.map(function(v){return v.value;}));
      if(!best || spread>best.spread)best={valid:valid,spread:spread,values:vals};
    });
    if(!best)return {summary:'Fewer than two matching model temperatures available in the next 24 hours.',blocked:true,evidence:[]};
    var imperial=s.imperial!==false, factor=imperial?1.8:1, unit=imperial?'°F':'°C';
    rows.push(evidence('model-receipt','Open-Meteo multi-model response',at,'Received '+stamp(at)+'. Model run initialization times are not supplied here. '+(outdated?'This response is old or unverified.':'')));
    rows.push(evidence('model-spread','Matching model temperature forecasts',best.valid,
      'At '+stamp(best.valid)+', '+best.values.length+' models span '+(best.spread*factor).toFixed(1)+unit+': '+best.values.map(function(v){return v.name+' '+(v.value*factor+(imperial?32:0)).toFixed(1)+unit;}).join('; ')+'.'));
    return {summary:(outdated?'Using an old/unverified response: ':'')+'Largest temperature disagreement in the next 24 hours is '+(best.spread*factor).toFixed(1)+unit+'. Model spread is not a calibrated probability or accuracy score.',blocked:outdated,evidence:rows};
  }
  function field(s) { return {summary:'This check cannot establish a safe route or storm intercept.',blocked:true,evidence:[
    evidence('field-coverage','Device connectivity',null,(root.navigator && root.navigator.onLine===false?'Browser reports offline. ':'Connectivity alone does not establish live data. ')+'Radar tiles may be unavailable offline. Keep an independent official warning source.'),
    evidence('field-limits','VANE capability boundary',null,'Road closures, terrain, shelter suitability and changing route hazards are not verified. Photography vantage geometry is not a navigation recommendation.') ]}; }
  var tools={warnings:warnings,freshness:freshness,models:models,field:field};
  function run(task,s,now) {
    if(!tasks[task])throw new Error('Unknown agent task');
    now=now===undefined?Date.now():now;s=s||{};
    var out={task:task,title:tasks[task].title,at:now,location:s.location && s.location.name || 'Selected point',
      engine:'Local rule-based evidence agents; no language model connected',steps:[],evidence:[],limitations:[
        'Read-only assistance, not a warning service or operational forecast improvement.',
        'StormSignal research motivates explicit freshness checks; it does not validate these operational forecasts.']};
    tasks[task].tools.forEach(function(name){var result=tools[name](s,now);
      out.steps.push({tool:name,status:result.blocked?'limited':'complete',summary:result.summary,evidenceIds:result.evidence.map(function(e){return e.id;})});
      out.evidence=out.evidence.concat(result.evidence);
    });return out;
  }
  function node(tag,text) {var n=root.document.createElement(tag);if(text!==undefined)n.textContent=text;return n;}
  var latest=null, getState=null, watch=false, timer=null, lastSignature=null;
  function render(result) {
    var box=root.document.getElementById('agent-result');if(!box)return;box.textContent='';
    box.appendChild(node('h3',result.title));box.appendChild(node('p',result.location+' · Snapshot '+stamp(result.at)));
    result.steps.forEach(function(step){var block=node('details');block.open=true;
      block.appendChild(node('summary',step.tool+' · '+(step.status==='limited'?'Evidence limited':'Checked')));block.appendChild(node('p',step.summary));
      result.evidence.filter(function(e){return step.evidenceIds.indexOf(e.id)!==-1;}).forEach(function(e){
        var p=node('p',e.text), meta=node('small',e.source+' · '+stamp(e.at));block.appendChild(meta);block.appendChild(p);
        if(e.href){var a=node('a','Open official source');a.href=e.href;a.target='_blank';a.rel='noopener noreferrer';block.appendChild(a);}
      });box.appendChild(block);
    });box.appendChild(node('p',result.limitations.join(' ')));
  }
  function execute() {
    if(!getState)return;var task=root.document.getElementById('agent-task').value;
    latest=run(task,getState());render(latest);
    root.document.getElementById('agent-status').textContent='Finished using currently loaded evidence. No new network requests were made.';
    root.document.getElementById('agent-export').disabled=false;
  }
  function signature(s) {return JSON.stringify([s.location,s.fetchedAt,s.ensembleAt,s.radarProvenance,s.alertStatus]);}
  function receive(s) {
    if(!watch || root.document.hidden)return;
    var sig=signature(s);if(sig===lastSignature)return;lastSignature=sig;execute();
  }
  function init(reader) {
    if(getState)return;getState=reader;
    var button=root.document.getElementById('agent-run');if(!button)return;
    button.addEventListener('click',execute);
    root.document.getElementById('agent-task').addEventListener('change',function(){latest=null;root.document.getElementById('agent-result').textContent='Run this task to inspect current evidence.';root.document.getElementById('agent-export').disabled=true;});
    root.document.getElementById('agent-watch').addEventListener('change',function(e){watch=e.target.checked;lastSignature=null;
      root.document.getElementById('agent-status').textContent=watch?'Watching loaded evidence while this page is visible. No background alerts.':'Watch stopped.';
      if(timer)root.clearInterval(timer);timer=null;
      if(watch){receive(getState());timer=root.setInterval(function(){if(!root.document.hidden)execute();},60000);}
    });
    root.document.addEventListener('visibilitychange',function(){if(watch&&!root.document.hidden)execute();});
    root.document.getElementById('agent-export').addEventListener('click',function(){if(!latest)return;
      var url=root.URL.createObjectURL(new root.Blob([JSON.stringify(latest,null,2)],{type:'application/json'}));
      var a=node('a');a.href=url;a.download='vane-evidence-run.json';a.click();root.setTimeout(function(){root.URL.revokeObjectURL(url);},1000);
    });
  }
  var api={tasks:tasks,run:run,init:init,receive:receive,latest:function(){return latest;}};root.VaneAgents=api;
  if(typeof module!=='undefined')module.exports=api;
})(typeof window!=='undefined'?window:globalThis);
