/* Vane — NEXRAD radar site registry.
 *
 * Lets you jump the map to any radar in the country and view that single
 * site's products rather than the national mosaic. Two reasons a chaser wants
 * this: the mosaic hides which radar is actually painting a storm (and at what
 * range), and single-site products include the velocity data the mosaic has no
 * equivalent for.
 *
 * Station metadata comes from api.weather.gov/radar/stations, which carries
 * live operational state — when Level II data was last received, the RDA's
 * operability, and the Volume Coverage Pattern. The VCP is the useful bit:
 * a radar in a precipitation VCP is actively watching storms, one in a
 * clear-air VCP is idling. That is what "active weather radar" really means,
 * and it beats guessing from whether tiles happen to be non-empty. */
(function (global) {
  'use strict';

  var U = global.U;

  /* Volume Coverage Patterns. Precip VCPs scan faster and lower; clear-air
   * VCPs are the slow, sensitive modes used when nothing is happening. */
  var PRECIP_VCP = [12, 112, 121, 212, 215, 11, 21, 211];
  var CLEAR_VCP = [31, 32, 34, 35];

  function vcpNumber(vcp) {
    if (!vcp) return null;
    var m = /(\d+)/.exec(String(vcp));
    return m ? parseInt(m[1], 10) : null;
  }

  function vcpMode(vcp) {
    var n = vcpNumber(vcp);
    if (n === null) return 'unknown';
    if (PRECIP_VCP.indexOf(n) !== -1) return 'precip';
    if (CLEAR_VCP.indexOf(n) !== -1) return 'clear';
    return 'unknown';
  }

  /* "Online" is judged from data actually arriving, not from the maintenance
   * flag: plenty of radars report "Maintenance Action Required" while still
   * scanning perfectly well, and treating those as down would hide most of
   * the network. */
  var STALE_MS = 20 * 60 * 1000;

  function isOnline(site) {
    if (!site.lastData) return false;
    return (Date.now() - site.lastData) < STALE_MS;
  }

  function parse(features) {
    return (features || []).map(function (f) {
      var p = f.properties || {};
      var g = f.geometry || {};
      if (!g.coordinates) return null;
      var rda = (p.rda && p.rda.properties) || {};
      var latency = p.latency || {};
      var last = latency.levelTwoLastReceivedTime
        ? new Date(latency.levelTwoLastReceivedTime).getTime() : null;

      var site = {
        id: p.id,
        name: p.name || p.id,
        type: p.stationType,
        lat: g.coordinates[1],
        lon: g.coordinates[0],
        elevation: p.elevation && p.elevation.value,
        vcp: rda.volumeCoveragePattern || null,
        vcpNumber: vcpNumber(rda.volumeCoveragePattern),
        mode: rda.mode || null,
        operability: rda.operabilityStatus || null,
        alarms: rda.alarmSummary || null,
        lastData: last && !isNaN(last) ? last : null
      };
      site.scanMode = vcpMode(site.vcp);
      site.online = isOnline(site);
      // Only WSR-88D sites carry the Level III products Vane renders; TDWR and
      // wind profilers are listed by the API but not usable here.
      site.usable = site.type === 'WSR-88D';
      return site;
    }).filter(Boolean);
  }

  /* Nominal range of the 0.5° base products, used for the coverage ring.
   * WSR-88D base reflectivity reaches ~230 km. */
  function rangeKm(site) {
    return site.type === 'TDWR' ? 90 : 230;
  }

  var state = { sites: [], fetchedAt: 0, error: null };

  function load() {
    if (state.sites.length && Date.now() - state.fetchedAt < 10 * 60 * 1000) {
      return Promise.resolve(state.sites);
    }
    return global.API.radarStations().then(function (features) {
      state.sites = parse(features);
      state.fetchedAt = Date.now();
      state.error = null;
      return state.sites;
    }).catch(function (e) {
      state.error = e.message;
      return [];
    });
  }

  function byId(id) {
    for (var i = 0; i < state.sites.length; i++) {
      if (state.sites[i].id === id) return state.sites[i];
    }
    return null;
  }

  /* Sites near a point, nearest first, with distance and bearing attached. */
  function near(lat, lon, opts) {
    opts = opts || {};
    return state.sites.filter(function (s) {
      if (opts.usableOnly !== false && !s.usable) return false;
      if (opts.activeOnly && !(s.online && s.scanMode === 'precip')) return false;
      return true;
    }).map(function (s) {
      return Object.assign({}, s, {
        distance: U.haversine(lat, lon, s.lat, s.lon),
        bearing: bearingTo(lat, lon, s.lat, s.lon)
      });
    }).sort(function (a, b) { return a.distance - b.distance; });
  }

  function bearingTo(lat1, lon1, lat2, lon2) {
    var dLon = U.toRad(lon2 - lon1);
    var y = Math.sin(dLon) * Math.cos(U.toRad(lat2));
    var x = Math.cos(U.toRad(lat1)) * Math.sin(U.toRad(lat2)) -
      Math.sin(U.toRad(lat1)) * Math.cos(U.toRad(lat2)) * Math.cos(dLon);
    return (Math.atan2(y, x) * 180 / Math.PI + 360) % 360;
  }

  /* Free-text match on identifier or city name, so "KTLX", "tlx" and "norman"
   * all find the same radar. */
  function search(query, lat, lon) {
    var q = String(query || '').trim().toLowerCase();
    var list = near(lat, lon);
    if (!q) return list;
    return list.filter(function (s) {
      return s.id.toLowerCase().indexOf(q) !== -1 ||
        s.name.toLowerCase().indexOf(q) !== -1;
    });
  }

  // The radar most likely to be painting a given point well: closest site that
  // is online and actually in precipitation mode, else just the closest online.
  function bestFor(lat, lon) {
    var active = near(lat, lon, { activeOnly: true });
    if (active.length) return active[0];
    var online = near(lat, lon).filter(function (s) { return s.online; });
    return online.length ? online[0] : (near(lat, lon)[0] || null);
  }

  function summary() {
    var usable = state.sites.filter(function (s) { return s.usable; });
    return {
      total: usable.length,
      online: usable.filter(function (s) { return s.online; }).length,
      precip: usable.filter(function (s) { return s.online && s.scanMode === 'precip'; }).length
    };
  }

  global.Sites = {
    state: state,
    load: load,
    parse: parse,
    near: near,
    search: search,
    byId: byId,
    bestFor: bestFor,
    summary: summary,
    rangeKm: rangeKm,
    vcpMode: vcpMode,
    vcpNumber: vcpNumber,
    isOnline: isOnline,
    bearingTo: bearingTo,
    PRECIP_VCP: PRECIP_VCP,
    CLEAR_VCP: CLEAR_VCP
  };
})(window);
