/* Vane — app chrome rendering: search results, saved places, the
 * keyboard help sheet, settings, and the radar-site picker. */
(function (global) {
  'use strict';

  var C = global.VaneConfig, U = global.U, D = global.Derive;
  var UI = global.UI;
  // Shared helpers from js/ui-core.js.
  var status = UI.status;
  /* ── Search & saved lists ───────────────────────────────────────────── */

  function renderSearchResults(results, onPick) {
    var list = U.el('search-results');
    U.clear(list);
    if (!results || !results.length) { list.hidden = true; return; }
    list.hidden = false;
    results.forEach(function (r) {
      var li = U.make('li');
      var btn = U.make('button', 'result-btn');
      btn.appendChild(U.make('span', 'result-name', r.name));
      btn.appendChild(U.make('span', 'result-admin', r.admin || ''));
      btn.addEventListener('click', function () { onPick(r); });
      li.appendChild(btn);
      list.appendChild(li);
    });
  }

  function renderSaved(saved, current, onPick, onRemove, onAdd) {
    var list = U.el('saved-list');
    U.clear(list);
    var isSaved = saved.some(function (s) {
      return Math.abs(s.lat - current.lat) < 0.02 && Math.abs(s.lon - current.lon) < 0.02;
    });

    var addLi = U.make('li');
    var addBtn = U.make('button', 'saved-add',
      isSaved ? '✓ ' + current.name + ' is saved' : '+ Save ' + current.name);
    addBtn.disabled = isSaved;
    addBtn.addEventListener('click', onAdd);
    addLi.appendChild(addBtn);
    list.appendChild(addLi);

    if (!saved.length) {
      var empty = U.make('li', 'saved-empty', 'No saved locations yet.');
      list.appendChild(empty);
      return;
    }
    saved.forEach(function (s) {
      var li = U.make('li', 'saved-row');
      var b = U.make('button', 'saved-pick', s.name);
      b.addEventListener('click', function () { onPick(s); });
      var x = U.make('button', 'saved-remove', '×');
      x.title = 'Remove ' + s.name;
      x.addEventListener('click', function (e) { e.stopPropagation(); onRemove(s); });
      li.appendChild(b);
      li.appendChild(x);
      list.appendChild(li);
    });
  }

  function renderHelp() {
    var dl = U.el('help-list');
    U.clear(dl);
    C.SHORTCUTS.forEach(function (s) {
      dl.appendChild(U.make('dt', null, s[0]));
      dl.appendChild(U.make('dd', null, s[1]));
    });
  }

  /* ── Settings panel ─────────────────────────────────────────────────── */

  function renderSettings(onChange) {
    var box = U.el('settings-body');
    U.clear(box);
    var S = global.Settings;
    var s = S.load();

    /* "I have no way to save settings" — there never was a Save button,
     * because every change commits the moment it is made, but nothing SAID
     * so: the sheet offered only "Close", which reads as "discard". Now the
     * sheet says it up front, flashes Saved ✓ on every change, and the
     * button says Done. */
    var savedFlash = null;
    function flashSaved() {
      var chip = U.el('settings-saved');
      if (!chip) return;
      chip.hidden = false;
      if (savedFlash) clearTimeout(savedFlash);
      savedFlash = setTimeout(function () { chip.hidden = true; }, 1600);
    }
    box.appendChild(U.make('p', 'settings-note settings-autosave',
      'Everything here saves the moment you change it — to this device, nowhere else.'));

    function section(title) {
      var h = U.make('h3', 'settings-h', title);
      box.appendChild(h);
    }

    function toggle(label, key, note, handler) {
      var row = U.make('label', 'settings-row');
      var input = U.make('input');
      input.type = 'checkbox';
      input.checked = !!s[key];
      input.addEventListener('change', function () {
        var patch = {};
        patch[key] = input.checked;
        S.save(patch);
        flashSaved();
        if (handler) handler(input.checked);
        if (onChange) onChange(key, input.checked);
      });
      row.appendChild(input);
      var text = U.make('span', 'settings-text');
      text.appendChild(U.make('span', null, label));
      if (note) text.appendChild(U.make('span', 'settings-note', note));
      row.appendChild(text);
      box.appendChild(row);
      return input;
    }

    section('Alerts I care about');
    var filterWrap = U.make('div', 'filter-grid');
    C.ALERT_FILTERS.forEach(function (f) {
      var row = U.make('label', 'filter-chip' + (s.filters[f.key] !== false ? ' on' : ''));
      var input = U.make('input');
      input.type = 'checkbox';
      input.checked = s.filters[f.key] !== false;
      input.addEventListener('change', function () {
        s.filters[f.key] = input.checked;
        S.save({ filters: s.filters });
        flashSaved();
        row.classList.toggle('on', input.checked);
        if (onChange) onChange('filters', s.filters);
      });
      row.appendChild(input);
      row.appendChild(U.make('span', null, f.label));
      filterWrap.appendChild(row);
    });
    box.appendChild(filterWrap);

    section('Notifications');
    if ('setAppBadge' in navigator) {
      box.appendChild(U.make('p', 'settings-note',
        'When Vane is installed to your home screen, the app icon carries a count ' +
        'of active alerts at or above the severity you pick below — the closest ' +
        'thing a web app has to a widget. Only severe and above, so it stays ' +
        'worth looking at.'));
    }
    var askPermission = function (key) {
      return function (on) {
        if (!on) return;
        S.requestNotifications().then(function (p) {
          if (p !== 'granted') {
            status('Notification permission was ' + p + '.', 'warn');
            var off = {}; off[key] = false;
            S.save(off);
          } else if (key !== 'notify') {
            // requestNotifications flips `notify` on grant; keep the
            // toggle the user actually pressed as the source of truth.
            var keep = {}; keep[key] = true;
            S.save(keep);
          }
        });
      };
    };
    toggle('New alerts for your location', 'notify',
      'Fires once per alert, at Severe or above. Nothing is sent anywhere.',
      askPermission('notify'));
    toggle('Rain on the way', 'notifyRain',
      'VaneMotion fits the last hour of radar in your browser; when it sees rain ' +
      'tracking to your pin within about 45 minutes, you get one heads-up per ' +
      'approaching echo. Needs the app open — the fit runs on your device.',
      askPermission('notifyRain'));
    toggle('Severe outlook at your location', 'notifyOutlook',
      'Once a day when the Storm Prediction Center\'s Day 1 or Day 2 outlook puts ' +
      'a Slight risk or higher over your pin — and again only if it upgrades.',
      askPermission('notifyOutlook'));
    renderNotifyLearned(box, function () { renderSettings(onChange); });
    box.appendChild(U.make('p', 'settings-note',
      'Honest limits: Vane has no server, so there is no push. Notifications ' +
      'fire while the app is open (it re-checks every few minutes). Installed ' +
      'on Android or desktop Chrome, alerts are also re-checked a few times a ' +
      'day in the background. On an iPhone, open the app to check.'));

    section('Appearance');
    toggle('Reduce transparency', 'solid',
      'Swaps every frosted panel for a solid one. Easier to read in direct sunlight.',
      function (on) { document.body.classList.toggle('solid', on); });
    toggle('Animated sky effects', 'skyMotion',
      'Falling rain and snow over the background. Off automatically if your system asks for reduced motion.',
      function () { if (onChange) onChange('skyMotion'); });

    section('Behaviour');
    toggle('Auto-suggest Chase mode during severe weather', 'autoChase');
    toggle('Show SPC outlook on radar', 'showSpc', null, function () {
      if (onChange) onChange('showSpc');
    });
    toggle('Show storm reports on radar in Chase mode', 'showReports',
      'Every NWS local storm report of the last 24 hours — tornadoes, funnels, hail, wind, ' +
      'flooding, snow and the rest — lettered by kind. Filter them under Radar → Options.',
      function () { if (onChange) onChange('showReports'); });
    toggle('Show storm reports in Simple mode too', 'showReportsSimple', null, function () {
      if (onChange) onChange('showReportsSimple');
    });
    toggle('Keep screen awake', 'keepAwake',
      'For dash-mounted use. Released when the tab is hidden.',
      function () { S.applyWakeLock(); });
    toggle('12-hour clock', 'hour12');

    /* The one place in Vane that can talk to something other than a weather
     * service, and the only thing the user has to bring themselves. It is
     * opt-in, it is off by default, and the app is complete without it. */
    /* Discoverable after the banner is gone. An install prompt that keeps
     * coming back is an ad; one you can never find again is a dead end. */
    section('Install');
    var I = global.Install;
    var ist = I.status();
    var installNote = U.make('p', 'settings-note', ist.state === 'installed'
      ? 'Vane is installed and running from your home screen.'
      : (ist.note || ''));
    if (ist.can) {
      var installBtn = U.make('button', 'ghost-btn', 'Add to home screen');
      installBtn.addEventListener('click', function () {
        I.install().then(function () { if (onChange) onChange('install'); });
      });
      box.appendChild(installBtn);
    }
    box.appendChild(installNote);
    box.appendChild(U.make('p', 'settings-note',
      'Vane installs from the browser rather than an app store: no account, no ' +
      'review queue, and it updates itself the next time you open it. Once ' +
      'installed it keeps working with no signal — the last forecast, the app ' +
      'itself and your saved locations are all on the device.'));

    section('Data');
    /* Everything Vane keeps lives under one prefix, so "clear" means all
     * of it — including the learners' histories, which an earlier version
     * of this button silently left behind — plus the location mirror the
     * service worker reads for background alert checks. */
    var clear = U.make('button', 'ghost-btn', 'Clear all Vane data on this device');
    clear.addEventListener('click', function () {
      try {
        Object.keys(localStorage).forEach(function (k) {
          if (k.indexOf('vane.') === 0) localStorage.removeItem(k);
        });
      } catch (e) { /* ignore */ }
      var done = function () { location.reload(); };
      if (global.caches) global.caches.delete('vane-watch').then(done, done);
      else done();
    });
    box.appendChild(clear);

    var privacy = U.make('p', 'muted settings-privacy',
      'Vane stores, in this browser only: your preferences and saved locations, ' +
      'the last forecast received, and what its learners have learned about your ' +
      'locations — the forecast-verification scorecard, VaneMotion’s graded ' +
      'arrival calls, the rain-chance record, followed-storm histories, plans and ' +
      'targets, and a cached list of weather stations. With background ' +
      'alerts on, it also keeps a copy of your location where the app’s service ' +
      'worker can read it. None of it leaves the device: there is no server, no ' +
      'account and no analytics. Requests go directly from your browser to the ' +
      'public weather sources — Open-Meteo, weather.gov, SPC, Iowa State Mesonet, ' +
      'Esri basemaps and RainViewer. No API key of any kind, anywhere.');
    box.appendChild(privacy);
  }

  /* ── Radar site picker ──────────────────────────────────────────────── */

  function renderSites(state, query, onPick) {
    var list = U.el('site-list');
    var summaryEl = U.el('site-summary');
    U.clear(list);
    var S = global.Sites;

    if (S.state.error) {
      summaryEl.textContent = 'Radar station list unavailable: ' + S.state.error;
      return;
    }
    if (!S.state.fetchedAt) {
      summaryEl.textContent = 'Loading radar stations…';
      return;
    }

    var sum = S.summary();
    summaryEl.textContent = sum.precip + ' of ' + sum.online +
      ' online radars are in precipitation mode (' + sum.total + ' WSR-88D sites total). ' +
      'Sorted by distance from ' + state.location.name + '.';

    var activeOnly = U.el('site-active-only').checked;
    var results = S.search(query, state.location.lat, state.location.lon)
      .filter(function (s) { return !activeOnly || (s.online && s.scanMode === 'precip'); });

    if (!results.length) {
      var li = U.make('li', 'site-empty',
        activeOnly ? 'No radars in precipitation mode match.' : 'No radars match.');
      list.appendChild(li);
      return;
    }

    // The list is capped for rendering cost; say so rather than silently
    // truncating, which also made a narrowing filter look like it did nothing.
    var CAP = 60;
    if (results.length > CAP) {
      summaryEl.textContent += ' Showing the nearest ' + CAP + ' of ' + results.length + '.';
    } else {
      summaryEl.textContent += ' ' + results.length +
        (results.length === 1 ? ' match.' : ' matches.');
    }

    var current = global.Radar.getSite();
    results.slice(0, CAP).forEach(function (s) {
      var li = U.make('li');
      var btn = U.make('button', 'site-row' + (current && current.id === s.id ? ' on' : ''));

      var dot = U.make('span', 'site-dot site-' +
        (!s.online ? 'off' : s.scanMode === 'precip' ? 'precip' : 'clear'));
      dot.title = !s.online ? 'No recent Level II data'
        : s.scanMode === 'precip' ? 'Precipitation mode — actively scanning storms'
        : 'Clear-air mode';
      btn.appendChild(dot);

      var text = U.make('span', 'site-text');
      text.appendChild(U.make('span', 'site-id', s.id));
      text.appendChild(U.make('span', 'site-name', s.name));
      btn.appendChild(text);

      var meta = U.make('span', 'site-meta');
      meta.appendChild(U.make('span', null, U.distance(s.distance, state.imperial)));
      meta.appendChild(U.make('span', 'site-vcp', s.vcp || '—'));
      btn.appendChild(meta);

      btn.addEventListener('click', function () { onPick(s); });
      li.appendChild(btn);
      list.appendChild(li);
    });
  }

  /* What the notification learner (js/notifylearn.js) has concluded, with
   * its evidence, and a way to undo each conclusion. Vane's own heads-ups
   * adapt by themselves; official alert families are only ever suggested,
   * and muting one still lets Extreme alerts through. */
  function renderNotifyLearned(box, rerender) {
    var L = global.NotifyLearn;
    if (!L) return;
    var wrap = U.make('div', 'settings-learned');
    wrap.appendChild(U.make('p', 'settings-note',
      'Vane learns from which notifications you open and which you swipe away, ' +
      'on this device only. Its own heads-ups go quieter if you keep dismissing ' +
      'them; official alerts never change unless you say so.'));
    var any = false;
    function button(label, fn) {
      var b = U.make('button', 'ghost-btn', label);
      b.addEventListener('click', function () { fn(); rerender(); });
      return b;
    }
    [['rain', 'Rain heads-ups', 'they now fire only for rain of 35 dBZ or more within 20 minutes'],
     ['spc', 'SPC outlook notices', 'they now wait for an Enhanced risk or higher']].forEach(function (k) {
      var pol = L.policyFor(k[0]);
      if (!pol.n) return;
      any = true;
      var row = U.make('p', 'settings-note learned-row',
        k[1] + ': opened ' + pol.open + ' of ' + pol.n + '. ' +
        (pol.quiet ? 'You rarely open these, so ' + k[2] + '.'
          : pol.pinned ? 'Kept at normal, as you asked.' : 'No change.'));
      wrap.appendChild(row);
      if (pol.quiet) wrap.appendChild(button('Back to normal', function () { L.pinNormal(k[0]); }));
    });
    var label = {};
    C.ALERT_FILTERS.forEach(function (f) { label[f.key] = f.label; });
    L.suggest().forEach(function (sg) {
      any = true;
      wrap.appendChild(U.make('p', 'settings-note learned-row',
        'You have dismissed ' + sg.dismiss + ' of ' + (sg.open + sg.dismiss) + ' ' +
        (label[sg.family] || sg.family) + ' alert notifications. Stop notifying for these? ' +
        'Extreme alerts would still come through.'));
      wrap.appendChild(button('Stop notifying for ' + (label[sg.family] || sg.family),
        function () { L.setMute(sg.family, true); }));
    });
    Object.keys(L.muted()).forEach(function (fam) {
      any = true;
      wrap.appendChild(U.make('p', 'settings-note learned-row',
        'Muted: ' + (label[fam] || fam) + ' alerts (Extreme ones still come through).'));
      wrap.appendChild(button('Unmute ' + (label[fam] || fam), function () { L.setMute(fam, false); }));
    });
    if (any) wrap.appendChild(button('Forget what Vane learned about notifications', function () { L.reset(); }));
    box.appendChild(wrap);
  }

  UI.renderSettings = renderSettings;
  UI.renderSites = renderSites;
  UI.renderSearchResults = renderSearchResults;
  UI.renderSaved = renderSaved;
  UI.renderHelp = renderHelp;
})(window);
