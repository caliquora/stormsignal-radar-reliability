/* Vane — application controller: state, loading, events, refresh. */
(function (global) {
  'use strict';

  var C = global.VaneConfig, U = global.U, UI = global.UI, D = global.Derive;

  var state = {
    location: { lat: 35.4676, lon: -97.5164, name: 'Oklahoma City', admin: 'Oklahoma, US' },
    imperial: true,
    hour12: true,
    mode: 'simple',
    data: null,
    sounding: null,
    convective: null,
    alerts: [],
    observation: null,
    air: null,
    ensemble: null,
    threat: null,
    afd: null,
    outlook: null,
    outlookError: null,
    normals: null,
    cellsOnMap: true,
    shotCell: null,               // the cell the shot planner is solving for
    shotPlan: null,
    shotView: 'observer',
    pairOpen: false,
    radarObsTotal: 0,             // observed frames on the timeline right now
    radarFuture: 0,               // 0 = observed; N = HRRR lead minutes shown
    radarHistory: 0,              // 0 = present; epoch ms of an archived hour's end
    tab: 'now',                   // phone tab; ignored above 720px
    mgHours: 24,
    hourOffset: 0,
    fetchedAt: 0,
    mapReady: false,
    // Radar read directly overhead: {dbz, at}, or null for "could not look".
    // Never {dbz: 0} — a failed read must not be mistaken for a dry one.
    overhead: null,
    // VaneMotion's fitted echo motion (js/motion.js), or null for no verdict.
    motion: null,
    modelDaily: null,             // per-agency daily runs for the model viewer
    modelFocus: null              // agency id, or null for the overlay
  };

  var refreshTimer = null;
  var searchTimer = null;
  var loadGeneration = 0;

  function decisions(kind) {
    state.savedPlaces = loadSaved();
    if (kind) global.DecisionUI.receive(state, kind);
    else global.DecisionUI.render(state);
    if (global.VaneAgents) global.VaneAgents.receive(state);
  }

  /* ── Persistence (no accounts, no server — F2) ──────────────────────── */

  function saveState() {
    try {
      localStorage.setItem(C.STORAGE_KEY, JSON.stringify({
        location: state.location,
        imperial: state.imperial,
        hour12: state.hour12,
        mode: state.mode,
        saved: loadSaved()
      }));
    } catch (e) { /* private browsing — preferences just won't persist */ }
  }

  function restoreState() {
    try {
      var raw = localStorage.getItem(C.STORAGE_KEY);
      if (!raw) return;
      var s = JSON.parse(raw);
      if (s.location && typeof s.location.lat === 'number') state.location = s.location;
      if (typeof s.imperial === 'boolean') state.imperial = s.imperial;
      if (typeof s.hour12 === 'boolean') state.hour12 = s.hour12;
      if (s.mode === 'chase' || s.mode === 'simple') state.mode = s.mode;
    } catch (e) { /* ignore corrupt state */ }
  }

  function loadSaved() {
    try {
      var raw = localStorage.getItem(C.STORAGE_KEY);
      return raw ? (JSON.parse(raw).saved || []) : [];
    } catch (e) { return []; }
  }

  function writeSaved(list) {
    try {
      var raw = localStorage.getItem(C.STORAGE_KEY);
      var s = raw ? JSON.parse(raw) : {};
      s.saved = list;
      localStorage.setItem(C.STORAGE_KEY, JSON.stringify(s));
    } catch (e) { /* ignore */ }
  }

  // F8: a cached payload beats a blank screen when the signal drops mid-chase.
  function cacheData() {
    if (!state.data) return;
    try {
      localStorage.setItem(C.CACHE_KEY, JSON.stringify({
        location: state.location, data: state.data, alerts: state.alerts, at: state.fetchedAt
      }));
    } catch (e) { /* quota — non-fatal */ }
  }

  function loadCache() {
    try {
      var raw = localStorage.getItem(C.CACHE_KEY);
      if (!raw) return null;
      var c = JSON.parse(raw);
      return (Date.now() - c.at) < 6 * 3600 * 1000 ? c : null;
    } catch (e) { return null; }
  }

  /* ── Loading ────────────────────────────────────────────────────────── */

  function load(opts) {
    opts = opts || {};
    var loc = state.location;
    var generation = ++loadGeneration;
    function active() { return generation === loadGeneration && state.location === loc; }
    UI.status(opts.silent ? null : 'Loading ' + loc.name + '…', 'info');
    // The models' card and Storm Odds need no forecast to speak: a failed
    // forecast must not leave the Vane AI card empty.
    if (global.AiHub) global.AiHub.render(state);
    loadStormOddsHere(loc);

    return global.API.forecast(loc.lat, loc.lon)
      .then(function (data) {
        if (!active()) return;
        state.data = data;
        // A service-worker cache hit is not a fresh observation. Date it by
        // when it was actually fetched, and say so.
        state.fetchedAt = data.__cachedAt || Date.now();
        state.stale = !!data.__cachedAt;
        cacheData();
        // The displayed forecast's own day-ahead numbers go on record too —
        // the microclimate fit learns how the number the user actually read
        // leans at this spot. A cached payload is not a fresh prediction.
        if (!state.stale) {
          global.Verify.recordBlend(loc, data);
          // And its hourly rain chances, to be checked hour by hour
          // against the station (js/raincal.js).
          if (global.RainCal) global.RainCal.record(loc, data);
        }
        renderCore();
        decisions('forecast');
        UI.status(state.stale
          ? 'Offline — showing the last forecast received, ' +
            U.relative(Date.now() - state.fetchedAt) + '.'
          : null, state.stale ? 'warn' : 'info');
      })
      .catch(function (err) {
        if (!active()) return;
        state.stale = true;
        var cached = loadCache();
        if (cached && !state.data && Math.abs(cached.location.lat - loc.lat) < 0.005 && Math.abs(cached.location.lon - loc.lon) < 0.005) {
          state.data = cached.data;
          state.fetchedAt = cached.at;
          state.alerts = cached.alerts || [];
          renderCore();
          UI.status('Offline — showing cached data from ' +
            U.relative(Date.now() - cached.at) + '. ' + err.message, 'warn');
        } else {
          decisions();
          UI.status('Could not load forecast: ' + err.message + ' — retrying on next refresh.', 'error');
        }
      })
      .then(function () {
        if (!active()) return;
        // Alerts, observations and air quality are supplementary; a failure
        // here must never block the forecast the user came for.
        global.API.alertsWithStatus(loc.lat, loc.lon).then(function (result) {
          if (!active()) return;
          state.alertStatus = result;
          state.alerts = result.alerts;
          applyAlerts();
          cacheData();
        });
        global.API.observation(loc.lat, loc.lon).then(function (o) {
          if (!active()) return;
          state.observation = o;
          decisions('observation');
          if (state.data) {
            UI.renderObservation(o, state);
            /* The station is the highest-authority answer to "is it raining on
             * me", so everything that answers that question is re-read the
             * moment it lands — the nowcast, the hero's condition and icon,
             * and the sky behind them. Half of the card agreeing is worse than
             * none of it. */
            UI.renderNowcast(state);
            UI.renderHero(state);
            applyTheme();
          }
          /* The scorecard verifies yesterday's day-ahead forecasts against
           * this station's own thermometer, then re-ranks the leaderboard. */
          var settled = function (changed) {
            if (!changed || !active()) return;
            UI.renderModels(state);
            // The microclimate note lives on the week card; the consensus
            // and best-model lines live on Insight; the ledger on the
            // accountability card.
            if (state.data) { UI.renderDaily(state); UI.renderInsight(state); }
            decisions();
          };
          var rainSettled = function (changed) {
            if (changed && active() && state.data) { UI.renderInsight(state); decisions(); }
          };
          if (o) {
            global.Verify.settle(loc, o).then(settled);
            if (global.RainCal) global.RainCal.settle(loc, o).then(rainSettled);
          } else {
            // Outside the US weather.gov has no station; the nearest METAR
            // station in Iowa State's worldwide archive verifies instead.
            global.API.nearestMetar(loc.lat, loc.lon).then(function (st) {
              if (!st || !active()) return;
              if (global.RainCal) global.RainCal.settle(loc, st).then(rainSettled);
              return global.Verify.settle(loc, st).then(settled);
            }).catch(function () { /* the scorecard waits for next load */ });
          }
        });
        radarSource(loc).then(function (src) {
          if (!active()) return;
          state.radarCoverage = src ? src.kind !== 'none' : null;
          sampleOverhead(loc, src);
          learnMotion(loc, src);
          gradeMotion(loc);
        });
        checkOutlookRisk();
        global.API.airQuality(loc.lat, loc.lon).then(function (aq) {
          if (!active()) return;
          state.air = aq;
          UI.renderAirQuality(aq);
        });
        loadCells();
        loadDiscussion();
        loadOutlook();
        global.API.modelDaily(loc.lat, loc.lon).then(function (md) {
          if (!active()) return;
          state.modelDaily = md;
          global.Modelcast.render(state);
          // Note down what every agency says about the days to come; the
          // scorecard settles the bet once each day has happened. Re-render
          // the card so its learning state shows regardless of whether the
          // ensemble comparison beat this request home.
          global.Verify.record(loc, md);
          UI.renderModels(state);
          if (state.data) { UI.renderDaily(state); UI.renderInsight(state); }
        }).catch(function () { /* the viewer simply stays hidden */ });
        /* Deliberately NOT loaded here: the model chart. Its nine lattice
         * requests fired at boot once tripped the API's rate limit and
         * starved the sounding the user was actually looking at. The chart
         * loads when Outlook opens — see setTab. */
        // The ensemble is a second, heavier request. The meteogram renders
        // without it and gains the confidence envelope when it lands.
        global.API.multiModel(loc.lat, loc.lon).then(function (ens) {
          if (!active()) return;
          state.ensemble = ens;
          state.ensembleAt = ens.__cachedAt || Date.now();
          decisions('ensemble');
          UI.renderModels(state);
          if (state.data) {
            UI.renderMeteogram(state);
          }
        }).catch(function () { /* ensemble is optional */ });
        if (state.mode === 'chase') loadChase();
      });
  }

  /* ── Storm cells ────────────────────────────────────────────────────── */

  function loadCells() {
    if (!global.Radar.inConus(state.location.lat, state.location.lon)) {
      global.Cells.state.cells = [];
      state.threat = null;
      UI.renderThreat(state);
      if (state.mode === 'chase') UI.renderCells(state);
      return Promise.resolve([]);
    }
    return global.Cells.load().then(function () {
      refreshCells();
    });
  }

  function refreshCells() {
    decisions('cells');
    state.threat = global.Cells.threatToPoint(state.location.lat, state.location.lon);
    if (state.data) UI.renderInsight(state);
    // The planner follows the best cell in range unless the user has pinned
    // one; re-resolve the pinned cell by id each refresh so its position and
    // structure stay current rather than freezing at the moment it was picked.
    var near = global.Cells.near(state.location.lat, state.location.lon, 500, 20);
    if (state.shotCell) {
      var again = null;
      for (var i = 0; i < near.length; i++) {
        if (near[i].id === state.shotCell.id) { again = near[i]; break; }
      }
      state.shotCell = again || near[0] || null;
    } else {
      state.shotCell = near[0] || null;
    }
    UI.renderThreat(state);
    if (state.mode === 'chase') { UI.renderCells(state); UI.renderShot(state); }
    if (state.mapReady) {
      global.Radar.setCells(near.slice(0, 10), {
        hidden: !state.cellsOnMap || state.mode !== 'chase',
        imperial: state.imperial
      });
    }
  }

  // Clicking a cell anywhere should take you to it on the radar.
  state.onFocusCell = function (cell) {
    if (!state.mapReady) return;
    state.shotCell = cell;
    if (state.mode !== 'chase') setMode('chase');
    UI.renderShot(state);
    global.Radar.focusCell(cell);
    showRadar();
  };

  /* Reads the real reflectivity field around a cell so the 3D view can be the
   * actual echo rather than a generic silhouette. One sample per cell, cached
   * by id, and it re-samples when the cell's own detection updates — a storm
   * looks different every volume scan and that is the point.
   *
   * The tiles come from the cell's own radar rather than the mosaic: the
   * single-site product is higher resolution and is the same scan the storm
   * attributes were computed from, so the footprint and the heights agree. */
  var fieldPending = {};

  state.onNeedField = function (cell) {
    var key = cell.id + '|' + cell.valid;
    if (fieldPending[key]) return;
    fieldPending[key] = true;

    var siteId = resolveSiteId(cell.site);
    var url = C.RIDGE_TILES.replace('{site}', siteId).replace('{product}', 'N0Q');

    /* The sample box is scaled to the storm. A fixed 90 km box around a 13 kft
     * cell renders it as a few specks in an empty field; sizing the box to the
     * echo top keeps a small shower and a 60 kft supercell both filling the
     * frame at their own scale. */
    var topKm = (cell.top || 20) * 0.3048;
    var halfKm = Math.max(10, Math.min(35, topKm * 1.6));

    global.Reflectivity.sample({
      lat: cell.lat, lon: cell.lon,
      halfKm: halfKm, grid: 128, zoom: 9,
      urlFor: function (z, x, y) {
        return url.replace('{z}', z).replace('{x}', x).replace('{y}', y);
      }
    }).then(function (field) {
      if (!field) return;                 // offline, or CORS refused: keep the fallback
      state.shotField = { cellId: cell.id, valid: cell.valid, field: field };
      if (state.mode === 'chase') UI.renderShot(state);
    }).catch(function () { /* the silhouette fallback already covers this */ });
  };

  // The attribute table uses the bare 3-letter radar id; RIDGE wants the full
  // 4-character ICAO. Prefer the real station list, since not every site takes
  // a K prefix (Alaska is P, the Pacific is not uniform either).
  function resolveSiteId(short) {
    var sites = global.Sites.state.sites;
    for (var i = 0; i < sites.length; i++) {
      if (sites[i].id.length === 4 && sites[i].id.slice(1) === short) return sites[i].id;
    }
    return short.length === 3 ? 'K' + short : short;
  }

  state.onShowTarget = function (target) {
    if (!state.mapReady) return;
    global.Radar.setVantage(target);
    global.Radar.panTo(target.lat, target.lon, 9);
    showRadar();
  };

  function applyAlerts() {
    if (global.WarningEvidence) global.WarningEvidence.render(state.alertStatus, state.location);
    var current = global.WarningEvidence ? global.WarningEvidence.activeRecords(state.alerts, Date.now()) : state.alerts;
    state.alerts = current; // Shared summaries must not re-present explicitly expired records.
    var shown = global.Settings.filterAlerts(current);
    UI.renderAlerts(shown, function () { setMode('chase'); });
    UI.renderAlertsFull(shown, state.alertStatus);
    global.Settings.notifyNew(current);
    // The home-screen icon carries the count, so a severe alert is visible
    // without opening anything.
    global.Settings.updateBadge(current);
    // Mirror what the background check needs into a cache the SW can read.
    global.Settings.syncWatch(state.location, state.alerts);
    decisions('alerts');
  }

  /* ── Extended outlook ───────────────────────────────────────────────── */

  /* Two requests, and the outlook is useful with only the first. The ensemble
   * gives the spread; the twenty-year archive gives something to compare it
   * against. If the archive fails, the chart still draws — it just cannot
   * place the skill horizon, and says so rather than guessing one. */
  function loadOutlook() {
    var loc = state.location;
    state.outlookError = null;

    var ens = global.API.ensembleDaily(loc.lat, loc.lon);
    var norm = global.API.normals(loc.lat, loc.lon).catch(function () { return null; });

    return Promise.all([ens, norm]).then(function (r) {
      state.normals = r[1];
      state.outlook = global.Outlook.build(r[0], r[1], state.data && state.data.daily);
      if (!state.outlook) throw new Error('no ensemble data for this location');
      UI.renderOutlook(state);
    }).catch(function (e) {
      state.outlook = null;
      state.outlookError = 'Extended outlook unavailable: ' + e.message + '.';
      UI.renderOutlook(state);
    });
  }

  /* ── Forecaster's discussion ────────────────────────────────────────── */

  function renderDiscussion() {
    UI.renderDiscussion(state, { openSettings: openSettings });
  }

  function loadDiscussion() {
    var loc = state.location;
    return global.API.afd(loc.lat, loc.lon).then(function (product) {
      state.afd = product;
      renderDiscussion();
    });
  }



  /* ── SPC products (Chase mode) ──────────────────────────────────────── */

  function loadSpc() {
    var S = global.SPC;
    var day = parseInt(U.el('spc-day').value, 10) || 1;
    var hazard = U.el('spc-hazard').value || 'cat';
    return S.load(day, hazard).then(function () {
      // Days 3+ only have a categorical product; reflect any fallback in the UI.
      U.el('spc-hazard').value = S.state.hazard;
      U.el('spc-hazard').disabled = S.state.day > 2;
      S.state.visible = global.Settings.get('showSpc');
      UI.renderSpc(state);
      S.draw(global.Radar.getMap());
    });
  }

  /* Vane Storm Odds for this place, the next twelve hours, for the Vane AI
   * card: one request, at most every fifteen minutes per place. */
  var oddsHereFor = '', oddsHereAt = 0;
  function loadStormOddsHere(loc) {
    var SO = global.StormOdds && global.StormOdds.weights();
    if (!SO || !SO.ship) return;
    var key = loc.lat.toFixed(3) + ',' + loc.lon.toFixed(3);
    if (key === oddsHereFor && Date.now() - oddsHereAt < 15 * 60000 && state.stormOddsHere) return;
    oddsHereFor = key; oddsHereAt = Date.now();
    if (key !== (state.stormOddsKey || '')) state.stormOddsHere = null;
    // Outside the US the model has nothing to say: it learned US weather.
    global.PopGrid.load().then(function (g) {
      if (!global.PopGrid.inUS(g, loc.lat, loc.lon)) return { outside: true };
      return global.API.stormEnv([{ lat: loc.lat, lon: loc.lon }], 12);
    }).then(function (rows) {
      if (state.location !== loc) return;
      state.stormOddsKey = key;
      state.stormOddsOutside = !!rows.outside;
      state.stormOddsHere = rows.outside ? [] : rows.length ? global.StormOdds.series(rows[0].hourly, rows[0].lon) : [];
      state.stormOddsFailed = false;
      if (global.AiHub) global.AiHub.render(state);
    }, function () {
      if (state.location !== loc) return;
      state.stormOddsFailed = true; oddsHereAt = 0;
      if (global.AiHub) global.AiHub.render(state);
    });
  }

  /* Turn one map field on, from elsewhere in the app (the Vane AI card). */
  function showLayer(kind) {
    setTab('radar');
    // Size the map for the tab it just appeared on before drawing over it.
    global.Radar.invalidate();
    if (global.Layers.active() !== kind) toggleLayer(kind);
  }

  /* Storm reports have a switch per mode: on by default in Chase, off in
   * Simple until asked for, so the Simple map never changes unbidden. */
  function reportsKey() { return state.mode === 'chase' ? 'showReports' : 'showReportsSimple'; }
  function reportsOn() { return !!global.Settings.get(reportsKey()); }

  function loadReports() {
    var S = global.SPC;
    return S.loadReports().then(function () {
      S.state.reportsVisible = reportsOn();
      S.state.reportTypes = global.Settings.get('reportTypes') || {};
      UI.renderReports(state);
      renderReportFilters();
      S.drawReports(global.Radar.getMap());
    });
  }

  /* One chip per kind of report present, with its count: the legend and
   * the filter in one. Hidden while the layer is off. */
  function renderReportFilters() {
    var box = U.el('report-filters');
    if (!box) return;
    U.clear(box);
    var S = global.SPC, counts = S.summary();
    box.hidden = !reportsOn() || !S.state.reports.length;
    if (box.hidden) return;
    var types = global.Settings.get('reportTypes') || {};
    C.REPORT_ORDER.forEach(function (k) {
      if (!counts[k]) return;
      var st = C.STORM_REPORT_STYLE[k], on = types[k] !== false;
      var b = U.make('button', 'report-filter');
      b.type = 'button';
      b.dataset.kind = k;
      b.setAttribute('aria-pressed', String(on));
      var dot = U.make('span', 'lsr-dot', st.glyph);
      dot.style.background = st.color;
      b.appendChild(dot);
      b.appendChild(U.make('span', null, st.label + ' ' + counts[k]));
      b.addEventListener('click', function () {
        var t = Object.assign({}, global.Settings.get('reportTypes') || {});
        if (t[k] === false) delete t[k]; else t[k] = false;
        global.Settings.save({ reportTypes: t });
        S.state.reportTypes = t;
        renderReportFilters();
        if (state.mapReady) S.drawReports(global.Radar.getMap());
      });
      box.appendChild(b);
    });
  }

  function loadChase() {
    var loc = state.location;
    return global.API.sounding(loc.lat, loc.lon)
      .then(function (s) {
        state.sounding = s;
        computeConvective();
        UI.renderParams(state);
        UI.renderHodograph(state);
        UI.renderProfile(state);
        // The sounding is what supplies the cloud base and the shear vector
        // the 3D view leans by, so the planner is redrawn once it lands.
        UI.renderShot(state);
      })
      .catch(function (err) {
        UI.status('Pressure-level data unavailable: ' + err.message, 'warn');
      });
  }

  function computeConvective() {
    if (!state.sounding || !state.data) { state.convective = null; return; }
    var h = state.sounding.hourly;
    var tz = state.sounding.utc_offset_seconds || 0;
    var base = 0;
    var now = Date.now();
    for (var i = 0; i < h.time.length; i++) {
      if (U.epochOf(h.time[i], tz) >= now - 1800000) { base = i; break; }
    }
    var idx = U.clamp(base + state.hourOffset, 0, h.time.length - 1);
    state.hourOffset = idx - base;

    var cur = state.data.current;
    state.convective = D.convective(state.sounding, idx, {
      speed: cur.wind_speed_10m, dir: cur.wind_direction_10m,
      // Surface temperature and dewpoint carry the LCL, which is what decides
      // how high the cloud base sits and therefore what the storm looks like.
      temp: cur.temperature_2m, dewpoint: cur.dew_point_2m
    });

    var label = state.hourOffset === 0 ? 'now'
      : U.fmtHour(U.parseLocal(h.time[idx]), state.hour12) + ' (+' + state.hourOffset + 'h)';
    U.el('cv-hour').textContent = label;
    computeChaseDay();
  }

  /* Chase-day odds (js/chaseday.js) for the next two evenings, read from
   * the forecast profile at 00Z — the hour the model's training soundings
   * were launched, so it is fed the same moment of the day it learned. */
  function computeChaseDay() {
    state.chaseDay = null;
    if (!global.ChaseDay || !state.sounding || !state.data) return;
    var h = state.sounding.hourly, tz = state.sounding.utc_offset_seconds || 0;
    var hd = state.data.hourly, dtz = state.data.utc_offset_seconds || 0, now = Date.now(), out = [];
    for (var i = 0; i < h.time.length && out.length < 2; i++) {
      var at = U.epochOf(h.time[i], tz);
      if (at < now || new Date(at).getUTCHours() !== 0) continue;
      // The hour's own surface temperature and dewpoint carry the LCL.
      var j = hd && hd.time ? hd.time.findIndex(function (t) { return Math.abs(U.epochOf(t, dtz) - at) < 1800000; }) : -1;
      var sw = j >= 0 ? { speed: hd.wind_speed_10m[j], dir: hd.wind_direction_10m[j],
        temp: hd.temperature_2m[j], dewpoint: hd.dew_point_2m ? hd.dew_point_2m[j] : null } : null;
      var p = global.ChaseDay.odds(global.ChaseDay.envFromConvective(D.convective(state.sounding, i, sw)));
      if (p !== null) out.push({ at: at, p: p });
    }
    state.chaseDay = out.length ? out : null;
  }

  function applyTheme() {
    if (!state.data || !global.Theme) return;
    var cur = state.data.current;
    /* The sky follows the observation too. Painting a clear blue gradient
     * while the card above it says rain is falling is the same contradiction
     * in a different medium. */
    var obs = D.observedPrecip({
      observation: state.observation, overhead: state.overhead, current: cur
    });
    var code = obs && obs.station && obs.station.raining && obs.station.code !== null
      ? obs.station.code : cur.weather_code;
    // Sun altitude, not the is_day flag, so the sky eases through twilight
    // instead of snapping between two looks.
    var alt = global.Astro
      ? global.Astro.sunPosition(new Date(), state.location.lat, state.location.lon).altitude
      : (cur.is_day ? 30 : -30);
    global.Theme.apply(code, alt, {
      reduceMotion: global.Settings.reduceMotion()
    });
  }

  function renderCore() {
    if (!state.data) return;
    decisions();
    applyTheme();
    UI.renderHero(state);
    UI.renderNowcast(state);
    UI.renderInsight(state);
    UI.renderHourly(state);
    UI.renderDaily(state);
    UI.renderDetails(state);
    UI.renderAstro(state);
    UI.renderMeteogram(state);
    UI.renderModels(state);
    if (state.afd) renderDiscussion();
    if (state.outlook || state.outlookError) UI.renderOutlook(state);
    if (state.air) UI.renderAirQuality(state.air);
    if (state.observation) UI.renderObservation(state.observation, state);
    var ago = state.fetchedAt ? U.relative(Date.now() - state.fetchedAt) : '';
    U.el('refresh-line').textContent = 'Updated ' + ago + ' · auto-refreshing every ' +
      (C.REFRESH_MS[state.mode] / 60000) + ' min · press R to refresh now';
  }

  /* ── Mode (F5: the zoom lens) ───────────────────────────────────────── */

  function setMode(mode) {
    state.mode = mode;
    document.body.dataset.mode = mode;
    Array.prototype.forEach.call(document.querySelectorAll('.mode-switch button'), function (b) {
      var on = b.dataset.mode === mode;
      b.classList.toggle('on', on);
      b.setAttribute('aria-selected', String(on));
    });
    saveState();
    /* Switching modes moves you to the new content, but only if you were on
     * the tab the switch makes stale. Someone who deliberately opened Radar
     * and then hit Chase wants the radar with chase data on it, not to be
     * yanked somewhere else. */
    if (mode === 'chase' && state.tab === 'now') setTab('chase');
    if (mode === 'simple' && state.tab === 'chase') setTab('now');
    if (state.data) { UI.renderHourly(state); renderCore(); }
    else if (state.afd) renderDiscussion();
    if (mode === 'chase') {
      if (!state.sounding) loadChase();
      else { computeConvective(); UI.renderParams(state); UI.renderHodograph(state); UI.renderProfile(state); }
      loadPolygons();
      refreshCells();
      UI.renderShot(state);
      /* Data already in hand redraws directly — leaving Chase removed the
       * drawings but kept the features, so the loaders' emptiness checks
       * would otherwise skip the redraw forever. */
      if (!global.SPC.state.features.length) loadSpc();
      else if (state.mapReady) global.SPC.draw(global.Radar.getMap());
      global.SPC.state.reportsVisible = reportsOn();
      if (!global.SPC.state.reports.length) loadReports();
      else if (state.mapReady) { global.SPC.drawReports(global.Radar.getMap()); renderReportFilters(); }
    } else if (state.mapReady) {
      /* Chase-only map layers leave with the mode. A user photographed Simple
       * mode still wearing the SPC outlines, storm cells and mesoscale boxes
       * drawn during a Chase session — layers with no visible controls left
       * to turn them off, since the chips vanish with the mode too. The
       * visibility SETTINGS survive; only the drawings leave, and re-entering
       * Chase redraws them through the normal loaders. */
      var m = global.Radar.getMap();
      var keepSpc = global.SPC.state.visible;
      global.SPC.state.visible = false;
      global.SPC.draw(m);
      global.SPC.state.visible = keepSpc;
      // Reports have their own Simple-mode switch, off unless asked for.
      global.SPC.state.reportsVisible = reportsOn();
      if (reportsOn() && !global.SPC.state.reports.length) loadReports();
      else { global.SPC.drawReports(m); renderReportFilters(); }
      refreshCells();                     // its hidden flag follows the mode
    }
    global.Radar.invalidate();
    scheduleRefresh();
  }

  /* ── Live radar (js/live.js) ────────────────────────────────────────
   * A tiny freshness probe per source; tiles re-fetch only when the source
   * has genuinely produced a new scan. */

  var pendingRadarFresh = null;

  function recordRadarProvenance(source, observedAt, frameTimesVerified, cached) {
    state.radarProvenance = { source: source, observedAt: observedAt,
      frameTimesVerified: !!frameTimesVerified, cached: !!cached, checkedAt: Date.now() };
    if (global.StormSignal) global.StormSignal.render(state.radarProvenance);
  }

  function probeRadar() {
    var src = global.Radar.getSource();
    if (src === 'nexrad') {
      return global.API.mosaicValid().then(function (v) {
        if (global.Radar.getSource() !== src) return null;
        recordRadarProvenance('IEM mosaic index', v, false);
        return v ? { key: 'n0q:' + v } : null;
      });
    }
    if (src === 'site') {
      var s = global.Radar.getSite();
      if (!s) return Promise.resolve(null);
      return global.API.siteScanTime(s.id).then(function (t) {
        if (global.Radar.getSource() !== src || !global.Radar.getSite() || global.Radar.getSite().id !== s.id) return null;
        recordRadarProvenance(s.id + ' Level II receipt (not tile scan time)', t, false);
        return t ? { key: s.id + ':' + t } : null;
      });
    }
    return global.API.radarIndex().then(function (ix) {
      var latest = null;
      ix.frames.forEach(function (f) { if (!f.forecast) latest = f.time; });
      // The whole index rides along: for RainViewer the new frame list IS the
      // new data, and re-fetching it separately would race the key.
      if (global.Radar.getSource() !== src) return null;
      recordRadarProvenance('RainViewer index', latest ? latest * 1000 : null, true, ix.__cachedAt);
      return latest ? { key: 'rv:' + latest, index: ix } : null;
    });
  }

  /* Fresh data is applied where it can be seen. With sections at every
   * width, the radar is only on screen on its own tab — re-fetching a
   * screenful of tiles behind another tab spends cellular data painting
   * nothing, so the refresh waits at the door and applies on entry. */
  function onRadarFresh(info) {
    if (state.tab === 'radar' && !document.hidden) applyRadarFresh(info);
    else pendingRadarFresh = info;
  }

  function applyRadarFresh(info) {
    pendingRadarFresh = null;
    global.Radar.refresh({ generation: Date.now(), index: info.index || null });
    // A new volume scan carries a new storm-attribute table with it: the
    // cells on the map should be the cells in the imagery under them.
    if (state.mode === 'chase') loadCells();
  }

  /* Read the radar directly over the user, out of the same national mosaic
   * tiles the map is drawing. Iowa State serves them with an open CORS header,
   * which is what makes reading the pixels back possible at all.
   *
   * A small box on purpose — 4 km, so this answers "is it raining on me" and
   * not "is it raining in the county". The peak inside that box is taken
   * rather than the single centre pixel: a shower is smaller than the box and
   * point-sampling would walk straight past it.
   *
   * Failure is silent and total: outside NEXRAD coverage, offline, or with the
   * canvas tainted, `overhead` stays null and the verdict simply falls back to
   * the station and then the model. A missing reading must never be reported
   * as a dry one. */
  /* Which radar can be read over this pin. NEXRAD inside the lower 48;
   * everywhere else RainViewer's global composite, but only after its
   * coverage mask confirms a radar actually sees the pin — a blank tile
   * over Kinshasa is not clear sky, it is no radar. Resolves
   * { kind: 'nexrad' }, { kind: 'rainviewer', frames }, { kind: 'none' }
   * (no radar here), or null (could not tell: offline, mask unreadable). */
  function radarSource(loc) {
    if (global.Radar.inConus(loc.lat, loc.lon)) return Promise.resolve({ kind: 'nexrad' });
    if (!global.Reflectivity) return Promise.resolve(null);
    return Promise.all([
      global.Reflectivity.covered(loc.lat, loc.lon, C.RAINVIEWER_COVERAGE),
      global.API.radarSampleFrames()
    ]).then(function (r) {
      if (r[0] === false) return { kind: 'none' };
      if (r[0] !== true || !r[1].length) return null;
      return { kind: 'rainviewer', frames: r[1] };
    }).catch(function () { return null; });
  }

  function sampleOverhead(loc, src) {
    if (!global.Reflectivity) return;
    if (!src || src.kind === 'none') {
      state.overhead = null;
      if (state.data) UI.renderNowcast(state);
      return;
    }
    var rv = src.kind === 'rainviewer';
    var url = rv ? src.frames[src.frames.length - 1].url
      : C.NEXRAD_TILES.replace('{product}', 'nexrad-n0q-900913');
    global.Reflectivity.sample({
      lat: loc.lat, lon: loc.lon,
      halfKm: C.OBSERVED.SAMPLE_HALF_KM, grid: 24, zoom: 8,
      decode: rv ? 'rainviewer' : null,
      reportClear: true,
      urlFor: function (z, x, y) {
        return url.replace('{z}', z).replace('{x}', x).replace('{y}', y);
      }
    }).then(function (field) {
      // A clear box reads back as dbz -Infinity, which is a real "nothing
      // there"; a failed read stays null, which is "no verdict".
      // RainViewer's newest frame is typically five to fifteen minutes old;
      // its own time is what the staleness check should judge.
      state.overhead = field
        ? { dbz: field.clear ? -Infinity : field.maxDbz,
            at: rv ? src.frames[src.frames.length - 1].t : Date.now(),
            source: src.kind }
        : null;
      if (state.data) UI.renderNowcast(state);
    }).catch(function () { state.overhead = null; });
  }

  /* VaneMotion (js/motion.js): fit a motion model to the last hour of the
   * same mosaic, in the browser, and let the nowcast say where the echoes
   * are headed and when the nearest one arrives. Failure is silent for the
   * same reason as above — no fit is a blank line, never a guess. */
  function learnMotion(loc, src) {
    if (!global.Motion) return;
    if (!src || src.kind === 'none') {
      state.motion = null;
      if (state.data) UI.renderNowcast(state);
      return;
    }
    global.Motion.learn({
      lat: loc.lat, lon: loc.lon,
      frames: src.kind === 'rainviewer' ? src.frames : null
    }).then(function (m) {
      // VaneMotion's own learned timing correction for this spot, if its
      // graded record here has earned one (js/motionskill.js).
      if (global.MotionSkill) m = global.MotionSkill.calibrate(loc, m);
      state.motion = m;
      if (state.data) { UI.renderNowcast(state); UI.renderInsight(state); }
      // The fit that says "rain in 25 minutes" is also the one heads-up
      // worth interrupting for. Opt-in, deduped per approach in Settings.
      global.Settings.notifyMotion(m);
      // And it goes on the record, to be graded against the archived
      // mosaic once its window has passed (js/motionskill.js).
      if (global.MotionSkill) global.MotionSkill.record(loc, m);
      blendRainTiming(loc, m, src);
    }).catch(function () { state.motion = null; });
  }

  /* Two clocks for "when does rain get here": VaneMotion's radar fit and
   * the forecast model's 15-minute nowcast. Both make calls, both are
   * graded, and the blend weights each by its record here
   * (js/motionskill.js). Only rain still ahead is timed. */
  function blendRainTiming(loc, m, src) {
    var MS = global.MotionSkill;
    if (!MS || !src || src.kind === 'none') { state.rainTiming = null; return; }
    var now = Date.now();
    var motionMin = m && m.eta && !m.overheadNow && !m.stationary ? m.eta.minutes : null;
    var nc = state.data ? D.nowcast(state.data) : null;
    var modelMin = nc && nc.state === 'starting' && nc.startAt
      ? (nc.startAt - now) / 60000 : null;
    if (modelMin !== null && (modelMin <= 0 || modelMin > 120)) modelMin = null;
    var w = MS.blendFor(loc);
    var both = motionMin !== null && modelMin !== null;
    var blendMin = both ? MS.blendMinutes(motionMin, modelMin, w) : null;
    MS.recordOthers(loc, modelMin, blendMin, src.kind);
    state.rainTiming = (motionMin === null && modelMin === null) ? null : {
      at: now, motionMin: motionMin, modelMin: modelMin, blendMin: blendMin, w: w
    };
    if (state.data) UI.renderInsight(state);
  }

  /* Grade any VaneMotion calls whose windows have closed, by looking back
   * at the archived mosaic over the pin. Runs on every load; costs nothing
   * when there is nothing due. */
  function gradeMotion(loc) {
    if (!global.MotionSkill) return;
    global.MotionSkill.settleDue(loc).then(function (changed) {
      if (changed && state.data) { UI.renderNowcast(state); UI.renderInsight(state); }
    }).catch(function () { /* the archive retries next load */ });
  }

  /* SPC's categorical outlook at the pin, for the opt-in once-a-day
   * notification. Fetched at most every three hours, days 1 and 2, in
   * either mode — the map's own SPC layer stays chase-only. */
  var SPC_CHECK_KEY = 'vane.spc.checked.v1';

  function checkOutlookRisk() {
    if (!global.Settings.get('notifyOutlook')) return;
    var last = 0;
    try { last = +localStorage.getItem(SPC_CHECK_KEY) || 0; } catch (e) { /* fine */ }
    if (Date.now() - last < 3 * 3600 * 1000) return;
    try { localStorage.setItem(SPC_CHECK_KEY, String(Date.now())); } catch (e) { /* fine */ }
    var loc = state.location;
    [1, 2].forEach(function (day) {
      global.API.spcOutlook(day, 'cat').then(function (features) {
        var risk = global.SPC.riskIn(features, loc.lat, loc.lon, 'cat');
        if (risk) global.Settings.notifyOutlook(day, risk);
      }).catch(function () { /* outlook check is best-effort */ });
    });
  }

  function loadPolygons() {
    if (!state.mapReady) return;
    global.API.alertsInArea().then(function (features) {
      state.warningFeatures = features;
      decisions();
      global.Radar.setPolygons(features);
    });
  }

  /* ── Location changes ───────────────────────────────────────────────── */

  function setLocation(loc, opts) {
    state.location = loc;
    state.data = null;
    state.fetchedAt = 0;
    state.stale = true;
    state.alerts = [];
    state.alertStatus = null;
    if (global.WarningEvidence) global.WarningEvidence.render(null, loc);
    state.modelDaily = null;
    /* Both of these observe one point on the ground. Carrying them to a new
     * location would report Miami's rain over Denver, so they are dropped
     * rather than left to be re-fetched a second later. */
    state.observation = null;
    state.overhead = null;
    state.motion = null;
    state.rainTiming = null;
    state.radarCoverage = null;
    state.sounding = null;
    state.convective = null;
    state.ensemble = null;
    state.ensembleAt = 0;
    state.threat = null;
    // A new location is usually a new forecast office; nothing about the old
    // office's discussion applies here.
    state.afd = null;
    // Normals are point-specific and the ensemble is a fresh run per location.
    state.outlook = null;
    state.outlookError = null;
    state.normals = null;
    U.el('afd-card').hidden = true;
    state.hourOffset = 0;
    saveState();
    U.el('place-name').textContent = loc.name;
    decisions();
    if (state.mapReady) {
      global.Radar.setMarker(loc.lat, loc.lon);
      if (!opts || !opts.keepView) global.Radar.panTo(loc.lat, loc.lon, 8);
      // NEXRAD is US-only; moving outside coverage must fall back to global.
      var want = global.Radar.pickSource(loc.lat, loc.lon);
      if (want !== global.Radar.getSource()) {
        global.Radar.setSource(want);
        renderRadarLegend();
      }
      U.el('radar-source').querySelector('option[value="nexrad"]').disabled =
        !global.Radar.inConus(loc.lat, loc.lon);
    }
    load();
  }

  function useGeolocation() {
    if (!navigator.geolocation) {
      UI.status('This browser does not expose location services.', 'warn');
      return;
    }
    UI.status('Getting your location…', 'info');
    navigator.geolocation.getCurrentPosition(function (pos) {
      var lat = pos.coords.latitude, lon = pos.coords.longitude;
      if (state.mapReady) global.Radar.setMarker(lat, lon, pos.coords.accuracy);
      // Reverse-geocode for a human label, but never block the forecast on it.
      global.API.geocode(lat.toFixed(3) + ',' + lon.toFixed(3)).then(function () {
        setLocation({ lat: lat, lon: lon, name: 'My location',
          admin: lat.toFixed(3) + ', ' + lon.toFixed(3) });
      });
    }, function (err) {
      UI.status('Location unavailable: ' + err.message, 'warn');
    }, { enableHighAccuracy: true, timeout: 10000, maximumAge: 60000 });
  }

  /* ── Refresh ────────────────────────────────────────────────────────── */

  function scheduleRefresh() {
    if (refreshTimer) clearInterval(refreshTimer);
    refreshTimer = setInterval(function () {
      if (document.hidden) return;           // don't burn data in a pocket
      load({ silent: true });
      // Reports used to load once per session and never again; new ones
      // land all evening on a storm day.
      if (reportsOn()) loadReports();
    }, C.REFRESH_MS[state.mode]);
  }

  /* ── Events ─────────────────────────────────────────────────────────── */

  function wireSearch() {
    var input = U.el('search-input');
    var form = U.el('search-form');

    input.addEventListener('input', function () {
      var q = input.value.trim();
      if (searchTimer) clearTimeout(searchTimer);
      if (q.length < 2) { U.el('search-results').hidden = true; return; }
      searchTimer = setTimeout(function () {
        global.API.geocode(q).then(function (results) {
          UI.renderSearchResults(results, function (r) {
            input.value = '';
            U.el('search-results').hidden = true;
            input.blur();
            setLocation(r);
          });
        }).catch(function () { U.el('search-results').hidden = true; });
      }, 250);
    });

    form.addEventListener('submit', function (e) {
      e.preventDefault();
      var q = input.value.trim();
      if (!q) return;
      global.API.geocode(q).then(function (results) {
        if (results.length) {
          input.value = '';
          U.el('search-results').hidden = true;
          input.blur();
          setLocation(results[0]);
        } else {
          UI.status('No match for "' + q + '".', 'warn');
        }
      });
    });

    document.addEventListener('click', function (e) {
      if (!form.contains(e.target)) U.el('search-results').hidden = true;
      var sw = document.querySelector('.saved-wrap');
      if (sw && !sw.contains(e.target)) U.el('saved-list').hidden = true;
    });
  }

  function wireSaved() {
    var btn = U.el('saved-btn'), list = U.el('saved-list');
    function refresh() {
      decisions();
      UI.renderSaved(loadSaved(), state.location,
        function (s) { list.hidden = true; setLocation(s); },
        function (s) {
          writeSaved(loadSaved().filter(function (x) { return x.name !== s.name; }));
          refresh();
        },
        function () {
          var cur = loadSaved();
          cur.push({ lat: state.location.lat, lon: state.location.lon,
            name: state.location.name, admin: state.location.admin });
          writeSaved(cur.slice(0, 12));
          refresh();
        });
    }
    btn.addEventListener('click', function () {
      var showing = list.hidden;
      if (showing) refresh();
      list.hidden = !showing;
      btn.setAttribute('aria-expanded', String(showing));
    });
  }

  function wireControls() {
    U.el('geo-btn').addEventListener('click', useGeolocation);

    U.el('units-btn').addEventListener('click', function () {
      state.imperial = !state.imperial;
      U.el('units-label').textContent = state.imperial ? '°F' : '°C';
      saveState();
      renderCore();
      if (state.mode === 'chase') { UI.renderParams(state); UI.renderProfile(state); }
    });

    Array.prototype.forEach.call(document.querySelectorAll('.mode-switch button'), function (b) {
      b.addEventListener('click', function () { setMode(b.dataset.mode); });
    });

    U.el('radar-play').addEventListener('click', function () {
      // Play continues forward from wherever the timeline sits — a future
      // scrub included; the loop crosses "now" on its own.
      U.el('radar-play').textContent = global.Radar.toggle() ? 'Pause' : 'Play';
    });

    U.el('radar-opacity').addEventListener('input', function (e) {
      global.Radar.setOpacity(e.target.value / 100);
    });

    U.el('radar-expand').addEventListener('click', toggleExpand);

    U.el('radar-source').addEventListener('change', function (e) {
      if (e.target.value === 'site') {
        pickNearestSite();
      } else {
        global.Radar.setSource(e.target.value);
        global.Radar.drawRangeRing();
      }
      // A new source is a new freshness signal; re-prime rather than compare
      // a mosaic valid-time against a station scan-time.
      if (state.liveRadar) state.liveRadar.reset();
      syncRadarControls();
    });

    U.el('radar-product').addEventListener('change', function (e) {
      global.Radar.setProduct(e.target.value);
      syncRadarControls();
    });

    U.el('site-btn').addEventListener('click', toggleSitePanel);
    U.el('site-close').addEventListener('click', function () {
      U.el('site-panel').hidden = true;
      U.el('site-btn').setAttribute('aria-expanded', 'false');
    });
    U.el('radar-opts-btn').addEventListener('click', toggleRadarOpts);
    U.el('radar-opts-done').addEventListener('click', closeRadarOpts);
    U.el('site-search').addEventListener('input', refreshSitePanel);
    U.el('site-active-only').addEventListener('change', refreshSitePanel);

    /* One timeline, past through future: positions below the observed
     * frame count scrub what fell; each stop past them is one HRRR lead —
     * simulated reflectivity, the model that actually looks like radar. */
    /* The Forecast regime's model row: HRRR carries the map (the only
     * agency whose output is published as radar imagery, keyless); the
     * global agencies are one tap away as full synoptic charts, which is
     * where a GFS or Euro forecast can be shown without lying about
     * looking like radar. */
    (function () {
      var row = U.el('fc-models');
      var hr = U.make('button', 'mc-chip on', 'HRRR · on the map');
      hr.disabled = true;
      row.appendChild(hr);
      C.CHART_MODELS.forEach(function (mdl) {
        if (mdl.id === 'ncep_hrrr_conus') return;
        var b = U.make('button', 'mc-chip', mdl.short);
        b.title = mdl.name + ' — opens in Model charts';
        b.addEventListener('click', function () {
          loadModelChart(mdl.id);
          setTab('outlook');
          setTimeout(function () {
            var card = U.el('mchart-card');
            if (card && !card.hidden) card.scrollIntoView({ behavior: 'smooth', block: 'start' });
          }, 350);
        });
        row.appendChild(b);
      });
    })();

    U.el('mode-history').addEventListener('click', function () { setRadarMode('history'); });
    U.el('mode-live').addEventListener('click', function () { setRadarMode('live'); });
    U.el('mode-forecast').addEventListener('click', function () { setRadarMode('forecast'); });
    U.el('history-when').addEventListener('change', applyHistory);

    U.el('radar-frame').addEventListener('input', function (e) {
      global.Radar.pause();
      var v = parseInt(e.target.value, 10);
      /* The track is scoped to the regime the thumb is in — History, Live
       * and Forecast each own its full width. The unified 102-stop track
       * crammed the observed hour into its first tenth; the field report
       * was "the scroll bar is tiny and doesn't move a lot". */
      if (state.radarFuture) {
        enterFuture(C.HRRR_LEADS[Math.max(0, Math.min(v, C.HRRR_LEADS.length - 1))]);
      } else {
        global.Radar.goto(v);
      }
      U.el('radar-play').textContent = 'Play';
    });

    U.el('layer-wind').addEventListener('click', function () { toggleLayer('wind'); });
    U.el('layer-temp').addEventListener('click', function () { toggleLayer('temp'); });
    U.el('layer-cape').addEventListener('click', function () { toggleLayer('cape'); });
    // Vane's own storm model: offered only when a shippable model loaded.
    var SO = global.StormOdds && global.StormOdds.weights();
    U.el('layer-odds').hidden = !(SO && SO.ship);
    U.el('layer-odds').addEventListener('click', function () { toggleLayer('odds'); });
    // Every re-sample (pan, 15-minute refresh, return to the app) re-states
    // the legend's valid time and stable-air note.
    global.Layers.onUpdate(function () { renderFieldLegend(global.Layers.active()); });

    /* ── Layer chips: everything on the map, switchable in one place ── */

    U.el('chip-warnings').addEventListener('click', function () {
      var on = !global.Settings.get('showWarnings');
      global.Settings.save({ showWarnings: on });
      global.Radar.setWarningsVisible(on);
      syncLayerChips();
    });
    U.el('chip-cells').addEventListener('click', function () {
      state.cellsOnMap = !state.cellsOnMap;
      U.el('cells-on-map').checked = state.cellsOnMap;
      refreshCells();
      syncLayerChips();
    });
    U.el('chip-spc').addEventListener('click', function () {
      var on = !global.Settings.get('showSpc');
      global.Settings.save({ showSpc: on });
      global.SPC.state.visible = on;
      if (state.mapReady) global.SPC.draw(global.Radar.getMap());
      syncLayerChips();
    });
    // Non-weather echoes (js/radar.js): on by default; off is the raw mosaic.
    U.el('chip-clean').addEventListener('click', function () {
      var on = global.Settings.get('radarClean') === false;
      global.Settings.save({ radarClean: on });
      global.Radar.setClean(on);
      syncLayerChips();
    });
    U.el('chip-reports').addEventListener('click', function () {
      var on = !reportsOn(), patch = {};
      patch[reportsKey()] = on;
      global.Settings.save(patch);
      global.SPC.state.reportsVisible = on;
      if (on && !global.SPC.state.reports.length) loadReports();
      else if (state.mapReady) { global.SPC.drawReports(global.Radar.getMap()); renderReportFilters(); }
      syncLayerChips();
    });

    wireModelChart();

    Array.prototype.forEach.call(document.querySelectorAll('.mg-range'), function (b) {
      b.addEventListener('click', function () {
        state.mgHours = parseInt(b.dataset.hours, 10);
        Array.prototype.forEach.call(document.querySelectorAll('.mg-range'), function (o) {
          o.classList.toggle('on', o === b);
        });
        UI.renderMeteogram(state);
      });
    });

    U.el('cv-prev').addEventListener('click', function () { stepHour(-1); });
    U.el('cv-next').addEventListener('click', function () { stepHour(1); });

    U.el('help-close').addEventListener('click', function () { U.el('help').hidden = true; });

    U.el('cells-on-map').addEventListener('change', function (e) {
      state.cellsOnMap = e.target.checked;
      refreshCells();
    });

    U.el('spc-day').addEventListener('change', loadSpc);
    U.el('spc-hazard').addEventListener('change', loadSpc);

    /* Phone tabs. Purely presentational — the cards are all rendered as
     * before and CSS decides which are on screen — so nothing downstream has
     * to know whether it is visible. */
    Array.prototype.forEach.call(document.querySelectorAll('.tabbar button'), function (b) {
      b.addEventListener('click', function () { setTab(b.dataset.tab); });
    });
    setTab(state.tab);

    U.el('pair-btn').addEventListener('click', togglePair);
    U.el('pair-product').addEventListener('change', function () {
      global.Radar.setPairProduct(this.value);
      updatePairNote();
    });

    Array.prototype.forEach.call(document.querySelectorAll('.view-switch button'), function (b) {
      b.addEventListener('click', function () {
        state.shotView = b.dataset.view;
        Array.prototype.forEach.call(document.querySelectorAll('.view-switch button'), function (o) {
          var on = o === b;
          o.classList.toggle('on', on);
          o.setAttribute('aria-selected', String(on));
        });
        UI.renderShot(state);
      });
    });

    Array.prototype.forEach.call(document.querySelectorAll('#shot-3d-controls button'), function (b) {
      b.addEventListener('click', function () {
        if (global.Storm3D) global.Storm3D.orbit(parseFloat(b.dataset.orbit || 0), parseFloat(b.dataset.tilt || 0));
        UI.renderShot(state);
      });
    });


    wireInstall();
    U.el('settings-btn').addEventListener('click', openSettings);
    U.el('settings-close').addEventListener('click', function () {
      U.el('settings').hidden = true;
    });
  }

  /* Dual pane needs a single radar to pair against: the national mosaic has no
   * velocity equivalent, so opening it from the mosaic switches to the nearest
   * useful site rather than showing an empty second map. */
  /* "Look at this on the radar" has to work from any tab. Scrolling to a card
   * that CSS has hidden is a no-op that reads as a dead button. */
  function showRadar() {
    setTab('radar');
    U.el('radar-card').scrollIntoView({ behavior: 'smooth', block: 'center' });
    global.Radar.invalidate();
  }

  function setTab(tab) {
    state.tab = tab;
    document.body.dataset.mtab = tab;
    // Chase and Outlook bring their own code on first entry (js/lazy.js).
    if (tab === 'chase' || tab === 'outlook') {
      global.Lazy.need(tab).catch(function () {
        UI.status('This tab could not load — check your connection and try again.', 'warn');
      });
    }
    // A scan that arrived while the radar was off screen applies on entry.
    if (tab === 'radar' && pendingRadarFresh) applyRadarFresh(pendingRadarFresh);
    /* The chart's lattice is fetched here, on entering Outlook, and never
     * at boot: it is the app's heaviest request set, and paying for it
     * before the user asks starved rate-limited boot data. load() dedupes
     * against its own in-flight and 30-minute-fresh state, so re-entering
     * the tab is free, and a failed attempt heals on the next visit. */
    if (tab === 'outlook') loadModelChart();
    Array.prototype.forEach.call(document.querySelectorAll('.tabbar button'), function (b) {
      var on = b.dataset.tab === tab;
      b.classList.toggle('on', on);
      b.setAttribute('aria-selected', String(on));
    });
    // Leaflet renders nothing into a container that was display:none when it
    // was created, so the map has to be told its size the moment it appears.
    if (tab === 'radar') global.Radar.invalidate();
    if (tab === 'chase' && state.shotCell) UI.renderShot(state);
    global.scrollTo({ top: 0, behavior: 'auto' });
  }

  function togglePair() {
    if (state.pairOpen) {
      global.Radar.closePair();
      state.pairOpen = false;
      U.el('pane-b').hidden = true;
      U.el('pair-btn').classList.remove('on');
      global.Radar.invalidate();
      return;
    }
    var start = Promise.resolve();
    if (global.Radar.getSource() !== 'site') {
      start = global.Sites.load().then(function () {
        var best = global.Sites.bestFor(state.location.lat, state.location.lon);
        if (best) {
          global.Radar.setSite(best, 'N0Q');
          syncRadarControls();
        }
      });
    }
    start.then(function () {
      // Both panes are single-site products from one radar. With no site
      // resolved there is nothing to pair against, and opening an empty second
      // map beside a full one reads as a broken feed rather than as a missing
      // prerequisite.
      if (!global.Radar.getSite()) {
        UI.status('Dual pane needs a single radar, and no station list is available ' +
          'for this location. Pick one with the Radar site button.', 'warn');
        return;
      }
      U.el('pane-b').hidden = false;
      state.pairOpen = true;
      U.el('pair-btn').classList.add('on');
      global.Radar.openPair('map2', U.el('pair-product').value);
      global.Radar.invalidate();
      updatePairNote();
    });
  }

  function updatePairNote() {
    var site = global.Radar.getSite();
    var p = U.el('pair-product').value;
    U.el('pair-note').textContent = (site ? site.id : '—') + ' · ' +
      (p === 'N0S' ? 'storm motion removed' : p === 'N0U' ? 'green toward, red away' : 'super-resolution');
  }

  /* ── Install ────────────────────────────────────────────────────────── */

  function refreshInstall() {
    var I = global.Install;
    var banner = U.el('install-banner');
    var st = I.status();

    var show = I.shouldOfferBanner();
    banner.hidden = !show;
    if (!show) return;

    U.el('install-title').textContent = st.state === 'ios'
      ? 'Add Vane to your home screen'
      : 'Install Vane';
    U.el('install-note').textContent = st.note || '';
    U.el('install-go').hidden = !st.can;
  }

  function wireInstall() {
    var I = global.Install;
    U.el('install-go').addEventListener('click', function () {
      I.install().then(function (outcome) {
        if (outcome === 'accepted') UI.status('Vane installed. Open it from your home screen.', 'info');
        refreshInstall();
      });
    });
    U.el('install-dismiss').addEventListener('click', function () {
      I.dismiss();
      refreshInstall();
    });
    // The event can arrive after boot, so the banner reacts rather than being
    // decided once.
    I.onChange(refreshInstall);
    refreshInstall();
  }

  /* Deep links from the manifest's shortcuts: ?mode=chase&tab=radar. Applied
   * once at boot, then stripped so a refresh does not keep forcing them. */
  function applyLaunchParams() {
    var q = new URLSearchParams(location.search);
    var mode = q.get('mode'), tab = q.get('tab');
    if (mode === 'chase' || mode === 'simple') state.mode = mode;
    if (['now', 'radar', 'chase', 'outlook'].indexOf(tab) !== -1) state.tab = tab;
    if ((mode || tab) && global.history && history.replaceState) {
      history.replaceState({}, '', location.pathname);
    }
  }

  function openSettings() {
    UI.renderSettings(function (key) {
      var S = global.SPC;
      if (key === 'filters') { applyAlerts(); return; }
      if (key === 'hour12') { state.hour12 = global.Settings.get('hour12'); renderCore(); return; }
      if (key === 'showSpc') {
        S.state.visible = global.Settings.get('showSpc');
        S.draw(global.Radar.getMap());
        return;
      }
      if (key === 'skyMotion') { applyTheme(); return; }
      if (key === 'showReports' || key === 'showReportsSimple') {
        S.state.reportsVisible = reportsOn();
        if (S.state.reportsVisible && !S.state.reports.length) loadReports();
        else { S.drawReports(global.Radar.getMap()); renderReportFilters(); }
      }
    });
    U.el('settings').hidden = false;
  }

  /* ── Radar sites ────────────────────────────────────────────────────── */

  function syncRadarControls() {
    var src = global.Radar.getSource();
    // HRRR covers the lower 48; the global source has no future half.
    if (src === 'global') exitFuture();
    U.el('radar-source').value = src;

    var sel = U.el('radar-product');
    sel.hidden = src !== 'site';
    if (src === 'site' && !sel.options.length) {
      C.RADAR_PRODUCTS.forEach(function (p) {
        var o = document.createElement('option');
        o.value = p.id;
        o.textContent = p.label;
        o.title = p.note;
        sel.appendChild(o);
      });
    }
    if (src === 'site') sel.value = global.Radar.getProduct();

    /* The button says what you are looking at, not what pressing it does.
     * "Radar site" answered a question nobody had; "KDMX" and "National
     * mosaic" answer the one everybody has. */
    var site = global.Radar.getSite();
    U.el('site-btn').textContent = src === 'site'
      ? (site ? site.id + (site.name ? ' · ' + site.name : '') : 'Pick a radar')
      : src === 'global' ? 'Global' : 'National mosaic';


    // A single scan cannot be animated; don't offer a play button that lies.
    var play = U.el('radar-play');
    play.disabled = src === 'site';
    play.textContent = src === 'site' ? 'Latest scan'
      : (global.Radar.isPlaying() ? 'Pause' : 'Play');

    renderRadarLegend();
  }

  function toggleSitePanel() {
    var panel = U.el('site-panel');
    var showing = panel.hidden;
    panel.hidden = !showing;
    U.el('site-btn').setAttribute('aria-expanded', String(showing));
    if (showing) {
      // Only one panel at a time: two open sheets push the map off screen.
      closeRadarOpts();
      refreshSitePanel();
      U.el('site-search').focus();
    }
  }

  function closeRadarOpts() {
    U.el('radar-opts').hidden = true;
    U.el('radar-opts-btn').setAttribute('aria-expanded', 'false');
    U.el('radar-opts-btn').classList.remove('on');
  }

  function toggleRadarOpts() {
    var panel = U.el('radar-opts');
    var showing = panel.hidden;
    panel.hidden = !showing;
    U.el('radar-opts-btn').setAttribute('aria-expanded', String(showing));
    U.el('radar-opts-btn').classList.toggle('on', showing);
    if (showing) {
      U.el('site-panel').hidden = true;
      U.el('site-btn').setAttribute('aria-expanded', 'false');
    }
    global.Radar.invalidate();
  }

  /* One pick handler for every way a radar can be chosen — the panel list,
   * and the dots on the map itself. */
  function pickSite(s) {
    global.Radar.setSite(s);
    U.el('site-panel').hidden = true;
    U.el('site-btn').setAttribute('aria-expanded', 'false');
    if (state.liveRadar) state.liveRadar.reset();
    syncRadarControls();
    if (state.mode === 'chase') refreshCells();
  }

  function refreshSitePanel() {
    UI.renderSites(state, U.el('site-search').value, pickSite);
  }

  function loadSites() {
    return global.Sites.load().then(function () {
      if (!U.el('site-panel').hidden) refreshSitePanel();
      // Freshly loaded statuses recolour the dots on the map too.
      global.Radar.drawSiteMarkers();
    });
  }

  function pickNearestSite() {
    var best = global.Sites.bestFor(state.location.lat, state.location.lon);
    if (!best) {
      UI.status('No radar site list available yet — try again in a moment.', 'warn');
      U.el('radar-source').value = global.Radar.getSource();
      return;
    }
    global.Radar.setSite(best);
  }

  /* ── Map field layers ───────────────────────────────────────────────── */

  function toggleLayer(kind) {
    // Falls through to the original body; the chips resync after it runs.
    setTimeout(syncLayerChips, 0);
    if (!state.mapReady) {
      UI.status('The map is unavailable, so field layers cannot be drawn.', 'warn');
      return;
    }
    // The three fields share one canvas, so they are exclusive.
    var btn = U.el('layer-' + kind);
    btn.textContent = '';
    btn.appendChild(U.make('span', 'layer-dot'));
    btn.appendChild(document.createTextNode(' …'));

    global.Layers.toggle(kind, global.Radar.getMap(), {
      reduceMotion: global.Settings.reduceMotion(),
      capeKind: global.Settings.get('capeKind')
    }).then(function (on) {
      FIELD_KINDS.forEach(function (k) {
        setLayerButton(U.el('layer-' + k), k, k === kind && on);
      });
      renderFieldLegend(on ? kind : null);
      // A layer that could not load says so, instead of quietly switching off.
      if (!on && global.Layers.state.failed) {
        UI.status('The ' + FIELD_LABELS[kind] + ' layer could not load the model grid — offline, ' +
          'or the data service is busy. Try it again in a minute.', 'warn');
      }
    });
  }

  var FIELD_KINDS = ['wind', 'temp', 'cape', 'odds'];
  var FIELD_LABELS = { wind: 'Wind', temp: 'Temp', cape: 'CAPE', odds: 'Storm odds' };

  function setLayerButton(btn, kind, on) {
    U.clear(btn);
    btn.appendChild(U.make('span', 'layer-dot'));
    btn.appendChild(document.createTextNode(FIELD_LABELS[kind]));
    if (kind === 'odds') btn.appendChild(aiChip());
    btn.classList.toggle('on', !!on);
  }

  // The one mark every AI/ML output in Vane carries.
  function aiChip() {
    var c = U.make('span', 'ai-chip', 'AI');
    c.setAttribute('aria-label', 'AI');
    return c;
  }

  /* The 3 km HRRR CAPE legend: the server's palette, which parcel, which
   * run and hour, and a one-tap choice of parcel. */
  function renderHrrrCapeLegend(box, L, info) {
    box.appendChild(U.make('span', null, String(L.CAPE_RANGE[0])));
    var ramp = U.make('span', 'field-ramp');
    ramp.style.background = 'linear-gradient(90deg,' + L.CAPE_SPECTRAL.join(',') + ')';
    box.appendChild(ramp);
    box.appendChild(U.make('span', null, L.CAPE_RANGE[1] + '+ J/kg'));
    var kinds = U.make('span', 'cape-kinds');
    kinds.setAttribute('role', 'group');
    kinds.setAttribute('aria-label', 'Which CAPE');
    L.CAPE_ORDER.forEach(function (k) {
      var b = U.make('button', 'cape-kind', L.CAPE_KINDS[k].label);
      b.type = 'button';
      b.setAttribute('data-kind', k);
      b.setAttribute('aria-pressed', String(k === info.kind));
      b.addEventListener('click', function () {
        global.Settings.save({ capeKind: k });
        L.setCapeKind(k);
        renderFieldLegend('cape');
      });
      kinds.appendChild(b);
    });
    box.appendChild(kinds);
    var kind = L.CAPE_KINDS[info.kind];
    box.appendChild(U.make('span', 'muted',
      '· ' + kind.label + ' CAPE from the HRRR model at 3 km, ' + info.run.slice(-4, -2) + 'Z run, valid ' +
      localClock(info.validAt) + ', checked every 15 min. ' + kind.help +
      ' Fuel for storms, not storms: without lift and shear, high CAPE does nothing. Clear below ' +
      L.CAPE_RANGE[0] + ' J/kg.'));
  }

  /* Storm Odds on the map: Vane's own model, so the legend leads with the
   * AI mark, says exactly what the number is, steps through the next nine
   * hours, and carries the model's held-out record. */
  /* A moment on the forecast location's clock — or, before the forecast
   * has loaded, on the device's own rather than UTC's. */
  function localClock(ms) {
    return state.data ? U.fmtEpoch(ms, state.data.utc_offset_seconds, state.hour12)
      : U.fmtTime(new Date(ms), state.hour12);
  }

  function renderOddsLegend(box) {
    var L = global.Layers, W = global.StormOdds.weights(), E = W.eval;
    box.appendChild(aiChip());
    box.appendChild(U.make('span', null, '½%'));
    var ramp = U.make('span', 'field-ramp');
    var lo = Math.log(L.ODDS_STOPS[0][0]), hi = Math.log(L.ODDS_STOPS[L.ODDS_STOPS.length - 1][0]);
    ramp.style.background = 'linear-gradient(90deg,' + L.ODDS_STOPS.map(function (st) {
      return 'rgb(' + st[1].join(',') + ') ' + Math.round((Math.log(st[0]) - lo) / (hi - lo) * 100) + '%';
    }).join(',') + ')';
    box.appendChild(ramp);
    box.appendChild(U.make('span', null, Math.round(L.ODDS_STOPS[L.ODDS_STOPS.length - 1][0] * 100) + '%+'));
    var leads = U.make('span', 'cape-kinds');
    leads.setAttribute('role', 'group');
    leads.setAttribute('aria-label', 'Hours ahead');
    [0, 3, 6, 9].forEach(function (h) {
      var b = U.make('button', 'cape-kind', h ? '+' + h + ' h' : 'Now');
      b.type = 'button';
      b.setAttribute('data-lead', String(h));
      b.setAttribute('aria-pressed', String((L.state.oddsLead || 0) === h));
      b.addEventListener('click', function () { L.setOddsLead(h); renderFieldLegend('odds'); });
      leads.appendChild(b);
    });
    box.appendChild(leads);
    var t = L.state.oddsTimes[L.state.oddsIdx];
    var peak = L.maxInView('odds');
    if (L.state.oddsOutside) {
      box.appendChild(U.make('span', 'field-stable',
        peak === null ? 'Nothing to draw here: Storm odds cover the lower 48 US states, where the model was trained.'
          : 'Drawn over the US only — the model learned US weather against US storm reports.'));
    }
    if (peak !== null) {
      box.appendChild(U.make('span', 'field-stable',
        'Highest in view: ' + fmtOdds(peak) + (peak < 0.005 ? ' — nowhere here looks primed for severe storms.' : '.')));
    }
    box.appendChild(U.make('span', 'muted',
      '· Vane Storm Odds — Vane\u2019s own AI model: the chance of a severe storm report (tornado, 1\u2033 hail, ' +
      '58 mph gust or wind damage) within ' + W.radiusKm + ' km in the ' + W.windowHours + ' hours from ' +
      (t ? localClock(t) : 'now') + ', from the forecast environment on a ' +
      L.state.grid.length + '-point grid. Trained on ' + E.analyses + ' hours of NOAA HRRR analyses and every ' +
      'NWS report in them; on ' + E.heldOutDays + ' days it never saw it out-ranked CAPE \u00d7 shear (AUC ' +
      E.auc.toFixed(2) + ' vs ' + E.aucWmaxshear.toFixed(2) + '; ' + E.unstable.auc.toFixed(2) + ' vs ' +
      E.unstable.aucWmaxshear.toFixed(2) + ' where CAPE \u2265 500). It reads the environment, not radar: ' +
      'it cannot see whether storms actually fire. Not a warning \u2014 follow the NWS.'));
  }

  function fmtOdds(p) {
    return p < 0.005 ? 'under ½%' : p < 0.01 ? (Math.round(p * 1000) / 10) + '%' : Math.round(p * 100) + '%';
  }

  function renderFieldLegend(kind) {
    var box = U.el('field-legend');
    U.clear(box);
    if (!kind) { box.hidden = true; return; }
    box.hidden = false;
    var L0 = global.Layers;
    // When the values are for, so a field left on screen is visibly current.
    // On the forecast location's clock, the same one the radar loop reads.
    var when = L0.state.validAt
      ? ' · valid ' + (state.data ? U.fmtEpoch(L0.state.validAt, state.data.utc_offset_seconds, state.hour12)
        : U.fmtTime(new Date(L0.state.validAt), state.hour12)) + ', refreshed every 15 min'
      : '';
    var pts = L0.state.grid.length || 42;

    if (kind === 'temp') {
      box.appendChild(U.make('span', null, state.imperial ? '-20°F' : '-30°C'));
      var ramp = U.make('span', 'field-ramp');
      var stops = [];
      for (var t = -30; t <= 48; t += 6) {
        var c = global.Layers.tempColor(t);
        stops.push('rgb(' + c[0] + ',' + c[1] + ',' + c[2] + ') ' +
          Math.round((t + 30) / 78 * 100) + '%');
      }
      ramp.style.background = 'linear-gradient(90deg,' + stops.join(',') + ')';
      box.appendChild(ramp);
      box.appendChild(U.make('span', null, state.imperial ? '118°F' : '48°C'));
      box.appendChild(U.make('span', 'muted',
        '· surface temperature, interpolated from a ' + pts + '-point model grid' + when));
    } else if (kind === 'odds') {
      renderOddsLegend(box);
    } else if (kind === 'cape') {
      var L = global.Layers, info = L.capeInfo();
      if (info.source === 'hrrr') {
        renderHrrrCapeLegend(box, L, info);
        return;
      }
      box.appendChild(U.make('span', null, L.CAPE_MIN));
      var cramp = U.make('span', 'field-ramp');
      var top = L.CAPE_STOPS[L.CAPE_STOPS.length - 1][0];
      cramp.style.background = 'linear-gradient(90deg,' + L.CAPE_STOPS.map(function (st) {
        var c = st[1];
        return 'rgb(' + c[0] + ',' + c[1] + ',' + c[2] + ') ' +
          Math.round((st[0] - L.CAPE_MIN) / (top - L.CAPE_MIN) * 100) + '%';
      }).join(',') + ')';
      box.appendChild(cramp);
      box.appendChild(U.make('span', null, top + '+ J/kg'));
      // CAPE is fuel, not storms; the legend says so rather than let a red
      // patch read as a warning.
      var peak = L.maxInView('cape');
      if (L.state.failed && L.uncovered()) {
        // The last fetch failed and the old grid does not reach this view.
        box.appendChild(U.make('span', 'field-stable field-failed',
          'Could not load CAPE for this part of the map — offline, or the data service is busy. ' +
          'Retrying every minute.'));
      } else if (peak !== null && peak < L.CAPE_MIN) {
        // Nothing drawn is an answer, not a fault — say so.
        box.appendChild(U.make('span', 'field-stable',
          'No CAPE above ' + L.CAPE_MIN + ' J/kg anywhere in view right now (peak ' +
          Math.round(peak) + ') — the air here is stable.'));
      }
      // Which CAPE this is, and why not the 3 km field.
      var why = info.inCoverage
        ? 'The 3 km HRRR field is unavailable right now (Unidata\u2019s server did not answer), so this is '
        : 'Outside the HRRR\u2019s US coverage, so this is ';
      box.appendChild(U.make('span', 'muted',
        '· ' + why + 'CAPE sampled from the model on a coarse ' + pts + '-point grid' + when +
        '. Fuel for storms, not storms: without lift and shear, high CAPE does nothing. Fades out below ' +
        L.CAPE_MIN + ' J/kg'));
    } else {
      box.appendChild(U.make('span', null, 'calm'));
      var wramp = U.make('span', 'field-ramp');
      wramp.style.background =
        'linear-gradient(90deg, rgba(255,255,255,.5), rgba(120,220,200,.8), ' +
        'rgba(255,214,10,.9), rgba(255,55,95,1))';
      box.appendChild(wramp);
      box.appendChild(U.make('span', null, 'gale'));
      box.appendChild(U.make('span', 'muted',
        '· 10 m wind, animated along the flow' + when));
    }
  }

  function stepHour(delta) {
    state.hourOffset = U.clamp(state.hourOffset + delta, 0, 23);
    computeConvective();
    UI.renderParams(state);
    UI.renderHodograph(state);
    UI.renderProfile(state);
  }

  /* Reference panels — the hodograph, the level-by-level table, the rest of
   * the parameter grid — fold on a phone and stand open on a desktop, where
   * the card sits half-width and costs nothing to leave open.
   *
   * This has to be JavaScript. A closed <details> hides its body with
   * `content-visibility`, which no stylesheet declaration on the children
   * overrides, so the only way to open one is the `open` attribute.
   *
   * A panel the user has touched stops following the viewport. Someone who
   * folded the wind profile away on a phone did that on purpose, and having
   * it spring back open on the next rotation is the app arguing with them. */
  function applyFolds() {
    var wide = matchMedia('(min-width: 721px)').matches;
    Array.prototype.forEach.call(document.querySelectorAll('.phone-fold'), function (d) {
      if (d.dataset.userSet !== '1') d.open = wide;
    });
  }

  function wireFolds() {
    Array.prototype.forEach.call(document.querySelectorAll('.phone-fold > summary'), function (s) {
      s.addEventListener('click', function () { s.parentNode.dataset.userSet = '1'; });
    });
    applyFolds();
    var mq = matchMedia('(min-width: 721px)');
    // Safari before 14 has no addEventListener on MediaQueryList.
    if (mq.addEventListener) mq.addEventListener('change', applyFolds);
    else if (mq.addListener) mq.addListener(applyFolds);
  }

  /* ── Future radar: HRRR simulated reflectivity ────────────────────────
   * Scrubbed right of the newest frame, the timeline keeps going on the
   * one model that genuinely looks like radar. HRRR covers the lower 48
   * only, so the future half exists only on the CONUS sources. */

  var hrrrRun = { init: 0, fetchedAt: 0 };

  function futureStops() {
    if (state.radarHistory) return 0;   // the archive ends where it ends
    return global.Radar.getSource() === 'global' ? 0 : C.HRRR_LEADS.length;
  }

  function fmtLead(minute) {
    if (minute % 60 === 0) return '+' + (minute / 60) + 'h';
    if (minute < 60) return '+' + minute + ' min';
    return '+' + Math.floor(minute / 60) + 'h' + ('0' + (minute % 60)).slice(-2);
  }

  /* ── History · Live · Forecast ────────────────────────────────────────
   * The segment names the regime the thumb is in; selecting one moves the
   * timeline there. It is derived state, recomputed from what the map is
   * actually showing, so it can never disagree with the pixels. */

  function syncRadarMode() {
    var m = state.radarHistory ? 'history' : (state.radarFuture ? 'forecast' : 'live');
    ['history', 'live', 'forecast'].forEach(function (k) {
      var b = U.el('mode-' + k);
      b.classList.toggle('on', k === m);
      b.setAttribute('aria-selected', String(k === m));
    });
    U.el('mode-forecast').disabled = !state.radarHistory && !futureStops();
    U.el('history-bar').hidden = m !== 'history';
    U.el('forecast-bar').hidden = m !== 'forecast';
  }

  function setRadarMode(mode) {
    global.Radar.pause();
    U.el('radar-play').textContent = 'Play';
    if (mode === 'history') {
      var inp = U.el('history-when');
      if (!inp.value) {
        // Default to this hour yesterday, in the picker's local clock.
        var d = new Date(Date.now() - 86400000);
        var p = function (n) { return (n < 10 ? '0' : '') + n; };
        inp.value = d.getFullYear() + '-' + p(d.getMonth() + 1) + '-' + p(d.getDate()) +
          'T' + p(d.getHours()) + ':00';
      }
      applyHistory();
      return;
    }
    exitHistory();
    if (mode === 'forecast') {
      enterFuture(C.HRRR_LEADS[0]);
    } else {
      exitFuture();
      var last = (state.radarObsTotal || 1) - 1;
      U.el('radar-frame').value = String(last);
      global.Radar.goto(last);
    }
    syncRadarMode();
  }

  function applyHistory() {
    var inp = U.el('history-when');
    if (!inp.value) return;
    var t = new Date(inp.value).getTime();            // datetime-local is local
    if (!isFinite(t)) return;
    t = Math.min(t, Date.now());
    exitFuture();
    state.radarHistory = t;
    global.Radar.setHistory(t);
    syncRadarControls();
    syncRadarMode();
  }

  /* "Radar at this time", from a storm report's popup: the loop jumps to
   * the scan nearest the report. A report inside the live hour is shown in
   * the live loop; an older one opens the archived hour around it — ending
   * fifteen minutes after, so the storm that produced it is seen arriving
   * and leaving. The popup stays open, pinned to the spot. */
  function radarAt(t) {
    if (!state.mapReady || !isFinite(t)) return;
    global.Radar.pause();
    U.el('radar-play').textContent = 'Play';
    exitFuture();
    var near = global.Radar.frameNear(t);
    if ((!near || near.gapMs > 5 * 60000) && state.radarHistory) {
      exitHistory();                              // perhaps the live hour has it
      near = global.Radar.frameNear(t);
    }
    if (!near || near.gapMs > 5 * 60000) {
      var d = new Date(Math.min(t + 15 * 60000, Date.now()));
      var p = function (n) { return (n < 10 ? '0' : '') + n; };
      U.el('history-when').value = d.getFullYear() + '-' + p(d.getMonth() + 1) + '-' + p(d.getDate()) +
        'T' + p(d.getHours()) + ':' + p(d.getMinutes());
      applyHistory();
      near = global.Radar.frameNear(t);
    }
    if (near) global.Radar.goto(near.index);
    syncRadarMode();
  }

  function exitHistory() {
    if (!state.radarHistory) return;
    state.radarHistory = 0;
    global.Radar.setHistory(null);
  }

  var futureSettle = null;

  function enterFuture(minute) {
    exitHistory();
    state.radarFuture = minute;
    var slider = U.el('radar-frame');
    slider.max = String(C.HRRR_LEADS.length - 1);
    slider.value = String(Math.max(0, C.HRRR_LEADS.indexOf(minute)));
    slider.style.setProperty('--split', '0%');
    syncRadarMode();
    var kind = U.el('radar-kind');
    kind.textContent = 'forecast';
    kind.className = 'tag tag-forecast';
    updateFutureBadge();
    /* A thumb dragged across ninety stops fires input per pixel. The badge
     * and clock track every position; the imagery loads only where the
     * thumb settles, so a fast drag costs one lead's tiles, not ninety. */
    if (futureSettle) clearTimeout(futureSettle);
    futureSettle = setTimeout(function () {
      futureSettle = null;
      if (state.radarFuture) global.Radar.showFuture(state.radarFuture);
    }, 160);
    if (Date.now() - hrrrRun.fetchedAt > 15 * 60 * 1000) {
      global.API.hrrrMeta().then(function (m) {
        hrrrRun.init = m.init;
        hrrrRun.fetchedAt = Date.now();
        if (state.radarFuture) updateFutureBadge();
      }).catch(function () { /* the badge shows the lead without a clock */ });
    }
  }

  function exitFuture() {
    if (futureSettle) { clearTimeout(futureSettle); futureSettle = null; }
    if (!state.radarFuture) return;
    state.radarFuture = 0;
    global.Radar.clearFuture();
    U.el('fr-badge').hidden = true;
    syncRadarMode();
  }

  function updateFutureBadge() {
    var badge = U.el('fr-badge');
    var minute = state.radarFuture;
    if (!minute) { badge.hidden = true; return; }
    if (global.StormSignal) global.StormSignal.showFrame({forecast:true, time:hrrrRun.init ? (hrrrRun.init + minute * 60000)/1000 : null});
    var when = '';
    if (hrrrRun.init) {
      var epoch = hrrrRun.init + minute * 60000;
      when = ' · ' + U.fmtEpoch(epoch, state.data ? state.data.utc_offset_seconds : 0, state.hour12);
      U.el('radar-time').textContent = U.fmtEpoch(epoch,
        state.data ? state.data.utc_offset_seconds : 0, state.hour12);
    } else {
      U.el('radar-time').textContent = fmtLead(minute);
    }
    badge.hidden = false;
    badge.textContent = '';
    badge.appendChild(document.createTextNode('HRRR ' + fmtLead(minute) + when + ' · '));
    badge.appendChild(U.make('span', 'fr-badge-note', 'simulated reflectivity — forecast'));
  }

  /* ── Model charts: the classic synoptic frame ─────────────────────────
   * Chart data is CONUS-wide, so it loads once per agency, not per
   * location; the card renders as soon as the first load lands. */

  var mchartModel = 'gfs_seamless';

  function loadModelChart(id) {
    if (id) mchartModel = id;
    // The chart's code arrives with the Outlook tab (js/lazy.js).
    global.Lazy.need('outlook').then(function () {
      return global.ModelChart.load(mchartModel);
    }).then(function (ok) {
      var card = U.el('mchart-card');
      if (!ok) {
        if (!global.ModelChart.state.rows.length) {
          card.hidden = true;
          UI.status('Model chart delayed — the data service is rate-limiting. It retries when you reopen Outlook.', 'warn');
        }
        return;
      }
      card.hidden = false;
      var slider = U.el('mchart-hour');
      slider.max = String(Math.max(1, global.ModelChart.state.horizon - 1));
      if (+slider.value > +slider.max) slider.value = slider.max;
      renderModelChart();
    }).catch(function () {
      UI.status('Outlook charts could not load — check your connection and reopen Outlook.', 'warn');
    });
  }

  function renderModelChart() {
    if (!global.ModelChart) return;
    var hour = parseInt(U.el('mchart-hour').value, 10) || 6;
    if (!global.ModelChart.render(U.el('mchart-canvas'), hour)) return;
    hour = global.ModelChart.state.hour;
    var iso = global.ModelChart.state.times[hour];
    var short = mchartModel;
    C.CHART_MODELS.forEach(function (m) { if (m.id === mchartModel) short = m.short; });
    var when = iso ? U.fmtEpoch(U.epochOf(iso, 0),
      state.data ? state.data.utc_offset_seconds : 0, state.hour12) : '';
    var day = iso ? U.parseLocal(iso.replace('T', ' ').slice(0, 10)) : null;
    U.el('mchart-title').textContent = short + ' · +' + hour + 'h · valid ' +
      (day ? day.toLocaleDateString(undefined, { weekday: 'short' }) + ' ' : '') + when;
    Array.prototype.forEach.call(document.querySelectorAll('#mchart-chips .mc-chip'),
      function (b) { b.classList.toggle('on', b.dataset.model === mchartModel); });
  }

  function wireModelChart() {
    var chips = U.el('mchart-chips');
    C.CHART_MODELS.forEach(function (m) {
      var b = U.make('button', 'mc-chip', m.short);
      b.dataset.model = m.id;
      b.style.setProperty('--mc', m.color);
      b.addEventListener('click', function () { loadModelChart(m.id); });
      chips.appendChild(b);
    });
    U.el('mchart-hour').addEventListener('input', renderModelChart);
    U.el('mchart-prev').addEventListener('click', function () {
      U.el('mchart-hour').stepDown(); renderModelChart();
    });
    U.el('mchart-next').addEventListener('click', function () {
      U.el('mchart-hour').stepUp(); renderModelChart();
    });
  }

  /* One place recomputes every layer control's lit state, so the chips can
   * never drift from what the map is actually showing. */
  function syncLayerChips() {
    var active = global.Layers.active();
    // The active field always captions itself; no field, no caption.
    renderFieldLegend(active);
    U.el('layer-wind').classList.toggle('on', active === 'wind');
    U.el('layer-temp').classList.toggle('on', active === 'temp');
    U.el('layer-cape').classList.toggle('on', active === 'cape');
    U.el('layer-odds').classList.toggle('on', active === 'odds');
    U.el('chip-warnings').classList.toggle('on', !!global.Settings.get('showWarnings'));
    U.el('chip-cells').classList.toggle('on', !!state.cellsOnMap);
    U.el('chip-spc').classList.toggle('on', !!global.Settings.get('showSpc'));
    U.el('chip-reports').classList.toggle('on', reportsOn());
    U.el('chip-clean').classList.toggle('on', global.Settings.get('radarClean') !== false);
    renderReportFilters();
  }

  function toggleExpand() {
    var card = U.el('radar-card');
    var on = card.classList.toggle('expanded');
    U.el('radar-expand').textContent = on ? 'Collapse' : 'Expand';
    global.Radar.invalidate();
  }

  function wireKeys() {
    document.addEventListener('keydown', function (e) {
      var t = e.target;
      if (t && (t.tagName === 'INPUT' || t.tagName === 'TEXTAREA')) {
        if (e.key === 'Escape') t.blur();
        return;
      }
      if (e.metaKey || e.ctrlKey || e.altKey) return;

      switch (e.key) {
        case 'm': case 'M':
          setMode(state.mode === 'simple' ? 'chase' : 'simple'); break;
        case 'g': case 'G': useGeolocation(); break;
        case 'u': case 'U': U.el('units-btn').click(); break;
        case 's': case 'S': U.el('saved-btn').click(); break;
        case '/': e.preventDefault(); U.el('search-input').focus(); break;
        case ' ': e.preventDefault(); U.el('radar-play').click(); break;
        case 'f': case 'F': toggleExpand(); break;
        case 'o': case 'O': toggleRadarOpts(); break;
        case 'w': case 'W': toggleLayer('wind'); break;
        case 't': case 'T': toggleLayer('temp'); break;
        case 'c': case 'C': toggleLayer('cape'); break;
        case 'n': case 'N': toggleSitePanel(); break;
        /* Sections are sections at every width now, so they need a keyboard
         * route. Numbered in the order they appear in the bar; 3 is Chase,
         * which only exists in Chase mode, so it switches mode rather than
         * doing nothing. */
        case '1': setTab('now'); break;
        case '2': setTab('radar'); break;
        case '3':
          if (state.mode !== 'chase') setMode('chase');
          setTab('chase'); break;
        case '4': setTab('outlook'); break;
        case 'v': case 'V': togglePair(); break;
        case 'r': case 'R': load(); if (state.mode === 'chase') loadChase(); break;
        case 'd': case 'D':
          if (state.afd) U.el('afd-card').scrollIntoView({ behavior: 'smooth', block: 'start' });
          break;
        case 'ArrowLeft': if (state.mode === 'chase') { e.preventDefault(); stepHour(-1); } break;
        case 'ArrowRight': if (state.mode === 'chase') { e.preventDefault(); stepHour(1); } break;
        case ',': e.preventDefault(); openSettings(); break;
        case '?': U.el('help').hidden = false; break;
        case 'Escape':
          U.el('help').hidden = true;
          U.el('settings').hidden = true;
          closeRadarOpts();
          U.el('site-panel').hidden = true;
          U.el('site-btn').setAttribute('aria-expanded', 'false');
          if (U.el('radar-card').classList.contains('expanded')) toggleExpand();
          break;
      }
    });
  }

  /* ── Radar bootstrap ────────────────────────────────────────────────── */

  function initRadar() {
    var ok = global.Radar.init(state.location.lat, state.location.lon, {
      onFrameChange: function (frame, i, total) {
        state.radarObsTotal = total;
        if (global.StormSignal && !state.radarFuture) global.StormSignal.showFrame(frame);
        /* A live refresh landing while the thumb is in the future must not
         * yank it back to the observed frames it silently updated. */
        if (state.radarFuture) return;
        var slider = U.el('radar-frame');
        slider.max = String(total - 1);   // Live/History own the whole track
        slider.style.setProperty('--split', '100%');
        slider.value = i;
        // RainViewer frame times are true epochs; show them on the forecast
        // location's clock so radar and forecast times agree.
        var off = state.data ? state.data.utc_offset_seconds : 0;
        var clock = U.fmtEpoch(frame.time * 1000, off, state.hour12);
        if (frame.archive) {
          clock = new Date((frame.time + off) * 1000).toLocaleDateString('en-US',
            { timeZone: 'UTC', month: 'short', day: 'numeric' }) + ' · ' + clock;
        }
        U.el('radar-time').textContent = frame.timeBasis === 'request' ? 'Requested ' + clock + ' · scan time unverified' : clock;
        var kind = U.el('radar-kind');
        kind.textContent = frame.archive ? 'archive' : (frame.forecast ? 'forecast' : 'observed');
        kind.className = 'tag ' + (frame.archive ? 'tag-archive'
          : (frame.forecast ? 'tag-forecast' : 'tag-obs'));
        syncRadarMode();
      },
      /* The playing loop stepping through HRRR leads drives the same UI
       * the scrubber does: tag, badge, clock and thumb all follow. */
      onFutureFrame: function (minute) {
        if (minute === null) {
          state.radarFuture = 0;
          U.el('fr-badge').hidden = true;
          return;
        }
        state.radarFuture = minute;
        var kind = U.el('radar-kind');
        kind.textContent = 'forecast';
        kind.className = 'tag tag-forecast';
        var slider = U.el('radar-frame');
        slider.max = String(C.HRRR_LEADS.length - 1);
        slider.value = String(Math.max(0, C.HRRR_LEADS.indexOf(minute)));
        slider.style.setProperty('--split', '0%');
        syncRadarMode();
        updateFutureBadge();
      },
      onMove: function () { if (state.mode === 'chase') loadPolygons(); },
      onSourceChange: function () {
        recordRadarProvenance('Selected radar source', null, false);
        syncRadarControls();
      }
    });
    state.mapReady = ok;
    if (!ok) return;
    global.Radar.setClean(global.Settings.get('radarClean') !== false);

    // A storm report's "Radar at this time" button (js/spc.js). Leaflet
    // stops clicks inside a popup from bubbling, so it is wired on open.
    global.Radar.getMap().on('popupopen', function (e) {
      var b = e.popup.getElement() && e.popup.getElement().querySelector('[data-radar-at]');
      if (b) b.onclick = function () { radarAt(+b.getAttribute('data-radar-at')); };
    });

    /* The basemap follows the app's colour scheme — light canvas by day
     * theme, dark by dark — and re-follows it live if the system flips. */
    var darkMq = matchMedia('(prefers-color-scheme: dark)');
    if (!darkMq.matches) global.Radar.setBaseTheme(true);
    var onScheme = function () { global.Radar.setBaseTheme(!darkMq.matches); };
    if (darkMq.addEventListener) darkMq.addEventListener('change', onScheme);
    else if (darkMq.addListener) darkMq.addListener(onScheme);

    loadSites();
    global.API.radarIndex().then(function (index) {
      global.Radar.loadFrames(index);
      syncRadarControls();
    }).catch(function (err) {
      UI.status('Radar frames unavailable: ' + err.message, 'warn');
    });
  }

  // The legend is built from the live source's real palette. A radar key that
  // doesn't match the pixels is worse than none at all.
  function renderRadarLegend() {
    var box = U.el('radar-legend');
    U.clear(box);
    var leg = global.Radar.legend();

    leg.scale.forEach(function (s) {
      // dBZ rows are [value, colour, label]; relative and velocity rows are
      // [colour, label].
      var isDbz = leg.kind === 'dbz';
      var color = isDbz ? s[1] : s[0];
      var label = isDbz ? s[2] : s[1];
      var cell = U.make('span', 'legend-step');
      var sw = U.make('span', 'legend-swatch');
      sw.style.background = color;
      sw.title = isDbz ? s[0] + ' dBZ' : label || '';
      cell.appendChild(sw);
      if (label) cell.appendChild(U.make('span', 'legend-label', label));
      box.appendChild(cell);
    });

    var note = U.make('span', 'legend-note', leg.note);
    box.appendChild(note);
  }

  /* ── Boot ───────────────────────────────────────────────────────────── */

  function boot() {
    restoreState();
    try {
      // The optional AI layer is gone; any key or cache it left behind on
      // this device goes with it.
      localStorage.removeItem('vane.brief.key.v1');
      localStorage.removeItem('vane.brief.cache.v1');
    } catch (e) { /* private mode */ }
    applyLaunchParams();
    // Taps and swipes on notifications the worker handled while we were
    // away, folded into what Vane has learned (js/notifylearn.js).
    if (global.NotifyLearn) global.NotifyLearn.drainSW();
    var settings = global.Settings.load();
    state.hour12 = settings.hour12;
    document.body.dataset.mode = state.mode;
    U.el('units-label').textContent = state.imperial ? '°F' : '°C';
    Array.prototype.forEach.call(document.querySelectorAll('.mode-switch button'), function (b) {
      var on = b.dataset.mode === state.mode;
      b.classList.toggle('on', on);
      b.setAttribute('aria-selected', String(on));
    });

    document.body.classList.toggle('solid', !!settings.solid);

    /* The stylesheet pins the radar controls under the topbar, whose height
     * varies with viewport (one row on desktop, two on a phone, plus the
     * status-bar inset when installed). Publish the measured value. */
    var setChromeVar = function () {
      var tb = document.querySelector('.topbar');
      if (tb) document.documentElement.style.setProperty('--topbar-h', tb.offsetHeight + 'px');
    };
    setChromeVar();
    global.addEventListener('resize', setChromeVar);

    state.savedPlaces = loadSaved();
    global.DecisionUI.init(state);
    if (global.VaneAgents) global.VaneAgents.init(function () { return state; });
    if (global.VaneLocalAI) global.VaneLocalAI.init();
    UI.renderHelp();
    wireSearch();
    wireSaved();
    wireControls();
    wireKeys();
    /* Jargon becomes pressable. Wired before the first render so the terms in
     * the markup — the derived-note paragraphs, the footer — are decorated on
     * the first paint rather than appearing plain and then sprouting
     * underlines a beat later. */
    global.Glossary.wire();
    global.Glossary.decorateAll();
    global.Glossary.observe();
    wireFolds();
    initRadar();
    global.Radar.setSitePicker(pickSite);
    global.Radar.setWarningsVisible(global.Settings.get('showWarnings'));
    syncLayerChips();
    /* The radar watches its own sources for new scans — see js/live.js. */
    state.liveRadar = global.Live.start({
      doc: document, win: global,
      pollMs: C.RADAR_LIVE_MS,
      probe: function () { return probeRadar().catch(function () {
        recordRadarProvenance('Radar source unavailable', null, false); return null;
      }); },
      onFresh: onRadarFresh
    });

    // Show true aging even when an unchanged index never triggers onFresh.
    state.liveRadar.probe();
    setInterval(function () {
      if (!document.hidden && global.StormSignal) global.StormSignal.render(state.radarProvenance);
      if (!document.hidden && global.WarningEvidence) global.WarningEvidence.render(state.alertStatus, state.location);
    }, 30000);

    // Paint cached data immediately so the first frame is never empty (F1).
    var cached = loadCache();
    if (cached && Math.abs(cached.location.lat - state.location.lat) < 0.005 && Math.abs(cached.location.lon - state.location.lon) < 0.005) {
      state.data = cached.data;
      state.alerts = cached.alerts || [];
      state.fetchedAt = cached.at;
      state.stale = true;
      renderCore();
      UI.renderAlerts(global.Settings.filterAlerts(state.alerts), function () { setMode('chase'); });
    }

    // Don't fire a burst of notifications for alerts that were already active
    // when the app opened — only for ones issued while it's running.
    global.API.alerts(state.location.lat, state.location.lon).then(global.Settings.seed);
    global.Settings.applyWakeLock();

    load().then(function () {
      if (state.mode === 'chase') { loadPolygons(); loadSpc(); loadReports(); }
      else if (reportsOn()) loadReports();
    });
    scheduleRefresh();

    if ('serviceWorker' in navigator) {
      /* Registration plus the part that was missing: finishing the update.
       * The worker activates new versions immediately, but the running page
       * stays built from the old shell until something reloads it — which
       * used to be the user, reopening the app twice per release. Now the
       * page reloads itself when nobody would notice, and offers a pill when
       * somebody would. */
      global.Updates.wire({
        container: navigator.serviceWorker,
        doc: document,
        win: global,
        checkMs: C.UPDATE_CHECK_MS,
        register: function () { return navigator.serviceWorker.register('sw.js'); },
        reload: function () { global.location.reload(); },
        offer: function (accept) {
          var pill = U.el('update-pill');
          pill.hidden = false;
          pill.addEventListener('click', accept);
        }
      }).catch(function () {
        /* offline shell unavailable — the app still works online */
      });

      /* Where the platform allows it (installed on Android / desktop
       * Chrome), ask for a periodic background check so severe alerts can
       * notify without the app open. Best-effort everywhere else: the API
       * simply does not exist on iOS, and the settings sheet says so. */
      if (global.Settings.get('notify')) {
        navigator.serviceWorker.ready.then(function (reg) {
          if (!('periodicSync' in reg)) return;
          return reg.periodicSync.register('vane-watch', {
            minInterval: 6 * 3600 * 1000
          });
        }).catch(function () { /* denied or unsupported — foreground still works */ });
      }
    }

    // Coming back to a backgrounded tab should show current data, not stale data.
    document.addEventListener('visibilitychange', function () {
      if (!document.hidden && global.NotifyLearn) global.NotifyLearn.drainSW();
      if (!document.hidden && Date.now() - state.fetchedAt > C.REFRESH_MS[state.mode]) {
        load({ silent: true });
      }
    });
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', boot);
  } else {
    boot();
  }

  global.Vane = { state: state, radarAt: radarAt, setTab: setTab, showLayer: showLayer, load: load, setMode: setMode, setLocation: setLocation,
    radarSource: radarSource, loadReports: loadReports };
})(window);

