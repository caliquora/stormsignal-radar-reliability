/* Vane — Chase rendering: convective parameters, hodograph, profile,
 * areas of interest, and the shot planner with its 3D view. Loaded on
 * first entry to the Chase tab (js/lazy.js), so nothing outside that tab
 * may live here: the storm banner is in ui-now.js, the radar-site picker
 * in ui-chrome.js, and the SPC and reports cards in ui-outlook.js. */
(function (global) {
  'use strict';

  var C = global.VaneConfig, U = global.U, D = global.Derive;
  var UI = global.UI;
  // Shared helpers from js/ui-core.js.
  var svg = UI.svg;
  /* ── Chase: convective parameters ───────────────────────────────────── */

  function param(label, value, note, tone) {
    var cell = U.make('div', 'param' + (tone ? ' tone-' + tone : ''));
    cell.appendChild(U.make('span', 'param-label', label));
    cell.appendChild(U.make('span', 'param-value', value));
    if (note) cell.appendChild(U.make('span', 'param-note', note));
    return cell;
  }

  function toneFor(kind, v) {
    if (v === null || v === undefined) return null;
    if (kind === 'cape') return v > 2500 ? 'hot' : v > 1000 ? 'warm' : v > 300 ? 'mild' : null;
    if (kind === 'shear') return v > 18 ? 'hot' : v > 12 ? 'warm' : v > 8 ? 'mild' : null;
    if (kind === 'srh') return Math.abs(v) > 250 ? 'hot' : Math.abs(v) > 150 ? 'warm' : Math.abs(v) > 75 ? 'mild' : null;
    if (kind === 'index') return v > 4 ? 'hot' : v > 1 ? 'warm' : v > 0.4 ? 'mild' : null;
    return null;
  }

  /* The four that decide whether a day is worth driving to: is there fuel, is
   * there enough shear to organise a storm, is there enough low-level spin to
   * rotate it, and the blend of the three. Everything else refines that
   * answer rather than making it, so it folds on a phone. */
  var HEADLINE_PARAMS = ['CAPE', '0–6 km shear', '0–1 km SRH', 'Supercell index'];

  function renderParams(state) {
    var box = U.el('params');
    var rest = U.el('params-rest');
    var more = document.querySelector('.param-more');
    U.clear(box); U.clear(rest);
    var cv = state.convective;
    if (!cv) {
      if (more) more.hidden = true;
      box.appendChild(U.make('p', 'muted',
        'Loading pressure-level data…'));
      return;
    }
    if (more) more.hidden = false;
    var imp = state.imperial;
    var kt = function (ms) { return ms === null || ms === undefined ? '--' : Math.round(U.msToKt(ms)) + ' kt'; };

    // Built once in one order, then split — so the fold can never disagree
    // with the headline about which parameters exist.
    var tiles = [];
    var add = function (label, value, note, tone) {
      tiles.push({ label: label, el: param(label, value, note, tone) });
    };

    add('CAPE', cv.cape === null ? '--' : Math.round(cv.cape) + ' J/kg',
      'surface-based', toneFor('cape', cv.cape));
    add('CIN', cv.cin === null ? '--' : Math.round(cv.cin) + ' J/kg',
      cv.cin !== null && cv.cin < -100 ? 'capped' : 'inhibition');
    add('Lifted index', cv.li === null ? '--' : cv.li.toFixed(1),
      cv.li !== null && cv.li < -4 ? 'very unstable' : '');
    add('0–1 km shear', cv.shear1 ? kt(cv.shear1.magnitude) : '--',
      cv.shear1 ? U.speed(cv.shear1.magnitude, imp) : '', toneFor('shear', cv.shear1 && cv.shear1.magnitude));
    add('0–6 km shear', cv.shear6 ? kt(cv.shear6.magnitude) : '--',
      cv.shear6 ? U.speed(cv.shear6.magnitude, imp) : '', toneFor('shear', cv.shear6 && cv.shear6.magnitude));
    add('0–1 km SRH', cv.srh1 === null || cv.srh1 === undefined ? '--' : Math.round(cv.srh1) + ' m²/s²',
      'right mover', toneFor('srh', cv.srh1));
    add('0–3 km SRH', cv.srh3 === null || cv.srh3 === undefined ? '--' : Math.round(cv.srh3) + ' m²/s²',
      'right mover', toneFor('srh', cv.srh3));

    if (cv.motion) {
      add('Storm motion (RM)',
        U.compass(cv.motion.right.dir) + ' ' + kt(cv.motion.right.speed), 'Bunkers right');
      add('Storm motion (LM)',
        U.compass(cv.motion.left.dir) + ' ' + kt(cv.motion.left.speed), 'Bunkers left');
      add('Mean wind 0–6 km',
        U.compass(cv.motion.mean.dir) + ' ' + kt(cv.motion.mean.speed), '');
    }
    add('Freezing level', cv.freezingLevel === null ? '--' : U.height(cv.freezingLevel, imp), 'hail growth');
    add('Mixing height', cv.pbl === null ? '--' : U.height(cv.pbl, imp), 'boundary layer');
    if (cv.index !== undefined) {
      add('Supercell index', cv.index.toFixed(1),
        'derived blend, not SPC SCP', toneFor('index', cv.index));
    }

    /* The read goes first. It used to sit under fourteen tiles of numbers,
     * which is backwards: the numbers are the evidence and the sentence is the
     * finding. Someone glancing at a phone in a field gets the finding. */
    var summary = D.convectiveSummary(cv);
    if (summary) {
      var s = U.make('div', 'param-summary');
      s.appendChild(U.make('span', 'param-summary-label', 'Read'));
      s.appendChild(U.make('span', null, summary));
      box.appendChild(s);
    }

    /* Chase-day odds (js/chaseday.js): the environment's track record,
     * not a promise that storms fire. Evening by evening, from 00Z. */
    var CD = global.ChaseDay, W = CD && CD.weights();
    if (state.chaseDay && W) {
      var tz = state.data ? state.data.utc_offset_seconds || 0 : 0;
      var today = new Date(Date.now() + tz * 1000).getUTCDate();
      var parts = state.chaseDay.map(function (d) {
        // 00Z is the evening of the previous local day across the Americas.
        var local = new Date(d.at - 60000 + tz * 1000);
        var name = local.getUTCDate() === today ? 'this evening'
          : ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'][local.getUTCDay()] + ' evening';
        return name + ' ' + (d.p < 0.01 ? 'under 1%' : Math.round(d.p * 100) + '%');
      });
      var o = U.make('div', 'param-summary param-odds');
      o.appendChild(U.make('span', 'param-summary-label', 'Chase-day odds'));
      o.appendChild(U.make('span', null, 'Severe report within ' + W.radiusKm + ' km: ' + parts.join(' · ') +
        '. From the forecast’s evening sounding here, by a model trained on ' + W.eval.days +
        ' days of real soundings (' + W.eval.stations + ' US stations) — it out-ranked CAPE × shear on days it never ' +
        'saw (AUC ' + W.eval.auc.toFixed(2) + ' vs ' + W.eval.aucWmaxshear.toFixed(2) + '). The environment’s odds, not ' +
        'a promise storms form: it cannot see a cap break.'));
      box.appendChild(o);
    }

    tiles.forEach(function (t) {
      (HEADLINE_PARAMS.indexOf(t.label) >= 0 ? box : rest).appendChild(t.el);
    });
  }

  // Layer colouring follows the convention chasers already read on SPC hodographs.
  var HODO_LAYERS = [
    { max: 1000, color: '#ff453a', label: '0–1 km' },
    { max: 3000, color: '#ff9f0a', label: '1–3 km' },
    { max: 6000, color: '#30d158', label: '3–6 km' },
    { max: 99000, color: '#64d2ff', label: '6 km+' }
  ];

  function layerColor(agl) {
    for (var i = 0; i < HODO_LAYERS.length; i++) if (agl <= HODO_LAYERS[i].max) return HODO_LAYERS[i].color;
    return '#64d2ff';
  }

  function renderHodograph(state) {
    var box = U.el('hodograph');
    U.clear(box);
    U.clear(U.el('hodo-key'));
    var cv = state.convective;
    if (!cv || !cv.profile) {
      box.appendChild(U.make('p', 'muted', 'Wind profile unavailable for this location or hour.'));
      return;
    }
    var levels = cv.profile.levels;
    var size = 320, cx = size / 2, cy = size / 2;

    // Scale to fit the strongest wind in the profile, in 10 kt steps.
    var maxKt = levels.reduce(function (a, l) { return Math.max(a, U.msToKt(l.speed)); }, 20);
    if (cv.motion) maxKt = Math.max(maxKt, U.msToKt(cv.motion.right.speed));
    var ringMax = Math.ceil((maxKt + 8) / 10) * 10;
    var scale = (size / 2 - 18) / ringMax;

    var s = svg('svg', { viewBox: '0 0 ' + size + ' ' + size, class: 'hodo', role: 'img',
      'aria-label': 'Hodograph of wind vectors from the surface to 500 hPa' });

    for (var r = 10; r <= ringMax; r += 10) {
      s.appendChild(svg('circle', { cx: cx, cy: cy, r: r * scale, class: 'hodo-ring' }));
      var t = svg('text', { x: cx + r * scale + 2, y: cy - 3, class: 'hodo-ring-label' });
      t.textContent = r;
      s.appendChild(t);
    }
    s.appendChild(svg('line', { x1: 0, y1: cy, x2: size, y2: cy, class: 'hodo-axis' }));
    s.appendChild(svg('line', { x1: cx, y1: 0, x2: cx, y2: size, class: 'hodo-axis' }));

    // Screen y is inverted relative to the v component (north is up).
    var px = function (u) { return cx + U.msToKt(u) * scale; };
    var py = function (v) { return cy - U.msToKt(v) * scale; };

    for (var i = 0; i < levels.length - 1; i++) {
      var a = levels[i], b = levels[i + 1];
      s.appendChild(svg('line', {
        x1: px(a.u), y1: py(a.v), x2: px(b.u), y2: py(b.v),
        stroke: layerColor(b.agl), 'stroke-width': 3, 'stroke-linecap': 'round'
      }));
    }

    levels.forEach(function (l) {
      var dot = svg('circle', { cx: px(l.u), cy: py(l.v), r: 3.4, fill: layerColor(l.agl),
        stroke: '#0b0d10', 'stroke-width': 1 });
      var title = svg('title');
      title.textContent = (l.surface ? 'Surface (10 m)' : l.p + ' hPa') +
        ' · ' + Math.round(l.agl) + ' m AGL · ' + U.compass(l.dir) + ' ' +
        Math.round(U.msToKt(l.speed)) + ' kt';
      dot.appendChild(title);
      s.appendChild(dot);
    });

    if (cv.motion) {
      [['right', '#ffffff', 'RM'], ['left', '#8e8e93', 'LM']].forEach(function (m) {
        var mo = cv.motion[m[0]];
        var g = svg('g', {});
        g.appendChild(svg('circle', { cx: px(mo.u), cy: py(mo.v), r: 5,
          fill: 'none', stroke: m[1], 'stroke-width': 2 }));
        var lbl = svg('text', { x: px(mo.u) + 8, y: py(mo.v) + 4, class: 'hodo-motion-label', fill: m[1] });
        lbl.textContent = m[2];
        g.appendChild(lbl);
        s.appendChild(g);
      });
    }

    box.appendChild(s);

    var key = U.el('hodo-key');
    HODO_LAYERS.forEach(function (l) {
      var row = U.make('div', 'hodo-key-row');
      var sw = U.make('span', 'hodo-swatch');
      sw.style.background = l.color;
      row.appendChild(sw);
      row.appendChild(U.make('span', null, l.label));
      key.appendChild(row);
    });
    var note = U.make('p', 'muted', 'Rings in knots. RM/LM are Bunkers storm motions.');
    key.appendChild(note);
  }

  /* ── Chase: wind profile table ──────────────────────────────────────── */

  function renderProfile(state) {
    var table = U.el('profile');
    U.clear(table);
    var cv = state.convective;
    if (!cv || !cv.profile) {
      table.appendChild(U.make('caption', 'muted', 'Pressure-level winds unavailable.'));
      return;
    }
    var imp = state.imperial;
    var thead = U.make('thead'), hr = U.make('tr');
    ['Level', 'Height AGL', 'Wind', 'Speed', 'Temp'].forEach(function (h) {
      hr.appendChild(U.make('th', null, h));
    });
    thead.appendChild(hr);
    table.appendChild(thead);

    var tb = U.make('tbody');
    cv.profile.levels.slice().reverse().forEach(function (l) {
      var tr = U.make('tr', l.surface ? 'sfc-row' : null);
      tr.appendChild(U.make('td', null, l.surface ? 'Surface' : l.p + ' hPa'));
      tr.appendChild(U.make('td', null, U.height(l.agl, imp)));
      tr.appendChild(U.make('td', null, U.compass(l.dir) + ' (' + Math.round(l.dir) + '°)'));
      tr.appendChild(U.make('td', null, Math.round(U.msToKt(l.speed)) + ' kt'));
      tr.appendChild(U.make('td', null, l.temp === null ? '--' : U.temp(l.temp, imp)));
      tb.appendChild(tr);
    });
    table.appendChild(tb);
  }

  /* ── Storm cells: areas of interest ─────────────────────────────────── */

  var CELLS_COLLAPSED = 4;

  function renderCells(state) {
    var box = U.el('cells');
    var note = U.el('cells-note');
    U.clear(box);
    var Cl = global.Cells;

    if (Cl.state.error) {
      box.appendChild(U.make('p', 'muted',
        'Storm attributes unavailable: ' + Cl.state.error));
      note.textContent = '';
      return;
    }
    if (!Cl.state.fetchedAt) {
      box.appendChild(U.make('p', 'muted', 'Loading storm attributes…'));
      return;
    }

    /* Ten ranked cells is right on a desktop, where the card sits beside
     * another one and you scan it. On a phone it is most of a screen each and
     * pushes everything below it off the tab, so the tail collapses behind a
     * disclosure — the ranking already means the ones that matter are on top. */
    var list = Cl.near(state.location.lat, state.location.lon, 400, 10);
    var phone = global.matchMedia && global.matchMedia('(max-width: 720px)').matches;
    var visible = (phone && !state.cellsExpanded) ? CELLS_COLLAPSED : list.length;
    var rotating = list.filter(function (c) { return c.mesoRank > 0 || c.tvs; }).length;

    var summary = U.make('div', 'cells-summary');
    summary.appendChild(U.make('span', 'cells-count', list.length));
    summary.appendChild(U.make('span', null,
      list.length === 1 ? 'cell of interest within 400 km' : 'cells of interest within 400 km'));
    if (rotating) {
      var rot = U.make('span', 'cells-rot', rotating + ' with rotation');
      summary.appendChild(rot);
    }
    box.appendChild(summary);

    if (!list.length) {
      box.appendChild(U.make('p', 'muted',
        'No tracked cells meet the threshold nearby. ' +
        Cl.state.cells.length + ' cells are being tracked nationally.'));
    }

    list.slice(0, visible).forEach(function (cell) {
      var row = U.make('div', 'cell-row cell-' + cell.band.key);

      var head = U.make('div', 'cell-head');
      var badge = U.make('span', 'cell-score', cell.score);
      badge.title = cell.band.label + ' threat score';
      head.appendChild(badge);

      var titles = U.make('div', 'cell-titles');
      titles.appendChild(U.make('span', 'cell-title', UI.cellHeadline(cell, state)));
      titles.appendChild(U.make('span', 'cell-meta',
        cell.site + ' · cell ' + cell.stormId + ' · ' +
        cell.maxDbz + ' dBZ · top ' + Math.round(cell.top) + ' kft' +
        (cell.vilDensity !== null ? ' · VILD ' + cell.vilDensity.toFixed(1) : '')));
      head.appendChild(titles);

      var focus = U.make('button', 'cell-focus', 'Locate');
      focus.addEventListener('click', function () {
        if (state.onFocusCell) state.onFocusCell(cell);
      });
      head.appendChild(focus);
      if (global.DecisionUI) {
        var following = global.Intelligence.read().following.indexOf(cell.id) !== -1;
        var follow = U.make('button', 'cell-focus', following ? 'Following' : 'Follow storm');
        follow.disabled = following;
        follow.addEventListener('click', function () { global.DecisionUI.follow(cell); });
        head.appendChild(follow);
      }
      row.appendChild(head);

      /* The fitted tendency, when there is one: a cell organising across
       * scans matters more than its snapshot, and the numbers that earned
       * the verdict ride along. Steady cells stay quiet — ten rows of
       * "steady" would bury the two that are changing. */
      if (cell.trend && cell.trend.dir !== 'steady') {
        var up = cell.trend.dir === 'strengthening';
        var tLine = U.make('div', 'cell-trend ' + (up ? 'up' : 'down'));
        var tText = (up ? '▲ Strengthening' : '▼ Weakening') + ' — ' +
          cell.trend.firstDbz + '→' + cell.trend.lastDbz + ' dBZ over ' +
          cell.trend.scans + ' scans (' + (cell.trend.dbzRate > 0 ? '+' : '') +
          cell.trend.dbzRate.toFixed(1) + ' dBZ/10 min)';
        if (cell.trend.topNote) {
          tText += ', top ' + Math.round(cell.trend.firstTop) + '→' +
            Math.round(cell.trend.lastTop) + ' kft';
        }
        tLine.textContent = tText;
        row.appendChild(tLine);
      }

      /* The two trained models (js/stormmodel.js), each only where it has
       * earned it: the intensity outlook needs three scans of history, and
       * neither speaks below the dBZ floor it was trained on. */
      var SM = global.StormModel, SW = SM && SM.weights();
      if (SW && cell.maxDbz >= SW.meta.minDbz) {
        var bits = [];
        var hist = Cl.historyOf ? Cl.historyOf(cell.id) : null;
        var it = SM.intensity(cell, hist);
        if (it) {
          SM.note(cell.id, hist[hist.length - 1].t, it);
          bits.push('core ' + it.dbzNow + '→' + it.dbz20 + ' dBZ by 20 min');
        }
        var pct = function (p) { return p < 0.01 ? 'under 1%' : Math.round(p * 100) + '%'; };
        var ps = SM.severe(cell);
        if (ps !== null) bits.push('severe ' + pct(ps));
        var hz = SM.hail(cell);
        if (hz && hz.p1 >= 0.01) {
          bits.push('hail 1″+ ' + pct(hz.p1) +
            (hz.p175 !== null && hz.p175 >= 0.01 ? ', 1.75″+ ' + pct(hz.p175) : ''));
        }
        if (bits.length) {
          var mLine = U.make('div', 'cell-model');
          mLine.appendChild(U.make('span', 'cell-model-label', 'Next 30 min'));
          mLine.appendChild(U.make('span', null, bits.join(' · ')));
          row.appendChild(mLine);
        }
      }

      // Show the evidence, not just the verdict.
      if (cell.reasons.length) {
        var why = U.make('div', 'cell-reasons');
        cell.reasons.slice(0, 4).forEach(function (r) {
          var chip = U.make('span', 'cell-reason', r.label);
          chip.title = '+' + r.points + ' to the threat score';
          why.appendChild(chip);
        });
        row.appendChild(why);
      }

      var env = Cl.environment(cell, state.convective);
      if (env && (cell.mesoRank > 0 || cell.tvs)) {
        var envRow = U.make('div', 'cell-env');
        envRow.appendChild(U.make('span', 'cell-env-label', 'Environment'));
        envRow.appendChild(U.make('span', null, env));
        row.appendChild(envRow);
      }

      box.appendChild(row);
    });

    if (visible < list.length) {
      var more = U.make('button', 'ghost-btn cells-more',
        'Show the other ' + (list.length - visible) + ' cells');
      more.addEventListener('click', function () {
        state.cellsExpanded = true;
        renderCells(state);
      });
      box.appendChild(more);
    } else if (phone && state.cellsExpanded && list.length > CELLS_COLLAPSED) {
      var less = U.make('button', 'ghost-btn cells-more', 'Show fewer');
      less.addEventListener('click', function () {
        state.cellsExpanded = false;
        renderCells(state);
      });
      box.appendChild(less);
    }

    var age = Cl.state.generatedAt
      ? U.relative(Date.now() - new Date(Cl.state.generatedAt).getTime())
      : U.relative(Date.now() - Cl.state.fetchedAt);
    note.textContent =
      'Rotation and hail detections are the WSR-88D’s own Mesocyclone Detection ' +
      'Algorithm and Tornado Vortex Signature output, not derived here — base velocity ' +
      'is not publicly available, and the operational algorithm sees the full volumetric ' +
      'data these tiles do not contain. Both have known false-alarm rates, and a TVS is a ' +
      'velocity signature, not a confirmed tornado. Attributes update per volume scan ' +
      '(~4–6 min); this snapshot is ' + age + '. Strengthening and weakening tendencies ' +
      'are fitted in your browser from each cell’s own scans while the app is open — ' +
      'at least three scans before a verdict, and never from a single snapshot. ' +
      'US only. Never a substitute for an NWS warning.';
    var mNote = modelNote(), fold = U.el('cells-model-fold');
    if (fold) {
      fold.hidden = !mNote;
      U.el('cells-model-note').textContent = mNote;
    }
  }

  /* What the "Model" lines are, and how they scored on days they never
   * saw — plus how the intensity outlook is doing on the storms in front
   * of you this session. */
  function modelNote() {
    var SM = global.StormModel, W = SM && SM.weights();
    if (!W) return '';
    if (global.Cells && global.Cells.historyOf) SM.grade(global.Cells.historyOf);
    var m = W.meta, out = 'The Model lines come from models trained on ' + m.days +
      ' days of archived storm attributes and storm reports (' + m.first.slice(0, 4) + '–' +
      m.last.slice(0, 4) + ') and scored on ' + m.heldOutDays + ' days they never saw. ';
    if (W.intensity.ship) {
      var ie = W.intensity.eval;
      out += 'The 20-minute core outlook missed by ' + ie.maeModel.toFixed(1) + ' dBZ on average ' +
        'there, against ' + ie.maePersistence.toFixed(1) + ' for assuming no change, and called the ' +
        'direction of a 5 dBZ or larger change right ' + Math.round(ie.directionHit * 100) + '% of the time. ';
    }
    if (W.severe.ship) {
      var se = W.severe.eval;
      out += 'The severe-report probability ranked cells better than Vane’s own threat score ' +
        '(AUC ' + se.auc.toFixed(2) + ' vs ' + se.aucHeuristic.toFixed(2) + ') and its percentages ' +
        'held up — but it predicts that someone REPORTED severe weather within ' + m.severeKm +
        ' km and 30 minutes, and storms over empty country get fewer reports. ';
    }
    if (W.hail1 && W.hail1.ship) {
      var he = W.hail1.eval;
      out += 'Hail chances out-ranked the radar’s own size estimate (AUC ' + he.auc.toFixed(2) +
        ' vs ' + he.aucBaseline.toFixed(2) + ' for 1″ hail) — but ran low in the middle of the range ' +
        'on the held-out days, so read them as a floor. ';
    }
    if (W.track && W.track.single.ship) {
      var ts = W.track.single.eval, tw = W.track.watched.eval;
      out += 'Projected tracks use a trained correction to the radar’s straight line: 30 minutes ' +
        'out it was ' + ts.kmModel.toFixed(1) + ' km off on average against ' + ts.kmStraightLine.toFixed(1) +
        ' for the straight line' + (W.track.watched.ship
          ? ' (' + tw.kmModel.toFixed(1) + ' vs ' + tw.kmStraightLine.toFixed(1) + ' km for cells the app has watched)' : '') +
        '. ';
    }
    var sk = SM.sessionSkill();
    if (sk.track && sk.track.n) {
      out += 'This session its tracks have been checked against ' + sk.track.n + ' later scan' +
        (sk.track.n === 1 ? '' : 's') + ': ' + sk.track.km.toFixed(1) + ' km off on average (straight line: ' +
        sk.track.kmStraight.toFixed(1) + '). ';
    }
    if (sk.n) {
      out += 'This session it has been checked against ' + sk.n + ' later scan' +
        (sk.n === 1 ? '' : 's') + ': typical miss ' + sk.mae.toFixed(1) + ' dBZ (no-change: ' +
        sk.maePersist.toFixed(1) + '). ';
    }
    return out;
  }

  /* ── Shot planner ───────────────────────────────────────────────────── */

  function fmtKm(km, imp) {
    return imp ? Math.round(km * 0.621371) + ' mi' : Math.round(km) + ' km';
  }

  function renderShot(state) {
    var card = U.el('shot-card');
    var cell = state.shotCell;
    if (!cell || state.mode !== 'chase') { card.hidden = true; return; }
    card.hidden = false;

    var imp = state.imperial;
    var cv = state.convective;
    var env = {
      lclKm: cv && cv.lcl !== undefined && cv.lcl !== null ? cv.lcl / 1000 : null,
      shearMs: cv && cv.shear6 ? cv.shear6.magnitude : 0,
      shearEast: cv && cv.shear6 ? cv.shear6.u : undefined,
      shearNorth: cv && cv.shear6 ? cv.shear6.v : undefined
    };
    var plan = global.Shot.plan(cell, state.location.lat, state.location.lon);
    state.shotPlan = plan;

    U.el('shot-src').textContent = cell.site + '-' + cell.stormId + ' · ' +
      cell.top.toFixed(0) + ' kft top';

    var v = U.el('shot-verdict');
    v.className = 'shot-verdict shot-' + plan.verdict.key;
    v.textContent = plan.verdict.text;

    /* ── The read ────────────────────────────────────────────────────── */

    var read = U.el('shot-read');
    U.clear(read);

    function row(label, value, note) {
      var r = U.make('div', 'shot-row');
      r.appendChild(U.make('span', 'shot-label', label));
      r.appendChild(U.make('span', 'shot-value', value));
      if (note) r.appendChild(U.make('span', 'shot-note', note));
      read.appendChild(r);
    }

    var l = plan.from.light;
    row('Light', l.direction.label, l.quality.label);
    row('Sun', Math.round(l.sunAzimuth) + '° az, ' + Math.round(l.sunAltitude) + '° up',
      Math.round(l.relative) + '° off your line of sight');
    row('Structure', plan.structure.visibility.label,
      plan.structure.vilDensity !== null ? plan.structure.vilDensity.toFixed(1) + ' g/m³ VIL density' : '');
    row('Range', fmtKm(plan.from.distanceKm, imp), Math.round(plan.from.bearing) + '° bearing');
    if (plan.from.framing) {
      var f = plan.from.framing;
      row('In frame', Math.round(f.angularWidthDeg) + '° wide, top at ' + f.elevationDeg.toFixed(1) + '°',
        '~' + Math.round(f.focalMm) + ' mm ' + f.lens);
    }
    row('Cloud base', env.lclKm !== null
      ? (imp ? Math.round(env.lclKm * 3280.84) + ' ft' : Math.round(env.lclKm * 1000) + ' m')
      : 'unknown',
      env.lclKm !== null ? 'LCL, approximated' : 'needs pressure-level data');

    var why = U.make('ul', 'shot-reasons');
    plan.structure.reasons.concat([l.direction.note, l.quality.note]).forEach(function (r) {
      why.appendChild(U.make('li', null, r));
    });
    read.appendChild(why);

    /* ── Where to move ───────────────────────────────────────────────── */

    var t = U.el('shot-target');
    U.clear(t);
    if (plan.target) {
      var tg = plan.target;
      var head = U.make('div', 'shot-target-head');
      head.appendChild(U.make('h3', null, 'Suggested vantage'));
      head.appendChild(U.make('span', 'tag' + (tg.sunFavourable ? ' tag-obs' : ''),
        tg.sunFavourable ? 'Sun at your back' : 'Best available light'));
      t.appendChild(head);

      var line = U.make('p', 'shot-target-line');
      line.textContent = fmtKm(tg.moveKm, imp) + ' away, on the storm\'s inflow flank — ' +
        fmtKm(tg.standoffKm, imp) + ' out from the cell, looking ' +
        U.compass(tg.lookBearing) + '.' +
        (tg.stormEtaMin !== null && tg.stormEtaMin > 0
          ? ' The cell reaches that area in about ' + Math.round(tg.stormEtaMin) + ' min.'
          : '');
      t.appendChild(line);

      var go = U.make('button', 'ghost-btn', 'Show it on the radar');
      go.addEventListener('click', function () {
        if (state.onShowTarget) state.onShowTarget(tg);
      });
      t.appendChild(go);

      if (tg.inCorePath) {
        // Should be unreachable given the inflow arc, but a suggested position
        // is a thing people drive to, so a failure here is stated loudly
        // rather than quietly shipped.
        t.appendChild(U.make('p', 'shot-danger',
          'This position sits in the storm\'s forward path. Do not use it.'));
      }
    }

    var caveat = U.make('p', 'derived-note',
      'Geometry over a radar snapshot up to six minutes old. It assumes a road exists ' +
      'where it points and cannot see terrain, trees or traffic. It is a framing aid, ' +
      'not a routing or safety system — never let it put a storm between you and your ' +
      'way out.');
    t.appendChild(caveat);

    render3D(state, plan, env);
  }

  function render3D(state, plan, env) {
    var canvas = U.el('storm3d');
    if (!canvas || !global.Storm3D) return;
    // Idempotent: attaches once, then re-renders on every gesture.
    global.Storm3D.attach(canvas, function () { render3D(state, plan, env); });
    var cell = plan.cell;
    var mode = state.shotView || 'observer';
    U.el('shot-3d-controls').hidden = mode !== 'orbit';

    // Observer offset from the storm, in km east/north.
    var kmPerDegLat = 111.32;
    var kmPerDegLon = 111.32 * Math.cos(U.toRad(state.location.lat));
    var oe = (state.location.lon - cell.lon) * kmPerDegLon;
    var on = (state.location.lat - cell.lat) * kmPerDegLat;

    // The reflectivity field is fetched asynchronously; until it lands the
    // fallback silhouette is drawn, and the panel says which one you are
    // looking at rather than letting them pass for each other.
    var have = state.shotField && state.shotField.cellId === cell.id
      ? state.shotField.field : null;
    if (!have && state.onNeedField) state.onNeedField(cell);

    var m = global.Storm3D.render(canvas, cell, env, {
      mode: mode,
      observerE: oe,
      observerN: on,
      field: have,
      sunAzimuth: plan.from.light.sunAzimuth,
      sunAltitude: plan.from.light.sunAltitude
    });

    var note = U.el('shot-3d-note');
    if (!m) { note.textContent = 'No vertical structure reported for this cell.'; return; }
    // The observer view is framed rather than fixed, so say what lens it is
    // simulating; otherwise the render silently disagrees with the read-out.
    var lens = (mode === 'observer' && m.observerFocalMm)
      ? 'Framed as a ~' + Math.round(m.observerFocalMm) + ' mm lens would see it from ' +
        Math.round(m.observerDistanceKm) + ' km. '
      : '';
    var shape = m.fromRadar
      ? 'The shape is the actual 0.5° reflectivity field, read out of the radar ' +
        'tiles and inverted to dBZ through the published NWS colour table — same ' +
        'colours as the map, extruded. '
      : 'Reflectivity tiles could not be read for this cell, so the outline is a ' +
        'generic silhouette rather than this storm\'s real shape. ';
    note.textContent = lens + shape +
      'Column heights are modelled between two measured anchors: the strongest ' +
      'return reaches the measured echo top (' + Math.round(m.topKm / 0.3048) + ' kft), ' +
      'weaker returns are proportionally shallower. Cloud base is ' +
      (m.hasLcl ? 'the derived LCL' : 'a default, since no pressure-level data loaded') +
      ' and the lean is the derived 0–6 km shear vector' +
      (m.shearMs ? ' (' + Math.round(m.shearMs) + ' m/s)' : '') + '. ' +
      'Only the 0.5° tilt is published publicly, so there is no volume behind ' +
      'the vertical — it is a model, not a scan. Heights are drawn ' +
      m.exaggeration + '× exaggerated, as operational 3D radar displays do, ' +
      'because a storm really is several times wider than it is tall.';
  }

  UI.renderCells = renderCells;
  UI.renderShot = renderShot;
  UI.render3D = render3D;
  UI.renderParams = renderParams;
  UI.renderHodograph = renderHodograph;
  UI.renderProfile = renderProfile;
})(window);
