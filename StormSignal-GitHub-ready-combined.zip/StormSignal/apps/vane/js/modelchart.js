/* Model charts: the classic synoptic frame — precipitation shaded in the
 * familiar greens, mean sea-level pressure contoured every 4 hPa, highs and
 * lows lettered — rendered by Vane over the lower 48 from a 720-point
 * Open-Meteo lattice of the chosen agency's run. It is drawn in the visual
 * language of the charts forecasters publish, and the card says plainly
 * that it is Vane's rendering of the agency's grid, not the agency's own
 * native-resolution graphic. */
(function (global) {
  'use strict';

  var C = global.VaneConfig, U = global.U;
  var CH = C.CHART;                     // { NX, NY, LAT0, LAT1, LON0, LON1 }

  var DEFAULT_DOMAIN = { LAT0: CH.LAT0, LAT1: CH.LAT1, LON0: CH.LON0, LON1: CH.LON1 };

  var state = {
    id: null,
    domain: DEFAULT_DOMAIN,             // HRRR charts an inset lower-48 box
    rows: [],                           // row-major from the south-west corner
    times: [],
    horizon: 0,                         // hours of real (non-null) pressure data
    hour: 6,
    fetchedAt: 0,
    loading: false
  };

  /* ── Sampling ──────────────────────────────────────────────────────── */

  function cell(ix, iy, hour, key) {
    var r = state.rows[iy * CH.NX + ix];
    var v = r && r[key][hour];
    // Typed-array storage encodes missing as NaN; v !== v catches it.
    return (v === null || v === undefined || v !== v) ? null : v;
  }

  // Bilinear on the regular lattice; nulls read as 0 for precip (dry) and
  // poison the sample for pressure (a contour through fake data lies).
  function sampleGrid(fx, fy, hour, key) {
    fx = Math.max(0, Math.min(fx, CH.NX - 1.001));
    fy = Math.max(0, Math.min(fy, CH.NY - 1.001));
    var ix = Math.floor(fx), iy = Math.floor(fy);
    var tx = fx - ix, ty = fy - iy;
    var v00 = cell(ix, iy, hour, key), v10 = cell(ix + 1, iy, hour, key);
    var v01 = cell(ix, iy + 1, hour, key), v11 = cell(ix + 1, iy + 1, hour, key);
    if (key === 'precip') {
      return (v00 || 0) * (1 - tx) * (1 - ty) + (v10 || 0) * tx * (1 - ty) +
             (v01 || 0) * (1 - tx) * ty + (v11 || 0) * tx * ty;
    }
    if (v00 === null || v10 === null || v01 === null || v11 === null) return null;
    return v00 * (1 - tx) * (1 - ty) + v10 * tx * (1 - ty) +
           v01 * (1 - tx) * ty + v11 * tx * ty;
  }

  /* ── The classic precip ramp, mm per hour ──────────────────────────── */

  var RAMP = [
    [0.1, [215, 242, 208]],
    [0.25, [174, 227, 151]],
    [0.5, [126, 209, 101]],
    [1, [77, 188, 60]],
    [2, [43, 166, 42]],
    [3, [22, 135, 29]],
    [4, [11, 107, 26]],
    [6, [247, 243, 138]],
    [8, [242, 203, 82]],
    [12, [237, 163, 62]],
    [16, [229, 100, 46]],
    [25, [217, 43, 35]],
    [35, [193, 31, 110]],
    [50, [143, 44, 158]]
  ];

  function chartColor(v) {
    if (v === null || v < RAMP[0][0]) return null;
    var c = RAMP[0][1];
    for (var i = 0; i < RAMP.length; i++) {
      if (v >= RAMP[i][0]) c = RAMP[i][1];
    }
    return c;
  }

  /* ── Marching squares ──────────────────────────────────────────────────
   * Segments per cell at a threshold, endpoints linearly interpolated.
   * Field is a flat array w×h; nulls skip the cell. Returned segments are
   * in field coordinates: [x1, y1, x2, y2]. */

  function contourSegments(field, w, h, level) {
    var segs = [];
    function lerpT(a, b) { return (level - a) / (b - a); }
    for (var y = 0; y < h - 1; y++) {
      for (var x = 0; x < w - 1; x++) {
        var tl = field[y * w + x], tr = field[y * w + x + 1];
        var bl = field[(y + 1) * w + x], br = field[(y + 1) * w + x + 1];
        if (tl === null || tr === null || bl === null || br === null) continue;
        var idx = (tl >= level ? 8 : 0) | (tr >= level ? 4 : 0) |
                  (br >= level ? 2 : 0) | (bl >= level ? 1 : 0);
        if (idx === 0 || idx === 15) continue;
        // Edge crossing points: top, right, bottom, left.
        var pt = {
          t: [x + lerpT(tl, tr), y],
          r: [x + 1, y + lerpT(tr, br)],
          b: [x + lerpT(bl, br), y + 1],
          l: [x, y + lerpT(tl, bl)]
        };
        var EDGES = {
          1: ['l', 'b'], 2: ['b', 'r'], 3: ['l', 'r'], 4: ['t', 'r'],
          5: ['t', 'l', 'b', 'r'], 6: ['t', 'b'], 7: ['t', 'r', 'l', 'b'],
          8: ['t', 'l'], 9: ['t', 'b'], 10: ['t', 'r', 'l', 'b'],
          11: ['t', 'r'], 12: ['l', 'r'], 13: ['b', 'r'], 14: ['l', 'b']
        }[idx];
        for (var e = 0; e < EDGES.length; e += 2) {
          var a = pt[EDGES[e]], b = pt[EDGES[e + 1]];
          segs.push([a[0], a[1], b[0], b[1]]);
        }
      }
    }
    return segs;
  }

  /* Pressure centres: extrema over a two-cell neighbourhood, kept only when
   * the surrounding ring stands well proud of them. The first cut lettered
   * every half-hectopascal thermal wiggle over the Rockies — a chart with a
   * dozen phantom lows reads as noise, so only synoptic-scale centres earn
   * a letter, capped at the deepest few of each kind. */
  function extrema(hour) {
    var found = [];
    for (var iy = 2; iy < CH.NY - 2; iy++) {
      for (var ix = 2; ix < CH.NX - 2; ix++) {
        var v = cell(ix, iy, hour, 'mslp');
        if (v === null) continue;
        var lo = true, hi = true, ringLo = Infinity, ringHi = Infinity;
        for (var dy = -2; dy <= 2; dy++) {
          for (var dx = -2; dx <= 2; dx++) {
            if (!dx && !dy) continue;
            var n = cell(ix + dx, iy + dy, hour, 'mslp');
            if (n === null) { lo = hi = false; continue; }
            if (n <= v) lo = false;
            if (n >= v) hi = false;
            if (Math.abs(dx) === 2 || Math.abs(dy) === 2) {
              ringLo = Math.min(ringLo, n - v);
              ringHi = Math.min(ringHi, v - n);
            }
          }
        }
        if (lo && ringLo >= 1.5) found.push({ kind: 'L', ix: ix, iy: iy, value: v, depth: ringLo });
        if (hi && ringHi >= 1.5) found.push({ kind: 'H', ix: ix, iy: iy, value: v, depth: ringHi });
      }
    }
    found.sort(function (a, b) { return b.depth - a.depth; });
    var out = [], counts = { L: 0, H: 0 };
    found.forEach(function (x) {
      if (counts[x.kind] < 4) { counts[x.kind]++; out.push(x); }
    });
    return out;
  }

  /* ── Rendering ─────────────────────────────────────────────────────── */

  function project(lon, lat, W, H) {
    var d = state.domain;
    return [
      (lon - d.LON0) / (d.LON1 - d.LON0) * W,
      (d.LAT1 - lat) / (d.LAT1 - d.LAT0) * H
    ];
  }

  function fieldX(px, W) { return px / W * (CH.NX - 1); }
  function fieldY(py, H) { return py / H * (CH.NY - 1); }

  var shade = null;                     // offscreen raster for the precip fill

  function render(canvas, hour) {
    if (!canvas || !state.rows.length) return false;
    hour = Math.max(0, Math.min(hour, state.horizon - 1));
    state.hour = hour;
    var ctx = canvas.getContext('2d');
    var W = canvas.width, H = canvas.height;

    // The paper: charts are read on white, even inside a dark app.
    ctx.fillStyle = '#f6f4ee';
    ctx.fillRect(0, 0, W, H);

    // Precipitation shading, rasterised at half resolution and scaled up —
    // close enough to native that the band edges stay curves, not stairs.
    var FW = 480, FH = Math.round(480 * H / W);
    if (!shade) shade = document.createElement('canvas');
    shade.width = FW; shade.height = FH;
    var sctx = shade.getContext('2d');
    var img = sctx.createImageData(FW, FH);
    for (var yy = 0; yy < FH; yy++) {
      for (var xx = 0; xx < FW; xx++) {
        var v = sampleGrid(fieldX((xx + 0.5) / FW * W, W),
                           (CH.NY - 1) - fieldY((yy + 0.5) / FH * H, H), hour, 'precip');
        var c = chartColor(v);
        var o = (yy * FW + xx) * 4;
        if (!c) { img.data[o + 3] = 0; continue; }
        img.data[o] = c[0]; img.data[o + 1] = c[1]; img.data[o + 2] = c[2];
        img.data[o + 3] = 255;
      }
    }
    sctx.putImageData(img, 0, 0);
    ctx.imageSmoothingEnabled = true;
    ctx.imageSmoothingQuality = 'high';
    ctx.drawImage(shade, 0, 0, W, H);

    // State lines over the fill, under the contours.
    ctx.strokeStyle = 'rgba(90, 86, 76, 0.75)';
    ctx.lineWidth = 1;
    (global.US_OUTLINES || []).forEach(function (ring) {
      ctx.beginPath();
      for (var i = 0; i < ring.length; i++) {
        var p = project(ring[i][0], ring[i][1], W, H);
        if (i === 0) ctx.moveTo(p[0], p[1]); else ctx.lineTo(p[0], p[1]);
      }
      ctx.stroke();
    });

    // Isobars every 4 hPa on a 4x-upsampled pressure field.
    var PW = (CH.NX - 1) * 4 + 1, PH = (CH.NY - 1) * 4 + 1;
    var pf = new Array(PW * PH);
    var pmin = Infinity, pmax = -Infinity;
    for (var py = 0; py < PH; py++) {
      for (var px = 0; px < PW; px++) {
        var pv = sampleGrid(px / 4, (CH.NY - 1) - py / 4, hour, 'mslp');
        pf[py * PW + px] = pv;
        if (pv !== null) { if (pv < pmin) pmin = pv; if (pv > pmax) pmax = pv; }
      }
    }
    /* Levels clamped to the pressures Earth actually produces: a single
     * garbage value from the API (a 9999 sentinel, Pa instead of hPa) must
     * not send this loop tracing thousands of contours in one frame — a
     * hang the phone OS answers by killing the page. */
    pmin = Math.max(pmin, 870);
    pmax = Math.min(pmax, 1090);
    if (pmin < pmax) {
      ctx.strokeStyle = 'rgba(45, 45, 45, 0.85)';
      ctx.lineWidth = 2;             // survives the canvas being CSS-downscaled
      for (var lev = Math.ceil(pmin / 4) * 4; lev <= pmax; lev += 4) {
        var segs = contourSegments(pf, PW, PH, lev);
        ctx.beginPath();
        for (var s = 0; s < segs.length; s++) {
          ctx.moveTo(segs[s][0] / (PW - 1) * W, segs[s][1] / (PH - 1) * H);
          ctx.lineTo(segs[s][2] / (PW - 1) * W, segs[s][3] / (PH - 1) * H);
        }
        ctx.stroke();
      }
    }

    // Highs and lows, lettered the way every surface chart letters them.
    ctx.font = '700 22px system-ui, sans-serif';
    ctx.textAlign = 'center';
    extrema(hour).forEach(function (x) {
      var p = project(
        state.domain.LON0 + (state.domain.LON1 - state.domain.LON0) * x.ix / (CH.NX - 1),
        state.domain.LAT0 + (state.domain.LAT1 - state.domain.LAT0) * x.iy / (CH.NY - 1), W, H);
      ctx.fillStyle = x.kind === 'L' ? '#c22' : '#22c';
      ctx.fillText(x.kind, p[0], p[1]);
      ctx.font = '600 11px system-ui, sans-serif';
      ctx.fillText(String(Math.round(x.value)), p[0], p[1] + 12);
      ctx.font = '700 22px system-ui, sans-serif';
    });

    ctx.strokeStyle = '#444';
    ctx.strokeRect(0.5, 0.5, W - 1, H - 1);
    return true;
  }

  /* ── Data ──────────────────────────────────────────────────────────── */

  /* The two most recent agencies stay in hand: a chart load spends real
   * API quota (2,880 locations), and tapping ECMWF then back to GFS must
   * not spend it twice. Two grids ≈ 2 MB of typed arrays — cheap. */
  var kept = [];                        // [{id, rows, times, horizon, at}]

  function adopt(entry) {
    state.domain = entry.domain;
    state.rows = entry.rows;
    state.times = entry.times;
    state.horizon = entry.horizon;
    state.id = entry.id;
    state.fetchedAt = entry.at;
  }

  function load(id) {
    if (state.loading) return Promise.resolve(false);
    if (id === state.id && state.rows.length &&
        Date.now() - state.fetchedAt < 30 * 60 * 1000) {
      return Promise.resolve(true);
    }
    for (var i = 0; i < kept.length; i++) {
      if (kept[i].id === id && Date.now() - kept[i].at < 30 * 60 * 1000) {
        adopt(kept[i]);
        return Promise.resolve(true);
      }
    }
    state.loading = true;
    return global.API.chartGrid(id)
      .then(function (rows) {
        state.rows = rows;
        state.times = rows.length ? rows[0].times : [];
        // The horizon is where the pressure data really ends (short-horizon
        // agencies pad the tail of a 7-day request with nulls).
        var probe = rows[Math.floor(rows.length / 2)] || { mslp: [] };
        var n = 0;
        while (n < probe.mslp.length && probe.mslp[n] === probe.mslp[n]) n++;
        state.horizon = n;
        state.id = id;
        state.fetchedAt = Date.now();
        state.loading = false;
        state.domain = global.API.chartDomain(id);
        kept = kept.filter(function (e) { return e.id !== id; });
        kept.push({ id: id, rows: rows, times: state.times, domain: state.domain,
                    horizon: state.horizon, at: state.fetchedAt });
        if (kept.length > 2) kept.shift();
        return rows.length > 0;
      })
      .catch(function () { state.loading = false; return false; });
  }

  global.ModelChart = {
    load: load,
    render: render,
    state: state,
    chartColor: chartColor,
    contourSegments: contourSegments,
    extrema: extrema
  };
})(window);
