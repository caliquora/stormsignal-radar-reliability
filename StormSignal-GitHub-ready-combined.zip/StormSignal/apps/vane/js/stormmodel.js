/* Vane — two storm models trained offline, run in the browser.
 *
 * Both were fitted by scripts/train/train.js on two years of Iowa State's
 * archived NEXRAD storm attribute tables and local storm reports, and ship
 * as plain numbers in js/stormmodel-weights.js. Nothing is fetched to run
 * them; no server, no key. The training script and this file share
 * featuresOf() — the model is fed exactly the numbers it was trained on.
 *
 *   INTENSITY — where a cell's core reflectivity will be in about twenty
 *   minutes: a linear model over its current attributes and its fitted
 *   trend. It needs the trend, so it speaks only once the app has watched
 *   the cell for three scans (about ten minutes of Chase mode).
 *
 *   SEVERE — the probability that a cell is followed, within thirty
 *   minutes, by a severe local storm report within 15 km of it: a tornado,
 *   hail of an inch or more, a 58 mph gust, or thunderstorm wind damage.
 *   Logistic regression on a single scan's attributes, so it speaks at once.
 *
 * Both models carry their held-out evaluation (days the fit never saw) and
 * the app shows a model only if it beat its baseline there: persistence
 * for intensity, climatology for severe. LSRs are what people reported —
 * a storm over empty country produces fewer of them — so the severe number
 * is "a report was made", not "severe weather happened", and it says so. */
(function (global) {
  'use strict';

  var FEATURES = ['dbz', 'top', 'dbzH', 'vil', 'vild', 'posh', 'poh', 'size',
                  'meso', 'tvs', 'spd', 'slope', 'topSlope'];
  var TREND_WINDOW_MS = 20 * 60000;
  var TREND_MIN_SCANS = 3, TREND_MIN_SPAN_MIN = 8;

  function slope(h, key) {
    var n = h.length, st = 0, sv = 0, stt = 0, stv = 0;
    for (var i = 0; i < n; i++) {
      var t = (h[i].t - h[0].t) / 600000;          // per 10 minutes
      st += t; sv += h[i][key]; stt += t * t; stv += t * h[i][key];
    }
    var den = n * stt - st * st;
    return den ? (n * stv - st * sv) / den : 0;
  }

  /* cell: the app's parsed cell (js/cells.js parse()); history: [{t, dbz,
   * top}] oldest first, the current scan last — or null. Returns the raw
   * feature vector in FEATURES order and whether a trend was available. */
  function featuresOf(cell, history) {
    var h = (history || []).filter(function (p) {
      return history[history.length - 1].t - p.t <= TREND_WINDOW_MS;
    });
    var span = h.length ? (h[h.length - 1].t - h[0].t) / 60000 : 0;
    var hasTrend = h.length >= TREND_MIN_SCANS && span >= TREND_MIN_SPAN_MIN;
    var topKft = cell.top || 0, vil = cell.vil || 0;
    var vild = vil && topKft ? vil / (topKft * 304.8) * 1000 : 0;
    return {
      x: [
        cell.maxDbz || 0, topKft, cell.maxDbzHeight || 0, vil, vild,
        cell.posh || 0, cell.poh || 0, cell.maxSize || 0,
        cell.mesoRank || 0, cell.tvs ? 1 : 0, cell.speedKt || 0,
        hasTrend ? slope(h, 'dbz') : 0,
        hasTrend ? slope(h, 'top') : 0
      ],
      hasTrend: hasTrend
    };
  }

  // Standardised and clipped at ±5 SD, exactly as in training.
  var CLIP = 5;
  function linear(m, x) {
    var s = m.b;
    for (var i = 0; i < m.use.length; i++) {
      var z = (x[m.use[i]] - m.mean[i]) / m.std[i];
      s += m.w[i] * Math.max(-CLIP, Math.min(CLIP, z));
    }
    return s;
  }

  function weights() { return global.StormModelWeights || null; }

  /* → { dbzNow, dbz20, delta } or null (no trend yet, or no model). */
  function intensity(cell, history) {
    var W = weights(); if (!W || !W.intensity || !W.intensity.ship) return null;
    var f = featuresOf(cell, history);
    if (!f.hasTrend) return null;
    var d = linear(W.intensity, f.x);
    d = Math.max(-25, Math.min(25, d));
    return { dbzNow: cell.maxDbz, dbz20: Math.round(cell.maxDbz + d), delta: Math.round(d) };
  }

  /* → probability 0..1, or null when there is no shippable model. */
  function severe(cell) {
    var W = weights(); if (!W || !W.severe || !W.severe.ship) return null;
    var z = linear(W.severe, featuresOf(cell, null).x);
    return 1 / (1 + Math.exp(-z));
  }

  /* ── Hail: how big, calibrated ───────────────────────────────────────
   * The radar's own hail-size estimate (max_size) is one number with no
   * error bars. These are probabilities of a REPORT of hail at or above an
   * inch, and at or above golf-ball size (1.75"), within 15 km and 30
   * minutes — trained on what was actually reported under each estimate. */
  function hail(cell) {
    var W = weights(); if (!W || !W.hail1 || !W.hail1.ship) return null;
    var x = featuresOf(cell, null).x;
    var p1 = 1 / (1 + Math.exp(-linear(W.hail1, x)));
    var p175 = W.hail175 && W.hail175.ship ? 1 / (1 + Math.exp(-linear(W.hail175, x))) : null;
    // Larger hail implies the smaller threshold: keep the pair coherent.
    if (p175 !== null && p175 > p1) p175 = p1;
    return { p1: p1, p175: p175 };
  }

  /* ── Track: where it will be in thirty minutes ───────────────────────
   * The attribute table's motion is the radar algorithm's straight-line
   * fit. Real storms turn — supercells drift right of the mean wind,
   * cells merge and propagate — so the model learns a correction from the
   * table's own motion, the cell's observed motion over the last fifteen
   * minutes (when the app has watched it), and its attributes. Output is
   * the displacement in km over the next 30 minutes, east and north. */
  var TRACK_FEATURES = ['scitE', 'scitN', 'obsE', 'obsN', 'meso', 'tvs', 'dbz', 'top', 'spd'];
  var OBS_WINDOW_MS = 15 * 60000, OBS_MIN_SPAN_MIN = 8;

  function kmBetween(a, b) {
    var kx = 111.32 * Math.cos(a.lat * Math.PI / 180);
    return { e: (b.lon - a.lon) * kx, n: (b.lat - a.lat) * 111.32 };
  }

  /* history: [{t, lat, lon}] oldest first, current scan last, or null. */
  function trackFeaturesOf(cell, history) {
    var toward = ((cell.fromDeg || 0) + 180) * Math.PI / 180;
    var d30 = (cell.speedKt || 0) * 1.852 * 0.5;           // km in 30 minutes
    var scitE = d30 * Math.sin(toward), scitN = d30 * Math.cos(toward);
    var obsE = 0, obsN = 0, hasObs = false;
    var h = (history || []).filter(function (p) {
      return typeof p.lat === 'number' && history[history.length - 1].t - p.t <= OBS_WINDOW_MS;
    });
    if (h.length >= 2) {
      var spanMin = (h[h.length - 1].t - h[0].t) / 60000;
      if (spanMin >= OBS_MIN_SPAN_MIN) {
        var d = kmBetween(h[0], h[h.length - 1]);
        obsE = d.e * 30 / spanMin; obsN = d.n * 30 / spanMin;
        hasObs = true;
      }
    }
    return {
      x: [scitE, scitN, obsE, obsN, cell.mesoRank || 0, cell.tvs ? 1 : 0,
          cell.maxDbz || 0, cell.top || 0, cell.speedKt || 0],
      hasObs: hasObs, scitE: scitE, scitN: scitN, obsE: obsE, obsN: obsN
    };
  }

  /* → { east, north, lat, lon, watched } km over 30 minutes and the
   * implied position, or null with no shippable model. */
  function track(cell, history) {
    var W = weights(); if (!W || !W.track) return null;
    var f = trackFeaturesOf(cell, history);
    var m = f.hasObs ? W.track.watched : W.track.single;
    if (!m || !m.ship) return null;
    var e = linear(m.east, f.x), n = linear(m.north, f.x);
    return { east: e, north: n, watched: f.hasObs,
      lat: cell.lat + n / 111.32,
      lon: cell.lon + e / (111.32 * Math.cos(cell.lat * Math.PI / 180)) };
  }

  /* ── Graded as you watch ──────────────────────────────────────────
   * Every intensity outlook shown is remembered (in memory, this session)
   * and checked against the scan that actually arrives about twenty
   * minutes later, beside what "it stays the same" would have scored. The
   * held-out numbers say how the model did in training; these say how it
   * is doing on the storms in front of you. */
  var calls = {}, graded = [], trackCalls = {}, trackGraded = [];

  /* A track call: where the model put the cell in 30 minutes, and where
   * the straight line would have. */
  function noteTrack(id, t, model, straight) {
    var list = trackCalls[id] || (trackCalls[id] = []);
    if (list.length && list[list.length - 1].t === t) return;
    list.push({ t: t, model: model, straight: straight });
  }

  function kmApart(a, b) {
    var kx = 111.32 * Math.cos(a.lat * Math.PI / 180);
    var dx = (a.lon - b.lon) * kx, dy = (a.lat - b.lat) * 111.32;
    return Math.sqrt(dx * dx + dy * dy);
  }

  function note(id, t, out) {
    if (!out) return;
    var list = calls[id] || (calls[id] = []);
    if (list.length && list[list.length - 1].t === t) return;
    list.push({ t: t, dbzNow: out.dbzNow, dbz20: out.dbz20 });
  }

  /* historyOf(id) → [{t, dbz}] as js/cells.js keeps it. */
  function grade(historyOf) {
    Object.keys(trackCalls).forEach(function (id) {
      var h = (historyOf(id) || []).filter(function (p) { return typeof p.lat === 'number'; });
      trackCalls[id] = trackCalls[id].filter(function (c) {
        var target = c.t + 30 * 60000, hit = null;
        h.forEach(function (p) {
          if (Math.abs(p.t - target) <= 3 * 60000 &&
              (!hit || Math.abs(p.t - target) < Math.abs(hit.t - target))) hit = p;
        });
        if (hit) {
          trackGraded.push({ km: kmApart(c.model, hit), straight: kmApart(c.straight, hit) });
          return false;
        }
        return !h.length || h[h.length - 1].t < target + 3 * 60000;
      });
    });
    Object.keys(calls).forEach(function (id) {
      var h = historyOf(id) || [];
      calls[id] = calls[id].filter(function (c) {
        var target = c.t + 20 * 60000, hit = null;
        h.forEach(function (p) {
          if (Math.abs(p.t - target) <= 3 * 60000 &&
              (!hit || Math.abs(p.t - target) < Math.abs(hit.t - target))) hit = p;
        });
        if (hit) {
          graded.push({ err: Math.abs(hit.dbz - c.dbz20), persist: Math.abs(hit.dbz - c.dbzNow) });
          return false;
        }
        // Gone past the window with no scan: the cell left the table or the
        // app was away. Dropped, not scored.
        return !h.length || h[h.length - 1].t < target + 3 * 60000;
      });
    });
  }

  function sessionSkill() {
    var out = { n: 0, track: { n: 0 } };
    if (graded.length) {
      var e = 0, p = 0;
      graded.forEach(function (g) { e += g.err; p += g.persist; });
      out = { n: graded.length, mae: e / graded.length, maePersist: p / graded.length, track: { n: 0 } };
    }
    if (trackGraded.length) {
      var k = 0, sl = 0;
      trackGraded.forEach(function (g) { k += g.km; sl += g.straight; });
      out.track = { n: trackGraded.length, km: k / trackGraded.length, kmStraight: sl / trackGraded.length };
    }
    return out;
  }

  function resetSession() { calls = {}; graded = []; trackCalls = {}; trackGraded = []; }

  global.StormModel = {
    FEATURES: FEATURES,
    featuresOf: featuresOf,
    intensity: intensity,
    severe: severe,
    hail: hail,
    track: track,
    trackFeaturesOf: trackFeaturesOf,
    TRACK_FEATURES: TRACK_FEATURES,
    weights: weights,
    note: note,
    noteTrack: noteTrack,
    grade: grade,
    sessionSkill: sessionSkill,
    resetSession: resetSession
  };
})(typeof window !== 'undefined' ? window : globalThis);
