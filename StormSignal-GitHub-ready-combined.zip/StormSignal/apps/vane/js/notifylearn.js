/* Vane — notifications that learn what you care about.
 *
 * Every notification Vane posts carries its kind: a rain heads-up from
 * VaneMotion, an SPC outlook, or an NWS alert of a family (flood, winter,
 * heat…). What you do with it is the signal — opened, or swiped away
 * unread. This learner keeps that tally per kind, on the device, and acts
 * on it within hard limits:
 *
 *   - Vane's OWN heads-ups adapt by themselves. Dismiss rain heads-ups
 *     often enough and they go quiet — only heavier rain, closer in. Ignore
 *     Slight-risk outlook notices and they wait for Enhanced. Start opening
 *     them again and they come back. Each change is stated in Settings,
 *     with the numbers, and can be undone there.
 *   - OFFICIAL ALERTS NEVER ADAPT BY THEMSELVES. A family you keep
 *     dismissing is only ever SUGGESTED for muting, in Settings, and muting
 *     it still lets Extreme alerts through. A learner must never be the
 *     reason someone missed a tornado warning.
 *
 * Engagement is a smoothed open rate, (opens + 1) / (outcomes + 2), so two
 * dismissals do not read as a pattern. Nothing is decided before
 * MIN_OUTCOMES outcomes. Outcomes from notifications handled by the
 * service worker (the app closed, the notification tapped from the shade)
 * are logged by the worker and drained in here on the next open. */
(function (global) {
  'use strict';

  var KEY = 'vane.notifylearn.v1';
  var MIN_OUTCOMES = 5;
  var QUIET_BELOW = 0.2;       // fewer than ~1 in 5 opened: quiet it
  var RESTORE_ABOVE = 0.4;     // opened again often enough: bring it back
  var SW_CACHE = 'vane-watch', SW_LOG = './notify-log';

  function empty() { return { kinds: {}, mute: {} }; }
  function kindOf(store, kind) {
    return store.kinds[kind] || (store.kinds[kind] = { open: 0, dismiss: 0, quiet: false, pinned: false });
  }

  /* ── Pure core ───────────────────────────────────────────────────── */

  function engagement(k) { return (k.open + 1) / (k.open + k.dismiss + 2); }

  /* Fold one outcome in. Only Vane's own kinds (rain, spc) may flip their
   * quiet flag; alert kinds only accumulate evidence for a suggestion. */
  function recordOutcome(store, kind, action) {
    if (!kind || (action !== 'open' && action !== 'dismiss')) return store;
    var k = kindOf(store, kind);
    k[action]++;
    if (kind.indexOf('alert:') === 0 || k.pinned) return store;
    var e = engagement(k), n = k.open + k.dismiss;
    if (!k.quiet && n >= MIN_OUTCOMES && e < QUIET_BELOW) k.quiet = true;
    else if (k.quiet && e > RESTORE_ABOVE) k.quiet = false;
    return store;
  }

  function policy(store, kind) {
    var k = store.kinds[kind];
    if (!k) return { quiet: false, n: 0, open: 0, dismiss: 0, engagement: null };
    return { quiet: !!k.quiet, pinned: !!k.pinned, n: k.open + k.dismiss,
             open: k.open, dismiss: k.dismiss, engagement: engagement(k) };
  }

  /* Alert families worth offering to mute: mostly dismissed, enough
   * evidence, not already muted. */
  function suggestions(store) {
    return Object.keys(store.kinds).filter(function (kind) {
      if (kind.indexOf('alert:') !== 0) return false;
      var k = store.kinds[kind], fam = kind.slice(6);
      return !store.mute[fam] && k.open + k.dismiss >= MIN_OUTCOMES && engagement(k) < QUIET_BELOW;
    }).map(function (kind) {
      var k = store.kinds[kind];
      return { family: kind.slice(6), open: k.open, dismiss: k.dismiss };
    });
  }

  /* Muted families still pass Extreme alerts (rank 4). */
  function alertAllowed(store, family, rank) {
    return !store.mute[family] || rank >= 4;
  }

  /* ── Storage ─────────────────────────────────────────────────────── */

  function load() {
    try {
      var s = JSON.parse(global.localStorage.getItem(KEY));
      if (s && s.kinds && s.mute) return s;
    } catch (e) { /* corrupt or unavailable */ }
    return empty();
  }

  function save(s) {
    try { global.localStorage.setItem(KEY, JSON.stringify(s)); } catch (e) { /* full */ }
  }

  function outcome(kind, action) { save(recordOutcome(load(), kind, action)); }
  function policyFor(kind) { return policy(load(), kind); }
  function suggest() { return suggestions(load()); }
  function allowAlert(family, rank) { return alertAllowed(load(), family, rank); }
  function muted() { return load().mute; }

  function setMute(family, on) {
    var s = load();
    if (on) s.mute[family] = true; else delete s.mute[family];
    save(s);
  }

  /* "Back to normal": undo a learned quieting and stop it re-learning. */
  function pinNormal(kind) {
    var s = load(), k = kindOf(s, kind);
    k.quiet = false; k.pinned = true;
    save(s);
  }

  function reset() {
    try { global.localStorage.removeItem(KEY); } catch (e) { /* nothing */ }
  }

  /* Outcomes the service worker logged while the page was away. */
  function drainSW() {
    if (!global.caches) return Promise.resolve(0);
    return global.caches.open(SW_CACHE).then(function (c) {
      return c.match(SW_LOG).then(function (r) {
        if (!r) return 0;
        return r.json().then(function (list) {
          var s = load();
          (list || []).forEach(function (o) { recordOutcome(s, o.kind, o.action); });
          save(s);
          return c.delete(SW_LOG).then(function () { return (list || []).length; });
        });
      });
    }).catch(function () { return 0; });
  }

  global.NotifyLearn = {
    outcome: outcome,
    policyFor: policyFor,
    suggest: suggest,
    allowAlert: allowAlert,
    muted: muted,
    setMute: setMute,
    pinNormal: pinNormal,
    reset: reset,
    drainSW: drainSW,
    // Pure core, exported for the test suite.
    recordOutcome: recordOutcome,
    policy: policy,
    suggestions: suggestions,
    alertAllowed: alertAllowed,
    engagement: engagement,
    empty: empty,
    MIN_OUTCOMES: MIN_OUTCOMES
  };
})(window);
