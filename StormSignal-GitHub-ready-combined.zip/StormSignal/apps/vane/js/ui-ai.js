/* Vane — the Vane AI card: every model in one place.
 *
 * "AI and ML are not obvious" was the field report: nine models work on
 * this forecast, but each spoke in its own card, in plain sentences, with
 * nothing to mark it as a model — and the one place that gathered them
 * (Vane Insight) hid itself whenever it had nothing to say. This card is
 * always there, at the top of Now. One row per model: what it is, what it
 * says for this place right now (or what it is waiting for), how it has
 * done, and a button to where it lives. Everything it shows is computed on
 * this device; nothing is sent anywhere. */
(function (global) {
  'use strict';

  var U = global.U;

  function chip() {
    var c = U.make('span', 'ai-chip', 'AI');
    c.setAttribute('aria-label', 'AI');
    return c;
  }

  function pct(p) {
    return p < 0.005 ? 'under ½%' : p < 0.01 ? (Math.round(p * 1000) / 10) + '%' : Math.round(p * 100) + '%';
  }

  /* What each model says here and now. Every row is { id, name, kind,
   * status, action? }; `kind` says how it learned. */
  function rows(state) {
    // The forecast location's clock; the device's until the forecast loads.
    var clock = function (ms) {
      return state.data ? U.fmtEpoch(ms, state.data.utc_offset_seconds, state.hour12)
        : U.fmtTime(new Date(ms), state.hour12);
    };
    var out = [];

    // 1. Storm Odds — Vane's own model of the environment.
    var SO = global.StormOdds && global.StormOdds.weights();
    if (SO && SO.ship) {
      var here = state.stormOddsHere, st;
      if (state.stormOddsOutside) {
        st = 'Covers the lower 48 US states, where it was trained — not this location.';
      } else if (here && here.length) {
        var now = global.StormOdds.at(here, Date.now()) || here[0];
        var peak = here.reduce(function (a, b) { return b.p > a.p ? b : a; });
        st = 'Here: ' + pct(now.p) + ' chance of a severe storm report within ' + SO.radiusKm +
          ' km in the next ' + SO.windowHours + ' hours' +
          (peak.p >= 0.01 && peak.at !== now.at ? '; highest ' + pct(peak.p) + ' around ' + clock(peak.at) : '') +
          (peak.p < 0.005 ? ' — nothing in the next 12 hours looks primed for severe storms.' : '.');
      } else {
        st = state.stormOddsFailed ? 'Could not load the forecast environment for this place — retrying with the next refresh.'
          : 'Reading the forecast environment for this place…';
      }
      out.push({ id: 'odds', name: 'Storm odds', kind: 'Trained by Vane', status: st,
        record: 'On ' + SO.eval.heldOutDays + ' days it never saw: AUC ' + SO.eval.auc.toFixed(2) +
          ' vs ' + SO.eval.aucWmaxshear.toFixed(2) + ' for CAPE × shear.',
        action: { label: 'See it on the map', go: function () { global.Vane.showLayer('odds'); } } });
    }

    // 2. Rain timing — VaneMotion's radar motion fit, blended with HRRR.
    if (global.MotionSkill) {
      var ms = global.MotionSkill.summary(state.location);
      // { at: when computed, motionMin / modelMin / blendMin: minutes until rain }
      var rt = state.rainTiming, mins = null, src = '';
      if (rt) {
        if (rt.blendMin !== null && rt.blendMin !== undefined) {
          mins = rt.blendMin; src = 'the radar’s motion fit blended with the HRRR, weighted by their record here';
        } else if (rt.motionMin !== null && rt.motionMin !== undefined) {
          mins = rt.motionMin; src = 'the radar’s motion fit';
        } else if (rt.modelMin !== null && rt.modelMin !== undefined) {
          mins = rt.modelMin; src = 'the HRRR';
        }
      }
      out.push({ id: 'motion', name: 'Rain timing', kind: 'Learns on this device',
        status: mins !== null ? 'Rain around ' + clock(rt.at + mins * 60000) + ', from ' + src + '.'
          : 'Watching the radar’s motion for rain heading here.',
        record: ms.ready ? 'Graded ' + ms.n + ' arrival calls here; typical miss ' + Math.round(ms.medianAbsErrMin) + ' min.'
          : 'Grades every arrival call against the radar that follows (' + ms.n + ' of 3 graded so far).',
        action: { label: 'Rain timeline', go: function () { scrollTo('nowcast', 'now'); } } });
    }

    // 3. Which agency to trust here, and 4. how the forecast leans.
    if (global.Verify) {
      var sc = global.Verify.scorecard();
      out.push({ id: 'scorecard', name: 'Local scorecard', kind: 'Learns on this device',
        status: sc.rows.length ? 'Most accurate here so far: ' + sc.rows[0].name + '.'
          : 'Verifying each forecast agency against the station’s thermometer.',
        record: sc.days + ' verified day' + (sc.days === 1 ? '' : 's') + (sc.rows.length ? '.' : ' (it ranks after 3).'),
        action: { label: 'Scorecard', go: function () { scrollTo('scorecard', 'outlook'); } } });
      var mc = global.Verify.climate();
      out.push({ id: 'micro', name: 'Microclimate correction', kind: 'Learns on this device',
        status: mc && mc.meaningful ? 'Highs here run ' + Math.abs(Math.round(mc.corrHi * (state.imperial ? 1.8 : 1))) + '° ' +
            (mc.corrHi < 0 ? 'cooler' : 'warmer') + ' than forecast; Vane corrects for it.'
          : mc ? 'The forecast has been right on here; no correction needed.'
          : 'Learning how the forecast leans at your spot.',
        record: mc ? 'From ' + mc.n + ' verified days.' : 'Speaks after enough verified days.',
        action: { label: '7-day forecast', go: function () { scrollTo('daily-card', 'now'); } } });
    }

    // 5. What "40%" means here.
    if (global.RainCal) {
      var rc = global.RainCal.summary(state.location);
      var ready = rc.rows.filter(function (r) { return r.ready; }).length;
      out.push({ id: 'raincal', name: 'Rain-chance calibration', kind: 'Learns on this device',
        status: ready ? 'Checks what each rain chance has meant here; ' + ready + ' chance band' + (ready === 1 ? '' : 's') + ' calibrated.'
          : 'Checking hourly rain chances against what the station reports.',
        record: rc.hours + ' verified hour' + (rc.hours === 1 ? '' : 's') + '.' });
    }

    // 6. The storm-cell models and 7. chase-day odds (chasing).
    if (global.StormModelWeights) {
      var cells = global.Cells && global.Cells.state ? (global.Cells.state.cells || []).length : 0;
      out.push({ id: 'cells', name: 'Storm-cell models', kind: 'Trained by Vane',
        status: cells ? 'Running on ' + cells + ' storm cell' + (cells === 1 ? '' : 's') + ' now: intensity in 20 min, ' +
            'severe-report and hail odds, and a 30-minute track for each.'
          : 'Intensity in 20 min, severe-report and hail odds, and a 30-minute track for every storm cell.',
        record: 'Trained on two springs of NEXRAD cell tracks and NWS reports; each beat its baseline on unseen days.',
        action: { label: 'Storm cells', go: function () { needChase(); scrollTo('cells-card', 'chase'); } } });
    }
    var CD = global.ChaseDay && global.ChaseDay.weights();
    if (CD && CD.ship) {
      out.push({ id: 'chaseday', name: 'Chase-day odds', kind: 'Trained by Vane',
        status: state.chaseDay && state.chaseDay.length
          ? 'Severe report within ' + CD.radiusKm + ' km by tonight: ' + pct(state.chaseDay[0].p) + '.'
          : 'This evening’s and tomorrow’s severe odds, from the forecast sounding (Chase mode).',
        record: 'Trained on ' + CD.eval.days + ' days of real soundings; AUC ' + CD.eval.auc.toFixed(2) + ' vs ' +
          CD.eval.aucWmaxshear.toFixed(2) + ' for CAPE × shear.',
        action: { label: 'Chase tab', go: function () { needChase(); scrollTo('params', 'chase'); } } });
    }

    // 8. Notifications that learn, and 9. the forecast discussion summary.
    if (global.NotifyLearn) {
      var sug = global.NotifyLearn.suggest() || [];
      out.push({ id: 'notify', name: 'Smart notifications', kind: 'Learns on this device',
        status: sug.length ? sug.length + ' suggestion' + (sug.length === 1 ? '' : 's') + ' from what you open and dismiss.'
          : 'Learns which alerts you open and which you swipe away. Never mutes the most serious ones.',
        record: 'Your settings show what it has learned, with one tap to forget it.' });
    }
    if ('Summarizer' in global) {
      out.push({ id: 'afd', name: 'Forecast discussion, in plain English', kind: 'On-device language model',
        status: 'Your browser’s built-in AI summarises the forecasters’ discussion; every point is checked against their words.',
        record: 'Runs in your browser; nothing is sent anywhere.',
        action: { label: 'Discussion', go: function () { scrollTo('afd-card', 'outlook'); } } });
    }
    return out;
  }

  function needChase() {
    if (global.Vane.state.mode !== 'chase') global.Vane.setMode('chase');
  }

  function scrollTo(id, tab) {
    global.Vane.setTab(tab);
    setTimeout(function () {
      var el = document.getElementById(id);
      if (el && !el.hidden && el.scrollIntoView) el.scrollIntoView({ behavior: 'smooth', block: 'start' });
    }, 60);
  }

  function render(state) {
    var list = U.el('ai-hub-list');
    if (!list) return;
    U.clear(list);
    var rs = rows(state);
    U.el('ai-hub-count').textContent = rs.length + ' models';
    // Three lead; the rest fold away so Now stays a glance on a phone.
    var more = U.el('ai-hub-more');
    if (more) more.parentNode.removeChild(more);
    var rest = null;
    rs.forEach(function (r, n) {
      if (n === 3) {
        var det = U.make('details', 'ai-more');
        det.id = 'ai-hub-more';
        det.appendChild(U.make('summary', null, 'All ' + rs.length + ' models'));
        rest = U.make('ul', 'ai-hub-list');
        det.appendChild(rest);
        list.parentNode.appendChild(det);
      }
      var li = U.make('li', 'ai-row');
      li.setAttribute('data-model', r.id);
      var head = U.make('div', 'ai-row-head');
      head.appendChild(U.make('strong', 'ai-row-name', r.name));
      head.appendChild(U.make('span', 'ai-row-kind', r.kind));
      li.appendChild(head);
      li.appendChild(U.make('p', 'ai-row-status', r.status));
      var foot = U.make('div', 'ai-row-foot');
      foot.appendChild(U.make('span', 'ai-row-record', r.record));
      if (r.action) {
        var b = U.make('button', 'ai-row-go', r.action.label + ' →');
        b.type = 'button';
        b.addEventListener('click', r.action.go);
        foot.appendChild(b);
      }
      li.appendChild(foot);
      (rest || list).appendChild(li);
    });
  }

  global.AiHub = { render: render, rows: rows, chip: chip, pct: pct };
})(window);
