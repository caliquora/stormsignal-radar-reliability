/* Vane — chase-day odds: will this environment produce severe weather?
 *
 * A logistic model trained by scripts/train/env.js on two years of real
 * evening (00Z) upper-air soundings — Iowa State's archive of every US
 * radiosonde, with CAPE, CIN, bulk shear, helicity and LCL already derived
 * — against whether a severe local storm report (tornado, 1" hail, 58 mph
 * gust, thunderstorm wind damage) followed within 100 km that afternoon and
 * evening. Shipped as plain numbers in js/chaseday-weights.js.
 *
 * In the app it reads the FORECAST profile for the same hour (00Z) — so the
 * odds are only as good as the forecast's environment, and the card says
 * so. It is the environment's odds, not a forecast that storms will form:
 * capped, quiet days with big CAPE and shear are exactly what it learned to
 * discount, but it cannot see the cap break.
 *
 * featuresOf() is shared with the training script, so the model is fed in
 * the app exactly what it was fit on. */
(function (global) {
  'use strict';

  var FEATURES = ['logCape', 'cin', 'shear6', 'srh1', 'srh3', 'lclKm', 'wmax'];
  var CLIP = 5;

  /* env: { cape (J/kg), cin (J/kg, either sign), shear6 (m/s),
   *        srh1, srh3 (m²/s², signed for the right mover), lcl (m AGL) } */
  function featuresOf(env) {
    var cape = Math.max(0, +env.cape || 0), shear = Math.max(0, +env.shear6 || 0);
    return [
      Math.log(1 + cape),
      Math.min(300, Math.abs(+env.cin || 0)),
      shear,
      +env.srh1 || 0,
      +env.srh3 || 0,
      Math.max(0, +env.lcl || 0) / 1000,
      Math.sqrt(2 * cape) * shear / 100          // WMAXSHEAR, scaled
    ];
  }

  function weights() { return global.ChaseDayWeights || null; }

  /* → probability 0..1, or null with no shippable model or missing inputs. */
  function odds(env) {
    var W = weights();
    if (!W || !W.ship || !env || env.cape === null || env.cape === undefined ||
        env.shear6 === null || env.shear6 === undefined) return null;
    var x = featuresOf(env), z = W.b;
    for (var i = 0; i < W.w.length; i++) {
      var s = (x[i] - W.mean[i]) / W.std[i];
      z += W.w[i] * Math.max(-CLIP, Math.min(CLIP, s));
    }
    return 1 / (1 + Math.exp(-z));
  }

  /* The app's derived convective numbers (js/derive.js convective()) →
   * the env this model takes. */
  function envFromConvective(cv) {
    if (!cv) return null;
    return { cape: cv.cape, cin: cv.cin,
             shear6: cv.shear6 ? cv.shear6.magnitude : null,
             srh1: cv.srh1, srh3: cv.srh3, lcl: cv.lcl };
  }

  global.ChaseDay = {
    FEATURES: FEATURES,
    featuresOf: featuresOf,
    odds: odds,
    envFromConvective: envFromConvective,
    weights: weights
  };
})(typeof window !== 'undefined' ? window : globalThis);
