/* Vane — configuration, constants and code tables.
 * Everything here is static data: no network, no state. */
(function (global) {
  'use strict';

  var CONFIG = {
    // All requests use SI internally (°C, m/s, mm). Conversion happens at render
    // time only, so derived meteorology never has to care about display units.
    OM_FORECAST: 'https://api.open-meteo.com/v1/forecast',
    OM_GEOCODE: 'https://geocoding-api.open-meteo.com/v1/search',
    // A true perturbed-member ensemble: one model integrated 50 times from
    // slightly different initial states. This is a different measurement from
    // the multi-model panel — that one compares five agencies' single runs and
    // so sees model-formulation error; this one sees the chaos in the
    // atmosphere itself, which is what actually bounds the forecast.
    OM_ENSEMBLE: 'https://ensemble-api.open-meteo.com/v1/ensemble',
    // ERA5 reanalysis, used to compute local normals in-browser. Without a
    // normal, "42 °C on day 14" is a number with no meaning attached.
    OM_ARCHIVE: 'https://archive-api.open-meteo.com/v1/archive',
    OM_AIR: 'https://air-quality-api.open-meteo.com/v1/air-quality',
    NWS_BASE: 'https://api.weather.gov',
    SPC_BASE: 'https://www.spc.noaa.gov',
    // NEXRAD Level III storm attribute table: the WSR-88D's own mesocyclone
    // (MDA) and tornado-vortex-signature detections, plus hail and structure.
    STORM_CELLS: 'https://mesonet.agron.iastate.edu/geojson/nexrad_attr.geojson',
    // IEM's tile-service index: a small JSON naming each layer's valid time.
    // Polling this is how the radar knows a new composite exists without
    // re-downloading a single tile.
    TMS_INDEX: 'https://mesonet.agron.iastate.edu/json/tms.json',
    /* Worldwide METARs, for the scorecard outside the US: Iowa State's station
     * directory (one network per country, each with its extent) and its
     * METAR archive, both CORS-open. aviationweather.gov has the same
     * reports but sends no CORS header, so a browser cannot read them. */
    IEM_NETWORKS: 'https://mesonet.agron.iastate.edu/api/1/networks.json',
    IEM_NETWORK: 'https://mesonet.agron.iastate.edu/api/1/network/{id}.json',
    IEM_ASOS: 'https://mesonet.agron.iastate.edu/cgi-bin/request/asos.py',
    // Every NWS local storm report of the last 24 hours, all kinds — the
    // feed SPC's tornado/wind/hail list is drawn from. CORS-open, keyless.
    LSR_GEOJSON: 'https://mesonet.agron.iastate.edu/geojson/lsr.geojson?hours=24',
    // How often to ask each radar source whether it has produced a new scan.
    // The probes are tiny JSON; the imagery only re-fetches on a real change.
    RADAR_LIVE_MS: 60 * 1000,
    /* The model chart's canvas: the lower 48 on an 80×36 lattice (~0.8°),
     * row-major from the south-west corner. 2,880 points arrive as nine
     * four-row requests — the API caps URL length, not locations, and each
     * chunk gzips to ~110 KB. The first cut at 40×18 drew convective cells
     * as single fat blocks; the review was "IT MUST BE MORE GRANULAR". */
    CHART: { NX: 80, NY: 36, CHUNK_ROWS: 4, LAT0: 22, LAT1: 52, LON0: -128, LON1: -64 },
    RAINVIEWER_INDEX: 'https://api.rainviewer.com/public/weather-maps.json',
    /* Reading RainViewer's pixels back as dBZ (js/reflectivity.js). Smoothing
     * off (0_0) because smoothing invents colours that are not in the
     * published table; the colour-scheme number is ignored by the cache —
     * every scheme returns byte-identical Universal Blue tiles. The free
     * cache stops at zoom 7: 8 and up return one placeholder tile. */
    RAINVIEWER_SAMPLE: '/256/{z}/{x}/{y}/2/0_0.png',
    RAINVIEWER_MAX_ZOOM: 7,
    // Where RainViewer has a radar at all: opaque = no coverage, clear = covered.
    RAINVIEWER_COVERAGE: 'https://tilecache.rainviewer.com/v2/coverage/0/256/{z}/{x}/{y}/0/0_0.png',
    /* Esri's canvas basemaps: genuinely keyless raster tiles. CARTO's free
     * basemap began watermarking "API KEY REQUIRED" across every tile —
     * photographed in the field — so it is gone. Note Esri's {z}/{y}/{x}
     * order, and that the canvas set tops out at zoom 16 natively. */
    OSM_TILES: 'https://server.arcgisonline.com/ArcGIS/rest/services/Canvas/World_Dark_Gray_Base/MapServer/tile/{z}/{y}/{x}',
    OSM_TILES_LIGHT: 'https://server.arcgisonline.com/ArcGIS/rest/services/Canvas/World_Light_Gray_Base/MapServer/tile/{z}/{y}/{x}',
    // Drawn in a pane above the radar so place names stay readable over returns.
    OSM_LABELS: 'https://server.arcgisonline.com/ArcGIS/rest/services/Canvas/World_Dark_Gray_Reference/MapServer/tile/{z}/{y}/{x}',
    OSM_LABELS_LIGHT: 'https://server.arcgisonline.com/ArcGIS/rest/services/Canvas/World_Light_Gray_Reference/MapServer/tile/{z}/{y}/{x}',
    // Iowa State Mesonet: real NEXRAD Level III base reflectivity (N0Q), CORS-open.
    NEXRAD_TILES: 'https://mesonet.agron.iastate.edu/cache/tile.py/1.0.0/{product}/{z}/{x}/{y}.png',
    // Single-site RIDGE products, including the velocity data the national
    // mosaic has no equivalent for.
    RIDGE_TILES: 'https://mesonet.agron.iastate.edu/cache/tile.py/1.0.0/ridge::{site}-{product}-0/{z}/{x}/{y}.png',
    NWS_RADAR_STATIONS: 'https://api.weather.gov/radar/stations',
    /* HRRR simulated reflectivity: the model that genuinely looks like
     * radar (3 km, convection-allowing), served as WMS imagery by IEM.
     * Leads run every 15 minutes to +18 h, then hourly to +36 h; the JSON
     * sidecar names the run so valid times are real, not guessed. */
    HRRR_WMS: 'https://mesonet.agron.iastate.edu/cgi-bin/wms/hrrr/refd.cgi',
    /* HRRR CAPE at the model's own 3 km, as WMS imagery from Unidata's
     * public THREDDS server (UCAR) — one dataset per run, named by its
     * initial time. No key; images load cross-origin without CORS. */
    HRRR_CAPE_WMS: 'https://thredds.ucar.edu/thredds/wms/grib/NCEP/HRRR/CONUS_2p5km/HRRR_CONUS_2p5km_{run}.grib2',
    HRRR_META: 'https://mesonet.agron.iastate.edu/data/gis/images/4326/hrrr/refd_0000.json',

    STORAGE_KEY: 'vane.state.v1',
    CACHE_KEY: 'vane.cache.v1',

    // F8: chasers leave the app open in a moving vehicle. Refresh without touch.
    REFRESH_MS: { simple: 10 * 60 * 1000, chase: 2 * 60 * 1000 },
    // How often a long-running session looks for a new app version. The
    // browser only checks on navigation, and an installed app may not
    // navigate for hours.
    UPDATE_CHECK_MS: 60 * 60 * 1000,
    RADAR_FRAME_MS: 500,
    // Future frames carry a network fetch each; they play slower on purpose.
    RADAR_FUTURE_FRAME_MS: 900,

    // Pressure levels requested for the wind profile / hodograph / shear math.
    // 400 hPa (~7.2 km) is included so that 6 km is genuinely bracketed by two
    // levels; 500 hPa alone tops out near 5.9 km and would force extrapolation.
    LEVELS: [1000, 975, 950, 925, 900, 850, 800, 700, 600, 500, 400],

    // Precip intensity thresholds in mm per 15-minute block.
    PRECIP: { trace: 0.05, light: 0.25, moderate: 1.2, heavy: 3.0 },

    /* Deciding whether it is raining on you *now*, which is an observation
     * question and not a forecast one.
     *
     * RADAR_RAIN_DBZ — at and above this, returns overhead are precipitation
     * that is reaching the ground in all but unusual cases. RADAR_TRACE_DBZ
     * down to 15 is the ambiguous band: drizzle, or virga evaporating before
     * it lands. Vane reports that band as "something overhead" rather than
     * calling it rain, because the radar cannot see the last kilometre.
     *
     * STATION_STALE_MIN — routine METARs are hourly, with specials in between,
     * so 75 minutes allows one missed cycle before an observation stops being
     * evidence about right now. */
    OBSERVED: {
      RADAR_RAIN_DBZ: 20,
      RADAR_TRACE_DBZ: 15,
      STATION_STALE_MIN: 75,
      RADAR_STALE_MIN: 20,
      SAMPLE_HALF_KM: 4          // ~8 km box: "on me", not "in the county"
    }
  };

  // WMO 4677 weather codes → label + glyph. Kept deliberately plain (F1): the
  // icon is an affordance, not the product.
  var WMO = {
    0:  ['Clear', '☀'],       1:  ['Mainly clear', '🌤'],
    2:  ['Partly cloudy', '⛅'], 3:  ['Overcast', '☁'],
    45: ['Fog', '🌫'],          48: ['Rime fog', '🌫'],
    51: ['Light drizzle', '🌦'], 53: ['Drizzle', '🌦'], 55: ['Heavy drizzle', '🌧'],
    56: ['Freezing drizzle', '🌧'], 57: ['Freezing drizzle', '🌧'],
    61: ['Light rain', '🌦'],   63: ['Rain', '🌧'],     65: ['Heavy rain', '🌧'],
    66: ['Freezing rain', '🌧'], 67: ['Freezing rain', '🌧'],
    71: ['Light snow', '🌨'],   73: ['Snow', '🌨'],     75: ['Heavy snow', '❄'],
    77: ['Snow grains', '🌨'],
    80: ['Rain showers', '🌦'], 81: ['Showers', '🌧'],  82: ['Violent showers', '⛈'],
    85: ['Snow showers', '🌨'], 86: ['Heavy snow showers', '❄'],
    95: ['Thunderstorm', '⛈'], 96: ['Thunderstorm, hail', '⛈'], 99: ['Severe thunderstorm, hail', '⛈']
  };

  // NWS severity → styling bucket. `extreme`/`severe` drive the Chase-mode nudge (F5).
  var ALERT_RANK = { Extreme: 4, Severe: 3, Moderate: 2, Minor: 1, Unknown: 0 };

  var SHORTCUTS = [
    ['1 – 4', 'Jump to a section'],
    ['M', 'Toggle Simple / Chase mode'],
    ['G', 'Use my location'],
    ['U', 'Toggle units (imperial / metric)'],
    ['S', 'Saved locations'],
    ['/', 'Focus search'],
    ['Space', 'Play / pause radar'],
    ['F', 'Expand radar'],
    ['O', 'Radar options'],
    ['W', 'Wind field layer'],
    ['T', 'Temperature layer'],
    ['C', 'CAPE (instability) layer'],
    ['N', 'Choose a radar site'],
    ['V', 'Reflectivity + velocity dual pane'],
    ['← / →', 'Step forecast hour (Chase)'],
    ['D', 'Jump to the forecaster\'s discussion'],
    ['R', 'Refresh now'],
    [',', 'Settings'],
    ['Esc', 'Close overlay / collapse radar'],
    ['?', 'This help']
  ];

  /* Global NWP models compared in the ensemble view. Each is run by a
   * different meteorological agency on different physics, so agreement between
   * them is a genuine confidence signal rather than one model repeated. */
  var MODELS = [
    { id: 'ecmwf_ifs025',           short: 'ECMWF', name: 'ECMWF IFS',      color: '#ff9f0a' },
    { id: 'gfs_seamless',           short: 'GFS',   name: 'NOAA GFS',       color: '#0a84ff' },
    { id: 'icon_seamless',          short: 'ICON',  name: 'DWD ICON',       color: '#30d158' },
    { id: 'gem_seamless',           short: 'GEM',   name: 'Environment Canada GEM', color: '#bf5af2' },
    { id: 'meteofrance_seamless',   short: 'ARPEGE', name: 'Météo-France ARPEGE',  color: '#ff375f' }
  ];

  /* The model-forecasts viewer: each agency's single daily run, browsable as
   * a scenario. Two more agencies than the hourly agreement card, because the
   * daily endpoint carries them and a chaser reads the Euro-vs-GFS argument
   * by name. Each model publishes to a different horizon and the viewer says
   * so rather than padding with blanks. */
  var MODELS_DAILY = MODELS.concat([
    { id: 'ukmo_seamless', short: 'UKMO', name: 'UK Met Office',  color: '#64d2ff' },
    { id: 'jma_seamless',  short: 'JMA',  name: 'Japan Met Agency', color: '#ffd60a' }
  ]);

  /* Level III products available per site through IEM's RIDGE service.
   * Velocity is the reason single-site mode exists: rotation is a velocity
   * couplet, and no mosaic product shows it. */
  var RADAR_PRODUCTS = [
    { id: 'N0B', label: 'Reflectivity (super-res)', short: 'Refl ×',
      kind: 'reflectivity',
      note: 'Super-resolution base reflectivity, 0.5° tilt' },
    { id: 'N0Q', label: 'Reflectivity', short: 'Refl',
      kind: 'reflectivity',
      note: 'Base reflectivity, 0.5° tilt' },
    { id: 'N0U', label: 'Base velocity', short: 'Vel',
      kind: 'velocity',
      note: 'Base radial velocity, 0.5° tilt. Green is toward the radar, red is away; ' +
            'a tight green/red couplet is rotation.' },
    { id: 'N0S', label: 'Storm-relative velocity', short: 'SRV',
      kind: 'velocity',
      note: 'Storm-relative velocity, 0.5° tilt — storm motion removed, which makes ' +
            'a mesocyclone stand out from the background flow.' }
  ];

  // SPC categorical risk levels. `dn` is the value SPC puts in the GeoJSON.
  var SPC_RISK = {
    2:  { code: 'TSTM', label: 'General thunderstorms', color: '#55BB55', rank: 1 },
    3:  { code: 'MRGL', label: 'Marginal',  color: '#005500', rank: 2 },
    4:  { code: 'SLGT', label: 'Slight',    color: '#DDAA00', rank: 3 },
    5:  { code: 'ENH',  label: 'Enhanced',  color: '#FF6600', rank: 4 },
    6:  { code: 'MDT',  label: 'Moderate',  color: '#CC0000', rank: 5 },
    8:  { code: 'HIGH', label: 'High',      color: '#CC00CC', rank: 6 }
  };

  var SPC_HAZARDS = [
    { key: 'cat',  label: 'Categorical' },
    { key: 'torn', label: 'Tornado' },
    { key: 'hail', label: 'Hail' },
    { key: 'wind', label: 'Wind' }
  ];

  // F7: "customizable alert zones to filter warnings by storm type". Users pick
  // which event families they care about; everything else is muted, not hidden.
  var ALERT_FILTERS = [
    { key: 'tornado',  label: 'Tornado',            match: /tornado/i },
    { key: 'severe',   label: 'Severe thunderstorm', match: /severe thunderstorm/i },
    { key: 'flood',    label: 'Flood / flash flood', match: /flood/i },
    { key: 'winter',   label: 'Winter / ice',        match: /winter|ice|snow|blizzard|freez/i },
    { key: 'wind',     label: 'High wind',           match: /wind(?!.*thunderstorm)|dust/i },
    { key: 'heat',     label: 'Heat / cold',         match: /heat|cold|frost|wind chill/i },
    { key: 'fire',     label: 'Fire weather',        match: /fire|red flag/i },
    { key: 'marine',   label: 'Marine / coastal',    match: /marine|coastal|surf|rip current|small craft/i },
    { key: 'other',    label: 'Everything else',     match: null }
  ];

  /* Extended outlook.
   *
   * ECMWF's IFS ensemble is the reference medium-range system and carries the
   * most members Open-Meteo publishes, so it is what the outlook is built on.
   * 16 days is the full length available; how much of it is *forecast* rather
   * than decoration is measured per location and per run, not asserted here —
   * see js/outlook.js. */
  var OUTLOOK = {
    MODEL: 'ecmwf_ifs025',
    MODEL_LABEL: 'ECMWF IFS ensemble',
    DAYS: 16,
    // Years of ERA5 used for the local normal. Twenty is enough to stabilise a
    // day-of-year mean without reaching so far back that the climate it
    // describes is no longer the one you are standing in.
    NORMAL_YEARS: 20,
    // The normal for a calendar day is pooled over a window either side of it,
    // otherwise a single date's 20 samples are far too noisy to compare against.
    NORMAL_WINDOW_DAYS: 7,
    // A day counts as wet at the threshold the WMO uses for a "rain day".
    WET_MM: 1.0,
    /* Where the forecast stops being a forecast. Skill is not asserted by lead
     * day: it is measured as the ensemble's own p10–p90 spread divided by the
     * climatological p10–p90 spread for the same calendar window. At a ratio of
     * 1 the ensemble is as uncertain as knowing nothing but the season, so it
     * has told you nothing. These are the bands between. */
    SKILL_BANDS: [
      { max: 0.35, key: 'firm',  label: 'Forecast' },
      { max: 0.65, key: 'soft',  label: 'Low confidence' },
      { max: 0.90, key: 'trend', label: 'Trend only' },
      { max: Infinity, key: 'none', label: 'No signal' }
    ]
  };

  /* NWS local storm reports, by kind. Each has a colour AND a glyph, so the
   * map reads without relying on colour alone. */
  var STORM_REPORT_STYLE = {
    tornado: { color: '#ff375f', label: 'Tornado',             glyph: 'T' },
    funnel:  { color: '#ff9f0a', label: 'Funnel / waterspout', glyph: 'F' },
    hail:    { color: '#30d158', label: 'Hail',                glyph: 'H' },
    wind:    { color: '#0a84ff', label: 'Wind',                glyph: 'W' },
    flood:   { color: '#40c8e0', label: 'Flood / heavy rain',  glyph: '≈' },
    winter:  { color: '#bf5af2', label: 'Snow / ice',          glyph: 'S' },
    other:   { color: '#8e8e93', label: 'Other',               glyph: '•' }
  };
  var REPORT_ORDER = ['tornado', 'funnel', 'hail', 'wind', 'flood', 'winter', 'other'];

  CONFIG.WMO = WMO;
  /* HRRR leads as IEM publishes them: every 15 minutes through +18 h,
   * hourly from +19 h to +36 h. 91 stops on the future timeline. */
  var HRRR_LEADS = [];
  for (var m = 15; m <= 1080; m += 15) HRRR_LEADS.push(m);
  for (var m2 = 1140; m2 <= 2160; m2 += 60) HRRR_LEADS.push(m2);
  CONFIG.HRRR_LEADS = HRRR_LEADS;
  /* The leads the PLAY loop visits: hourly to +18 h. Every future frame is
   * a fresh WMS fetch (IEM sends no cache headers), so the animation stays
   * affordable; the scrubber still offers all ninety stops. */
  CONFIG.HRRR_PLAY_LEADS = HRRR_LEADS.filter(function (m) {
    return m % 60 === 0 && m <= 1080;
  });

  CONFIG.ALERT_RANK = ALERT_RANK;
  CONFIG.SHORTCUTS = SHORTCUTS;
  CONFIG.MODELS = MODELS;
  /* The model chart's agencies: the five globals plus HRRR. HRRR's Lambert
   * cone clips the chart box's ocean corners, and one outside point poisons
   * a multi-location request — so it charts an inset lower-48 box. */
  CONFIG.CHART_MODELS = MODELS.concat([{
    id: 'ncep_hrrr_conus', short: 'HRRR', name: 'NOAA HRRR (3 km)', color: '#ff6b35',
    domain: { LAT0: 24, LAT1: 50, LON0: -124, LON1: -67 }
  }]);
  CONFIG.MODELS_DAILY = MODELS_DAILY;
  CONFIG.RADAR_PRODUCTS = RADAR_PRODUCTS;
  CONFIG.SPC_RISK = SPC_RISK;
  CONFIG.SPC_HAZARDS = SPC_HAZARDS;
  CONFIG.ALERT_FILTERS = ALERT_FILTERS;
  CONFIG.STORM_REPORT_STYLE = STORM_REPORT_STYLE;
  CONFIG.REPORT_ORDER = REPORT_ORDER;
  CONFIG.OUTLOOK = OUTLOOK;
  global.VaneConfig = CONFIG;
})(window);
