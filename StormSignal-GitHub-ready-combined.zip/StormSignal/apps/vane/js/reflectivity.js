/* Vane — reading dBZ back out of the radar image.
 *
 * The 3D storm view used to be a smooth cone: a generic storm silhouette
 * scaled by measured heights. It was honest about its numbers and wrong about
 * its shape, because a real echo is not a circle — it has a hook, a notch, a
 * ragged forward flank, and that shape is most of what a chaser reads off the
 * screen. A 3D view that does not resemble the radar it sits beside is
 * decoration.
 *
 * So this module reads the actual pixels. Iowa State serves the NEXRAD tiles
 * with `Access-Control-Allow-Origin: *`, which means the browser can draw them
 * into a canvas and read them back, and IEM publishes the exact 256-entry
 * colour table its N0Q product is rendered with. That makes the inversion
 * exact rather than approximate: every colour in a tile is a lookup, not a
 * nearest-neighbour guess.
 *
 * The ramp below is that published table, verified against live tiles — index
 * i is -32 + i/2 dBZ, in uniform half-decibel steps, which is asserted in the
 * test suite rather than assumed.
 *
 * WHAT THIS BUYS AND WHAT IT DOES NOT. It buys the true horizontal shape and
 * the true intensity field of the 0.5 degree scan. It does not buy a volume:
 * higher elevation tilts are not published, so the vertical distribution is
 * still modelled from the two measured anchors in the storm attribute table
 * (echo top and the height of maximum reflectivity). The panel says exactly
 * that on screen.
 */
(function (global) {
  'use strict';

  /* IEM's published N0Q colour table, packed as RRGGBB per half-decibel from
   * -32 dBZ. Source: mesonet.agron.iastate.edu/GIS/rasters.php?rid=2 */
  var RAMP_HEX =
    '85718f85728f86738d87758b87768b887789897987897a878a7b858b7d848b7e' +
    '848c7f828d81808d82808e837e8f847c8f857c90877b918879918979928b7793' +
    '8d759691539894579b975b9d9a60a09d64a3a068a5a36da8a671aaa976adac7a' +
    'b0af7eb2b283b7b88cbabb90bdbe94bfc199c2c49dc4c7a2c7caa6cacdaaccd0' +
    'afd2d4b4cfd2b4c9ccb4c6c9b4c3c7b4c0c4b4bdc1b4b9beb4b6bbb4b3b9b4b0' +
    'b6b4adb3b4aab0b4a4abb4a0a8b49da5b49aa2b497a0b4949db4919ab4949bb5' +
    '9098b48c95b38892b2808cb07c89af7886ae7483ac7080ab6c7daa6779a96376' +
    'a85f73a75b70a6576da44f67a24b64a14761a0435e9f415b9e4361a24568a648' +
    '6faa4a76ae4d7db24f84b6518bbb5699c3599fc75ba6cb5eadcf60b4d462bbd8' +
    '65c2dc67c9e06ad0e46fd6e868d6d759d6b352d6a24bd69043d67e3cd66d35d6' +
    '5b11d51811d11710cd1710c81610c4160fbc150fb7140eb3140eaf130eab130d' +
    'a6120da2120d9e110c99110c95100c91100b880f0b840e0a800e0a7c0d0a770d' +
    '09730c096f0c096b0b08660b08620a095e09327308467d085b88076f9207849d' +
    '0698a806adb205c1bd05d6c704ead204ffe200ffd800ffd300ffce00ffc900ff' +
    'c400ffc000ffbb00ffb600ffb100ffac00ffa700ffa200ff9900ff9400ff8f00' +
    'ff8a00ff8500ff8000ff0000f80000f10000ea0000e30000d50000cd0000c600' +
    '00bf0000b80000b10000aa0000a300009b00009400008d00007f000078000071' +
    '0000fffffffff5ffffeaffffdfffffd4ffffc9ffffbeffffb3ffff9dffff92ff' +
    'ff75fffc6bfdf960faf656f7f34bf4f040f1ed36efea2bece720e9e10be3b200' +
    'ffac00fca400f79b00f49300ef8800ea8300e87900e27200dd6900db05ecf005' +
    'ebf005eaf005dde005dce005dbe005cdd005ccd004bdc004bcc004bbc004aeb0' +
    '04adb0049ea0049da0049ca0038e90038d90038c90037e80037d80036f70036e' +
    '70036d70025f60025e60024f50024e50024d50023f40023e40023d4001303001' +
    '2f30012020011f20011e203a67b53a66b53a65b53a64b53a63b53a62b5';

  var DBZ_MIN = -32, DBZ_STEP = 0.5;

  var ramp = [];       // [{ r, g, b, dbz }]
  var lut = null;      // packed rgb -> dbz, exact matches

  function buildRamp() {
    if (ramp.length) return ramp;
    for (var i = 0; i * 6 < RAMP_HEX.length; i++) {
      var h = RAMP_HEX.substr(i * 6, 6);
      ramp.push({
        r: parseInt(h.substr(0, 2), 16),
        g: parseInt(h.substr(2, 2), 16),
        b: parseInt(h.substr(4, 2), 16),
        dbz: DBZ_MIN + i * DBZ_STEP
      });
    }
    return ramp;
  }

  function buildLut() {
    if (lut) return lut;
    lut = {};
    buildRamp().forEach(function (e) {
      lut[(e.r << 16) | (e.g << 8) | e.b] = e.dbz;
    });
    return lut;
  }

  /* Exact lookup first, because the tiles are served unscaled and every pixel
   * should be a table entry. The nearest-colour fallback exists only for
   * resampled or recompressed tiles; it is bounded so a wildly off colour
   * (a base-map pixel that leaked in, say) returns null rather than being
   * forced onto the ramp. */
  function toDbz(r, g, b, a) {
    if (a !== undefined && a < 12) return null;
    var exact = buildLut()[(r << 16) | (g << 8) | b];
    if (exact !== undefined) return exact;

    var best = null, bestD = Infinity;
    var t = buildRamp();
    for (var i = 0; i < t.length; i++) {
      var dr = t[i].r - r, dg = t[i].g - g, db = t[i].b - b;
      var d = dr * dr + dg * dg + db * db;
      if (d < bestD) { bestD = d; best = t[i]; }
    }
    return bestD <= 900 ? best.dbz : null;      // within ~30 per channel
  }

  /* ── RainViewer: the same inversion, worldwide ─────────────────────────
   *
   * Outside the United States the only keyless radar is RainViewer's global
   * composite. Its free cache serves one palette whatever scheme the URL
   * asks for — "Universal Blue" — and RainViewer publishes that palette
   * per whole decibel (rainviewer.com/files/rainviewer_api_colors_table.csv,
   * the rain block). Checked against live tiles: every opaque pixel is an
   * exact table colour, and every semi-transparent one is identified by its
   * alpha alone, which matters because canvas readback premultiplies and
   * distorts the RGB of translucent pixels but never their alpha.
   *
   * Two plateaus: the table paints 65-74 dBZ one white and 75-95 one green.
   * Both decode to the plateau's LOWER edge — a reading may be stronger than
   * it says, never weaker. Below -10 dBZ the table is fully transparent. */
  var UB_HEX =                       // 15..64 dBZ, one per decibel, opaque
    '88ddee6cd1eb51c5e836bae51baee200a3e0009ad50091ca0088bf007fb40077' +
    'aa0070a300699c006295005b8e005588005180004e78004a70004768ffee00ff' +
    'e000ffd200ffc500ffb700ffaa00ff9f00ff9500ff8b00ff8100ff4400f23600' +
    'e62800d91b00cd0d00c10000a800008f00007600005d0000ffaaffff9fffff95' +
    'ffff8bffff81ffff77ffff6cffff62ffff58ffff4eff';
  var UB_ALPHA =                     // -10..14 dBZ: translucent, alpha is the key
    [20, 25, 30, 36, 41, 46, 52, 57, 62, 68, 73, 78, 84, 89, 94, 100,
     110, 120, 130, 140, 150, 160, 170, 180, 190];
  var ubRamp = null, ubLut = null, ubAlpha = null;

  function buildUb() {
    if (ubRamp) return;
    ubRamp = []; ubLut = {}; ubAlpha = {};
    for (var i = 0; i * 6 < UB_HEX.length; i++) {
      var h = UB_HEX.substr(i * 6, 6);
      ubRamp.push({ r: parseInt(h.substr(0, 2), 16), g: parseInt(h.substr(2, 2), 16),
                    b: parseInt(h.substr(4, 2), 16), dbz: 15 + i });
    }
    ubRamp.push({ r: 255, g: 255, b: 255, dbz: 65 });
    ubRamp.push({ r: 0, g: 255, b: 0, dbz: 75 });
    ubRamp.forEach(function (e) { ubLut[(e.r << 16) | (e.g << 8) | e.b] = e.dbz; });
    UB_ALPHA.forEach(function (a, k) { ubAlpha[a] = -10 + k; });
  }

  function toDbzRainViewer(r, g, b, a) {
    buildUb();
    if (a === undefined) a = 255;
    if (a === 0) return null;
    if (a < 255) {
      var t = ubAlpha[a];
      return t === undefined ? null : t;
    }
    var exact = ubLut[(r << 16) | (g << 8) | b];
    if (exact !== undefined) return exact;
    var best = null, bestD = Infinity;
    for (var i = 0; i < ubRamp.length; i++) {
      var dr = ubRamp[i].r - r, dg = ubRamp[i].g - g, db = ubRamp[i].b - b;
      var d = dr * dr + dg * dg + db * db;
      if (d < bestD) { bestD = d; best = ubRamp[i]; }
    }
    return bestD <= 900 ? best.dbz : null;
  }

  function colourForRainViewer(dbz) {
    buildUb();
    if (dbz >= 75) return ubRamp[ubRamp.length - 1];
    if (dbz >= 65) return ubRamp[ubRamp.length - 2];
    if (dbz >= 15) return ubRamp[Math.round(dbz) - 15];
    var k = Math.max(0, Math.min(UB_ALPHA.length - 1, Math.round(dbz) + 10));
    return { alpha: UB_ALPHA[k], dbz: -10 + k };
  }

  var RV_MAX_ZOOM = 7;   // the free cache's ceiling; see VaneConfig

  function colourFor(dbz) {
    var t = buildRamp();
    var i = Math.round((dbz - DBZ_MIN) / DBZ_STEP);
    return t[Math.max(0, Math.min(t.length - 1, i))];
  }

  /* ── Web Mercator ───────────────────────────────────────────────────── */

  function lonToTileX(lon, z) { return (lon + 180) / 360 * Math.pow(2, z); }

  function latToTileY(lat, z) {
    var rad = lat * Math.PI / 180;
    return (1 - Math.log(Math.tan(rad) + 1 / Math.cos(rad)) / Math.PI) / 2 * Math.pow(2, z);
  }

  function tileXToLon(x, z) { return x / Math.pow(2, z) * 360 - 180; }

  function tileYToLat(y, z) {
    var n = Math.PI - 2 * Math.PI * y / Math.pow(2, z);
    return 180 / Math.PI * Math.atan(0.5 * (Math.exp(n) - Math.exp(-n)));
  }

  /* ── Sampling ───────────────────────────────────────────────────────── */

  var TILE = 256;
  var cache = {};

  function loadTile(url) {
    if (cache[url]) return cache[url];
    cache[url] = new Promise(function (resolve) {
      var img = new Image();
      // Required for getImageData to work without tainting the canvas. The
      // tiles are served with a permissive CORS header, so this succeeds.
      img.crossOrigin = 'anonymous';
      img.onload = function () { resolve(img); };
      img.onerror = function () { resolve(null); };
      img.src = url;
    });
    return cache[url];
  }

  /* Samples the reflectivity field on a square grid centred on a point, and
   * returns dBZ per grid node in a local east/north frame in kilometres.
   * Resolves to null if nothing could be read — offline, outside NEXRAD
   * coverage, or a tile server that stopped setting CORS headers. */
  function sample(opts) {
    var lat = opts.lat, lon = opts.lon;
    var halfKm = opts.halfKm || 40;
    var n = opts.grid || 64;
    var z = opts.zoom || 8;
    var rv = opts.decode === 'rainviewer';
    var decode = rv ? toDbzRainViewer : toDbz;
    if (rv) z = Math.min(z, RV_MAX_ZOOM);
    var urlFor = opts.urlFor;
    if (!urlFor) return Promise.resolve(null);

    var kmPerDegLat = 111.32;
    var kmPerDegLon = 111.32 * Math.cos(lat * Math.PI / 180);

    // Which tiles cover the box.
    var north = lat + halfKm / kmPerDegLat, south = lat - halfKm / kmPerDegLat;
    var west = lon - halfKm / kmPerDegLon, east = lon + halfKm / kmPerDegLon;
    var x0 = Math.floor(lonToTileX(west, z)), x1 = Math.floor(lonToTileX(east, z));
    var y0 = Math.floor(latToTileY(north, z)), y1 = Math.floor(latToTileY(south, z));

    var jobs = [];
    for (var tx = x0; tx <= x1; tx++) {
      for (var ty = y0; ty <= y1; ty++) {
        (function (tx, ty) {
          jobs.push(loadTile(urlFor(z, tx, ty)).then(function (img) {
            return { tx: tx, ty: ty, img: img };
          }));
        })(tx, ty);
      }
    }
    if (!jobs.length) return Promise.resolve(null);

    return Promise.all(jobs).then(function (tiles) {
      var got = tiles.filter(function (t) { return t.img; });
      if (!got.length) return null;

      // Stitch into one canvas so the grid sampling is a single readback.
      var cols = x1 - x0 + 1, rows = y1 - y0 + 1;
      var canvas = document.createElement('canvas');
      canvas.width = cols * TILE;
      canvas.height = rows * TILE;
      var ctx = canvas.getContext('2d', { willReadFrequently: true });
      got.forEach(function (t) {
        ctx.drawImage(t.img, (t.tx - x0) * TILE, (t.ty - y0) * TILE, TILE, TILE);
      });

      var data;
      try {
        data = ctx.getImageData(0, 0, canvas.width, canvas.height).data;
      } catch (e) {
        return null;                 // canvas tainted: CORS was refused
      }

      /* Each grid node carries the STRONGEST return inside its own footprint,
       * not a single sampled pixel. This matters more than it sounds: the grid
       * is about five image pixels apart, and a storm's core can be only a few
       * pixels across, so point sampling walks straight past it — a cell whose
       * attribute table reports 66 dBZ came back as 34. Taking the maximum is
       * also the physically right reduction for reflectivity, and it is what
       * every radar product does when it decimates. */
      var grid = [], maxDbz = -Infinity, hits = 0;
      var stepX = (lonToTileX(east, z) - lonToTileX(west, z)) * TILE / (n - 1);
      var stepY = (latToTileY(south, z) - latToTileY(north, z)) * TILE / (n - 1);
      var padX = Math.max(1, Math.ceil(stepX / 2));
      var padY = Math.max(1, Math.ceil(stepY / 2));

      for (var j = 0; j < n; j++) {
        var row = [];
        // Row 0 is the north edge, matching image order.
        var la = north - (north - south) * (j / (n - 1));
        var cy = Math.round((latToTileY(la, z) - y0) * TILE);
        for (var i = 0; i < n; i++) {
          var lo = west + (east - west) * (i / (n - 1));
          var cx = Math.round((lonToTileX(lo, z) - x0) * TILE);
          var v = null;

          for (var py = cy - padY; py <= cy + padY; py++) {
            if (py < 0 || py >= canvas.height) continue;
            for (var px = cx - padX; px <= cx + padX; px++) {
              if (px < 0 || px >= canvas.width) continue;
              var k = (py * canvas.width + px) * 4;
              var d = decode(data[k], data[k + 1], data[k + 2], data[k + 3]);
              if (d !== null && (v === null || d > v)) v = d;
            }
          }

          if (v !== null) { hits++; if (v > maxDbz) maxDbz = v; }
          row.push(v);
        }
        grid.push(row);
      }

      /* No echo anywhere in the box. For the storm renderers that is nothing
       * to draw, so the default stays null. But "the radar looked and saw
       * clear sky" is a real observation, and a caller deciding whether it is
       * raining on you needs to tell it apart from "the tiles never loaded" —
       * which is the other thing null means here. `reportClear` hands those
       * callers the empty field, with maxDbz null rather than -Infinity. */
      if (!hits) {
        return opts.reportClear
          ? { grid: grid, size: n, halfKm: halfKm, kmPerCell: (halfKm * 2) / (n - 1),
              maxDbz: null, coverage: 0, zoom: z, clear: true }
          : null;
      }
      return {
        grid: grid,
        size: n,
        halfKm: halfKm,
        kmPerCell: (halfKm * 2) / (n - 1),
        maxDbz: maxDbz,
        coverage: hits / (n * n),
        zoom: z
      };
    });
  }

  /* Does RainViewer have a radar over this point at all? Without asking,
   * a transparent tile over the Sahara reads exactly like clear sky over
   * London — and "radar is clear overhead" where there is no radar is a lie.
   * RainViewer's coverage layer is a mask: opaque where nothing is seen.
   * Resolves true, false, or null when the mask could not be read. */
  function covered(lat, lon, template) {
    var z = RV_MAX_ZOOM;
    var X = lonToTileX(lon, z), Y = latToTileY(lat, z);
    var tx = Math.floor(X), ty = Math.floor(Y);
    var url = template.replace('{z}', z).replace('{x}', tx).replace('{y}', ty);
    return loadTile(url).then(function (img) {
      if (!img) return null;
      var canvas = document.createElement('canvas');
      canvas.width = 1; canvas.height = 1;
      var ctx = canvas.getContext('2d', { willReadFrequently: true });
      ctx.drawImage(img, -Math.floor((X - tx) * TILE), -Math.floor((Y - ty) * TILE));
      try { return ctx.getImageData(0, 0, 1, 1).data[3] === 0; }
      catch (e) { return null; }
    });
  }

  function clearCache() { cache = {}; }

  global.Reflectivity = {
    sample: sample,
    toDbz: toDbz,
    colourFor: colourFor,
    toDbzRainViewer: toDbzRainViewer,
    colourForRainViewer: colourForRainViewer,
    covered: covered,
    ramp: buildRamp,
    lonToTileX: lonToTileX,
    latToTileY: latToTileY,
    tileXToLon: tileXToLon,
    tileYToLat: tileYToLat,
    clearCache: clearCache,
    DBZ_MIN: DBZ_MIN,
    DBZ_STEP: DBZ_STEP
  };
})(window);
