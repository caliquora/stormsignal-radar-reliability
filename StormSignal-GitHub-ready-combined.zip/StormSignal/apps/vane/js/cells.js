/* Vane — storm cell intelligence: "what on this radar should I be looking at?"
 *
 * WHERE THE DETECTIONS COME FROM. Rotation is not something this app infers
 * from a reflectivity image, and it would be dishonest to pretend otherwise.
 * Every mesocyclone and tornado-vortex signature here is the WSR-88D's *own*
 * algorithm output — the Mesocyclone Detection Algorithm and TVS run on the
 * full volumetric Doppler velocity data at the radar site, distributed as the
 * NEXRAD Level III storm attribute table and republished by Iowa State Mesonet.
 * That is strictly better than anything this app could derive: base velocity
 * is not available from any keyless public endpoint, and the operational
 * algorithm sees data the tiles don't contain.
 *
 * WHAT THIS MODULE ADDS on top of those detections:
 *   1. an explainable threat score that fuses rotation, hail and structure
 *      into one ranking, so a chaser can triage 500 cells at a glance;
 *   2. closest-approach maths — will this cell actually reach *you*, and when;
 *   3. cross-reference against the convective environment Vane already derives
 *      (SRH, deep-layer shear), because the same mesocyclone means something
 *      different in 300 m²/s² of helicity than in 50.
 *
 * LIMITS, stated plainly and surfaced in the UI:
 *   - MDA and TVS have well-documented false-alarm rates. A TVS is a velocity
 *     signature, NOT a confirmed tornado.
 *   - Attributes update per volume scan (roughly 4–6 minutes) and the feed is
 *     a rolling national snapshot, so cells carry slightly different valid times.
 *   - NEXRAD is United States only.
 *   - This is never a substitute for an NWS warning. */
(function (global) {
  'use strict';

  var C = global.VaneConfig, U = global.U;

  /* MDA strength rank runs 1 (weak) to 25 (strongest). Well-defined
   * mesocyclones typically sit at 5–9; above 13 is exceptionally rare. */
  function mesoRank(value) {
    if (value === null || value === undefined) return 0;
    if (value === 'NONE' || value === '') return 0;
    var n = parseInt(value, 10);
    return isNaN(n) ? 0 : n;
  }

  function hasTvs(value) {
    return !!value && value !== 'NONE' && value !== '';
  }

  /* VIL density discriminates large hail better than VIL alone: a tall storm
   * spreading the same liquid over more depth is less impressive than a
   * compact one. VIL is kg/m², echo top is kft. */
  function vilDensity(vil, topKft) {
    if (!vil || !topKft) return null;
    var topM = topKft * 304.8;
    return (vil / topM) * 1000;      // g/m³
  }

  /* Explainable scoring. Every contribution carries the reason it fired, so
   * the UI can say *why* a cell is flagged rather than showing a bare number
   * the user has to trust blindly. */
  function score(cell) {
    var reasons = [], total = 0;

    function add(points, label) {
      if (points <= 0) return;
      total += points;
      reasons.push({ points: Math.round(points), label: label });
    }

    if (cell.tvs) {
      add(45, 'Tornado vortex signature');
    }
    if (cell.mesoRank > 0) {
      // rank 5 ≈ well-defined; cap the contribution so hail can still matter.
      add(Math.min(35, cell.mesoRank * 4),
        'Mesocyclone, MDA rank ' + cell.mesoRank +
        (cell.mesoRank >= 5 ? ' (well-defined)' : ' (weak)'));
    }
    if (cell.posh >= 30) add(cell.posh * 0.25, cell.posh + '% chance of severe hail');
    else if (cell.posh > 0) add(cell.posh * 0.15, cell.posh + '% chance of severe hail');

    if (cell.maxSize >= 2) add(18, 'Hail to ' + cell.maxSize.toFixed(2) + '"');
    else if (cell.maxSize >= 1) add(12, 'Hail to ' + cell.maxSize.toFixed(2) + '"');
    else if (cell.maxSize >= 0.75) add(6, 'Severe-criteria hail ' + cell.maxSize.toFixed(2) + '"');

    if (cell.vilDensity !== null) {
      if (cell.vilDensity >= 4) add(15, 'VIL density ' + cell.vilDensity.toFixed(1) + ' g/m³');
      else if (cell.vilDensity >= 3.5) add(10, 'VIL density ' + cell.vilDensity.toFixed(1) + ' g/m³');
      else if (cell.vilDensity >= 2.5) add(5, 'VIL density ' + cell.vilDensity.toFixed(1) + ' g/m³');
    }

    if (cell.maxDbz >= 65) add(10, cell.maxDbz + ' dBZ core');
    else if (cell.maxDbz >= 60) add(7, cell.maxDbz + ' dBZ core');
    else if (cell.maxDbz >= 55) add(4, cell.maxDbz + ' dBZ core');

    if (cell.top >= 50) add(8, 'Echo top ' + Math.round(cell.top) + ' kft');
    else if (cell.top >= 45) add(5, 'Echo top ' + Math.round(cell.top) + ' kft');
    else if (cell.top >= 40) add(3, 'Echo top ' + Math.round(cell.top) + ' kft');

    reasons.sort(function (a, b) { return b.points - a.points; });
    return { total: Math.min(100, Math.round(total)), reasons: reasons };
  }

  var BANDS = [
    { min: 70, key: 'extreme', label: 'Extreme' },
    { min: 45, key: 'high', label: 'High' },
    { min: 25, key: 'elevated', label: 'Elevated' },
    { min: 10, key: 'moderate', label: 'Moderate' },
    { min: 0, key: 'low', label: 'Low' }
  ];

  function band(total) {
    for (var i = 0; i < BANDS.length; i++) if (total >= BANDS[i].min) return BANDS[i];
    return BANDS[BANDS.length - 1];
  }

  /* ── Parsing ────────────────────────────────────────────────────────── */

  function parse(features) {
    return features.map(function (f) {
      var p = f.properties || {};
      var g = f.geometry || {};
      if (!g.coordinates) return null;
      var cell = {
        id: p.nexrad + '-' + p.storm_id,
        site: p.nexrad,
        stormId: p.storm_id,
        lon: g.coordinates[0],
        lat: g.coordinates[1],
        tvs: hasTvs(p.tvs),
        mesoRank: mesoRank(p.meso),
        posh: p.posh || 0,
        poh: p.poh || 0,
        maxSize: p.max_size || 0,
        vil: p.vil || 0,
        maxDbz: p.max_dbz || 0,
        maxDbzHeight: p.max_dbz_height || 0,
        top: p.top || 0,
        // `drct` follows the meteorological convention used everywhere else in
        // this app: the direction the storm is coming FROM. (Confirmed against
        // the live feed — the national median is ~228°, i.e. cells tracking
        // toward the north-east, which is what mid-latitude storms do.)
        fromDeg: p.drct,
        speedKt: p.sknt || 0,
        range: p.range || 0,              // from the radar: Ground Truth reads the beam's view
        valid: p.valid
      };
      cell.vilDensity = vilDensity(cell.vil, cell.top);
      var s = score(cell);
      cell.score = s.total;
      cell.reasons = s.reasons;
      cell.band = band(s.total);
      return cell;
    }).filter(Boolean);
  }

  /* ── Geometry relative to the viewer ────────────────────────────────── */

  // Convert storm motion to a local east/north velocity in km/h.
  function motionVector(cell) {
    // The trained track model's correction, where it has one (js/stormmodel.js).
    if (cell.modelMotion) return cell.modelMotion;
    var kmh = cell.speedKt * 1.852;
    var uv = U.windToUV(kmh, cell.fromDeg);   // same from-convention as wind
    return { east: uv.u, north: uv.v, speedKmh: kmh };
  }

  /* Closest approach of a moving cell to a fixed point, solved in a local
   * flat-earth frame. Good to well under a kilometre at storm-chasing ranges,
   * and far more useful than raw distance: a violent cell moving away matters
   * less than a marginal one heading straight at you. */
  function approach(cell, lat, lon) {
    var kmPerDegLat = 111.32;
    var kmPerDegLon = 111.32 * Math.cos(U.toRad(lat));

    // Vector from viewer to cell, in km.
    var rx = (cell.lon - lon) * kmPerDegLon;
    var ry = (cell.lat - lat) * kmPerDegLat;
    var m = motionVector(cell);

    var distance = Math.sqrt(rx * rx + ry * ry);
    var bearing = (Math.atan2(rx, ry) * 180 / Math.PI + 360) % 360;

    var speed2 = m.east * m.east + m.north * m.north;
    if (speed2 < 1e-6) {
      return { distance: distance, bearing: bearing, stationary: true,
               closest: distance, etaMin: null, approaching: false };
    }

    // t minimising |r + v t|
    var t = -(rx * m.east + ry * m.north) / speed2;         // hours
    var approaching = t > 0;
    var cx = rx + m.east * t, cy = ry + m.north * t;
    var closest = approaching ? Math.sqrt(cx * cx + cy * cy) : distance;

    return {
      distance: distance,
      bearing: bearing,
      stationary: false,
      approaching: approaching,
      closest: closest,
      etaMin: approaching ? t * 60 : null,
      speedKmh: m.speedKmh,
      towardDeg: (Math.atan2(m.east, m.north) * 180 / Math.PI + 360) % 360
    };
  }

  // Where the cell will be in `minutes`, for drawing a projected track.
  function project(cell, minutes) {
    var m = motionVector(cell);
    var hours = minutes / 60;
    var kmPerDegLat = 111.32;
    var kmPerDegLon = 111.32 * Math.cos(U.toRad(cell.lat));
    return {
      lat: cell.lat + (m.north * hours) / kmPerDegLat,
      lon: cell.lon + (m.east * hours) / kmPerDegLon
    };
  }

  /* ── Per-cell trend learning ─────────────────────────────────────────
   * The attribute table is a snapshot; a chaser's real question is the
   * derivative. The feed carries stable per-radar cell ids, so each scan's
   * attributes can be strung into a history and a least-squares line
   * fitted through it: a cell whose core has climbed 38 → 51 dBZ across
   * four scans is organising, whatever its current rank says. Same
   * learning discipline as VaneMotion and the scorecard — real
   * observations in, a fit with its evidence out, all on-device.
   *
   * HONESTY RULES. A trend needs at least three scans spanning eight
   * minutes — two points is a line through anything. The verdict comes
   * from the fitted slope, never from eyeballing first-vs-last. Histories
   * go stale and are dropped; ids are per-radar, so a cell handed between
   * radars starts a fresh history rather than inheriting another storm's. */

  var TREND_MAX_SCANS = 8;
  var TREND_STALE_MS = 40 * 60000;
  var TREND_MIN_SCANS = 3;
  var TREND_MIN_SPAN_MIN = 8;
  var TREND_DBZ_RATE = 3;        // dBZ per 10 min: the strengthening bar
  var TREND_TOP_RATE = 3;        // kft per 10 min: worth mentioning

  var trendHistory = {};         // cell.id → [{ t, dbz, top, lat, lon }]

  function ingest(cells, now) {
    now = now || Date.now();
    (cells || []).forEach(function (c) {
      var t = c.valid ? Date.parse(c.valid) : NaN;
      if (!isFinite(t)) t = now;
      var h = trendHistory[c.id] || (trendHistory[c.id] = []);
      // One point per volume scan: a re-fetch of the same scan is not news.
      if (h.length && h[h.length - 1].t === t) return;
      h.push({ t: t, dbz: c.maxDbz, top: c.top, lat: c.lat, lon: c.lon });
      if (h.length > TREND_MAX_SCANS) h.shift();
    });
    Object.keys(trendHistory).forEach(function (id) {
      var h = trendHistory[id];
      if (!h.length || now - h[h.length - 1].t > TREND_STALE_MS) {
        delete trendHistory[id];
      }
    });
  }

  // Least-squares slope of `key` against time, in units per 10 minutes.
  function trendSlope(h, key) {
    var n = h.length, st = 0, sv = 0, stt = 0, stv = 0;
    for (var i = 0; i < n; i++) {
      var t = (h[i].t - h[0].t) / 600000;      // 10-minute units
      st += t; sv += h[i][key]; stt += t * t; stv += t * h[i][key];
    }
    var den = n * stt - st * st;
    return den ? (n * stv - st * sv) / den : 0;
  }

  function trendOf(id) {
    return fitTrend(trendHistory[id]);
  }

  /* The one trend algorithm in the app. Both the automatic per-cell
   * histories above and the persisted followed-storm stories
   * (js/intelligence-ui.js) fit through here, so "strengthening" means
   * the same thing on every surface. Input: [{ t, dbz, top }], oldest
   * first, any length — the window is the caller's. */
  function fitTrend(h) {
    if (!h || h.length < TREND_MIN_SCANS) return null;
    var spanMin = (h[h.length - 1].t - h[0].t) / 60000;
    if (spanMin < TREND_MIN_SPAN_MIN) return null;

    var dbzRate = trendSlope(h, 'dbz');
    var topRate = trendSlope(h, 'top');
    return {
      dir: dbzRate >= TREND_DBZ_RATE ? 'strengthening'
         : dbzRate <= -TREND_DBZ_RATE ? 'weakening' : 'steady',
      dbzRate: dbzRate,
      topRate: topRate,
      topNote: Math.abs(topRate) >= TREND_TOP_RATE,
      scans: h.length,
      spanMin: Math.round(spanMin),
      firstDbz: h[0].dbz, lastDbz: h[h.length - 1].dbz,
      firstTop: h[0].top, lastTop: h[h.length - 1].top
    };
  }

  function resetTrends() { trendHistory = {}; }

  /* The trained track model (js/stormmodel.js): a corrected 30-minute
   * displacement replaces the table's straight line as each convective
   * cell's motion, so closest approach, the threat banner and the map's
   * projected tracks all use it. Each call is remembered and graded
   * against the scan that arrives thirty minutes on, beside the straight
   * line it replaced. */
  function applyTrackModel(cells) {
    var SM = global.StormModel, W = SM && SM.weights();
    if (!W || !W.track) return;
    if (SM.grade) SM.grade(historyOf);
    (cells || []).forEach(function (c) {
      if (c.maxDbz < W.meta.minDbz) return;
      var h = historyOf(c.id);
      var tk = SM.track(c, h);
      if (!tk) return;
      c.modelMotion = { east: tk.east * 2, north: tk.north * 2,
                        speedKmh: Math.sqrt(tk.east * tk.east + tk.north * tk.north) * 2 };
      c.trackWatched = tk.watched;
      if (SM.noteTrack && h.length) {
        var sl = straightLine(c, 30);
        SM.noteTrack(c.id, h[h.length - 1].t, { lat: tk.lat, lon: tk.lon }, sl);
      }
    });
  }

  function straightLine(cell, minutes) {
    var kmh = cell.speedKt * 1.852, uv = U.windToUV(kmh, cell.fromDeg), hours = minutes / 60;
    return { lat: cell.lat + uv.v * hours / 111.32,
             lon: cell.lon + uv.u * hours / (111.32 * Math.cos(U.toRad(cell.lat))) };
  }

  // A copy of one cell's scan history, for the storm models (js/stormmodel.js).
  function historyOf(id) { return (trendHistory[id] || []).slice(); }

  /* ── Selection ──────────────────────────────────────────────────────── */

  var state = { cells: [], fetchedAt: 0, generatedAt: null, error: null };

  function load() {
    return global.API.stormCells().then(function (res) {
      state.cells = parse(res.features);
      state.generatedAt = res.generatedAt;
      state.fetchedAt = Date.now();
      state.error = null;
      // Every scan feeds the per-cell histories the trend fits read.
      ingest(state.cells);
      applyTrackModel(state.cells);
      return state.cells;
    }).catch(function (e) {
      state.error = e.message;
      return [];
    });
  }

  /* Cells worth surfacing near a point, ranked by threat then proximity.
   * `minScore` filters out the long tail of ordinary showers — the feed
   * carries every tracked cell in the country, most of which are nothing. */
  function near(lat, lon, radiusKm, minScore) {
    var r = radiusKm || 300;
    var floor = minScore === undefined ? 10 : minScore;
    return state.cells.map(function (c) {
      var a = approach(c, lat, lon);
      return Object.assign({}, c, { approach: a, trend: trendOf(c.id) });
    }).filter(function (c) {
      return c.approach.distance <= r && c.score >= floor;
    }).sort(function (a, b) {
      if (b.score !== a.score) return b.score - a.score;
      return a.approach.distance - b.approach.distance;
    });
  }

  /* The single most relevant cell to the viewer: something notable that is
   * actually going to arrive. This is what Simple mode surfaces — a casual
   * user does not want a ranked table, they want "a severe storm reaches you
   * in about 40 minutes". */
  function threatToPoint(lat, lon, opts) {
    opts = opts || {};
    var withinKm = opts.withinKm || 25;      // how close counts as "hits you"
    var horizonMin = opts.horizonMin || 90;

    var candidates = near(lat, lon, 250, 15).filter(function (c) {
      return c.approach.approaching &&
        c.approach.closest <= withinKm &&
        c.approach.etaMin !== null &&
        c.approach.etaMin <= horizonMin;
    });
    if (!candidates.length) return null;

    // Soonest arrival wins ties on score — imminence is the point.
    candidates.sort(function (a, b) {
      if (b.score !== a.score) return b.score - a.score;
      return a.approach.etaMin - b.approach.etaMin;
    });
    return candidates[0];
  }

  /* Environmental context. The detection is the radar's; this says whether the
   * air around it supports what the radar is seeing. Explicitly labelled in
   * the UI as model guidance, not observation. */
  function environment(cell, convective) {
    if (!convective) return null;
    var notes = [];
    if (convective.srh1 !== null && convective.srh1 !== undefined) {
      var srh = Math.abs(convective.srh1);
      if (srh >= 250) notes.push('very large low-level helicity (' + Math.round(srh) + ' m²/s²)');
      else if (srh >= 150) notes.push('supportive low-level helicity (' + Math.round(srh) + ' m²/s²)');
      else if (srh < 75 && cell.mesoRank > 0) {
        notes.push('but the modelled low-level helicity is weak (' + Math.round(srh) + ' m²/s²)');
      }
    }
    if (convective.shear6) {
      var sh = convective.shear6.magnitude;
      if (sh >= 18) notes.push('strong deep-layer shear');
      else if (sh < 10 && cell.mesoRank > 0) notes.push('weak deep-layer shear for a sustained mesocyclone');
    }
    if (convective.cape !== null && convective.cape !== undefined) {
      if (convective.cape >= 2500) notes.push('strong instability');
      else if (convective.cape < 500) notes.push('limited instability');
    }
    return notes.length ? notes.join(', ') + '.' : null;
  }

  global.Cells = {
    state: state,
    load: load,
    parse: parse,
    near: near,
    threatToPoint: threatToPoint,
    approach: approach,
    project: project,
    score: score,
    historyOf: historyOf,
    applyTrackModel: applyTrackModel,
    band: band,
    vilDensity: vilDensity,
    mesoRank: mesoRank,
    hasTvs: hasTvs,
    environment: environment,
    motionVector: motionVector,
    // Per-cell trend learning, exported for the test suite too.
    ingest: ingest,
    trendOf: trendOf,
    fitTrend: fitTrend,
    resetTrends: resetTrends,
    BANDS: BANDS
  };
})(window);
