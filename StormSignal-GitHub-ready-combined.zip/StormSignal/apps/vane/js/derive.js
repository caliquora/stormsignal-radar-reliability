/* Vane — derived meteorology, computed in the browser from public model data.
 *
 * Nothing here is vendor-supplied. Shear, storm motion and SRH are standard
 * textbook computations over Open-Meteo pressure-level winds; the UI labels
 * them as derived model guidance rather than observation (see F7). */
(function (global) {
  'use strict';

  var C = global.VaneConfig, U = global.U;

  /* ── Is it raining on me right now? ──────────────────────────────────
   *
   * This is an observation question, and the nowcast was answering it with a
   * forecast. Open-Meteo's 15-minute precipitation is model output: when the
   * model has missed a shower, the app said "no rain expected in the next 2
   * hours" to somebody standing in the rain. A forecast that contradicts the
   * window is not a forecast anyone will trust again.
   *
   * Vane already fetches two things that actually observe the sky and only
   * ever displayed them elsewhere:
   *
   *   1. The nearest METAR — an instrument at an airport, reporting what is
   *      falling at the ground. Highest authority, but it can be 20 km away
   *      and up to an hour old.
   *   2. The radar overhead — read straight out of the NEXRAD tiles the app
   *      is already drawing. Local and current, but it sees a beam a few
   *      hundred metres up at best, so it cannot tell rain from virga.
   *
   * Neither is authoritative alone, so both are reported, and the model is
   * ranked below both rather than above them. */

  /* METAR present-weather groups that mean precipitation is falling here.
   * `thunderstorms` is deliberately absent: TS on its own is thunder, and dry
   * thunderstorms are a real thing — one accompanied by rain also carries the
   * rain group, which is caught on its own. */
  var WX_PRECIP = {
    rain: 'Rain', drizzle: 'Drizzle', snow: 'Snow', snow_grains: 'Snow grains',
    snow_pellets: 'Snow pellets', ice_pellets: 'Sleet', ice_crystals: 'Ice crystals',
    hail: 'Hail', small_hail: 'Small hail', freezing_rain: 'Freezing rain',
    freezing_drizzle: 'Freezing drizzle', unknown_precipitation: 'Precipitation'
  };

  /* Raw METAR fallback, for reports that carry the group but no structured
   * present weather. Intensity, then descriptor, then phenomenon. */
  var METAR_WX = /^(-|\+)?(VC)?(MI|BC|PR|DR|BL|SH|TS|FZ)?((?:DZ|RA|SN|SG|IC|PL|GR|GS|UP){1,3})$/;
  var METAR_NAME = {
    DZ: 'Drizzle', RA: 'Rain', SN: 'Snow', SG: 'Snow grains', IC: 'Ice crystals',
    PL: 'Sleet', GR: 'Hail', GS: 'Small hail', UP: 'Precipitation'
  };

  /* An observed phenomenon as the nearest WMO 4677 code, so the hero's icon and
   * condition line can follow the observation instead of contradicting it. The
   * app already speaks WMO everywhere; translating here means nothing
   * downstream needs a second vocabulary. */
  function wmoFor(kind, intensity, showers) {
    var i = intensity === 'light' ? 0 : intensity === 'heavy' ? 2 : 1;
    var table = {
      rain: showers ? [80, 81, 82] : [61, 63, 65],
      drizzle: [51, 53, 55],
      freezing_rain: [66, 66, 67],
      freezing_drizzle: [56, 56, 57],
      snow: showers ? [85, 86, 86] : [71, 73, 75],
      snow_grains: [77, 77, 77],
      snow_pellets: [85, 86, 86],
      ice_pellets: [79, 79, 79],
      ice_crystals: [79, 79, 79],
      hail: [96, 96, 99],
      small_hail: [96, 96, 99],
      unknown_precipitation: [61, 63, 65]
    };
    return table[kind] ? table[kind][i] : null;
  }

  var METAR_KIND = {
    DZ: 'drizzle', RA: 'rain', SN: 'snow', SG: 'snow_grains', IC: 'ice_crystals',
    PL: 'ice_pellets', GR: 'hail', GS: 'small_hail', UP: 'unknown_precipitation'
  };

  function parseMetar(raw) {
    if (!raw) return null;
    // Everything after RMK is remarks, where RAB05 means "rain began at :05"
    // — past weather, and reading it as present weather would invent rain.
    var body = String(raw).split(/\sRMK\b/)[0];
    var tokens = body.split(/\s+/);
    for (var i = 0; i < tokens.length; i++) {
      var m = METAR_WX.exec(tokens[i]);
      if (!m) continue;
      var kinds = m[4].match(/../g) || [];
      var intensity = m[1] === '-' ? 'light' : m[1] === '+' ? 'heavy' : null;
      var showers = m[3] === 'SH';
      return {
        vicinity: m[2] === 'VC',
        intensity: intensity,
        showers: showers,
        label: kinds.map(function (k) { return METAR_NAME[k]; }).filter(Boolean).join(' and '),
        // The heaviest phenomenon in the group drives the icon.
        code: kinds.reduce(function (best, k) {
          var c = wmoFor(METAR_KIND[k], intensity, showers);
          return c !== null && (best === null || c > best) ? c : best;
        }, null),
        token: tokens[i]
      };
    }
    return null;
  }

  /* What the nearest station is reporting, or null if it cannot say. Structured
   * present weather is preferred over the raw text because it is already
   * parsed by the NWS; the raw report is the fallback. */
  function stationPrecip(obs, now) {
    if (!obs) return null;
    var ageMin = obs.time ? ((now || Date.now()) - new Date(obs.time).getTime()) / 60000 : null;
    if (ageMin === null || isNaN(ageMin)) return null;
    // Too old to be evidence about now — and a clock-skewed future timestamp
    // is not evidence either.
    if (ageMin > C.OBSERVED.STATION_STALE_MIN || ageMin < -5) return null;

    var out = { station: obs.station || null, ageMin: Math.max(0, Math.round(ageMin)) };

    var pw = obs.presentWeather;
    if (pw && pw.length) {
      var hits = [], vicinityOnly = true, code = null;
      for (var i = 0; i < pw.length; i++) {
        var name = WX_PRECIP[pw[i].weather];
        if (!name) continue;
        var raw = String(pw[i].rawString || '');
        if (raw.indexOf('VC') === 0) continue;          // in the vicinity, not here
        vicinityOnly = false;
        hits.push(pw[i].intensity === 'light' ? 'Light ' + name.toLowerCase()
                : pw[i].intensity === 'heavy' ? 'Heavy ' + name.toLowerCase()
                : name);
        var c = wmoFor(pw[i].weather, pw[i].intensity,
          /SH/.test(raw) || pw[i].modifier === 'showers');
        if (c !== null && (code === null || c > code)) code = c;
      }
      if (hits.length) {
        out.raining = true;
        out.label = hits.join(' and ');
        out.code = code;
        return out;
      }
      // Present weather was reported and none of it was precipitation.
      if (!vicinityOnly || pw.length) { out.raining = false; return out; }
    }

    var m = parseMetar(obs.raw);
    if (m && !m.vicinity) {
      out.raining = true;
      out.label = (m.intensity === 'light' ? 'Light ' + m.label.toLowerCase()
                 : m.intensity === 'heavy' ? 'Heavy ' + m.label.toLowerCase()
                 : m.label) + (m.showers ? ' showers' : '');
      out.code = m.code;
      return out;
    }
    if (obs.raw || pw) { out.raining = false; return out; }
    return null;                       // nothing to read: no verdict either way
  }

  /* The single "is it raining" verdict, from every source that can speak.
   *
   * `raining: true` needs one source that observes the ground or close to it.
   * `raining: false` is asserted only when the best available source says so —
   * absence of a reading is not a dry report, and is returned as null. */
  function observedPrecip(opts) {
    opts = opts || {};
    var now = opts.now || Date.now();
    var out = { station: null, radar: null, model: null, raining: false, why: null };

    out.station = stationPrecip(opts.observation, now);

    var r = opts.overhead;
    if (r && typeof r.dbz === 'number' &&
        (!r.at || (now - r.at) / 60000 <= C.OBSERVED.RADAR_STALE_MIN)) {
      out.radar = {
        dbz: Math.round(r.dbz),
        raining: r.dbz >= C.OBSERVED.RADAR_RAIN_DBZ,
        // The band the radar cannot resolve: drizzle, or rain evaporating on
        // the way down. Reported, but never used to assert rain.
        trace: r.dbz >= C.OBSERVED.RADAR_TRACE_DBZ && r.dbz < C.OBSERVED.RADAR_RAIN_DBZ
      };
    }

    var cur = opts.current;
    if (cur && typeof cur.precipitation === 'number') {
      out.model = { mm: cur.precipitation, raining: cur.precipitation >= C.PRECIP.trace };
    }

    /* Authority order, and the reasoning is not "the ground always wins".
     *
     * The METAR stands on the ground but at an airport that can be 20 km away,
     * and a summer shower is smaller than that — a dry airport is no evidence
     * that your own street is dry. The radar sample is taken directly
     * overhead, so for the question "is it raining on *me*" it is the more
     * local reading, and it is allowed to override a dry station.
     *
     * What it is not allowed to do is override on a weak echo. Virga is the
     * real risk in that trade, and it is handled by the 20 dBZ floor and the
     * 15–20 dBZ band that is reported but never asserted — not by throwing the
     * local reading away. Both numbers are shown either way, so a disagreement
     * is visible rather than resolved behind the reader's back.
     *
     * The model ranks below both, and only speaks when neither can. */
    if (out.station && out.station.raining) { out.raining = true; out.why = 'station'; }
    else if (out.radar && out.radar.raining) { out.raining = true; out.why = 'radar'; }
    else if (!out.station && !out.radar && out.model && out.model.raining) {
      out.raining = true; out.why = 'model';
    } else if (out.station) { out.why = 'station'; }
    else if (out.radar) { out.why = 'radar'; }
    else if (out.model) { out.why = 'model'; }
    else return null;                  // nothing observed anything

    return out;
  }

  /* ── Nowcast: answer the one question casual users ask (F4) ─────────── */

  function nowcast(data) {
    var m = data.minutely_15;
    if (!m || !m.time) return null;

    var now = Date.now();
    var tz = data.utc_offset_seconds || 0;
    var blocks = [];
    for (var i = 0; i < m.time.length; i++) {
      var t = U.parseLocal(m.time[i]);
      // Keep the block containing "now" plus everything ahead of it. The
      // comparison must use the location's UTC offset, not the device's.
      if (U.epochOf(m.time[i], tz) + 15 * 60000 < now - 15 * 60000) continue;
      blocks.push({
        time: t,
        at: U.epochOf(m.time[i], tz),        // real instant: end of the 15-min block
        mm: m.precipitation[i] === null ? 0 : m.precipitation[i],
        prob: m.precipitation_probability ? m.precipitation_probability[i] : null,
        code: m.weather_code ? m.weather_code[i] : null
      });
      if (blocks.length >= 8) break;         // 8 × 15 min = 2 hours
    }
    if (!blocks.length) return null;

    var wet = function (b) { return b.mm >= C.PRECIP.trace; };
    var anyWet = blocks.some(wet);
    var startingWet = wet(blocks[0]);
    var peak = blocks.reduce(function (a, b) { return b.mm > a.mm ? b : a; }, blocks[0]);

    var out = { blocks: blocks, any: anyWet, raining: startingWet, peak: peak };

    if (!anyWet) {
      out.state = 'dry';
      var maxProb = blocks.reduce(function (a, b) {
        return Math.max(a, b.prob === null ? 0 : b.prob);
      }, 0);
      out.maxProb = maxProb;
      return out;
    }

    if (startingWet) {
      // Currently precipitating — the useful answer is when it stops.
      var stopIdx = -1;
      for (var j = 0; j < blocks.length; j++) { if (!wet(blocks[j])) { stopIdx = j; break; } }
      out.state = stopIdx === -1 ? 'ongoing' : 'stopping';
      if (stopIdx !== -1) out.stopTime = blocks[stopIdx].time;
      return out;
    }

    // Dry now, wet later — when does it start, and for how long.
    var startIdx = blocks.findIndex(wet);
    var endIdx = startIdx;
    while (endIdx + 1 < blocks.length && wet(blocks[endIdx + 1])) endIdx++;
    out.state = 'starting';
    out.startTime = blocks[startIdx].time;
    // The block holds the 15 minutes BEFORE its stamp; mid-block is the
    // fairest single instant for "when it starts".
    out.startAt = blocks[startIdx].at - 7.5 * 60000;
    out.durationMin = (endIdx - startIdx + 1) * 15;
    out.continues = endIdx === blocks.length - 1;
    return out;
  }

  function intensityLabel(mm) {
    if (mm < C.PRECIP.trace) return 'none';
    if (mm < C.PRECIP.light) return 'trace';
    if (mm < C.PRECIP.moderate) return 'light';
    if (mm < C.PRECIP.heavy) return 'moderate';
    return 'heavy';
  }

  /* ── Wind profile assembly ──────────────────────────────────────────── */

  // Build a surface-to-500 hPa profile for one forecast hour, in metres AGL.
  function buildProfile(sound, hourIndex, surfaceWind) {
    if (!sound || !sound.hourly) return null;
    var h = sound.hourly;
    var elev = typeof sound.elevation === 'number' ? sound.elevation : 0;

    var levels = [];
    C.LEVELS.forEach(function (p) {
      var spd = h['wind_speed_' + p + 'hPa'];
      var dir = h['wind_direction_' + p + 'hPa'];
      var gh = h['geopotential_height_' + p + 'hPa'];
      var tp = h['temperature_' + p + 'hPa'];
      if (!spd || !dir || !gh) return;
      var s = spd[hourIndex], d = dir[hourIndex], g = gh[hourIndex];
      if (s === null || d === null || g === null) return;
      var agl = g - elev;
      if (agl < 0) return;                       // level is underground here
      var uv = U.windToUV(s, d);
      levels.push({
        p: p, agl: agl, u: uv.u, v: uv.v, speed: s, dir: d,
        temp: tp ? tp[hourIndex] : null
      });
    });

    // Anchor the profile at the 10 m wind so shear is measured from the ground up.
    if (surfaceWind && surfaceWind.speed !== null && surfaceWind.speed !== undefined) {
      var suv = U.windToUV(surfaceWind.speed, surfaceWind.dir);
      levels.unshift({
        p: null, agl: 10, u: suv.u, v: suv.v,
        speed: surfaceWind.speed, dir: surfaceWind.dir, temp: null, surface: true
      });
    }

    levels.sort(function (a, b) { return a.agl - b.agl; });
    return levels.length >= 3 ? { levels: levels, elevation: elev } : null;
  }

  // How far above the topmost level we'll still answer, by clamping to it.
  // At an elevated site the 400 hPa surface can sit just under 6 km AGL, and
  // refusing to report 0–6 km shear there would blank out the single most
  // useful chase parameter. Beyond this margin we return null rather than
  // silently pass off a much lower level as the 6 km wind.
  var TOP_CLAMP_M = 1200;

  // Linear interpolation of the wind vector at an arbitrary height AGL.
  function windAt(levels, agl) {
    if (!levels.length) return null;
    if (agl <= levels[0].agl) return { u: levels[0].u, v: levels[0].v };
    for (var i = 0; i < levels.length - 1; i++) {
      var a = levels[i], b = levels[i + 1];
      if (agl >= a.agl && agl <= b.agl) {
        var t = (agl - a.agl) / (b.agl - a.agl || 1);
        return { u: U.lerp(a.u, b.u, t), v: U.lerp(a.v, b.v, t) };
      }
    }
    var top = levels[levels.length - 1];
    if (agl - top.agl <= TOP_CLAMP_M) return { u: top.u, v: top.v, clamped: true };
    return null;   // too far above the profile to answer honestly
  }

  function bulkShear(levels, topAgl) {
    var top = windAt(levels, topAgl), bot = levels[0];
    if (!top) return null;
    var du = top.u - bot.u, dv = top.v - bot.v;
    return { u: du, v: dv, magnitude: Math.sqrt(du * du + dv * dv) };
  }

  // Depth-weighted mean wind through a layer, sampled every 250 m.
  function meanWind(levels, bottomAgl, topAgl) {
    var su = 0, sv = 0, n = 0;
    for (var z = bottomAgl; z <= topAgl; z += 250) {
      var w = windAt(levels, z);
      if (!w) break;
      su += w.u; sv += w.v; n++;
    }
    return n ? { u: su / n, v: sv / n } : null;
  }

  /* Bunkers internal dynamics method — right- and left-moving supercell motion.
   * V_RM = V_mean(0–6 km) + D · (V_shear × k̂)/|V_shear|, with D = 7.5 m/s. */
  function stormMotion(levels) {
    var mean = meanWind(levels, 0, 6000);
    var shear = bulkShear(levels, 6000);
    if (!mean || !shear || shear.magnitude < 0.1) return null;
    var D = 7.5;
    var px = shear.v / shear.magnitude, py = -shear.u / shear.magnitude;   // right of shear
    var rm = { u: mean.u + D * px, v: mean.v + D * py };
    var lm = { u: mean.u - D * px, v: mean.v - D * py };
    return {
      right: Object.assign(rm, U.uvToWind(rm.u, rm.v)),
      left: Object.assign(lm, U.uvToWind(lm.u, lm.v)),
      mean: Object.assign({}, mean, U.uvToWind(mean.u, mean.v))
    };
  }

  /* Storm-relative helicity, integrated over discrete 100 m sub-layers.
   * SRH = Σ (u_{n+1} − c_u)(v_n − c_v) − (u_n − c_u)(v_{n+1} − c_v) */
  function srh(levels, topAgl, motion) {
    if (!motion) return null;
    var cu = motion.u, cv = motion.v, total = 0;
    for (var z = 0; z < topAgl; z += 100) {
      var a = windAt(levels, z), b = windAt(levels, Math.min(z + 100, topAgl));
      if (!a || !b) return null;
      total += (b.u - cu) * (a.v - cv) - (a.u - cu) * (b.v - cv);
    }
    return total;   // m²/s²
  }

  /* ── Composite: the numbers a chaser reads first ────────────────────── */

  function convective(sound, hourIndex, surfaceWind) {
    if (!sound || !sound.hourly) return null;
    var h = sound.hourly;
    var pick = function (k) {
      return h[k] && h[k][hourIndex] !== undefined && h[k][hourIndex] !== null
        ? h[k][hourIndex] : null;
    };

    var prof = buildProfile(sound, hourIndex, surfaceWind);
    var out = {
      time: U.parseLocal(h.time[hourIndex]),
      cape: pick('cape'),
      cin: pick('convective_inhibition'),
      li: pick('lifted_index'),
      freezingLevel: pick('freezing_level_height'),
      pbl: pick('boundary_layer_height'),
      profile: prof
    };

    if (prof) {
      var L = prof.levels;
      out.shear1 = bulkShear(L, 1000);
      out.shear3 = bulkShear(L, 3000);
      out.shear6 = bulkShear(L, 6000);
      out.motion = stormMotion(L);
      out.srh1 = srh(L, 1000, out.motion && out.motion.right);
      out.srh3 = srh(L, 3000, out.motion && out.motion.right);
    }

    /* Lifting condensation level — where cloud base actually sits, which is
     * the number that decides what a storm *looks* like. A low LCL under a
     * supercell puts the wall cloud close to the ground and is the classic
     * photogenic (and tornadic) setup; a high LCL leaves a bare, ragged base
     * a mile up with nothing underneath it.
     *
     * Espy's approximation: 125 m per degree of surface dewpoint depression.
     * It is the rule of thumb chasers actually use, good to a couple of
     * hundred metres in a well-mixed boundary layer, and it is labelled as an
     * approximation everywhere it surfaces rather than dressed up as a
     * parcel calculation the pressure-level data cannot support. */
    if (surfaceWind && surfaceWind.temp !== undefined && surfaceWind.temp !== null &&
        surfaceWind.dewpoint !== undefined && surfaceWind.dewpoint !== null) {
      var depression = surfaceWind.temp - surfaceWind.dewpoint;
      out.lcl = Math.max(0, depression) * 125;          // metres AGL
      out.lclApproximate = true;
    }

    // A crude supercell-favourability blend of CAPE, 0–6 km shear and 0–1 km SRH.
    // Deliberately labelled "index" not "SCP" — it is not the SPC formulation and
    // shouldn't be read as one.
    if (out.cape !== null && out.shear6 && out.srh1 !== null) {
      var capeTerm = out.cape / 1000;
      var shearTerm = U.clamp(out.shear6.magnitude / 20, 0, 2);
      var srhTerm = Math.abs(out.srh1) / 150;
      out.index = capeTerm * shearTerm * srhTerm;
    }
    return out;
  }

  // Plain-language read on the derived numbers, so Chase mode isn't only for
  // people who already know what 0–1 km SRH means.
  function convectiveSummary(cv) {
    if (!cv) return null;
    var parts = [];
    if (cv.cape !== null) {
      if (cv.cape < 300) parts.push('Little instability');
      else if (cv.cape < 1000) parts.push('Marginal instability');
      else if (cv.cape < 2500) parts.push('Moderate instability');
      else parts.push('Strong instability');
    }
    if (cv.shear6) {
      var s = cv.shear6.magnitude;
      if (s < 10) parts.push('weak deep-layer shear (pulse/multicell)');
      else if (s < 18) parts.push('modest shear (organised multicell)');
      else parts.push('strong shear (supercell-supportive)');
    }
    if (cv.cin !== null && cv.cin < -100) parts.push('strong cap in place');
    if (cv.srh1 !== null && Math.abs(cv.srh1) > 150) parts.push('large low-level helicity');
    return parts.length ? parts.join(', ') + '.' : null;
  }

  /* ── The icon a day (or an hour) gets ─────────────────────────────────
   * Open-Meteo's weather code is the most significant weather in ANY hour
   * of the period, from one model run: a trace of drizzle in one hour makes
   * the whole day "rain" whatever its chance. "It says rain Friday and my
   * other apps don't" was the report — Friday in St. Louis was drizzle at a
   * 1% chance, 0.2 mm in one hour. A wet icon now needs rain to be LIKELY:
   * a chance of 30% or more, or 20% with a real amount behind it (20% for
   * thunderstorms, the NWS's "slight chance"). Otherwise the icon shows the
   * sky from the period's cloud cover, and the chance stays printed beside
   * it — the information is kept, the false alarm is not. */
  var WET_CODES = /^(5[1-7]|6[1-7]|7[1-7]|8[0-6]|9[5-9])$/;

  // sum: mm over the period. perHour: thresholds for one hour, not a day.
  function likelyIcon(code, pop, sum, cloud, perHour) {
    if (code === null || code === undefined || !WET_CODES.test(String(code))) return code;
    var amount = perHour ? 0.5 : 2;
    var thunder = code >= 95;
    var likely = pop === null || pop === undefined
      ? (sum || 0) >= (perHour ? 0.25 : 1)          // no chance given: the amount decides
      : pop >= 30 || (pop >= 20 && (thunder || (sum || 0) >= amount));
    if (likely) return code;
    if (cloud === null || cloud === undefined) return 2;
    return cloud < 15 ? 0 : cloud < 40 ? 1 : cloud < 70 ? 2 : 3;
  }

  global.Derive = {
    likelyIcon: likelyIcon,
    nowcast: nowcast,
    observedPrecip: observedPrecip,
    stationPrecip: stationPrecip,
    parseMetar: parseMetar,
    intensityLabel: intensityLabel,
    buildProfile: buildProfile,
    windAt: windAt,
    bulkShear: bulkShear,
    meanWind: meanWind,
    stormMotion: stormMotion,
    srh: srh,
    convective: convective,
    convectiveSummary: convectiveSummary
  };
})(window);
