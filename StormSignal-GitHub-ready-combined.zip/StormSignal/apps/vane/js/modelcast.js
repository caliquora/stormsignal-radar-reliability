/* Vane — the model forecasts, each agency by name.
 *
 * "What does the Euro say?" is how forecast arguments are actually had: the
 * GFS dries the weekend out, the Euro hangs the front back, ICON splits the
 * difference. The agreement card measures how much they disagree; this card
 * lets you read each one's answer — every agency's single daily run, ten days
 * out, as a browsable scenario.
 *
 * Two honesty rules the rendering enforces:
 *
 *   - A model's run is a SCENARIO, not a probability. The framing text says
 *     so, and the ensemble outlook below remains the place where uncertainty
 *     is measured rather than eyeballed.
 *   - Each agency publishes to a different public horizon — ARPEGE stops
 *     near day 4, UKMO near day 6 — and the card says "stops here" instead
 *     of padding the tail with blanks that look like a forecast. */
(function (global) {
  'use strict';

  var C = global.VaneConfig, U = global.U;
  var SVGNS = 'http://www.w3.org/2000/svg';

  function el(tag, attrs) {
    var n = document.createElementNS(SVGNS, tag);
    Object.keys(attrs || {}).forEach(function (k) { n.setAttribute(k, attrs[k]); });
    return n;
  }

  /* Reshape the per-model daily payload into one series per model.
   * `horizon` is the number of leading days the model actually filled in —
   * the ragged tail of nulls is each agency's publication limit, not data. */
  function parse(data) {
    var d = (data && data.daily) || {};
    var days = d.time || [];
    var models = C.MODELS_DAILY.map(function (m) {
      var hi = d['temperature_2m_max_' + m.id] || [];
      var lo = d['temperature_2m_min_' + m.id] || [];
      var pr = d['precipitation_sum_' + m.id] || [];
      var wc = d['weather_code_' + m.id] || [];
      var horizon = 0;
      for (var i = 0; i < days.length; i++) {
        if (hi[i] !== null && hi[i] !== undefined) horizon = i + 1;
      }
      return {
        id: m.id, short: m.short, name: m.name, color: m.color,
        hi: hi, lo: lo, precip: pr, code: wc, horizon: horizon
      };
    }).filter(function (m) { return m.horizon > 0; });
    return { days: days, models: models };
  }

  /* ── Chart: every model's highs and lows on one pair of axes ────────── */

  function chart(box, mc, focusId, imperial) {
    U.clear(box);
    if (!mc.days.length || !mc.models.length) return;

    var W = 720, H = 240, padL = 34, padR = 10, padT = 12, padB = 26;
    var svg = el('svg', { viewBox: '0 0 ' + W + ' ' + H, 'class': 'mc-svg', role: 'img',
      'aria-label': 'Daily highs and lows from each forecast model' });

    var all = [];
    mc.models.forEach(function (m) {
      m.hi.concat(m.lo).forEach(function (v) { if (v !== null && v !== undefined) all.push(v); });
    });
    var lo = Math.min.apply(null, all), hi = Math.max.apply(null, all);
    var span = (hi - lo) || 1;
    var x = function (i) { return padL + (W - padL - padR) * (mc.days.length === 1 ? 0.5 : i / (mc.days.length - 1)); };
    var y = function (v) { return padT + (H - padT - padB) * (1 - (v - lo) / span); };
    var conv = function (v) { return imperial ? v * 9 / 5 + 32 : v; };

    // Horizontal reference lines with temperature labels in display units.
    [0.25, 0.5, 0.75].forEach(function (f) {
      var v = lo + span * (1 - f);
      var gy = padT + (H - padT - padB) * f;
      svg.appendChild(el('line', { x1: padL, x2: W - padR, y1: gy, y2: gy, 'class': 'mc-grid' }));
      var t = el('text', { x: padL - 6, y: gy + 3, 'class': 'mc-ylabel', 'text-anchor': 'end' });
      t.textContent = Math.round(conv(v)) + '°';
      svg.appendChild(t);
    });

    // Day labels. parseLocal treats a bare date as local midnight — the 7-day
    // card ran a weekday behind for exactly this reason.
    mc.days.forEach(function (iso, i) {
      var t = el('text', { x: x(i), y: H - 8, 'class': 'mc-xlabel', 'text-anchor': 'middle' });
      var d = U.parseLocal(iso);
      // Ten days spans two weekends; a bare "Sat" twice in one axis invites
      // exactly the which-Saturday confusion the date number settles.
      t.textContent = i === 0 ? 'Today' : U.fmtDay(d) + ' ' + d.getDate();
      svg.appendChild(t);
    });

    function polyline(m, series, cls) {
      var pts = [];
      for (var i = 0; i < m.horizon; i++) {
        var v = series[i];
        if (v === null || v === undefined) continue;
        pts.push(x(i).toFixed(1) + ',' + y(v).toFixed(1));
      }
      if (pts.length < 2) return null;
      return el('polyline', { points: pts.join(' '), 'class': cls, stroke: m.color });
    }

    // Unfocused models first so the focused one draws on top.
    var ordered = mc.models.slice().sort(function (a, b) {
      return (a.id === focusId ? 1 : 0) - (b.id === focusId ? 1 : 0);
    });
    ordered.forEach(function (m) {
      var state = !focusId ? 'all' : (m.id === focusId ? 'focus' : 'dim');
      var g = el('g', { 'class': 'mc-model mc-' + state });
      var hiLine = polyline(m, m.hi, 'mc-hi');
      var loLine = polyline(m, m.lo, 'mc-lo');
      if (hiLine) g.appendChild(hiLine);
      if (loLine) g.appendChild(loLine);
      if (state === 'focus') {
        for (var i = 0; i < m.horizon; i++) {
          if (m.hi[i] === null || m.hi[i] === undefined) continue;
          g.appendChild(el('circle', { cx: x(i), cy: y(m.hi[i]), r: 3.2, fill: m.color }));
        }
      }
      svg.appendChild(g);
    });

    box.appendChild(svg);
  }

  /* ── Detail strip: the focused model's ten days, readably ───────────── */

  function strip(box, mc, focusId, state) {
    U.clear(box);
    var m = null;
    mc.models.forEach(function (x) { if (x.id === focusId) m = x; });
    if (!m) { box.hidden = true; return; }
    box.hidden = false;

    var imp = state.imperial;
    for (var i = 0; i < m.horizon; i++) {
      var day = document.createElement('div');
      day.className = 'mc-day';
      var name = document.createElement('span');
      name.className = 'mc-day-name';
      var dd = U.parseLocal(mc.days[i]);
      name.textContent = i === 0 ? 'Today' : U.fmtDay(dd) + ' ' + dd.getDate();
      day.appendChild(name);
      var icon = document.createElement('span');
      icon.className = 'mc-day-icon';
      if (m.code[i] !== null && m.code[i] !== undefined) {
        global.Icons.into(icon, m.code[i], true, 22);
      }
      day.appendChild(icon);
      var hi = document.createElement('span');
      hi.className = 'mc-day-hi';
      hi.textContent = U.temp(m.hi[i], imp);
      day.appendChild(hi);
      var lo = document.createElement('span');
      lo.className = 'mc-day-lo';
      lo.textContent = U.temp(m.lo[i], imp);
      day.appendChild(lo);
      var pr = document.createElement('span');
      pr.className = 'mc-day-pr' + (m.precip[i] >= 1 ? ' wet' : '');
      pr.textContent = (m.precip[i] === null || m.precip[i] === undefined)
        ? '' : (m.precip[i] === 0 ? '—' : U.precip(m.precip[i], imp));
      day.appendChild(pr);
      box.appendChild(day);
    }

    if (m.horizon < mc.days.length) {
      var note = document.createElement('p');
      note.className = 'mc-horizon';
      note.textContent = m.name + ' publishes ' + m.horizon +
        ' days of public forecast — the rest of the row is beyond its horizon, not a blank forecast.';
      box.appendChild(note);
    }
  }

  /* ── Chips: one per agency ──────────────────────────────────────────── */

  function chips(box, mc, focusId, onPick) {
    U.clear(box);
    var mk = function (label, id, color, horizon) {
      var b = document.createElement('button');
      b.className = 'mc-chip' + ((id === focusId || (!id && !focusId)) ? ' on' : '');
      if (color) {
        var dot = document.createElement('span');
        dot.className = 'mc-dot';
        dot.style.background = color;
        b.appendChild(dot);
      }
      b.appendChild(document.createTextNode(label));
      if (horizon) {
        var h = document.createElement('span');
        h.className = 'mc-chip-days';
        h.textContent = horizon + 'd';
        b.appendChild(h);
      }
      b.addEventListener('click', function () { onPick(id); });
      box.appendChild(b);
    };
    mk('All', null, null, 0);
    mc.models.forEach(function (m) { mk(m.short, m.id, m.color, m.horizon); });
  }

  function render(state) {
    var card = U.el('modelcast-card');
    if (!card) return;
    if (!state.modelDaily) { card.hidden = true; return; }
    var mc = parse(state.modelDaily);
    if (!mc.models.length) { card.hidden = true; return; }
    card.hidden = false;

    chips(U.el('mc-chips'), mc, state.modelFocus, function (id) {
      state.modelFocus = id;
      render(state);
    });
    chart(U.el('mc-chart'), mc, state.modelFocus, state.imperial);
    strip(U.el('mc-strip'), mc, state.modelFocus, state);
  }

  global.Modelcast = { parse: parse, render: render };
})(window);
