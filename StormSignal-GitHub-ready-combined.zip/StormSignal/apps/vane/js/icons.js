/* Vane — weather icons.
 *
 * Emoji read as a placeholder and render differently on every platform. These
 * are drawn as SVG so they match the app's light, animate subtly, and stay
 * crisp at any size. Motion is CSS-driven and disabled under
 * prefers-reduced-motion (see style.css). */
(function (global) {
  'use strict';

  var NS = 'http://www.w3.org/2000/svg';
  var uid = 0;

  function e(tag, attrs, kids) {
    var n = document.createElementNS(NS, tag);
    Object.keys(attrs || {}).forEach(function (k) { n.setAttribute(k, attrs[k]); });
    (kids || []).forEach(function (c) { n.appendChild(c); });
    return n;
  }

  /* Gradient definitions need unique ids per instance, otherwise a second icon
   * on the page silently re-uses the first one's stops. */
  function grad(id, stops, coords) {
    var g = e('linearGradient', Object.assign({
      id: id, x1: '0', y1: '0', x2: '0', y2: '1'
    }, coords || {}));
    stops.forEach(function (s) {
      g.appendChild(e('stop', { offset: s[0], 'stop-color': s[1] }));
    });
    return g;
  }

  var SUN = [['0', '#ffd772'], ['1', '#ff9a3c']];
  // Deep enough to read on the app's white cards as well as its dark ones.
  var MOON = [['0', '#e9eefb'], ['1', '#a9b6d2']];
  var CLOUD = [['0', '#f6f9fe'], ['1', '#b9c7d9']];
  var CLOUD_DARK = [['0', '#9fb0c4'], ['1', '#6b7f96']];
  var STORM_CLOUD = [['0', '#8b95ad'], ['1', '#4d5670']];

  function sun(id, cx, cy, r) {
    var g = e('g', { class: 'ic-sun' });
    var rays = e('g', { class: 'ic-rays', style: 'transform-origin:' + cx + 'px ' + cy + 'px' });
    for (var i = 0; i < 8; i++) {
      var a = (i * Math.PI) / 4;
      var x1 = cx + Math.cos(a) * (r + 3.2), y1 = cy + Math.sin(a) * (r + 3.2);
      var x2 = cx + Math.cos(a) * (r + 7.4), y2 = cy + Math.sin(a) * (r + 7.4);
      rays.appendChild(e('line', {
        x1: x1.toFixed(2), y1: y1.toFixed(2), x2: x2.toFixed(2), y2: y2.toFixed(2),
        stroke: 'url(#' + id + '-sun)', 'stroke-width': 2.6, 'stroke-linecap': 'round'
      }));
    }
    g.appendChild(rays);
    g.appendChild(e('circle', { cx: cx, cy: cy, r: r, fill: 'url(#' + id + '-sun)' }));
    return g;
  }

  function moon(id, cx, cy, r) {
    // Crescent via an even-odd mask rather than two stacked circles, so it
    // still reads correctly over a coloured background.
    var g = e('g', { class: 'ic-moon' });
    var maskId = id + '-mmask';
    var mask = e('mask', { id: maskId }, [
      e('circle', { cx: cx, cy: cy, r: r, fill: '#fff' }),
      e('circle', { cx: cx + r * 0.52, cy: cy - r * 0.42, r: r * 0.88, fill: '#000' })
    ]);
    g.appendChild(mask);
    g.appendChild(e('circle', {
      cx: cx, cy: cy, r: r, fill: 'url(#' + id + '-moon)', mask: 'url(#' + maskId + ')'
    }));
    return g;
  }

  // One reusable cloud silhouette, scaled and positioned by the caller.
  function cloudPath(fill, cls) {
    // The hairline keeps a pale cloud legible on a white card.
    return e('path', {
      class: cls || 'ic-cloud',
      d: 'M18 40a9.5 9.5 0 0 1 .6-19 14 14 0 0 1 26.5-4.2A11 11 0 1 1 47 40Z',
      fill: fill,
      stroke: 'rgba(70, 100, 140, 0.35)', 'stroke-width': '1.2'
    });
  }

  function drops(y0, count, cls) {
    var g = e('g', { class: cls || 'ic-drops' });
    for (var i = 0; i < count; i++) {
      var x = 22 + i * 9;
      var d = e('line', {
        x1: x, y1: y0, x2: x - 2.4, y2: y0 + 7,
        stroke: '#7fc4f2', 'stroke-width': 3, 'stroke-linecap': 'round'
      });
      d.setAttribute('style', 'animation-delay:' + (i * 0.22) + 's');
      g.appendChild(d);
    }
    return g;
  }

  function flakes(y0, count) {
    var g = e('g', { class: 'ic-flakes' });
    for (var i = 0; i < count; i++) {
      var c = e('circle', { cx: 22 + i * 9, cy: y0 + 3, r: 2.4, fill: '#9fc2e8' });
      c.setAttribute('style', 'animation-delay:' + (i * 0.3) + 's');
      g.appendChild(c);
    }
    return g;
  }

  function bolt() {
    return e('path', {
      class: 'ic-bolt',
      d: 'M34 41 L26 54 L32 54 L28 64 L40 50 L33.5 50 L38 41 Z',
      fill: '#ffd23c'
    });
  }

  function fogLines() {
    var g = e('g', { class: 'ic-fog' });
    [[16, 46, 50], [20, 52, 44], [18, 58, 48]].forEach(function (l, i) {
      var ln = e('line', {
        x1: l[0], y1: l[1], x2: l[0] + l[2], y2: l[1],
        stroke: '#a9bccf', 'stroke-width': 3.4, 'stroke-linecap': 'round'
      });
      ln.setAttribute('style', 'animation-delay:' + (i * 0.45) + 's');
      g.appendChild(ln);
    });
    return g;
  }

  /* Build an icon for a WMO code. `isDay` picks sun vs moon for the clear and
   * partly-cloudy variants. */
  function build(code, isDay, size) {
    var id = 'ic' + (++uid);
    var svg = e('svg', {
      viewBox: '0 0 72 72', class: 'wx-icon', role: 'img', focusable: 'false',
      width: size || 72, height: size || 72
    });
    var defs = e('defs', {}, [
      grad(id + '-sun', SUN), grad(id + '-moon', MOON),
      grad(id + '-cloud', CLOUD), grad(id + '-cloudd', CLOUD_DARK),
      grad(id + '-storm', STORM_CLOUD)
    ]);
    svg.appendChild(defs);

    var c = 'url(#' + id + '-cloud)';
    var cd = 'url(#' + id + '-cloudd)';
    var cs = 'url(#' + id + '-storm)';
    var label;

    switch (true) {
      case code === 0:
        svg.appendChild(isDay ? sun(id, 36, 36, 15) : moon(id, 36, 36, 16));
        label = isDay ? 'Clear' : 'Clear night';
        break;

      case code === 1:
      case code === 2:
        svg.appendChild(isDay ? sun(id, 46, 24, 11) : moon(id, 47, 23, 11));
        svg.appendChild(cloudPath(c));
        label = code === 1 ? 'Mainly clear' : 'Partly cloudy';
        break;

      case code === 3:
        svg.appendChild(e('path', {
          class: 'ic-cloud ic-cloud-back',
          d: 'M30 30a8 8 0 0 1 .5-16 12 12 0 0 1 22.5-3.6A9.5 9.5 0 1 1 55 30Z',
          fill: cd, opacity: '.75'
        }));
        svg.appendChild(cloudPath(c));
        label = 'Overcast';
        break;

      case code === 45 || code === 48:
        svg.appendChild(cloudPath(c));
        svg.appendChild(fogLines());
        label = code === 45 ? 'Fog' : 'Rime fog';
        break;

      case code >= 51 && code <= 57:
        svg.appendChild(cloudPath(c));
        svg.appendChild(drops(46, 3, 'ic-drops ic-drizzle'));
        label = 'Drizzle';
        break;

      case code >= 61 && code <= 67:
      case code >= 80 && code <= 82:
        svg.appendChild(cloudPath(code >= 65 || code === 82 ? cd : c));
        svg.appendChild(drops(46, code >= 65 || code === 82 ? 4 : 3));
        label = code >= 65 ? 'Heavy rain' : 'Rain';
        break;

      case (code >= 71 && code <= 77) || code === 85 || code === 86:
        svg.appendChild(cloudPath(c));
        svg.appendChild(flakes(46, 4));
        label = 'Snow';
        break;

      case code >= 95:
        svg.appendChild(cloudPath(cs));
        svg.appendChild(bolt());
        if (code >= 96) svg.appendChild(flakes(52, 2));
        label = code >= 96 ? 'Thunderstorm with hail' : 'Thunderstorm';
        break;

      default:
        svg.appendChild(cloudPath(c));
        label = 'Cloudy';
    }

    svg.setAttribute('aria-label', label);
    var t = e('title');
    t.textContent = label;
    svg.appendChild(t);
    return svg;
  }

  // Convenience: replace a node's contents with a freshly built icon.
  function into(node, code, isDay, size) {
    while (node.firstChild) node.removeChild(node.firstChild);
    node.appendChild(build(code, isDay, size));
    return node;
  }

  global.Icons = { build: build, into: into };
})(window);
