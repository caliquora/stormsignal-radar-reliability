/* Vane — VaneMotion grades its own homework.
 *
 * VaneMotion says "rain reaches you in about 25 minutes". This module
 * checks whether it did. Each arrival call is recorded when it is made,
 * and once its window has passed, Vane looks back at the archived national
 * mosaic — Iowa State keeps the composite at every five-minute stamp, the
 * same archive History mode replays — samples the pin through the window,
 * and finds when rain actually arrived. The difference is the call's error.
 *
 * Verified retrospectively on purpose: a check that needed the app to be
 * open at the predicted minute would grade only the calls someone happened
 * to be watching. This one grades every call, whenever Vane next opens.
 *
 * HONESTY RULES.
 *   - One call per approaching echo: VaneMotion re-fits every scan cycle,
 *     and a 25-, 20-, 15-minute countdown on the same rain is one call,
 *     not three. The first (longest-lead) call is the one graded — the one
 *     the rain-on-the-way notification fires on.
 *   - "Arrived" means the same thing the nowcast means by raining overhead:
 *     >= RADAR_RAIN_DBZ inside the same small box over the pin.
 *   - The archive is 5-minute frames, so arrival is known to 5 minutes;
 *     a hit is within +/-HIT_MIN. Rain that never came inside the window is
 *     a miss, not an omission.
 *   - A window with any frame that failed to load stays unsettled and is
 *     retried — a missing reading is never scored as a dry one.
 *   - No skill is claimed before MIN_CALLS settled calls.
 *
 * OUTSIDE THE US the calls come from RainViewer's composite, and so does
 * the grading — but RainViewer keeps only the last two hours, at ten-minute
 * frames, addressed by paths that exist only in its current index. So a
 * global call is graded only if Vane is opened within about two hours of
 * its window closing; after that its frames are gone, and the call is
 * dropped and counted as expired — never guessed at, never scored. Arrival
 * there is known to ten minutes, not five. */
(function (global) {
  'use strict';

  var C = global.VaneConfig, U = global.U;
  var KEY = 'vane.motionskill.v1';
  var HIT_MIN = 10;              // +/- minutes that count as "called it"
  var GRACE_MIN = 30;            // how long after the call we wait for rain
  var SAME_EVENT_MIN = 20;       // re-fits within this of an open call: same rain
  var MIN_CALLS = 3;
  var MAX_CALLS = 60;
  var MAX_AGE_MS = 7 * 86400000; // unsettleable after a week: dropped
  var STEP_MS = 300000;          // the archive's five-minute stamps
  var RV_STEP_MS = 600000;       // RainViewer's ten-minute frames
  var GONE = 'gone';             // a frame that has left RainViewer's archive
  var CAL_MIN = 5;               // timed calls before VaneMotion corrects itself
  var CAL_SHRINK = 5;            // pseudo-calls of "no bias" the evidence must outweigh
  var CAL_CLAMP = 20;            // a bias this large is a broken fit, not a lean
  var CAL_FLOOR = 2;             // below this the correction is noise: leave the call alone

  function locKey(loc) { return loc.lat.toFixed(2) + ',' + loc.lon.toFixed(2); }
  function empty(k) { return { loc: k, calls: [] }; }

  /* ── Pure core ───────────────────────────────────────────────────── */

  /* Record an arrival call. Returns the store, changed or not. A call is
   * only recorded for rain still upstream — overhead already wet has no
   * arrival to time. */
  function recordInto(store, k, motion, issuedAt) {
    if (store.loc !== k) store = empty(k);
    if (!motion || !motion.eta || motion.overheadNow || motion.stationary) return store;
    var predictedAt = issuedAt + motion.eta.minutes * 60000;
    // What the raw fit said, before any learned correction: the calibration
    // must keep learning from the fit's own errors, not from its corrections.
    var rawMin = motion.eta.rawMinutes !== undefined ? motion.eta.rawMinutes : motion.eta.minutes;
    var sameEvent = store.calls.some(function (c) {
      return !c.result && (c.by || 'motion') === 'motion' &&
        Math.abs(c.predictedAt - predictedAt) <= SAME_EVENT_MIN * 60000;
    });
    if (sameEvent) return store;
    store.calls.push({
      issuedAt: issuedAt,
      predictedAt: predictedAt,
      leadMin: motion.eta.minutes,
      rawPredictedAt: issuedAt + rawMin * 60000,
      calMin: motion.eta.minutes - rawMin,
      dbz: motion.eta.dbz,
      distanceKm: motion.eta.distanceKm,
      dir: motion.eta.dir,
      source: motion.source || 'nexrad',
      result: null
    });
    if (store.calls.length > MAX_CALLS) store.calls = store.calls.slice(-MAX_CALLS);
    return store;
  }

  /* The archive stamps that cover a call's window, in order: from the first
   * stamp after the call was made, through the grace period. */
  function stampsFor(call) {
    var step = call.source === 'rainviewer' ? RV_STEP_MS : STEP_MS;
    var out = [], t = Math.ceil((call.issuedAt + 1) / step) * step;
    var end = Math.max(call.predictedAt, call.rawPredictedAt || 0) + GRACE_MIN * 60000;
    for (; t <= end; t += step) out.push(t);
    return out;
  }

  /* samples: [{ t, dbz }] in time order; dbz is -Infinity for a clear
   * frame and null for a frame that could not be read. Returns the result
   * object, or null when the window cannot be graded (yet). */
  function grade(call, samples, now) {
    var closes = Math.max(call.predictedAt, call.rawPredictedAt || 0) + GRACE_MIN * 60000;
    if (now < closes) return null;                                  // window still open
    for (var i = 0; i < samples.length; i++) {
      var s = samples[i];
      if (s.dbz === null || s.dbz === undefined) return null;      // unreadable: retry later
      if (s.dbz >= C.OBSERVED.RADAR_RAIN_DBZ) {
        var err = (s.t - call.predictedAt) / 60000;
        return {
          outcome: Math.abs(err) <= HIT_MIN ? 'hit' : (err < 0 ? 'early' : 'late'),
          arrivedAt: s.t,
          errorMin: Math.round(err),
          dbz: s.dbz
        };
      }
    }
    // Every frame read, none wet: the rain never came.
    return { outcome: 'miss', arrivedAt: null, errorMin: null, dbz: null };
  }

  /* Who made a call: VaneMotion ('motion', the default for calls recorded
   * before there was anyone else), the forecast model's 15-minute nowcast
   * ('model'), or the blend of the two ('blend'). */
  function by(calls, who) {
    return (calls || []).filter(function (c) { return (c.by || 'motion') === who; });
  }

  function skill(calls, who) {
    var settled = by(calls, who || 'motion').filter(function (c) { return c.result; });
    var hits = 0, early = 0, late = 0, misses = 0, errs = [];
    settled.forEach(function (c) {
      var o = c.result.outcome;
      if (o === 'hit') hits++;
      else if (o === 'early') early++;
      else if (o === 'late') late++;
      else misses++;
      if (c.result.errorMin !== null) errs.push(Math.abs(c.result.errorMin));
    });
    errs.sort(function (a, b) { return a - b; });
    return {
      n: settled.length,
      hits: hits, early: early, late: late, misses: misses,
      medianAbsErrMin: errs.length ? errs[Math.floor(errs.length / 2)] : null,
      hitMin: HIT_MIN,
      ready: settled.length >= MIN_CALLS,
      open: by(calls, who || 'motion').length - settled.length
    };
  }

  /* ── Self-calibration ─────────────────────────────────────────────
   *
   * The report card says how VaneMotion has done here; this makes it do
   * better. Every graded call that saw rain arrive carries the RAW fit's
   * timing error (arrived minus what the fit alone said). If rain here
   * keeps arriving later than the fit says — a terrain-slowed flow, a
   * systematic lag in the source's frames — the median of those errors is
   * a correction worth applying.
   *
   * Learned cautiously: nothing before CAL_MIN timed calls; the median is
   * shrunk toward zero as if CAL_SHRINK calls had said "no bias", so a few
   * calls cannot swing it far; anything inside ±CAL_FLOOR is left alone;
   * it is clamped at ±CAL_CLAMP. Misses carry no arrival time and teach it
   * nothing.
   *
   * And it audits itself: once CAL_MIN corrected calls have been graded,
   * if the corrected times were on average further off than the raw fit
   * would have been on those same calls, the correction switches itself
   * off and says so. */
  function median(a) {
    var b = a.slice().sort(function (x, y) { return x - y; });
    if (!b.length) return null;
    var m = Math.floor(b.length / 2);
    return b.length % 2 ? b[m] : (b[m - 1] + b[m]) / 2;
  }

  function rawErr(c) {
    return (c.result.arrivedAt - (c.rawPredictedAt || c.predictedAt)) / 60000;
  }

  function calibration(calls) {
    var timed = by(calls, 'motion').filter(function (c) { return c.result && c.result.arrivedAt; });
    var n = timed.length;
    if (n < CAL_MIN) return { ready: false, n: n, need: CAL_MIN };
    var errs = timed.map(rawErr);
    var m = median(errs);
    var bias = Math.max(-CAL_CLAMP, Math.min(CAL_CLAMP, m * n / (n + CAL_SHRINK)));
    var spread = median(errs.map(function (e) { return Math.abs(e - m); }));

    // The audit: corrected calls, judged against what raw would have scored.
    var applied = timed.filter(function (c) { return c.calMin; });
    var audit = null, disabled = false;
    if (applied.length >= CAL_MIN) {
      var rawMae = 0, calMae = 0;
      applied.forEach(function (c) {
        rawMae += Math.abs(rawErr(c));
        calMae += Math.abs((c.result.arrivedAt - c.predictedAt) / 60000);
      });
      audit = { n: applied.length,
                rawMaeMin: Math.round(rawMae / applied.length),
                calMaeMin: Math.round(calMae / applied.length) };
      disabled = calMae > rawMae;
    }
    var biasMin = Math.round(bias);
    return {
      ready: true, n: n,
      biasMin: Math.abs(biasMin) < CAL_FLOOR ? 0 : biasMin,
      medianErrMin: Math.round(m),
      spreadMin: Math.round(spread),
      audit: audit,
      disabled: disabled
    };
  }

  /* Pure: a corrected copy of a VaneMotion verdict. Never mutates the
   * input — Motion caches its result per scan cycle, and correcting the
   * cached object twice would double the shift. */
  function applyCalibration(motion, cal) {
    if (!motion || !motion.eta || !cal || !cal.ready || cal.disabled || !cal.biasMin) return motion;
    var out = {}, k;
    for (k in motion) if (Object.prototype.hasOwnProperty.call(motion, k)) out[k] = motion[k];
    out.eta = {};
    for (k in motion.eta) if (Object.prototype.hasOwnProperty.call(motion.eta, k)) out.eta[k] = motion.eta[k];
    out.eta.rawMinutes = motion.eta.minutes;
    out.eta.minutes = Math.max(1, motion.eta.minutes + cal.biasMin);
    out.eta.calibration = { biasMin: cal.biasMin, n: cal.n, spreadMin: cal.spreadMin };
    return out;
  }

  /* ── Two clocks, one answer ────────────────────────────────────────
   *
   * VaneMotion extrapolates the radar; the forecast model's 15-minute
   * nowcast runs the physics. Radar extrapolation tends to win at short
   * range and the model further out, but which is better HERE is an
   * empirical question, so both make calls, both are graded by the same
   * archive check, and the blend weights each by its own record: inverse
   * mean squared error, where rain that never came costs as much as being
   * GRACE_MIN out. Equal weights until each has BLEND_MIN graded calls.
   * The blended call is graded too, so whether blending earns its keep
   * is on the record rather than assumed. */
  var BLEND_MIN = 5;

  function otherCallInto(store, k, who, minutes, issuedAt, source) {
    if (store.loc !== k) store = empty(k);
    if (!(minutes > 0)) return store;
    var predictedAt = issuedAt + minutes * 60000;
    var same = by(store.calls, who).some(function (c) {
      return !c.result && Math.abs(c.predictedAt - predictedAt) <= SAME_EVENT_MIN * 60000;
    });
    if (same) return store;
    store.calls.push({ by: who, issuedAt: issuedAt, predictedAt: predictedAt,
      rawPredictedAt: predictedAt, leadMin: Math.round(minutes), calMin: 0,
      source: source || 'nexrad', result: null });
    if (store.calls.length > MAX_CALLS) store.calls = store.calls.slice(-MAX_CALLS);
    return store;
  }

  function mse(calls) {
    var settled = calls.filter(function (c) { return c.result; });
    if (!settled.length) return { n: 0, mse: null };
    var s2 = 0;
    settled.forEach(function (c) {
      var e = c.result.arrivedAt ? (c.result.arrivedAt - c.predictedAt) / 60000 : GRACE_MIN;
      s2 += e * e;
    });
    return { n: settled.length, mse: s2 / settled.length };
  }

  /* → { wMotion, wModel, ready, nMotion, nModel } */
  function blendWeights(calls) {
    var a = mse(by(calls, 'motion')), b = mse(by(calls, 'model'));
    var ready = a.n >= BLEND_MIN && b.n >= BLEND_MIN;
    if (!ready) return { wMotion: 0.5, wModel: 0.5, ready: false, nMotion: a.n, nModel: b.n };
    var ia = 1 / Math.max(a.mse, 1), ib = 1 / Math.max(b.mse, 1);
    return { wMotion: ia / (ia + ib), wModel: ib / (ia + ib), ready: true, nMotion: a.n, nModel: b.n };
  }

  /* Pure: two arrival estimates (minutes from now; either may be null)
   * and the weights → the blended estimate. */
  function blendMinutes(motionMin, modelMin, w) {
    if (motionMin === null && modelMin === null) return null;
    if (modelMin === null) return motionMin;
    if (motionMin === null) return modelMin;
    return w.wMotion * motionMin + w.wModel * modelMin;
  }

  /* ── Storage + network ───────────────────────────────────────────── */

  function load() {
    try {
      var s = JSON.parse(global.localStorage.getItem(KEY));
      if (s && Array.isArray(s.calls)) return s;
    } catch (e) { /* corrupt or unavailable */ }
    return empty(null);
  }

  function save(s) {
    try { global.localStorage.setItem(KEY, JSON.stringify(s)); } catch (e) { /* full */ }
  }

  function record(loc, motion) {
    if (!loc) return;
    save(recordInto(load(), locKey(loc), motion, Date.now()));
  }

  /* One archived frame over the pin. Resolves to dBZ, -Infinity for a
   * clear read, null when the frame could not be read, or GONE when it was
   * a RainViewer frame that has already aged out of the archive.
   * `frames` is RainViewer's current past-frame list, for global calls. */
  function sampleAt(loc, t, call, frames) {
    var rv = call && call.source === 'rainviewer', url;
    if (rv) {
      var f = null;
      (frames || []).forEach(function (x) { if (x.t === t) f = x; });
      if (!f) {
        // Older than the oldest frame held: gone for good. Otherwise it
        // is simply not published yet (or the index failed) — retry.
        return Promise.resolve(frames && frames.length && t < frames[0].t ? GONE : null);
      }
      url = f.url;
    } else {
      url = C.NEXRAD_TILES.replace('{product}', 'ridge::USCOMP-N0Q-' + U.iemStamp(t));
    }
    return global.Reflectivity.sample({
      lat: loc.lat, lon: loc.lon,
      halfKm: C.OBSERVED.SAMPLE_HALF_KM, grid: 24, zoom: 8,
      decode: rv ? 'rainviewer' : null,
      reportClear: true,
      urlFor: function (z, x, y) {
        return url.replace('{z}', z).replace('{x}', x).replace('{y}', y);
      }
    }).then(function (field) {
      if (!field) return null;
      return field.clear ? -Infinity : field.maxDbz;
    }).catch(function () { return null; });
  }

  /* Walk a call's window frame by frame and stop at the first wet one —
   * a call that verified early costs a frame or two, not the whole window. */
  function sampleWindow(loc, call, frames) {
    var stamps = stampsFor(call), out = [];
    function next(i) {
      if (i >= stamps.length) return Promise.resolve(out);
      return sampleAt(loc, stamps[i], call, frames).then(function (dbz) {
        if (dbz === GONE) { out.gone = true; return out; }
        out.push({ t: stamps[i], dbz: dbz });
        if (dbz === null || dbz >= C.OBSERVED.RADAR_RAIN_DBZ) return out;
        return next(i + 1);
      });
    }
    return next(0);
  }

  /* Grade the calls whose windows have closed. At most `limit` per call, so
   * a week away does not become a burst of archive fetches on open.
   * Resolves true when anything was settled. */
  function settleDue(loc, opts) {
    opts = opts || {};
    if (!loc || !global.Reflectivity) return Promise.resolve(false);
    var store = load(), now = Date.now();
    if (store.loc !== locKey(loc)) return Promise.resolve(false);
    store.calls = store.calls.filter(function (c) { return c.result || now - c.issuedAt < MAX_AGE_MS; });
    var due = store.calls.filter(function (c) {
      return !c.result && now >= c.predictedAt + GRACE_MIN * 60000;
    }).slice(0, opts.limit || 2);
    if (!due.length) { save(store); return Promise.resolve(false); }

    var needFrames = due.some(function (c) { return c.source === 'rainviewer'; });
    var framesP = needFrames && global.API && global.API.radarSampleFrames
      ? global.API.radarSampleFrames().catch(function () { return null; })
      : Promise.resolve(null);

    var changed = false;
    return framesP.then(function (frames) {
      return due.reduce(function (p, call) {
        return p.then(function () {
          return sampleWindow(loc, call, frames).then(function (samples) {
            if (samples.gone) {
              store.calls = store.calls.filter(function (c) { return c !== call; });
              store.expired = (store.expired || 0) + 1;
              changed = true;
              return;
            }
            var r = grade(call, samples, now);
            if (r) { call.result = r; changed = true; }
          });
        });
      }, Promise.resolve());
    }).then(function () {
      global.Reflectivity.clearCache();            // archive frames are one-shot
      save(store);
      return changed;
    });
  }

  /* Record the model's and the blend's arrival calls for this location. */
  function recordOthers(loc, modelMin, blendMin, source) {
    if (!loc) return;
    var s = load(), k = locKey(loc), now = Date.now();
    if (modelMin !== null && modelMin !== undefined) s = otherCallInto(s, k, 'model', modelMin, now, source);
    if (blendMin !== null && blendMin !== undefined) s = otherCallInto(s, k, 'blend', blendMin, now, source);
    save(s);
  }

  function blendFor(loc) {
    var s = load();
    if (!loc || s.loc !== locKey(loc)) return blendWeights([]);
    return blendWeights(s.calls);
  }

  function skillBy(loc, who) {
    var s = load();
    if (!loc || s.loc !== locKey(loc)) return skill([], who);
    return skill(s.calls, who);
  }

  function calibrationFor(loc) {
    var s = load();
    if (!loc || s.loc !== locKey(loc)) return calibration([]);
    return calibration(s.calls);
  }

  function calibrate(loc, motion) {
    return applyCalibration(motion, calibrationFor(loc));
  }

  function summary(loc) {
    var s = load();
    if (!loc || s.loc !== locKey(loc)) return skill([]);
    var out = skill(s.calls);
    out.expired = s.expired || 0;
    out.calibration = calibration(s.calls);
    return out;
  }

  function reset() {
    try { global.localStorage.removeItem(KEY); } catch (e) { /* nothing */ }
  }

  global.MotionSkill = {
    record: record,
    settleDue: settleDue,
    summary: summary,
    reset: reset,
    // Pure core, exported for the test suite.
    recordInto: recordInto,
    stampsFor: stampsFor,
    otherCallInto: otherCallInto,
    blendWeights: blendWeights,
    blendMinutes: blendMinutes,
    recordOthers: recordOthers,
    blendFor: blendFor,
    skillBy: skillBy,
    calibration: calibration,
    applyCalibration: applyCalibration,
    calibrate: calibrate,
    calibrationFor: calibrationFor,
    sampleAt: sampleAt,
    grade: grade,
    skill: skill,
    empty: empty,
    HIT_MIN: HIT_MIN,
    GRACE_MIN: GRACE_MIN,
    MIN_CALLS: MIN_CALLS
  };
})(window);
