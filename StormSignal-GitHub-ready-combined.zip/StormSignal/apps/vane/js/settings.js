/* Vane — user settings and alert filtering.
 *
 * F7 called for "customizable alert zones to filter warnings by storm type".
 * F2 rules out accounts, so everything persists to localStorage and nothing
 * leaves the device. */
(function (global) {
  'use strict';

  var C = global.VaneConfig, U = global.U;
  var KEY = 'vane.settings.v1';

  var DEFAULTS = {
    filters: {},                 // filled below: every alert family on by default
    notify: false,               // desktop notifications for new severe alerts
    notifyMinSeverity: 'Severe',
    notifyRain: false,           // VaneMotion sees rain tracking to the pin
    notifyOutlook: false,        // SPC Day 1/2 risk at the pin, once a day
    autoChase: true,             // F5: auto-suggest Chase mode on severe alerts
    radarSpeed: 500,
    showWarnings: true,
    showSpc: true,
    showReports: true,           // Chase mode
    showReportsSimple: false,    // Simple mode: off unless asked for
    reportTypes: {},             // { category: false } hides that kind
    radarClean: true,            // filter birds, bugs and wind farms out of the mosaic (MRMS QC)
    capeKind: 'ml',              // CAPE layer parcel: 'sb' surface, 'ml' mixed-layer, 'mu' most unstable
    keepAwake: false,            // screen wake lock while chasing
    solid: false,                // opaque panels instead of glass (sunlight legibility)
    skyMotion: true,             // animated precipitation over the sky gradient
    hour12: true,
    imperial: true,
  };
  C.ALERT_FILTERS.forEach(function (f) { DEFAULTS.filters[f.key] = true; });

  var current = null;
  var seenAlertIds = {};
  var wakeLock = null;

  function load() {
    if (current) return current;
    current = JSON.parse(JSON.stringify(DEFAULTS));
    try {
      var raw = localStorage.getItem(KEY);
      if (raw) {
        var s = JSON.parse(raw);
        Object.keys(DEFAULTS).forEach(function (k) {
          if (s[k] !== undefined) {
            current[k] = (k === 'filters') ? Object.assign({}, DEFAULTS.filters, s[k]) : s[k];
          }
        });
      }
    } catch (e) { /* corrupt or unavailable storage — defaults stand */ }
    return current;
  }

  function save(patch) {
    var s = load();
    if (patch) Object.assign(s, patch);
    try { localStorage.setItem(KEY, JSON.stringify(s)); } catch (e) { /* ignore */ }
    return s;
  }

  function get(key) { return load()[key]; }

  /* ── Alert filtering ────────────────────────────────────────────────── */

  function familyOf(alert) {
    var text = (alert.event || '') + ' ' + (alert.headline || '');
    for (var i = 0; i < C.ALERT_FILTERS.length; i++) {
      var f = C.ALERT_FILTERS[i];
      if (f.match && f.match.test(text)) return f.key;
    }
    return 'other';
  }

  function filterAlerts(alerts) {
    var s = load();
    return (alerts || []).filter(function (a) {
      return s.filters[familyOf(a)] !== false;
    });
  }

  /* ── Desktop notifications for newly-issued alerts ──────────────────── */

  function requestNotifications() {
    if (!('Notification' in global)) {
      return Promise.resolve('unsupported');
    }
    return Notification.requestPermission().then(function (p) {
      save({ notify: p === 'granted' });
      return p;
    });
  }

  function canNotify() {
    return ('Notification' in global) && Notification.permission === 'granted';
  }

  /* One door for every notification. Android Chrome throws on the bare
   * `new Notification()` constructor inside an installed web app — only the
   * service-worker path works there — so the SW registration is preferred
   * whenever the page has one, and the constructor is the fallback. The old
   * code used the constructor alone and swallowed the throw, which meant
   * alert notifications silently never fired on the platform chasers
   * actually mount on a dash. */
  /* kind ('rain', 'spc', 'alert:flood'…) rides along in the notification's
   * data, so whether it was opened or dismissed can be learned from —
   * here for the constructor path, in sw.js for the worker path. */
  function post(title, opts, kind) {
    if (!canNotify()) return Promise.resolve('denied');
    opts = opts || {};
    if (kind) opts.data = { kind: kind };
    var viaSW = ('serviceWorker' in navigator) &&
      navigator.serviceWorker.controller &&
      navigator.serviceWorker.ready;
    if (viaSW) {
      return navigator.serviceWorker.ready.then(function (reg) {
        return reg.showNotification(title, opts).then(function () { return 'shown'; });
      }).catch(function () { return postDirect(title, opts, kind); });
    }
    return Promise.resolve(postDirect(title, opts, kind));
  }

  function postDirect(title, opts, kind) {
    try {
      var n = new Notification(title, opts), opened = false;
      var L = global.NotifyLearn;
      n.onclick = function () {
        opened = true;
        if (L && kind) L.outcome(kind, 'open');
        global.focus(); n.close();
      };
      n.onclose = function () { if (!opened && L && kind) L.outcome(kind, 'dismiss'); };
      return 'shown';
    } catch (e) { return 'failed'; }
  }

  // Only fires for alerts we haven't already shown, at or above the chosen
  // severity — a chaser doesn't want a popup for every routine advisory.
  function notifyNew(alerts) {
    var s = load();
    if (!s.notify || !canNotify()) return;
    var floor = C.ALERT_RANK[s.notifyMinSeverity] || 3;

    filterAlerts(alerts).forEach(function (a) {
      if (seenAlertIds[a.id]) return;
      seenAlertIds[a.id] = true;
      var rank = C.ALERT_RANK[a.severity] || 0, family = familyOf(a);
      if (rank < floor) return;
      // A family the user chose to mute (on Vane's suggestion) still lets
      // Extreme alerts through — js/notifylearn.js never mutes those.
      if (global.NotifyLearn && !global.NotifyLearn.allowAlert(family, rank)) return;
      post(a.event, {
        body: (a.headline || '').slice(0, 180),
        tag: a.id,
        requireInteraction: rank >= 4
      }, 'alert:' + family);
    });
  }

  /* ── Rain on the way: VaneMotion's fit, as a heads-up ────────────────
   * Pure decision + text so the suite can hold them to account without a
   * Notification object in sight. One notification per approach: after it
   * fires, quiet for SUPPRESS_MIN so a fit that re-learns 24, 22, 19
   * minutes on successive scans is one heads-up, not a drumbeat. */

  var RAIN_LEAD_MAX = 45;        // only worth interrupting for
  var RAIN_SUPPRESS_MIN = 45;
  var RAIN_KEY = 'vane.notified.rain.v1';
  // Learned quiet mode (js/notifylearn.js): heavier rain, closer in.
  var QUIET_RAIN_LEAD = 20, QUIET_RAIN_DBZ = 35;

  function shouldNotifyMotion(motion, lastEpoch, now, quiet) {
    if (!motion || motion.stationary || !motion.eta) return false;
    if (motion.eta.minutes > RAIN_LEAD_MAX) return false;
    if (quiet && (motion.eta.minutes > QUIET_RAIN_LEAD || motion.eta.dbz < QUIET_RAIN_DBZ)) return false;
    if (lastEpoch && (now - lastEpoch) < RAIN_SUPPRESS_MIN * 60000) return false;
    return true;
  }

  function motionNotifyText(motion) {
    var m = motion.eta;
    return 'Radar shows ' + m.dbz + ' dBZ about ' + m.distanceKm + ' km to the ' +
      m.dir + ', moving ' + motion.vector.toward + ' at ' + motion.vector.speed +
      ' km/h — at your location in about ' + m.minutes +
      ' min. Learned in your browser from the last hour of radar.';
  }

  function notifyMotion(motion) {
    if (!get('notifyRain') || !canNotify()) return;
    var last = 0;
    try { last = +localStorage.getItem(RAIN_KEY) || 0; } catch (e) { /* fine */ }
    var quiet = !!(global.NotifyLearn && global.NotifyLearn.policyFor('rain').quiet);
    if (!shouldNotifyMotion(motion, last, Date.now(), quiet)) return;
    try { localStorage.setItem(RAIN_KEY, String(Date.now())); } catch (e) { /* fine */ }
    post('Rain in about ' + motion.eta.minutes + ' minutes', {
      body: motionNotifyText(motion),
      tag: 'vane-rain'
    }, 'rain');
  }

  /* ── Severe outlook at the pin: once a day, and only upgrades ─────────
   * "SPC put an Enhanced risk over you today" is worth one notification.
   * The same category again the same day is not; an UPGRADE (Slight →
   * Moderate mid-morning) is. */

  var OUTLOOK_KEY = 'vane.notified.spc.v1';
  var OUTLOOK_MIN_RANK = 3;      // Slight and up
  var QUIET_OUTLOOK_RANK = 4;    // learned quiet mode: Enhanced and up

  function outlookNotifyPick(prev, date, day, risk, minRank) {
    if (!risk || risk.rank < (minRank || OUTLOOK_MIN_RANK)) return null;
    var p = (prev && prev.date === date) ? prev : { date: date };
    var k = 'day' + day;
    if ((p[k] || 0) >= risk.rank) return null;
    var next = { date: p.date };
    next.day1 = p.day1 || 0; next.day2 = p.day2 || 0;
    next[k] = risk.rank;
    return next;
  }

  function notifyOutlook(day, risk) {
    if (!get('notifyOutlook') || !canNotify()) return;
    var prev = null;
    try { prev = JSON.parse(localStorage.getItem(OUTLOOK_KEY)); } catch (e) { /* fine */ }
    var date = new Date().toISOString().slice(0, 10);
    var quiet = !!(global.NotifyLearn && global.NotifyLearn.policyFor('spc').quiet);
    var next = outlookNotifyPick(prev, date, day, risk, quiet ? QUIET_OUTLOOK_RANK : OUTLOOK_MIN_RANK);
    if (!next) return;
    try { localStorage.setItem(OUTLOOK_KEY, JSON.stringify(next)); } catch (e) { /* fine */ }
    post('SPC Day ' + day + ': ' + risk.label + ' risk at your location', {
      body: 'The Storm Prediction Center\'s Day ' + day + ' outlook puts a ' +
        risk.label.toLowerCase() + ' severe-weather risk over your pin. ' +
        'Details on the Radar tab under the SPC layer.',
      tag: 'vane-spc-day' + day
    }, 'spc');
  }

  /* ── Background watch state ──────────────────────────────────────────
   * There is no push server, but where the platform allows (installed on
   * Android / desktop Chrome), the service worker can re-check alerts a
   * few times a day via periodic background sync. The SW cannot read
   * localStorage, so the page mirrors what it needs — location, severity
   * floor, seen alert ids — into a cache the SW can open. */

  function syncWatch(loc, alerts) {
    if (!('caches' in global) || !loc) return Promise.resolve('unsupported');
    var s = load();
    var blob = {
      lat: loc.lat, lon: loc.lon, name: loc.name,
      notify: !!s.notify,
      floor: C.ALERT_RANK[s.notifyMinSeverity] || 3,
      seen: (alerts || []).map(function (a) { return a.id; }).slice(0, 400),
      // So the worker can tag its notifications by family (for learning)
      // and honour families the user muted — Extreme still gets through.
      families: C.ALERT_FILTERS.map(function (f) {
        return { key: f.key, src: f.match ? f.match.source : null };
      }),
      mute: global.NotifyLearn ? Object.keys(global.NotifyLearn.muted()) : []
    };
    return caches.open('vane-watch').then(function (c) {
      return c.put('/watch-state', new Response(JSON.stringify(blob), {
        headers: { 'Content-Type': 'application/json' }
      }));
    }).then(function () { return 'ok'; }).catch(function () { return 'failed'; });
  }

  // Seed the "already seen" set on first load so opening the app during an
  // ongoing event doesn't fire a burst of notifications for old alerts.
  function seed(alerts) {
    (alerts || []).forEach(function (a) { seenAlertIds[a.id] = true; });
  }

  /* ── App icon badge ─────────────────────────────────────────────────── */

  /* The closest thing an installed web app has to a live tile. On iOS 16.4+
   * and on Android and desktop Chrome, `setAppBadge` puts a count on the home
   * screen icon — so a severe alert is visible without opening anything, which
   * is the actual job a weather widget does.
   *
   * It is deliberately only severe-and-above. A badge that lights up for a
   * routine advisory is a badge people learn to ignore, and the one time it
   * matters they will not look. The count is filtered by the same alert
   * families the rest of the app respects, so muting marine warnings mutes the
   * badge too.
   *
   * Fails silently by design: the API is absent in most browsers, and on iOS
   * it exists but throws unless the app is actually installed. Neither is an
   * error worth showing anyone. */
  function badgeCount(alerts) {
    var floor = C.ALERT_RANK[get('notifyMinSeverity')] || 3;
    return filterAlerts(alerts).filter(function (a) {
      return (C.ALERT_RANK[a.severity] || 0) >= floor;
    }).length;
  }

  function updateBadge(alerts) {
    if (!('setAppBadge' in navigator)) return Promise.resolve('unsupported');
    var n = badgeCount(alerts);
    try {
      var p = n > 0 ? navigator.setAppBadge(n) : navigator.clearAppBadge();
      return Promise.resolve(p)
        .then(function () { return n > 0 ? 'set:' + n : 'cleared'; })
        .catch(function () { return 'denied'; });     // not installed, usually
    } catch (e) {
      return Promise.resolve('denied');
    }
  }

  /* ── Screen wake lock (F8: dash-mounted phone shouldn't sleep) ───────── */

  function applyWakeLock() {
    var want = get('keepAwake');
    if (!('wakeLock' in navigator)) return Promise.resolve('unsupported');
    if (want && !wakeLock) {
      return navigator.wakeLock.request('screen').then(function (lock) {
        wakeLock = lock;
        lock.addEventListener('release', function () { wakeLock = null; });
        return 'locked';
      }).catch(function (e) { return 'failed: ' + e.message; });
    }
    if (!want && wakeLock) {
      var l = wakeLock; wakeLock = null;
      return l.release().then(function () { return 'released'; });
    }
    return Promise.resolve('unchanged');
  }

  // A wake lock is dropped whenever the tab is hidden; re-acquire on return.
  document.addEventListener('visibilitychange', function () {
    if (!document.hidden && get('keepAwake') && !wakeLock) applyWakeLock();
  });

  // The OS preference always wins over the app setting: if the user has asked
  // the system for reduced motion, no toggle here re-enables animation.
  function reduceMotion() {
    var mq = global.matchMedia && global.matchMedia('(prefers-reduced-motion: reduce)');
    return (mq && mq.matches) || !get('skyMotion');
  }

  global.Settings = {
    load: load, save: save, get: get, reduceMotion: reduceMotion,
    DEFAULTS: DEFAULTS,
    familyOf: familyOf,
    filterAlerts: filterAlerts,
    requestNotifications: requestNotifications,
    notifyNew: notifyNew,
    notifyMotion: notifyMotion,
    notifyOutlook: notifyOutlook,
    syncWatch: syncWatch,
    // Pure decision logic, exported for the test suite.
    shouldNotifyMotion: shouldNotifyMotion,
    motionNotifyText: motionNotifyText,
    outlookNotifyPick: outlookNotifyPick,
    badgeCount: badgeCount,
    updateBadge: updateBadge,
    seed: seed,
    applyWakeLock: applyWakeLock
  };
})(window);
