/* Vane — the radar keeps itself current.
 *
 * The radar sources produce new data on their own clocks: the national
 * composite regenerates about every five minutes, a WSR-88D finishes a volume
 * scan every four to six in precipitation mode, RainViewer publishes a new
 * global frame every ten. The app used to learn about none of it until the
 * next full data refresh — up to ten minutes in Simple mode — so the "latest"
 * frame on screen could be a scan and a half old while the storm moved.
 *
 * This watcher polls a tiny freshness signal (never the imagery itself: the
 * mosaic's published valid time, a single station's last-scan timestamp, the
 * RainViewer frame index) and fires only when the answer actually changes.
 * The expensive part — re-fetching tiles — happens exactly once per real new
 * scan, which is also the least data a live radar can possibly cost.
 *
 * Two disciplines, both testable because everything is injected:
 *
 *   - The first successful probe primes the watcher and fires nothing. The
 *     imagery on screen was fetched seconds ago; "the data you already have
 *     exists" is not news.
 *   - Hidden means silent. No polling while the app is off screen — a phone
 *     in a pocket should not be pulling tiles — and one immediate probe on
 *     return, because the most likely thing to have changed while you were
 *     away is the radar. */
(function (global) {
  'use strict';

  function start(opts) {
    var doc = opts.doc;
    var state = { key: null, primed: false, stopped: false, inFlight: false };

    function probe() {
      if (state.stopped || state.inFlight) return Promise.resolve(false);
      state.inFlight = true;
      return opts.probe().then(function (result) {
        state.inFlight = false;
        // A probe that could not tell (offline, source has no signal) changes
        // nothing: staleness is not detected freshness.
        if (!result || result.key === null || result.key === undefined) return false;
        if (!state.primed) {
          state.primed = true;
          state.key = result.key;
          return false;
        }
        if (result.key === state.key) return false;
        state.key = result.key;
        opts.onFresh(result);
        return true;
      }).catch(function () {
        state.inFlight = false;
        return false;                    // next tick's problem
      });
    }

    var timer = opts.win.setInterval(function () {
      if (!doc.hidden) probe();
    }, opts.pollMs);

    doc.addEventListener('visibilitychange', function () {
      if (!doc.hidden) probe();
    });

    return {
      probe: probe,                      // exposed so the test suite can tick it
      // Switching radar source mid-session invalidates the primed key: the
      // new source's signal is a different quantity, and comparing a mosaic
      // valid-time against a station scan-time would either fire spuriously
      // or swallow the first real update.
      reset: function () { state.key = null; state.primed = false; },
      stop: function () { state.stopped = true; opts.win.clearInterval(timer); }
    };
  }

  global.Live = { start: start };
})(typeof window !== 'undefined' ? window : self);
