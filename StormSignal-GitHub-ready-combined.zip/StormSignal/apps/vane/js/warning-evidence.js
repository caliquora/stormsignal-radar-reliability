/* Evidence-linked official warnings. Session history, not a warning service.
 * Never infer cancellation from absence or turn an outage into an all-clear. */
(function (root) {
  'use strict';
  var STALE_MS = 15 * 60000;
  function time(s) { var v = typeof s === 'number' ? s : Date.parse(s); return isFinite(v) && v > 0 ? v : null; }
  function iso(s) { var t = time(s); return t === null ? 'Unknown' : new Date(t).toISOString(); }
  function sourceLink(a) {
    var s = a && a.id;
    if (typeof s !== 'string') return null;
    // Only official HTTPS alert records may become links; no markup or arbitrary hosts.
    if (/^https:\/\/api\.weather\.gov\/alerts\/[A-Za-z0-9:._%-]+$/.test(s)) return s;
    return null;
  }
  function feedState(status, now) {
    if (!status || !status.available) return 'unavailable';
    var t = time(status.receivedAt);
    if (t === null || t > now + 120000) return 'unknown';
    if (status.stale || now - t > STALE_MS) return 'stale';
    return 'current';
  }
  function activeRecords(alerts, now) {
    return (alerts || []).filter(function(a){var end=time(a.expires); return end===null || end>now;});
  }
  function fingerprint(a) {
    return JSON.stringify([a.event,a.severity,a.sent,a.onset,a.expires,a.headline,a.instruction,a.description]);
  }
  function createLedger() {
    var location = null, previous = {}, events = [], lastReceipt = null;
    function event(kind,a,at) {
      events.unshift({kind:kind,event:a.event || 'Official alert',id:a.id,at:at,sent:a.sent || null,
        expires:a.expires || null,source:sourceLink(a)}); events=events.slice(0,30);
    }
    return { ingest: function (key,status,now) {
      if (key !== location) {location=key;previous={};events=[];lastReceipt=null;}
      if (feedState(status,now)!=='current' || (lastReceipt !== null && time(status.receivedAt) <= time(lastReceipt))) return;
      var next={}; (status.alerts || []).forEach(function(a){
        if (!a.id) return; next[a.id]=a;
        if (!previous[a.id]) event('First seen here',a,now);
        else if (fingerprint(a)!==fingerprint(previous[a.id])) event('Record changed',a,now);
      });
      Object.keys(previous).forEach(function(id){
        if (!next[id]) event('Not returned by latest check; cancellation not inferred',previous[id],now);
      });
      previous=next;lastReceipt=status.receivedAt;
    }, events: function(){return events.slice();} };
  }
  var ledger = createLedger();
  function node(tag,text,cls) {var e=root.document.createElement(tag);if(text)e.textContent=text;if(cls)e.className=cls;return e;}
  function link(a) {var u=sourceLink(a);if(!u)return null;var e=node('a','Open official NWS record');e.href=u;e.target='_blank';e.rel='noopener noreferrer';return e;}
  function render(status,loc,now) {
    if (!root.document) return;
    now=now===undefined?Date.now():now;loc=loc||{};
    var key=String(loc.lat)+'|'+String(loc.lon), state=feedState(status,now);
    ledger.ingest(key,status,now);
    var box=root.document.getElementById('warning-evidence');if(!box)return;
    box.textContent='';box.dataset.state=state;
    var heading=node('div',null,'warning-evidence-head');
    heading.appendChild(node('strong','Official warning desk'));
    var official=node('a','NWS guidance ↗');official.href='https://www.weather.gov/';official.target='_blank';official.rel='noopener noreferrer';heading.appendChild(official);box.appendChild(heading);
    var current=status&&status.alerts||[];
    var active=activeRecords(current,now);
    var message=state==='current' ? (active.length ? active.length+' alert record(s) returned for this point.' : 'No active NWS alerts returned for this point at the last check. This is not an all-clear.')
      : state==='stale' ? 'Official alert feed is out of date. Current warning status is unknown.'
      : 'Official alert status is unavailable or unverified. Do not interpret an empty screen as no warnings.';
    box.appendChild(node('p',message,'warning-evidence-status'));
    box.appendChild(node('p',(loc.name || 'Selected point')+' · Last received '+iso(status&&status.receivedAt)+' · US coverage only.','warning-evidence-meta'));
    active.forEach(function(a){
      var d=node('details',null,'warning-evidence-record');
      if ((a.severity==='Extreme'||a.severity==='Severe')&&state==='current') d.open=true;
      d.appendChild(node('summary',(state==='current'?'':'Last received record · ')+(a.event||'Official alert')));
      d.appendChild(node('p',[a.severity,a.urgency,a.certainty].filter(Boolean).join(' · '),'warning-evidence-meta'));
      if(a.headline)d.appendChild(node('p',a.headline));
      d.appendChild(node('p','Issued '+iso(a.sent)+' · Effective '+iso(a.onset)+' · Expires '+iso(a.expires),'warning-evidence-meta'));
      d.appendChild(node('strong','Official instruction'));
      d.appendChild(node('p',a.instruction||'No instruction text supplied in this record. Read the official record.','warning-evidence-instruction'));
      var l=link(a);if(l)d.appendChild(l);
      if(a.description){var detail=node('details');detail.appendChild(node('summary','Full official description'));detail.appendChild(node('p',a.description,'warning-evidence-instruction'));d.appendChild(detail);}
      box.appendChild(d);
    });
    var history=node('details');history.appendChild(node('summary','Warning changes this session'));
    history.appendChild(node('p','Observed record changes for this selected point only. Not a complete warning archive. Changing location clears this log.','warning-evidence-meta'));
    var ol=node('ol');ledger.events().forEach(function(e){var li=node('li',iso(e.at)+' · '+e.kind+' · '+e.event);var l=link({id:e.id});if(l){li.appendChild(node('br'));li.appendChild(l);}ol.appendChild(li);});
    if(!ledger.events().length)history.appendChild(node('p','No changes recorded from a current feed.'));
    history.appendChild(ol);box.appendChild(history);
  }
  var api={activeRecords:activeRecords,feedState:feedState,sourceLink:sourceLink,createLedger:createLedger,render:render};
  root.WarningEvidence=api;if(typeof module!=='undefined')module.exports=api;
})(typeof window!=='undefined'?window:globalThis);
