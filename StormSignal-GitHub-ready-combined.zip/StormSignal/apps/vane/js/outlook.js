/* Vane — the extended outlook, and where it stops being a forecast.
 *
 * Every weather app will show you sixteen days. Almost all of them draw day 14
 * exactly like day 2: one number, one icon, same size, same confidence. That
 * is the most common lie in consumer weather, and it is the reason people say
 * forecasts are useless — they are judging the whole product by the part of it
 * that was never a forecast in the first place.
 *
 * The honest version needs two things this module computes.
 *
 * First, a real ensemble. Not five agencies' single runs compared against each
 * other — that is model-formulation disagreement, and it is what the model
 * agreement panel already shows. This is ECMWF's IFS integrated fifty times
 * from slightly perturbed initial states, which measures the chaos in the
 * atmosphere itself. Its spread is the actual uncertainty, and it grows: about
 * a degree on day 1, ten or more by day 14.
 *
 * Second, something to compare that spread against. A ten-degree spread means
 * nothing on its own. Compared against how much this location's temperature
 * varies at this time of year anyway — twenty years of ERA5, pooled over a
 * window around the calendar day — it means everything. When the ensemble's
 * p10–p90 range reaches the climatological p10–p90 range, the forecast has
 * told you precisely as much as "it is August in Oklahoma" and no more.
 *
 * That ratio is the skill horizon, and it is *measured per location and per
 * run* rather than asserted as a fixed number of days. It moves: a locked-in
 * summer ridge stays skilful far longer than a progressive winter pattern, and
 * the same date can be firm in Phoenix and mush in Reykjavík. Vane draws it
 * where it actually falls, and stops showing precise numbers past it. */
(function (global) {
  'use strict';

  var C = global.VaneConfig;

  /* ── Order statistics ───────────────────────────────────────────────── */

  // Linear-interpolated percentile on an already-sorted array.
  function percentile(sorted, p) {
    var n = sorted.length;
    if (!n) return null;
    if (n === 1) return sorted[0];
    var pos = (n - 1) * p;
    var lo = Math.floor(pos), hi = Math.ceil(pos);
    if (lo === hi) return sorted[lo];
    return sorted[lo] + (sorted[hi] - sorted[lo]) * (pos - lo);
  }

  function stats(values) {
    var v = (values || []).filter(function (x) {
      return x !== null && x !== undefined && !isNaN(x);
    }).slice().sort(function (a, b) { return a - b; });
    if (!v.length) return null;
    var sum = 0;
    for (var i = 0; i < v.length; i++) sum += v[i];
    return {
      n: v.length,
      min: v[0],
      max: v[v.length - 1],
      mean: sum / v.length,
      p10: percentile(v, 0.10),
      p25: percentile(v, 0.25),
      median: percentile(v, 0.50),
      p75: percentile(v, 0.75),
      p90: percentile(v, 0.90),
      spread: percentile(v, 0.90) - percentile(v, 0.10)
    };
  }

  /* ── Climatology ────────────────────────────────────────────────────── */

  /* Day-of-year distance that wraps at the year boundary, so a window around
   * 2 January still reaches back into December. */
  function doyDistance(a, b) {
    var d = Math.abs(a - b);
    return Math.min(d, 366 - d);
  }

  function dayOfYear(iso) {
    var m = /^(\d{4})-(\d{2})-(\d{2})/.exec(iso || '');
    if (!m) return null;
    var start = Date.UTC(+m[1], 0, 1);
    return Math.round((Date.UTC(+m[1], +m[2] - 1, +m[3]) - start) / 86400000) + 1;
  }

  /* The distribution of a variable at this location for a calendar day, pooled
   * over ±window days across every year in the archive. One date's twenty
   * samples are far too few; ±7 days gives ~300, which is enough for a stable
   * p10/p90 without smearing the seasonal cycle. */
  function climatology(archive, targetIso, opts) {
    opts = opts || {};
    var window = opts.window === undefined ? C.OUTLOOK.NORMAL_WINDOW_DAYS : opts.window;
    var doy = dayOfYear(targetIso);
    if (doy === null || !archive || !archive.time) return null;

    var tmax = [], tmin = [], precip = [], wet = 0, total = 0;
    for (var i = 0; i < archive.time.length; i++) {
      var d = dayOfYear(archive.time[i]);
      if (d === null || doyDistance(d, doy) > window) continue;
      var a = archive.tmax[i], b = archive.tmin[i], p = archive.precip[i];
      if (a !== null && a !== undefined && !isNaN(a)) tmax.push(a);
      if (b !== null && b !== undefined && !isNaN(b)) tmin.push(b);
      if (p !== null && p !== undefined && !isNaN(p)) {
        precip.push(p);
        total++;
        if (p >= C.OUTLOOK.WET_MM) wet++;
      }
    }
    if (!tmax.length) return null;
    return {
      samples: tmax.length,
      tmax: stats(tmax),
      tmin: stats(tmin),
      precip: stats(precip),
      wetFrequency: total ? wet / total : null
    };
  }

  /* ── Skill ──────────────────────────────────────────────────────────── */

  /* The ratio that decides everything below. 0 means every member agrees; 1
   * means the ensemble is as uncertain as the climate record, i.e. it has
   * added nothing to what you already knew about the season. */
  function skillRatio(ensembleStats, climateStats) {
    if (!ensembleStats || !climateStats) return null;
    var clim = climateStats.spread;
    if (!clim || clim <= 0) return null;
    return ensembleStats.spread / clim;
  }

  function bandFor(ratio) {
    if (ratio === null || ratio === undefined) return null;
    var bands = C.OUTLOOK.SKILL_BANDS;
    for (var i = 0; i < bands.length; i++) {
      if (ratio <= bands[i].max) return bands[i];
    }
    return bands[bands.length - 1];
  }

  /* The horizon is the first day that is no longer a forecast, and it has to be
   * *sustained*: a single noisy day past the threshold is not the end of skill,
   * it is a single noisy day. Requiring two consecutive days stops the marker
   * jumping around between runs. */
  function horizonIndex(days) {
    for (var i = 0; i < days.length - 1; i++) {
      var a = days[i], b = days[i + 1];
      if (!a.band || !b.band) continue;
      if (a.band.key !== 'firm' && a.band.key !== 'soft' &&
          b.band.key !== 'firm' && b.band.key !== 'soft') {
        return i;
      }
    }
    return -1;
  }

  /* ── Assembly ───────────────────────────────────────────────────────── */

  /* One row per lead day, carrying the ensemble distribution, the local normal
   * for that calendar day, the anomaly between them, and how much of that is
   * signal. `deterministic` is the ordinary single-run forecast, so the two can
   * be shown together — it is often outside the ensemble's own middle half at
   * long leads, which is itself worth seeing. */
  function build(ensemble, archive, deterministic) {
    if (!ensemble || !ensemble.time || !ensemble.time.length) return null;

    var days = ensemble.time.map(function (iso, i) {
      var tmax = stats(ensemble.tmax[i]);
      var tmin = stats(ensemble.tmin[i]);
      var precip = ensemble.precip[i] || [];
      var clim = archive ? climatology(archive, iso) : null;

      var wetMembers = precip.filter(function (p) { return p >= C.OUTLOOK.WET_MM; }).length;
      var ratio = clim ? skillRatio(tmax, clim.tmax) : null;

      var det = null;
      if (deterministic && deterministic.time) {
        var k = deterministic.time.indexOf(iso);
        if (k !== -1) {
          det = {
            tmax: deterministic.temperature_2m_max[k],
            tmin: deterministic.temperature_2m_min[k],
            code: deterministic.weather_code[k],
            precip: deterministic.precipitation_sum[k]
          };
        }
      }

      return {
        date: iso,
        lead: i,
        members: tmax ? tmax.n : 0,
        tmax: tmax,
        tmin: tmin,
        precipProbability: precip.length ? wetMembers / precip.length : null,
        precip: stats(precip),
        normal: clim,
        // Positive means warmer than the twenty-year normal for this date.
        anomaly: (tmax && clim && clim.tmax) ? tmax.median - clim.tmax.mean : null,
        wetAnomaly: (clim && clim.wetFrequency !== null && precip.length)
          ? (wetMembers / precip.length) - clim.wetFrequency : null,
        skill: ratio,
        band: bandFor(ratio),
        deterministic: det
      };
    });

    /* The tail is ragged: not every member is integrated to the full 16 days,
     * and the last day or two can come back with none at all. Trim those rather
     * than drawing dated columns with nothing in them — the card names its own
     * length from what actually arrived. */
    while (days.length && !days[days.length - 1].members) days.pop();
    if (!days.length) return null;

    var h = horizonIndex(days);
    return {
      model: ensemble.model,
      utcOffsetSeconds: ensemble.utcOffsetSeconds || 0,
      days: days,
      horizon: h,                          // index of the first non-forecast day
      hasNormals: !!archive,
      normalYears: archive ? archive.years : null,
      normalFrom: archive ? archive.from : null,
      normalTo: archive ? archive.to : null
    };
  }

  /* ── Plain language ─────────────────────────────────────────────────── */

  function describeAnomaly(anomalyC, imperial) {
    if (anomalyC === null || anomalyC === undefined) return null;
    // A temperature *difference* scales by 9/5 with no offset. Adding 32 here
    // is the classic bug and would turn "2 °C above normal" into "36 °F above".
    var v = imperial ? anomalyC * 9 / 5 : anomalyC;
    var unit = imperial ? '°F' : '°C';
    var a = Math.abs(v);
    if (a < (imperial ? 1.8 : 1)) return 'near normal';
    return Math.round(a) + ' ' + unit + (v > 0 ? ' above normal' : ' below normal');
  }

  var WEEKDAY = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
  var MONTH = ['January', 'February', 'March', 'April', 'May', 'June', 'July',
    'August', 'September', 'October', 'November', 'December'];

  // Built from the date parts directly: these are calendar dates in the
  // forecast location's own zone, and putting them through a Date the browser
  // will localise is exactly how a day gets lost.
  function lastLabel(day) {
    var m = /^(\d{4})-(\d{2})-(\d{2})$/.exec(day && day.date || '');
    if (!m) return 'the end of the useful range';
    var dow = new Date(Date.UTC(+m[1], +m[2] - 1, +m[3])).getUTCDay();
    return WEEKDAY[dow] + ' ' + parseInt(m[3], 10) + ' ' + MONTH[+m[2] - 1];
  }

  /* The sentence at the top of the card. It deliberately describes the *regime*
   * past the horizon rather than any single day, because that is the only thing
   * left with skill out there. */
  function summary(outlook, imperial) {
    if (!outlook || !outlook.days.length) return 'No extended data for this location.';
    var days = outlook.days;
    var h = outlook.horizon;
    var firm = h === -1 ? days.length : h;

    var parts = [];
    // Naming the date rather than a day number: "day 7" invites the reader to
    // wonder whether today was day 0 or day 1.
    var last = days[Math.max(0, firm - 1)];
    parts.push(firm >= days.length
      ? 'The ensemble holds together across the whole ' + days.length + '-day range for this location.'
      : 'Day-by-day detail is worth reading through ' + lastLabel(last) + '. After that the ' +
        'ensemble is as spread out as the climate record for these dates, so only the ' +
        'overall pattern means anything.');

    if (!outlook.hasNormals) return parts.join(' ');

    // Regime past the horizon: average the anomaly over the low-skill tail.
    var tail = days.slice(Math.max(1, firm));
    var vals = tail.map(function (d) { return d.anomaly; })
      .filter(function (v) { return v !== null; });
    if (vals.length) {
      var mean = vals.reduce(function (a, b) { return a + b; }, 0) / vals.length;
      var desc = describeAnomaly(mean, imperial);
      parts.push(desc === 'near normal'
        ? 'The later period leans close to normal for the time of year.'
        : 'The later period leans ' + desc + '.');
    }

    var wet = tail.map(function (d) { return d.wetAnomaly; })
      .filter(function (v) { return v !== null; });
    if (wet.length) {
      var wm = wet.reduce(function (a, b) { return a + b; }, 0) / wet.length;
      if (Math.abs(wm) >= 0.12) {
        parts.push(wm > 0 ? 'Wetter than usual for this window.' : 'Drier than usual for this window.');
      }
    }
    return parts.join(' ');
  }

  /* What the ensemble is and is not, said once, in the card. This is the
   * honest answer to "does this work for long range": as probability, yes; as
   * a daily forecast, no. */
  function caveat(outlook) {
    if (!outlook) return '';
    return 'Ensemble of ' + (outlook.days[0] ? outlook.days[0].members : 0) + ' members from ' +
      C.OUTLOOK.MODEL_LABEL + ', run from slightly different starting states so the ' +
      'spread between them measures real forecast uncertainty rather than ' +
      'disagreement between vendors. Ensembles do not extend how far ahead the ' +
      'weather on a given day can be known — they measure it. ' +
      (outlook.hasNormals
        ? 'The skill marker is placed where the spread reaches the ' +
          outlook.normalYears + '-year local range for the same dates (ERA5, ' +
          outlook.normalFrom + '–' + outlook.normalTo + '), not at a fixed day.'
        : 'Local normals could not be loaded, so the skill marker is unavailable ' +
          'for this location and only the raw spread is shown.');
  }

  global.Outlook = {
    build: build,
    stats: stats,
    percentile: percentile,
    climatology: climatology,
    dayOfYear: dayOfYear,
    doyDistance: doyDistance,
    skillRatio: skillRatio,
    bandFor: bandFor,
    horizonIndex: horizonIndex,
    describeAnomaly: describeAnomaly,
    summary: summary,
    lastLabel: lastLabel,
    caveat: caveat
  };
})(window);
