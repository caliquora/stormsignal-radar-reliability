/* Vane — each tab brings its own code.
 *
 * Every module used to load at boot, including ~170 KB that only Chase and
 * Outlook ever run: the 3D storm view, the shot planner, the model chart
 * with its state outlines, the box-plot and meteogram charts, and the two
 * tabs' renderers. On a phone that is parse and compile time paid before
 * the forecast can paint, for screens most opens never visit.
 *
 * Now those load on first entry to their tab. The app keeps calling
 * UI.renderCells(state) or UI.renderModels(state) whenever data lands, as
 * before; until the tab's code is here, each of those calls is a stub that
 * remembers its latest arguments. When the bundle arrives the real
 * renderers replace the stubs and every remembered call is replayed once —
 * the renderers draw from the live state object, so the latest call is the
 * only one that matters.
 *
 * Offline is unchanged: every file is still in the service worker's shell
 * cache, so a lazy load is a cache read. A load that fails anyway (first
 * visit, no network) leaves the stubs in place and is retried on the next
 * entry to the tab. */
(function (global) {
  'use strict';

  var UI = global.UI;

  var BUNDLES = {
    chase: {
      files: ['js/shot.js', 'js/storm3d.js', 'js/ui-chase.js'],
      stubs: ['renderParams', 'renderHodograph', 'renderProfile', 'renderCells', 'renderShot']
    },
    outlook: {
      files: ['js/usstates.js', 'js/modelchart.js', 'js/outlookchart.js',
              'js/meteogram.js', 'js/ui-outlook.js'],
      stubs: ['renderModels', 'renderMeteogram', 'renderOutlook', 'renderDiscussion',
              'renderSpc', 'renderReports']
    }
  };

  var queued = {}, inflight = {}, loaded = {};

  Object.keys(BUNDLES).forEach(function (b) {
    BUNDLES[b].stubs.forEach(function (name) {
      var stub = function () { queued[name] = Array.prototype.slice.call(arguments); };
      stub.lazyBundle = b;
      UI[name] = stub;
    });
  });

  function script(src) {
    return new Promise(function (resolve, reject) {
      var s = document.createElement('script');
      s.src = src;
      s.async = false;              // dynamic scripts then run in insertion order
      s.onload = resolve;
      s.onerror = function () { s.remove(); reject(new Error('Could not load ' + src)); };
      document.head.appendChild(s);
    });
  }

  function replay(b) {
    BUNDLES[b].stubs.forEach(function (name) {
      var args = queued[name];
      delete queued[name];
      if (!args || typeof UI[name] !== 'function' || UI[name].lazyBundle) return;
      try { UI[name].apply(UI, args); }
      catch (e) { if (global.console) console.error(e); }
    });
  }

  /* Resolves once the bundle's code is loaded and its queued renders have
   * been replayed. Idempotent; concurrent callers share one load. */
  function need(b) {
    if (!BUNDLES[b]) return Promise.resolve();
    if (loaded[b]) return Promise.resolve();
    if (inflight[b]) return inflight[b];
    inflight[b] = Promise.all(BUNDLES[b].files.map(script)).then(function () {
      loaded[b] = true;
      inflight[b] = null;
      replay(b);
    }, function (err) {
      inflight[b] = null;
      throw err;
    });
    return inflight[b];
  }

  global.Lazy = {
    need: need,
    loaded: function (b) { return !!loaded[b]; },
    BUNDLES: BUNDLES
  };
})(window);
