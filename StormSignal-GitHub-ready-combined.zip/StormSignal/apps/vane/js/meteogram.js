/* Vane — the meteogram.
 *
 * A 72-hour combined chart: day/night bands, cloud cover, an ensemble
 * temperature envelope with the mean line through it, precipitation bars
 * coloured by how many models agree, and a wind arrow row.
 *
 * The point is the envelope. A single forecast line implies a precision the
 * models don't have; drawing the spread between them shows the user where the
 * forecast is solid and where it is a guess. */
(function (global) {
  'use strict';

  var C = global.VaneConfig, U = global.U;
  var NS = 'http://www.w3.org/2000/svg';

  var W = 1000, H = 340;
  var PAD_L = 52, PAD_R = 16;
  var ROW = {
    cloud: { y: 6, h: 22 },
    temp: { y: 44, h: 132 },
    precip: { y: 192, h: 58 },
    wind: { y: 262, h: 30 },
    axis: { y: 300, h: 34 }
  };

  function e(tag, attrs, kids) {
    var n = document.createElementNS(NS, tag);
    Object.keys(attrs || {}).forEach(function (k) { n.setAttribute(k, attrs[k]); });
    (kids || []).forEach(function (c) { n.appendChild(c); });
    return n;
  }

  function text(str, attrs) {
    var t = e('text', attrs);
    t.textContent = str;
    return t;
  }

  /* ── Data assembly ──────────────────────────────────────────────────── */

  function build(state, hours) {
    var d = state.data;
    if (!d || !d.hourly) return null;
    var h = d.hourly, tz = d.utc_offset_seconds || 0;
    var now = Date.now();

    var start = 0;
    for (var i = 0; i < h.time.length; i++) {
      if (U.epochOf(h.time[i], tz) >= now - 3600000) { start = i; break; }
    }
    var end = Math.min(start + (hours || 72), h.time.length);

    // Ensemble series, if the multi-model payload has arrived. The chart works
    // without it — it just loses the envelope.
    var tempEns = state.ensemble ? global.Models.analyse(state.ensemble, 'temperature_2m') : null;
    var precipEns = state.ensemble ? global.Models.precipAgreement(state.ensemble) : null;
    var ensByEpoch = {};
    if (tempEns) tempEns.hours.forEach(function (x) { ensByEpoch[x.epoch] = x; });
    var precipByEpoch = {};
    if (precipEns) precipEns.hours.forEach(function (x) { precipByEpoch[x.epoch] = x; });

    var pts = [];
    for (var j = start; j < end; j++) {
      var epoch = U.epochOf(h.time[j], tz);
      var ens = ensByEpoch[epoch] || null;
      var pens = precipByEpoch[epoch] || null;
      pts.push({
        index: j,
        time: U.parseLocal(h.time[j]),
        epoch: epoch,
        temp: h.temperature_2m[j],
        feels: h.apparent_temperature ? h.apparent_temperature[j] : null,
        precip: h.precipitation[j],
        pop: h.precipitation_probability ? h.precipitation_probability[j] : null,
        code: h.weather_code[j],
        cloud: h.cloud_cover ? h.cloud_cover[j] : null,
        wind: h.wind_speed_10m[j],
        gust: h.wind_gusts_10m ? h.wind_gusts_10m[j] : null,
        dir: h.wind_direction_10m[j],
        lo: ens ? ens.min : null,
        hi: ens ? ens.max : null,
        spread: ens ? ens.spread : null,
        agreement: pens ? pens.agreement : null,
        wetCount: pens ? pens.wetCount : null,
        models: ens ? ens.n : null
      });
    }
    return { points: pts, tz: tz, ensemble: !!tempEns };
  }

  /* Day/night bands from the daily sunrise/sunset arrays. */
  function daylightBands(state, pts) {
    var d = state.data.daily;
    if (!d || !d.sunrise) return [];
    var tz = state.data.utc_offset_seconds || 0;
    var bands = [];
    for (var i = 0; i < d.sunrise.length; i++) {
      bands.push({
        rise: U.epochOf(d.sunrise[i], tz),
        set: U.epochOf(d.sunset[i], tz)
      });
    }
    return bands;
  }

  /* ── Render ─────────────────────────────────────────────────────────── */

  function render(container, state, opts) {
    opts = opts || {};
    var model = build(state, opts.hours || 72);
    while (container.firstChild) container.removeChild(container.firstChild);
    if (!model || model.points.length < 2) {
      var p = document.createElement('p');
      p.className = 'muted';
      p.textContent = 'Not enough forecast data to draw a meteogram.';
      container.appendChild(p);
      return;
    }

    var pts = model.points;
    var imp = state.imperial;
    var innerW = W - PAD_L - PAD_R;
    var step = innerW / (pts.length - 1);
    var x = function (i) { return PAD_L + i * step; };

    // Temperature scale spans the ensemble envelope, not just the mean, so the
    // envelope can never be clipped by its own axis.
    var lows = [], highs = [];
    pts.forEach(function (p) {
      if (p.temp !== null) { lows.push(p.temp); highs.push(p.temp); }
      if (p.lo !== null) lows.push(p.lo);
      if (p.hi !== null) highs.push(p.hi);
    });
    var tMin = Math.min.apply(null, lows), tMax = Math.max.apply(null, highs);
    var padT = Math.max(1.5, (tMax - tMin) * 0.15);
    tMin -= padT; tMax += padT;
    var ty = function (t) {
      return ROW.temp.y + ROW.temp.h - ((t - tMin) / (tMax - tMin || 1)) * ROW.temp.h;
    };

    var maxPrecip = Math.max(1, pts.reduce(function (a, p) {
      return Math.max(a, p.precip || 0, p.hi !== null ? 0 : 0);
    }, 0));

    var svg = e('svg', {
      viewBox: '0 0 ' + W + ' ' + H, class: 'meteogram',
      preserveAspectRatio: 'none', role: 'img',
      'aria-label': 'Meteogram: temperature, precipitation and wind for the next ' +
        pts.length + ' hours'
    });

    var defs = e('defs');
    var tempGrad = e('linearGradient', { id: 'mg-temp', x1: '0', y1: '0', x2: '0', y2: '1' }, [
      e('stop', { offset: '0', 'stop-color': '#ff9f0a' }),
      e('stop', { offset: '0.5', 'stop-color': '#ffd60a' }),
      e('stop', { offset: '1', 'stop-color': '#64d2ff' })
    ]);
    var envGrad = e('linearGradient', { id: 'mg-env', x1: '0', y1: '0', x2: '0', y2: '1' }, [
      e('stop', { offset: '0', 'stop-color': '#ffffff', 'stop-opacity': '.30' }),
      e('stop', { offset: '1', 'stop-color': '#ffffff', 'stop-opacity': '.10' })
    ]);
    defs.appendChild(tempGrad);
    defs.appendChild(envGrad);
    svg.appendChild(defs);

    /* Night shading behind everything else. */
    var bands = daylightBands(state, pts);
    var nightG = e('g', { class: 'mg-night' });
    pts.forEach(function (p, i) {
      var day = bands.some(function (b) { return p.epoch >= b.rise && p.epoch < b.set; });
      if (day) return;
      nightG.appendChild(e('rect', {
        x: x(i) - step / 2, y: ROW.cloud.y, width: step,
        height: ROW.wind.y + ROW.wind.h - ROW.cloud.y
      }));
    });
    svg.appendChild(nightG);

    /* Cloud cover band — opacity is the cover fraction. */
    var cloudG = e('g', { class: 'mg-cloud' });
    pts.forEach(function (p, i) {
      if (p.cloud === null) return;
      cloudG.appendChild(e('rect', {
        x: x(i) - step / 2, y: ROW.cloud.y, width: step + 0.5, height: ROW.cloud.h,
        fill: '#ffffff', opacity: (p.cloud / 100 * 0.72).toFixed(3)
      }));
    });
    svg.appendChild(cloudG);
    // An all-clear sky draws nothing above, so outline the row to show it was
    // measured rather than missing.
    cloudG.appendChild(e('rect', {
      x: PAD_L, y: ROW.cloud.y, width: W - PAD_L - PAD_R, height: ROW.cloud.h,
      fill: 'none', stroke: 'rgba(255,255,255,0.14)', 'stroke-width': 1, rx: 3
    }));
    svg.appendChild(text('cloud', { x: 4, y: ROW.cloud.y + 15, class: 'mg-rowlabel' }));

    /* Temperature gridlines. */
    var gridG = e('g', { class: 'mg-grid' });
    var ticks = niceTicks(tMin, tMax, 4);
    ticks.forEach(function (t) {
      gridG.appendChild(e('line', { x1: PAD_L, y1: ty(t), x2: W - PAD_R, y2: ty(t) }));
      gridG.appendChild(text(U.temp(t, imp), {
        x: PAD_L - 6, y: ty(t) + 4, class: 'mg-axis-label', 'text-anchor': 'end'
      }));
    });
    svg.appendChild(gridG);

    /* Ensemble envelope: the spread between the coolest and warmest model. */
    if (model.ensemble) {
      var top = [], bottom = [];
      pts.forEach(function (p, i) {
        if (p.hi === null || p.lo === null) return;
        top.push(x(i).toFixed(1) + ',' + ty(p.hi).toFixed(1));
        bottom.unshift(x(i).toFixed(1) + ',' + ty(p.lo).toFixed(1));
      });
      if (top.length > 1) {
        svg.appendChild(e('polygon', {
          class: 'mg-envelope', points: top.concat(bottom).join(' '), fill: 'url(#mg-env)'
        }));
      }
    }

    /* Temperature line. */
    var line = pts.filter(function (p) { return p.temp !== null; })
      .map(function (p) { return x(pts.indexOf(p)).toFixed(1) + ',' + ty(p.temp).toFixed(1); });
    svg.appendChild(e('polyline', {
      class: 'mg-templine', points: line.join(' '),
      fill: 'none', stroke: 'url(#mg-temp)', 'stroke-width': 2.6,
      'stroke-linejoin': 'round', 'stroke-linecap': 'round'
    }));

    /* Precipitation bars, tinted by model agreement where available. */
    var precipG = e('g', { class: 'mg-precip' });
    var barW = Math.max(2, step * 0.62);
    pts.forEach(function (p, i) {
      if (!p.precip) return;
      var hgt = Math.max(1.5, Math.min(1, p.precip / maxPrecip) * ROW.precip.h);
      var agree = p.agreement;
      var fill = agree === null ? '#64d2ff'
        : agree >= 0.99 ? '#0a84ff'
        : agree >= 0.6 ? '#64d2ff'
        : '#64d2ff';
      var rect = e('rect', {
        x: (x(i) - barW / 2).toFixed(1), y: (ROW.precip.y + ROW.precip.h - hgt).toFixed(1),
        width: barW.toFixed(1), height: hgt.toFixed(1), rx: 1.5,
        fill: fill, opacity: agree === null ? '.85' : (0.35 + agree * 0.65).toFixed(2)
      });
      precipG.appendChild(rect);
    });
    svg.appendChild(precipG);
    svg.appendChild(e('line', {
      class: 'mg-baseline', x1: PAD_L, y1: ROW.precip.y + ROW.precip.h,
      x2: W - PAD_R, y2: ROW.precip.y + ROW.precip.h
    }));
    svg.appendChild(text('precip', { x: 4, y: ROW.precip.y + ROW.precip.h, class: 'mg-rowlabel' }));

    /* Wind arrows: rotated to point downwind, opacity by speed. */
    var windG = e('g', { class: 'mg-wind' });
    var everyW = Math.max(1, Math.round(pts.length / 24));
    var maxWind = pts.reduce(function (a, p) { return Math.max(a, p.wind || 0); }, 1);
    pts.forEach(function (p, i) {
      if (i % everyW || p.dir === null) return;
      var cy = ROW.wind.y + ROW.wind.h / 2;
      var g = e('g', {
        transform: 'translate(' + x(i).toFixed(1) + ',' + cy + ') rotate(' + (p.dir + 180) + ')'
      });
      g.appendChild(e('path', {
        d: 'M0,-7 L0,7 M0,7 L-3.2,2.6 M0,7 L3.2,2.6',
        stroke: '#fff', 'stroke-width': 1.6, 'stroke-linecap': 'round',
        fill: 'none', opacity: (0.35 + (p.wind / maxWind) * 0.65).toFixed(2)
      }));
      windG.appendChild(g);
    });
    svg.appendChild(windG);
    svg.appendChild(text('wind', { x: 4, y: ROW.wind.y + ROW.wind.h / 2 + 4, class: 'mg-rowlabel' }));

    /* Time axis with day boundaries called out. */
    var axisG = e('g', { class: 'mg-axis' });
    var everyT = Math.max(1, Math.round(pts.length / 12));
    pts.forEach(function (p, i) {
      var midnight = p.time.getHours() === 0;
      if (i % everyT && !midnight) return;
      if (midnight) {
        axisG.appendChild(e('line', {
          class: 'mg-daybreak', x1: x(i), y1: ROW.cloud.y, x2: x(i), y2: ROW.axis.y - 4
        }));
        axisG.appendChild(text(U.fmtDay(p.time), {
          x: x(i) + 5, y: ROW.axis.y + 22, class: 'mg-daylabel'
        }));
      }
      axisG.appendChild(text(U.fmtHour(p.time, state.hour12), {
        x: x(i), y: ROW.axis.y + 9, class: 'mg-axis-label', 'text-anchor': 'middle'
      }));
    });
    svg.appendChild(axisG);

    /* "Now" marker. */
    var nowIdx = 0;
    var nowT = Date.now();
    for (var k = 0; k < pts.length; k++) { if (pts[k].epoch <= nowT) nowIdx = k; }
    svg.appendChild(e('line', {
      class: 'mg-now', x1: x(nowIdx), y1: ROW.cloud.y, x2: x(nowIdx), y2: ROW.axis.y - 4
    }));

    /* Hover crosshair + readout. */
    var hover = e('g', { class: 'mg-hover', style: 'display:none' });
    var hLine = e('line', { y1: ROW.cloud.y, y2: ROW.axis.y - 4, class: 'mg-hoverline' });
    var hDot = e('circle', { r: 4, class: 'mg-hoverdot' });
    hover.appendChild(hLine);
    hover.appendChild(hDot);
    svg.appendChild(hover);

    container.appendChild(svg);

    var readout = document.createElement('div');
    readout.className = 'mg-readout';
    container.appendChild(readout);
    setReadout(readout, pts[nowIdx], state, model.ensemble);

    // Pointer tracking works in viewBox units so it stays correct at any width.
    function locate(ev) {
      var rect = svg.getBoundingClientRect();
      var px = ((ev.clientX - rect.left) / rect.width) * W;
      var i = Math.round((px - PAD_L) / step);
      return U.clamp(i, 0, pts.length - 1);
    }

    svg.addEventListener('pointermove', function (ev) {
      var i = locate(ev);
      var p = pts[i];
      hover.style.display = '';
      hLine.setAttribute('x1', x(i));
      hLine.setAttribute('x2', x(i));
      hDot.setAttribute('cx', x(i));
      hDot.setAttribute('cy', p.temp === null ? ty(tMin) : ty(p.temp));
      setReadout(readout, p, state, model.ensemble);
    });

    svg.addEventListener('pointerleave', function () {
      hover.style.display = 'none';
      setReadout(readout, pts[nowIdx], state, model.ensemble);
    });
  }

  function setReadout(node, p, state, hasEnsemble) {
    while (node.firstChild) node.removeChild(node.firstChild);
    if (!p) return;
    var imp = state.imperial;

    function chip(label, value, cls) {
      var s = document.createElement('span');
      s.className = 'mg-chip' + (cls ? ' ' + cls : '');
      var l = document.createElement('span');
      l.className = 'mg-chip-label';
      l.textContent = label;
      var v = document.createElement('span');
      v.className = 'mg-chip-value';
      v.textContent = value;
      s.appendChild(l);
      s.appendChild(v);
      node.appendChild(s);
    }

    chip('', U.fmtDay(p.time) + ' ' + U.fmtHour(p.time, state.hour12), 'mg-chip-time');
    chip('temp', U.temp(p.temp, imp));
    if (p.feels !== null) chip('feels', U.temp(p.feels, imp));
    chip('precip', U.precip(p.precip, imp) + (p.pop !== null ? ' · ' + p.pop + '%' : ''));
    chip('wind', U.speed(p.wind, imp) + ' ' + U.compass(p.dir) +
      (p.gust ? ' G' + Math.round(imp ? U.msToMph(p.gust) : U.msToKph(p.gust)) : ''));
    if (p.cloud !== null) chip('cloud', p.cloud + '%');

    if (hasEnsemble && p.spread !== null) {
      var conf = global.Models.confidence(p.spread, 'temperature_2m');
      chip('models', p.models + ' models ±' +
        (imp ? (p.spread * 9 / 5 / 2).toFixed(1) + '°F' : (p.spread / 2).toFixed(1) + '°C'),
        'mg-conf-' + conf.level);
      if (p.wetCount !== null && p.wetCount > 0) {
        chip('rain in', p.wetCount + '/' + p.models + ' models',
          p.agreement >= 0.99 ? 'mg-conf-high' : p.agreement < 0.5 ? 'mg-conf-low' : '');
      }
    }
  }

  function niceTicks(min, max, count) {
    var range = max - min;
    if (!isFinite(range) || range <= 0) return [min];
    var raw = range / count;
    var mag = Math.pow(10, Math.floor(Math.log(raw) / Math.LN10));
    var norm = raw / mag;
    var stepv = (norm >= 5 ? 10 : norm >= 2 ? 5 : norm >= 1 ? 2 : 1) * mag;
    var out = [], t = Math.ceil(min / stepv) * stepv;
    for (; t <= max; t += stepv) out.push(t);
    return out;
  }

  global.Meteogram = { render: render, build: build };
})(window);
