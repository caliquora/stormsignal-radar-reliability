/* Vane — rendering core. Owns the global UI object and the two helpers
 * every card file shares: the status bar and the SVG element factory.
 *
 * Rendering is split by card (ui-now, ui-chase, ui-outlook, ui-chrome);
 * each file attaches its renderers to this same object, so callers keep
 * calling UI.renderX exactly as before. Pure functions of state → DOM;
 * no fetching happens in any of them. */
(function (global) {
  'use strict';

  var C = global.VaneConfig, U = global.U, D = global.Derive;
  var UI = global.UI = global.UI || {};
  /* ── Status bar (F8: never leave the user guessing about staleness) ── */

  function status(msg, kind) {
    var bar = U.el('status-bar');
    if (!msg) { bar.hidden = true; return; }
    bar.hidden = false;
    bar.className = 'status-bar ' + (kind || 'info');
    bar.textContent = msg;
  }

  /* ── Chase: hodograph ───────────────────────────────────────────────── */

  var SVGNS = 'http://www.w3.org/2000/svg';

  function svg(tag, attrs) {
    var n = document.createElementNS(SVGNS, tag);
    Object.keys(attrs || {}).forEach(function (k) { n.setAttribute(k, attrs[k]); });
    return n;
  }

  UI.status = status;
  UI.svg = svg;
})(window);
