/* Vane — Ground Truth: is this storm doing something nobody will report?
 *
 * Storm reports are the truth everything in severe weather is trained and
 * verified on — and a report exists only if a person sees the storm and
 * sends it. A hailstorm over empty ranchland at night and the same storm
 * over a city at noon look alike on radar; only one reaches the record.
 *
 * This model separates the two, the way ecologists separate "the animal is
 * there" from "the surveyor saw it" (occupancy models with imperfect
 * detection):
 *
 *   P(report) = P(severe weather is occurring) × P(someone reports it)
 *             =        σ(f(radar))           ×      σ(g(people, hour))
 *
 * f reads the storm's radar signature — the same eleven single-scan
 * features as Vane's severe model. g reads how many people live along the
 * storm's next half hour of track (within 10 and 40 km; US Census 2020)
 * and the local solar hour, since night hides hail and tornadoes alike.
 * Both are fitted together, on reports alone, by scripts/train/groundtruth.js;
 * the weights file records how it was checked.
 *
 * Research has measured this bias for years — Potvin et al. (2019) corrected
 * the tornado database for it; a 2024 Weather and Forecasting paper did it
 * for radar-estimated hail. What this adds is the live, storm-by-storm
 * version, for every severe hazard, in a free app: "this storm is probably
 * producing severe weather right now — and here is the chance anyone
 * reports it." The split rests on one assumption, stated wherever it is
 * shown: that reporting is near complete where many people are awake. */
(function (global) {
  'use strict';

  var GRID = global.PopGrid.GRID;
  var RADAR_N = 11;                // StormModel.featuresOf(cell, null).x, single scan
  /* Plus the storm's distance from its radar. Radars sit near cities, so a
   * storm over empty country is usually far from one: the beam passes high
   * over it and its signature reads weaker than the storm is. Without this
   * the model would blame the radar's blind spot on the witnesses. */
  var RADAR = ['…11 storm-model features', 'range100', 'range100sq'];
  // Night hides storms more where fewer people are about: the interaction.
  var DETECT = ['pop10', 'pop40', 'cosHour', 'sinHour', 'pop40xCos', 'pop40xSin'];
  var PATH_MIN = [0, 15, 30];
  var CLIP = 5;

  function popAt(grid, lat, lon) { return global.PopGrid.at(grid, lat, lon); }

  // Where a cell will be `min` minutes on, carried on its own motion.
  function ahead(cell, lat, lon, min) {
    var km = (cell.speedKt || 0) * 1.852 * min / 60;
    var toward = ((cell.fromDeg || 0) + 180) * Math.PI / 180;
    return { lat: lat + km * Math.cos(toward) / 111.32,
             lon: lon + km * Math.sin(toward) / (111.32 * Math.cos(lat * Math.PI / 180)) };
  }

  /* The "would anyone see it" features: people along the next half hour of
   * track, and the local solar hour. null off the population grid (outside
   * the lower 48), where the model does not speak. */
  function detectFeatures(cell, lat, lon, utcMs, grid) {
    var s10 = 0, s40 = 0, n = 0;
    PATH_MIN.forEach(function (m) {
      var p = ahead(cell, lat, lon, m), v = popAt(grid, p.lat, p.lon);
      if (v) { s10 += v.p10; s40 += v.p40; n++; }
    });
    if (!n) return null;
    var d = new Date(utcMs);
    var h = ((d.getUTCHours() + d.getUTCMinutes() / 60 + lon / 15) % 24 + 24) % 24;
    var c = Math.cos(2 * Math.PI * h / 24), sn = Math.sin(2 * Math.PI * h / 24), p40 = s40 / n;
    return [s10 / n, p40, c, sn, p40 * c, p40 * sn];
  }

  function radarFeatures(cell) {
    var r = (cell.range || 0) / 100;
    return global.StormModel.featuresOf(cell, null).x.slice(0, RADAR_N).concat([r, r * r]);
  }

  function weights() { return global.GroundTruthWeights || null; }

  function linear(part, x) {
    var z = part.b;
    for (var i = 0; i < part.w.length; i++) {
      z += part.w[i] * Math.max(-CLIP, Math.min(CLIP, (x[i] - part.mean[i]) / part.std[i]));
    }
    return z;
  }
  function sig(z) { return 1 / (1 + Math.exp(-z)); }

  /* → { occurring, reported, detect } probabilities, or null. */
  function assess(xr, xd, W) {
    W = W || weights();
    if (!W || !W.ship || !xr || !xd) return null;
    var occ = sig(linear(W.radar, xr)), det = sig(linear(W.detect, xd));
    return { occurring: occ, detect: det, reported: occ * det };
  }

  /* A live cell from js/cells.js → its assessment, given the decoded grid. */
  function forCell(cell, utcMs, grid) {
    if (!cell || !isFinite(cell.lat) || !isFinite(cell.lon)) return null;
    return assess(radarFeatures(cell), detectFeatures(cell, cell.lat, cell.lon, utcMs, grid));
  }

  function loadGrid() { return global.PopGrid.load(); }

  global.GroundTruth = {
    GRID: GRID, DETECT: DETECT, RADAR: RADAR, RADAR_N: RADAR_N,
    popAt: popAt, ahead: ahead, detectFeatures: detectFeatures, radarFeatures: radarFeatures,
    assess: assess, forCell: forCell, loadGrid: loadGrid, weights: weights
  };
})(typeof window !== 'undefined' ? window : globalThis);
