/* Integrated decision views; textContent throughout, no generated markup.
 * Optional point forecasts are requested on demand and reused for ten minutes. */
(function (global) {
  'use strict';
  var I = global.Intelligence, U = global.U, MIN = 60000, HOUR = 3600000;
  var current, bundles = {}, pending = {}, lastPlanRefresh = 0, comparing = false;
  function el(id) { return U.el(id); }
  function p(box, text, cls) { var n = U.make('p', cls || 'decision-note', text); box.appendChild(n); return n; }
  function button(box, text, fn) {
    var b = U.make('button', 'ghost-btn', text); b.type = 'button'; b.addEventListener('click', fn); box.appendChild(b); return b;
  }
  function clock(at, offset) { return U.fmtEpoch(at, offset === undefined ? (current.data || {}).utc_offset_seconds : offset, current.hour12); }
  function dateTime(at, offset) {
    var d = new Date(at + (offset || 0) * 1000);
    return d.toISOString().slice(5, 10) + ' ' + clock(at, offset);
  }
  function places() {
    var list = [current.location].concat(current.savedPlaces || []), seen = {};
    return list.filter(function (l) { var k = I.key(l); if (seen[k]) return false; seen[k] = true; return true; });
  }
  function updatePlaceSelect() {
    var select = el('decision-plan-place'), old = select.value;
    var signature = places().map(function (l) { return I.key(l) + l.name; }).join('|');
    if (select.dataset.signature === signature) return;
    U.clear(select); select.dataset.signature = signature;
    places().forEach(function (l) { var option = U.make('option', null, l.name); option.value = I.key(l); select.appendChild(option); });
    if (Array.from(select.options).some(function (o) { return o.value === old; })) select.value = old;
  }
  function warningText(status, now) {
    if (!status || !status.available) return 'Official alert status unavailable for this point.';
    if (status.stale || now - status.receivedAt > 15 * MIN) return 'Official alerts are out of date. Check the latest NWS guidance.';
    var active = status.alerts.filter(function (a) { return Date.parse(a.expires) > now; });
    return active.length ? 'NWS: ' + active.map(function (a) { return a.event; }).join(' · ') :
      'No active NWS alerts returned for this point at the last check.';
  }
  function stale(bundle, now) { return !bundle || !bundle.data || bundle.stale || bundle.data.__cachedAt || now - bundle.receivedAt > 30 * MIN; }
  function pointBundle(loc, extra, force) {
    var k = I.key(loc), now = Date.now(), previous = bundles[k];
    if (!force && previous && now - previous.receivedAt < 10 * MIN && (!extra || previous.extra)) return Promise.resolve(previous);
    if (pending[k]) return pending[k].then(function (b) { return extra && !b.extra ? pointBundle(loc, extra, false) : b; });
    var same = I.key(current.location) === k && current.data && !current.stale && now - current.fetchedAt < 10 * MIN;
    var sameReceivedAt = same ? current.fetchedAt : null;
    var forecast = same ? Promise.resolve(current.data) : global.API.forecast(loc.lat, loc.lon);
    pending[k] = Promise.all([forecast, global.API.alertsWithStatus(loc.lat, loc.lon),
      extra ? global.API.sounding(loc.lat, loc.lon).catch(function () { return null; }) : Promise.resolve(null),
      extra ? global.API.multiModel(loc.lat, loc.lon, 24).catch(function () { return null; }) : Promise.resolve(null)
    ]).then(function (r) {
      var b = { loc: loc, data: r[0], alerts: r[1], sounding: r[2], ensemble: r[3],
        extra: !!extra, extraReceivedAt: extra ? Date.now() : null,
        receivedAt: r[0].__cachedAt || (same ? sameReceivedAt : Date.now()) };
      bundles[k] = b;
      I.capture(loc, b.data, b.receivedAt);
      return b;
    }).finally(function () { delete pending[k]; });
    return pending[k];
  }
  function renderChanges() {
    var box = el('decision-changes'), entry = I.location(current.location), now = Date.now();
    U.clear(box);
    if (current.alertStatus && (!current.alertStatus.available || current.alertStatus.stale)) {
      p(box, warningText(current.alertStatus, now), 'decision-warning');
    }
    if (!current.data) { p(box, 'Waiting for a forecast for this location.'); return; }
    if (current.stale || now - current.fetchedAt > 30 * MIN) {
      p(box, 'Forecast is out of date. New conclusions are paused until fresh data arrives.', 'decision-warning'); return;
    }
    var history = entry.snapshots, after = history[history.length - 1], before = history[history.length - 2];
    if (!before) p(box, 'First forecast saved for ' + current.location.name + '. Changes appear after a later forecast is received.');
    else {
      p(box, 'Comparing forecasts received ' + dateTime(before.receivedAt, current.data.utc_offset_seconds) +
        ' and ' + dateTime(after.receivedAt, current.data.utc_offset_seconds) + '.');
      var changes = I.changes(before, after, now);
      if (!changes.length) p(box, 'No material changes in the overlapping next 24 hours.');
      changes.forEach(function (c) {
        var text;
        if (c.kind === 'timing') text = 'First modeled rain moved from ' + clock(c.before) + ' to ' + clock(c.after) +
          ' (' + Math.abs(c.delta / 60).toFixed(1) + ' hours ' + (c.delta < 0 ? 'earlier' : 'later') + ').';
        else if (c.kind === 'rain-signal') text = c.added ? 'A rain signal has appeared around ' + clock(c.at) + '.' :
          'The previous rain signal around ' + clock(c.at) + ' has dropped out of this forecast.';
        else {
          var format = c.kind === 'temp' ? function (v) { return U.temp(v, current.imperial); } :
            c.kind === 'wind' ? function (v) { return U.speed(v, current.imperial); } : function (v) { return v + '%'; };
          text = (c.kind === 'temp' ? 'Temperature' : c.kind === 'wind' ? 'Wind' : 'Rain chance') +
            ' at ' + clock(c.at) + ': ' + format(c.before) + ' → ' + format(c.after) + '.';
        }
        p(box, text, 'decision-change');
      });
    }
    var scenarios = I.scenarios(now - current.ensembleAt <= 30 * MIN ? current.ensemble : null, now);
    if (scenarios.length) {
      p(box, 'Possible outcomes over the next 12 hours', 'decision-label');
      scenarios.forEach(function (s) { p(box, s.models.join(', ') + ': ' +
        (s.dry ? 'no modeled rain ≥0.1 mm/hour in this window.' : 'first modeled rain ' +
          clock(s.start) + (s.end !== s.start ? '–' + clock(s.end) : '') + '.')); });
      p(box, 'What would change the outlook? New radar echoes and station rain reports can support an earlier rain scenario; ' +
        'a later forecast can shift the window again. Model counts describe agreement, not event probabilities.');
    } else p(box, 'Alternative model scenarios are unavailable for the upcoming window.');
    p(box, 'Sources: Open-Meteo forecast and named model guidance. Times are receipt times, not model issuance times.');
  }
  function renderStories() {
    var box = el('decision-stories'), s = I.read(), now = Date.now(); U.clear(box);
    /* Folded on a phone while empty; once you follow a storm it opens,
     * unless you have folded it yourself since. */
    var fold = el('decision-stories-fold');
    if (fold && s.following.length && fold.dataset.userSet !== '1') fold.open = true;
    if (!s.following.length) { p(box, 'Choose “Follow storm” in Areas of interest. Up to five storm histories stay on this device.'); return; }
    s.following.forEach(function (id) {
      var tr = s.tracks[id], latest = tr && tr.samples[tr.samples.length - 1]; if (!latest) return;
      var card = U.make('article', 'decision-item'); box.appendChild(card);
      card.appendChild(U.make('h3', null, 'Following ' + id));
      var status = tr.status;
      if (status === 'tracking' && now - latest.at > 15 * MIN) status = 'stale';
      var statusText = { tracking: 'Tracking', missing: 'Not in the latest feed — outcome unknown', stale: 'Last scan is out of date',
        'identity-uncertain': 'Identity uncertain — tracking paused' }[status] || status;
      p(card, statusText + ' · last scan ' + U.relative(now - latest.at), status === 'tracking' ? 'decision-label' : 'decision-warning');
      var c = latest.cell;
      /* The same fitted slope the Areas of interest rows use — never a
       * first-versus-last comparison, which a single noisy scan can flip. */
      var fit = global.Cells.fitTrend(tr.samples.slice(-8).map(function (s) {
        return { t: s.at, dbz: s.cell.maxDbz, top: s.cell.top };
      }));
      if (!fit) {
        p(card, tr.samples.length + ' recorded scan' + (tr.samples.length === 1 ? '' : 's') +
          '. Core ' + c.maxDbz + ' dBZ, top ' + Math.round(c.top) +
          ' kft — a trend needs three scans over eight minutes.');
      } else {
        p(card, tr.samples.length + ' recorded scans. ' +
          (fit.dir === 'strengthening' ? 'Strengthening' : fit.dir === 'weakening' ? 'Weakening' : 'Steady') +
          ': fitted ' + (fit.dbzRate > 0 ? '+' : '') + fit.dbzRate.toFixed(1) + ' dBZ/10 min over ' +
          fit.scans + ' scans (' + fit.firstDbz + ' → ' + fit.lastDbz + ' dBZ); echo top ' +
          Math.round(fit.firstTop) + ' → ' + Math.round(fit.lastTop) + ' kft.',
          fit.dir === 'strengthening' ? 'decision-warning' : null);
      }
      if (c.tvs || c.mesoRank > 0) p(card, 'Radar algorithm: ' + (c.tvs ? 'tornado-vortex signature; ' : '') +
        'mesocyclone rank ' + c.mesoRank + '. These detections do not confirm a tornado.');
      var warnings = I.warningsAt(c, current.warningFeatures, now);
      if (warnings.length) p(card, 'The last detected position falls inside: ' + warnings.join(', '), 'decision-warning');
      if (status === 'tracking') {
        places().slice(0, 6).forEach(function (loc) {
          var a = I.impact(tr, loc, now);
          if (a) p(card, 'Projection · ' + loc.name + ': closest approach about ' + Math.round(a.etaMin) +
            ' min from now, passing ' + U.distance(a.closest, current.imperial) + ' from the point if motion holds.');
        });
      }
      if (status !== 'tracking') p(card, 'Projections are paused. The feed does not identify splits, mergers, dissipation, or radar handoffs.');
      var nearby = (global.Cells.state.cells || []).filter(function (cell) {
        return cell.id !== id && I.validCell(cell, now) && I.distance(c, cell) < 30;
      }).slice(0, 3);
      if (status !== 'tracking' && nearby.length) {
        p(card, 'Nearby detections have unverified identities. Following one starts a separate history.');
        nearby.forEach(function (cell) { button(card, 'Follow ' + cell.id, function () { follow(cell); }); });
      }
      var detail = U.make('details', 'decision-history'); detail.appendChild(U.make('summary', null, 'Scan history and projection results'));
      tr.samples.slice(-8).reverse().forEach(function (sample) { p(detail, clock(sample.at) + ' · ' + sample.cell.maxDbz +
        ' dBZ · ' + sample.cell.lat.toFixed(3) + ', ' + sample.cell.lon.toFixed(3)); });
      var results = tr.predictions.filter(function (prediction) { return prediction.result; });
      if (results.length) {
        var mean = results.reduce(function (a, r) { return a + r.result.errorKm; }, 0) / results.length;
        p(detail, '15-minute position projections: mean error ' + U.distance(mean, current.imperial) +
          ' across ' + results.length + ' matches to later NEXRAD detections. This is position error, not tornado prediction skill.');
      } else p(detail, 'Position predictions are saved before the event. Waiting for matching later scans to check them.');
      card.appendChild(detail);
      var controls = U.make('div', 'decision-actions'); card.appendChild(controls);
      button(controls, 'Locate last position', function () { if (current.onFocusCell) current.onFocusCell(c); });
      if (status === 'identity-uncertain') {
        var live = global.Cells.state.cells.find(function (cell) { return cell.id === id; });
        if (live) button(controls, 'Start a new history', function () { follow(live); });
      }
      button(controls, 'Stop following', function () { I.unfollow(id); render(current); global.UI.renderCells(current); });
    });
    p(box, 'NEXRAD storm attributes via Iowa Environmental Mesonet. Fixed-motion projections do not model storm growth, splitting, or changing direction.');
  }
  function follow(cell) {
    if (!I.follow(cell, Date.now())) {
      el('decision-follow-status').textContent = 'Could not follow: the scan is stale or five storms are already followed.'; return;
    }
    el('decision-follow-status').textContent = 'Following ' + cell.id + '.';
    render(current); global.UI.renderCells(current);
  }
  function renderPlans() {
    var box = el('decision-plans'), plans = I.read().plans, now = Date.now(); U.clear(box);
    if (!plans.length) p(box, 'Add a place and activity to find upcoming hours that meet your preferences.');
    plans.forEach(function (plan) {
      var card = U.make('article', 'decision-item'); box.appendChild(card);
      card.appendChild(U.make('h3', null, plan.name + ' · ' + plan.loc.name));
      var b = bundles[I.key(plan.loc)];
      p(card, warningText(b && b.alerts, now), 'decision-warning');
      if (stale(b, now)) p(card, 'A fresh forecast is needed before suggesting a window. Use Refresh plans.');
      else {
        var windows = I.planWindow(b.data, plan.loc, plan.preferences, now);
        var blocked = b.alerts && b.alerts.available && b.alerts.alerts.some(function (a) {
          return Date.parse(a.expires) > now && (a.severity === 'Severe' || a.severity === 'Extreme');
        });
        if (blocked) p(card, 'A severe official alert applies here. Activity suggestions are paused; follow the official instructions.', 'decision-warning');
        else if (!windows.length) p(card, 'No complete forecast window meets these preferences in the next 48 hours.');
        else windows.forEach(function (w) { p(card, dateTime(w.start, b.data.utc_offset_seconds) + '–' + clock(w.end, b.data.utc_offset_seconds) +
          ' · forecast rain chance up to ' + w.maxPop + '% · gusts up to ' + U.speed(w.maxGust, current.imperial), 'decision-change'); });
        p(card, 'Forecast received ' + U.relative(now - b.receivedAt) + '. Times are local to ' + plan.loc.name + '.');
      }
      p(card, 'Preferences: ' + plan.preferences.duration + ' h, ' + plan.preferences.startHour + ':00–' + plan.preferences.endHour +
        ':00; rain chance ≤' + plan.preferences.maxPop + '%; gusts ≤' + U.speed(plan.preferences.maxGust, current.imperial) +
        '; ' + U.temp(plan.preferences.minTemp, current.imperial) + '–' + U.temp(plan.preferences.maxTemp, current.imperial) +
        (plan.preferences.daylight ? '; daylight.' : '.'));
      button(card, 'Remove plan', function () { I.read().plans = I.read().plans.filter(function (p) { return p.id !== plan.id; }); I.save(); renderPlans(); });
    });
  }
  function refreshPlans(force) {
    var now = Date.now();
    if (!force && now - lastPlanRefresh < 10 * MIN) return;
    lastPlanRefresh = now;
    var unique = {}, chain = Promise.resolve();
    I.read().plans.forEach(function (plan) {
      var k = I.key(plan.loc); if (unique[k]) return; unique[k] = true;
      chain = chain.then(function () { return pointBundle(plan.loc, false, !!force).catch(function () {
        el('decision-plan-status').textContent = 'Some point forecasts could not refresh; existing data retains its timestamp.';
      }).then(renderPlans); });
    });
    return chain;
  }
  function renderTargets() {
    var box = el('decision-targets'), now = Date.now(); U.clear(box);
    var list = I.read().targets;
    if (!list.length) p(box, 'Add up to three towns or coordinate pairs, then compare conditions at a shared future time.');
    list.forEach(function (target) {
      var card = U.make('article', 'decision-item'); box.appendChild(card);
      card.appendChild(U.make('h3', null, target.name));
      var b = bundles[I.key(target)], at = now + Number(el('decision-target-hours').value) * HOUR;
      p(card, U.distance(I.distance(current.location, target), current.imperial) + ' straight-line distance from ' + current.location.name + '.');
      p(card, warningText(b && b.alerts, now), 'decision-warning');
      if (stale(b, now) || !b.extra || now - b.extraReceivedAt > 30 * MIN) p(card, 'Choose Compare targets to load current guidance for this point.');
      else {
        // Nearest model hour; every candidate uses the same UTC valid time.
        at = Math.round(at / HOUR) * HOUR;
        var result = I.targetSummary(target, b.data, b.sounding, b.ensemble, at), h = result.hour, cv = result.convective;
        p(card, 'Valid ' + dateTime(at, b.data.utc_offset_seconds) + ' local · received ' + U.relative(now - b.receivedAt), 'decision-label');
        if (h) p(card, 'Visibility ' + (h.visibility === null ? 'unavailable' : U.distance(h.visibility / 1000, current.imperial)) +
          ' · gusts ' + U.speed(h.gust, current.imperial) + ' · rain chance ' + (h.pop === null ? 'unavailable' : h.pop + '%') + '.');
        if (cv) p(card, 'Modeled CAPE ' + (cv.cape == null ? 'unavailable' : Math.round(cv.cape) + ' J/kg') +
          ' · 0–6 km shear ' + (cv.shear6 ? U.speed(cv.shear6.magnitude, current.imperial) : 'unavailable') + '.');
        else p(card, 'Convective environment unavailable for this hour.');
        // Chase-day odds from this point's forecast profile (js/chaseday.js).
        var odds = cv && global.ChaseDay ? global.ChaseDay.odds(global.ChaseDay.envFromConvective(cv)) : null;
        if (odds !== null) {
          p(card, 'Chase-day odds: ' + (odds < 0.01 ? 'under 1%' : Math.round(odds * 100) + '%') +
            ' chance of a severe report within ' + global.ChaseDay.weights().radiusKm + ' km by the night, ' +
            'judged from this hour’s forecast profile (the model learned from early-evening soundings).');
        }
        if (result.daylight) p(card, result.daylight.isDaylight ? 'About ' + result.daylight.minutesToSunset + ' minutes of daylight remain at the comparison time.' : 'The comparison time is outside daylight.');
        if (result.scenarios.length) result.scenarios.forEach(function (s) {
          p(card, s.models.join(', ') + ': ' + (s.dry ? 'dry model scenario in the next 12 hours.' :
            'first modeled rain around ' + clock(s.start, b.data.utc_offset_seconds) + '.'));
        });
        else p(card, 'Model disagreement could not be assessed.');
        var reasons = [];
        if (h && h.visibility !== null && h.visibility < 5000) reasons.push('modeled visibility below 5 km');
        if (h && h.gust !== null && h.gust >= 15) reasons.push('modeled gusts at least ' + U.speed(15, current.imperial));
        if (result.daylight && !result.daylight.isDaylight) reasons.push('darkness');
        if (reasons.length) p(card, 'Planning constraints: ' + reasons.join('; ') + '.', 'decision-warning');
      }
      p(card, 'Road closures, terrain visibility, cellular coverage, and route travel time have not been verified. This is point guidance, not a safe-intercept route.');
      var a = U.make('a', 'ghost-btn', 'Open directions'); a.href = 'https://www.google.com/maps/dir/?api=1&destination=' +
        encodeURIComponent(target.lat + ',' + target.lon); a.target = '_blank'; a.rel = 'noopener noreferrer'; card.appendChild(a);
      button(card, 'Remove target', function () { I.read().targets = list.filter(function (t) { return I.key(t) !== I.key(target); }); I.save(); renderTargets(); });
    });
  }
  /* The accountability ledger. One verification engine feeds it —
   * js/verify.js, which settles each finished day against the station's
   * full METAR record — and the ranked leaderboard renders into #scorecard
   * above this box (UI.renderScorecard). This box adds what the ranking
   * does not show: which way each agency leans, the displayed forecast's
   * own record, and the limits. */
  function renderJournal() {
    var box = el('decision-journal'); U.clear(box);
    var V = global.Verify; if (!V) return;
    var sc = V.scorecard(), m = V.climate();
    var factor = current.imperial ? 1.8 : 1, unit = current.imperial ? '°F' : '°C';
    var signed = function (c) { return (c >= 0 ? '+' : '') + (c * factor).toFixed(1) + unit; };
    p(box, sc.days + ' verified day' + (sc.days === 1 ? '' : 's') + ' · ' + sc.pendingDays +
      ' forecast day' + (sc.pendingDays === 1 ? '' : 's') + ' awaiting verification · ' +
      current.location.name + '.', 'decision-label');
    if (sc.rows.length) {
      var wrap = U.make('div', 'decision-table-wrap'), table = U.make('table', 'decision-table');
      table.appendChild(U.make('caption', null, 'Which way each agency leans here (day-ahead, forecast minus observed)'));
      var head = U.make('tr');
      ['Agency', 'Highs', 'Lows', 'Days'].forEach(function (t) {
        var th = U.make('th', null, t); th.scope = 'col'; head.appendChild(th);
      });
      var thead = U.make('thead'); thead.appendChild(head); table.appendChild(thead);
      var body = U.make('tbody');
      sc.rows.forEach(function (r) {
        var tr = U.make('tr');
        [r.short, signed(r.biasHi), signed(r.biasLo), String(r.n)].forEach(function (t) {
          tr.appendChild(U.make('td', null, t));
        });
        body.appendChild(tr);
      });
      if (m) {
        var tr = U.make('tr', 'decision-row-blend');
        ['Displayed forecast', signed(m.biasHi), signed(m.biasLo), String(m.n)].forEach(function (t) {
          tr.appendChild(U.make('td', null, t));
        });
        body.appendChild(tr);
      }
      table.appendChild(body); wrap.appendChild(table); box.appendChild(wrap);
    }
    p(box, 'Day-ahead highs and lows only, each settled against ' + (sc.station || 'the nearest station') +
      '’s full day of METARs — every finished day is verified, whether or not Vane was open. ' +
      'A station is a reference near your pin, not a thermometer at it.');
    renderRainReliability(box);
    p(box, 'No tornado skill or false-alarm rate is claimed from these checks.');
    if (!I.storageOK()) p(box, 'Device storage is unavailable. This session works, but history will not survive closing it. Export to keep a copy.', 'decision-warning');
  }
  /* The rain-chance reliability table (js/raincal.js): per 10% band, what
   * the forecast said on average and how often it actually rained. */
  function renderRainReliability(box) {
    var R = global.RainCal; if (!R || !current) return;
    var r = R.summary(current.location);
    p(box, 'Rain chances: ' + r.hours + ' hour' + (r.hours === 1 ? '' : 's') + ' verified · ' +
      r.pending + ' awaiting their hour.', 'decision-label');
    if (r.rows.length) {
      var wrap = U.make('div', 'decision-table-wrap'), table = U.make('table', 'decision-table');
      table.appendChild(U.make('caption', null, 'How often it rained when the forecast gave each chance (six hours ahead)'));
      var head = U.make('tr');
      ['Forecast', 'Rained', 'Hours'].forEach(function (t) {
        var th = U.make('th', null, t); th.scope = 'col'; head.appendChild(th);
      });
      var thead = U.make('thead'); thead.appendChild(head); table.appendChild(thead);
      var body = U.make('tbody');
      r.rows.forEach(function (row) {
        var tr = U.make('tr');
        [row.lo + '–' + row.hi + '%', row.observed + '%', String(row.n) + (row.ready ? '' : ' (too few)')]
          .forEach(function (t) { tr.appendChild(U.make('td', null, t)); });
        body.appendChild(tr);
      });
      table.appendChild(body); wrap.appendChild(table); box.appendChild(wrap);
    }
    p(box, 'Each hour’s chance is the one shown six hours before it, checked against ' +
      (r.station || 'the nearest station') + '’s reports for that hour: any rain, drizzle, snow ' +
      'or hail reported there counts, "in the vicinity" does not. A band speaks in Insight once it has ' +
      R.MIN_BIN + ' hours.');
  }

  function render(state) {
    current = state;
    if (!el('decision-changes')) return;
    var bundle = bundles[I.key(state.location)];
    if (bundle && bundle.data === state.data) bundle.stale = !!state.stale;
    updatePlaceSelect(); renderChanges(); renderStories(); renderPlans(); renderTargets(); renderJournal();
  }
  function receive(state, kind) {
    current = state; var now = Date.now();
    if (state.data && !state.stale && now - state.fetchedAt <= 30 * MIN) {
      if (kind === 'forecast') I.capture(state.location, state.data, state.fetchedAt);
      bundles[I.key(state.location)] = Object.assign({}, bundles[I.key(state.location)], {
        loc: state.location, data: state.data, alerts: state.alertStatus, receivedAt: state.fetchedAt, stale: false });
    }
    if (kind === 'cells') {
      I.ingest(global.Cells.state.error ? [] : global.Cells.state.cells, now, true);
    }
    render(state);
    if (kind === 'forecast') refreshPlans(false);
  }
  function init(state) {
    current = state;
    el('decision-plan-form').addEventListener('submit', function (e) {
      e.preventDefault();
      var loc = places().find(function (l) { return I.key(l) === el('decision-plan-place').value; });
      var prefs = { duration: Number(el('decision-plan-duration').value), startHour: Number(el('decision-plan-start').value),
        endHour: Number(el('decision-plan-end').value), maxPop: Number(el('decision-plan-pop').value),
        maxGust: Number(el('decision-plan-gust').value) / 3.6,
        minTemp: Number(el('decision-plan-temperature').value.split(',')[0]),
        maxTemp: Number(el('decision-plan-temperature').value.split(',')[1]), daylight: el('decision-plan-daylight').checked };
      if (!loc || prefs.startHour >= prefs.endHour || prefs.duration > prefs.endHour - prefs.startHour) {
        el('decision-plan-status').textContent = 'Choose an end time after the start, with room for the full activity.'; return;
      }
      if (I.read().plans.length >= 6) { el('decision-plan-status').textContent = 'Remove a plan before adding more than six.'; return; }
      I.read().plans.push({ id: String(Date.now()) + Math.random().toString(36).slice(2, 6), loc: loc,
        name: el('decision-plan-name').value.trim() || 'Outdoor time', preferences: prefs });
      I.save(); el('decision-plan-status').textContent = 'Plan saved on this device.'; renderPlans(); refreshPlans(true);
    });
    el('decision-plan-refresh').addEventListener('click', function () {
      el('decision-plan-status').textContent = 'Refreshing saved places…';
      refreshPlans(true).then(function () { el('decision-plan-status').textContent = 'Refresh finished. Check each place’s data timestamp.'; });
    });
    el('decision-target-form').addEventListener('submit', function (e) {
      e.preventDefault(); var status = el('decision-target-status'), results = el('decision-target-results');
      status.textContent = 'Searching…'; U.clear(results);
      global.API.geocode(el('decision-target-query').value.trim()).then(function (list) {
        status.textContent = list.length ? 'Choose a location:' : 'No matching location found.';
        list.slice(0, 5).forEach(function (loc) { button(results, loc.name + ' · ' + (loc.admin || ''), function () {
          if (I.read().targets.some(function (t) { return I.key(t) === I.key(loc); })) { status.textContent = 'That target is already added.'; return; }
          if (I.read().targets.length >= 3) { status.textContent = 'Compare up to three targets; remove one first.'; return; }
          I.read().targets.push(loc); I.save(); U.clear(results); status.textContent = 'Target added.'; renderTargets();
        }); });
      }).catch(function () { status.textContent = 'Search unavailable. You can also enter latitude, longitude.'; });
    });
    el('decision-target-hours').addEventListener('change', renderTargets);
    el('decision-target-compare').addEventListener('click', function () {
      if (comparing) return;
      comparing = true; this.disabled = true;
      var status = el('decision-target-status'); status.textContent = 'Loading point forecasts and model guidance…';
      var chain = Promise.resolve(), failures = 0;
      I.read().targets.forEach(function (loc) { chain = chain.then(function () {
        return pointBundle(loc, true, true).catch(function () { failures++; }).then(renderTargets);
      }); });
      chain.finally(function () { comparing = false; el('decision-target-compare').disabled = false;
        status.textContent = failures ? 'Some target data could not refresh. Check the timestamps.' : 'Comparison updated. Review each constraint before choosing a target.'; });
    });
    el('decision-speak').addEventListener('click', function () {
      if (!global.speechSynthesis || !global.SpeechSynthesisUtterance) { el('decision-follow-status').textContent = 'Spoken briefings are unavailable in this browser.'; return; }
      global.speechSynthesis.cancel();
      var text = warningText(current.alertStatus, Date.now()) + ' ' + el('decision-stories').innerText.slice(0, 900);
      global.speechSynthesis.speak(new global.SpeechSynthesisUtterance(text));
    });
    el('decision-stop-speaking').addEventListener('click', function () { if (global.speechSynthesis) global.speechSynthesis.cancel(); });
    el('decision-export').addEventListener('click', function () {
      var scorecard = null;
      var motionCalls = null, rainChances = null;
      try { rainChances = JSON.parse(global.localStorage.getItem('vane.raincal.v1')); } catch (e) { /* none */ }
      try { scorecard = JSON.parse(global.localStorage.getItem('vane.scorecard.v1')); } catch (e) { /* none */ }
      try { motionCalls = JSON.parse(global.localStorage.getItem('vane.motionskill.v1')); } catch (e) { /* none */ }
      var blob = new Blob([JSON.stringify({ decisions: I.read(), verification: scorecard,
        motionCalls: motionCalls, rainChances: rainChances }, null, 2)],
        { type: 'application/json' }), url = URL.createObjectURL(blob);
      var a = U.make('a'); a.href = url; a.download = 'vane-weather-history.json'; a.click();
      setTimeout(function () { URL.revokeObjectURL(url); }, 1000);
    });
    el('decision-clear').addEventListener('click', function () {
      el('decision-clear-confirm').hidden = false;
    });
    el('decision-clear-cancel').addEventListener('click', function () { el('decision-clear-confirm').hidden = true; });
    el('decision-clear-yes').addEventListener('click', function () {
      I.reset();
      if (global.Verify) global.Verify.reset();
      if (global.MotionSkill) global.MotionSkill.reset();
      if (global.RainCal) global.RainCal.reset();
      el('decision-clear-confirm').hidden = true;
      render(current);
      global.UI.renderModels(current);
      if (current.data) { global.UI.renderDaily(current); global.UI.renderInsight(current); }
    });
    // Keep stale labels honest even if no network callbacks occur.
    global.setInterval(function () { if (!document.hidden) render(current); }, MIN);
    document.addEventListener('visibilitychange', function () { if (document.hidden && global.speechSynthesis) global.speechSynthesis.cancel(); });
    render(state);
  }
  global.DecisionUI = { init: init, render: render, receive: receive, follow: follow };
})(window);
