/* Vane decision tools. Pure calculations + bounded, versioned on-device history.
 * Forecasts are recorded before their valid time. Missing/stale data never means
 * dry weather, no warnings, a dissipated storm, or a verified prediction.
 *
 * Forecast VERIFICATION is not done here. An earlier version archived hourly
 * temperature predictions and verified each one only if the app happened to
 * be open within twenty minutes of its valid time — sparse, and a second
 * engine duplicating js/verify.js, which settles every finished day against
 * the station's full METAR record whether the app was open or not. One
 * engine now: js/verify.js. The archive this module used to keep is stripped
 * on read, which also returns its share of the localStorage budget. */
(function (global) {
  'use strict';
  var U = global.U, HOUR = 3600000, MIN = 60000;
  var KEY = 'vane.intelligence.v1', memory = null, storageOK = true;
  function finite(x) { return typeof x === 'number' && isFinite(x); }
  function key(loc) { return loc.lat.toFixed(3) + ',' + loc.lon.toFixed(3); }
  function empty() { return { version: 1, locations: {}, tracks: {}, following: [], plans: [], targets: [] }; }
  function read() {
    if (memory) return memory;
    try {
      var s = JSON.parse(global.localStorage.getItem(KEY));
      if (s && s.version === 1 && s.locations && s.tracks && Array.isArray(s.following) &&
          Array.isArray(s.plans) && Array.isArray(s.targets)) {
        memory = s;
        // Migration: the retired hourly-verification archive.
        var stripped = false;
        Object.keys(s.locations).forEach(function (k) {
          if (s.locations[k].predictions) { delete s.locations[k].predictions; stripped = true; }
        });
        if (stripped) save();
      }
    } catch (e) { storageOK = false; }
    return memory || (memory = empty());
  }
  function save() {
    try {
      var s = read(), serialized = JSON.stringify(s);
      // Leave room for the rest of Vane's preferences and cached forecast.
      // Evict the least recently used location archive if the byte budget fills.
      while (serialized.length > 1500000 && Object.keys(s.locations).length > 1) {
        var keys = Object.keys(s.locations).sort(function (a, b) { return s.locations[a].touched - s.locations[b].touched; });
        delete s.locations[keys[0]];
        serialized = JSON.stringify(s);
      }
      global.localStorage.setItem(KEY, serialized); storageOK = true;
    }
    catch (e) { storageOK = false; }
  }
  function location(loc) {
    var s = read(), k = key(loc);
    if (!s.locations[k]) {
      var keys = Object.keys(s.locations);
      if (keys.length >= 12) {
        keys.sort(function (a, b) { return s.locations[a].touched - s.locations[b].touched; });
        delete s.locations[keys[0]];
      }
      s.locations[k] = { name: loc.name, touched: Date.now(), snapshots: [] };
    }
    return s.locations[k];
  }
  function hours(data) {
    var h = data && data.hourly;
    if (!h || !Array.isArray(h.time)) return [];
    return h.time.map(function (t, i) {
      function v(n) { var x = (h[n] || [])[i]; return finite(x) ? x : null; }
      return { at: U.epochOf(t, data.utc_offset_seconds), temp: v('temperature_2m'),
        rain: v('precipitation'), pop: v('precipitation_probability'), wind: v('wind_speed_10m'),
        gust: v('wind_gusts_10m'), visibility: v('visibility'), code: v('weather_code'),
        dewpoint: v('dew_point_2m'), direction: v('wind_direction_10m'), uv: v('uv_index') };
    }).filter(function (h) { return finite(h.at); });
  }
  function changes(before, after, now) {
    if (!before || !after) return [];
    var pairs = [], map = {};
    before.hours.forEach(function (h) { map[h.at] = h; });
    after.hours.forEach(function (h) {
      if (h.at >= now && h.at <= now + 24 * HOUR && map[h.at]) pairs.push([map[h.at], h]);
    });
    if (!pairs.length) return [];
    var result = [];
    [['temp', 2], ['pop', 20], ['wind', 3]].forEach(function (spec) {
      var best = null;
      pairs.forEach(function (p) {
        if (!finite(p[0][spec[0]]) || !finite(p[1][spec[0]])) return;
        var delta = p[1][spec[0]] - p[0][spec[0]];
        if (Math.abs(delta) >= spec[1] && (!best || Math.abs(delta) > Math.abs(best.delta))) {
          best = { kind: spec[0], at: p[1].at, before: p[0][spec[0]], after: p[1][spec[0]], delta: delta };
        }
      });
      if (best) result.push(best);
    });
    var oldWet = pairs.find(function (p) { return finite(p[0].rain) && p[0].rain >= 0.1; });
    var newWet = pairs.find(function (p) { return finite(p[1].rain) && p[1].rain >= 0.1; });
    var completeRain = pairs.every(function (p) { return finite(p[0].rain) && finite(p[1].rain); });
    if (completeRain && oldWet && newWet && oldWet[0].at !== newWet[1].at) {
      result.unshift({ kind: 'timing', before: oldWet[0].at, after: newWet[1].at,
        delta: (newWet[1].at - oldWet[0].at) / MIN });
    } else if (completeRain && !!oldWet !== !!newWet) {
      result.unshift({ kind: 'rain-signal', added: !!newWet,
        at: newWet ? newWet[1].at : oldWet[0].at });
    }
    return result;
  }
  function capture(loc, data, receivedAt) {
    if (!data || data.__cachedAt || !finite(receivedAt)) return;
    var rows = hours(data).filter(function (h) { return h.at >= receivedAt && h.at <= receivedAt + 48 * HOUR; });
    if (!rows.length) return;
    var entry = location(loc), last = entry.snapshots[entry.snapshots.length - 1];
    // Five-minute minimum avoids refresh-button spam; repeated identical
    // payloads retain their original receipt time, not a fictional new run.
    if (last && receivedAt - last.receivedAt < 5 * MIN) return;
    var comparable = last && last.hours.filter(function (h) { return h.at >= receivedAt; });
    if (last && JSON.stringify(comparable) === JSON.stringify(rows)) return;
    entry.snapshots.push({ receivedAt: receivedAt, hours: rows });
    entry.snapshots = entry.snapshots.slice(-12);
    entry.touched = receivedAt;
    save();
  }
  function scenarios(data, now) {
    if (!data || data.__cachedAt || !data.hourly) return [];
    var h = data.hourly, inds = [];
    (h.time || []).forEach(function (t, i) {
      var at = U.epochOf(t, data.utc_offset_seconds);
      if (at >= now && at <= now + 12 * HOUR) inds.push({ i: i, at: at });
    });
    if (!inds.length) return [];
    var groups = {};
    global.VaneConfig.MODELS.forEach(function (m) {
      var series = h['precipitation_' + m.id] || [], first = null;
      // A model with holes is not a dry scenario.
      if (!inds.every(function (x) { return finite(series[x.i]); })) return;
      inds.some(function (x) { if (series[x.i] >= 0.1) { first = x.at; return true; } return false; });
      var bucket = first === null ? 'dry' : String(Math.floor((first - now) / (3 * HOUR)));
      var g = groups[bucket] || (groups[bucket] = { dry: first === null, start: first, end: first, models: [] });
      g.models.push(m.short);
      if (first !== null) { g.start = Math.min(g.start, first); g.end = Math.max(g.end, first); }
    });
    var validModels = Object.keys(groups).reduce(function (n, k) { return n + groups[k].models.length; }, 0);
    if (validModels < 2) return [];
    return Object.keys(groups).map(function (k) { return groups[k]; }).sort(function (a, b) {
      return (a.dry ? Infinity : a.start) - (b.dry ? Infinity : b.start);
    });
  }
  function distance(a, b) {
    var r = Math.PI / 180, dlat = (b.lat - a.lat) * r, dlon = (b.lon - a.lon) * r;
    var q = Math.sin(dlat / 2) ** 2 + Math.cos(a.lat * r) * Math.cos(b.lat * r) * Math.sin(dlon / 2) ** 2;
    return 6371 * 2 * Math.asin(Math.min(1, Math.sqrt(q)));
  }
  function validCell(c, now) {
    var at = Date.parse(c && c.valid);
    return c && finite(c.lat) && finite(c.lon) && finite(at) && at <= now + MIN && now - at <= 15 * MIN;
  }
  function follow(c, now) {
    now = now || Date.now();
    if (!validCell(c, now)) return false;
    var s = read();
    if (s.following.indexOf(c.id) === -1 && s.following.length >= 5) return false;
    s.tracks[c.id] = { id: c.id, startedAt: now, samples: [], predictions: [], status: 'waiting' };
    if (s.following.indexOf(c.id) === -1) s.following.push(c.id);
    ingest([c], now, false);
    save(); return true;
  }
  function unfollow(id) {
    var s = read(); s.following = s.following.filter(function (x) { return x !== id; });
    delete s.tracks[id]; save();
  }
  function ingest(cells, now, complete) {
    var s = read(), lookup = {};
    (cells || []).forEach(function (c) { lookup[c.id] = c; });
    s.following.forEach(function (id) {
      var tr = s.tracks[id]; if (!tr) return;
      var c = lookup[id], last = tr.samples[tr.samples.length - 1];
      if (!c) { if (complete !== false) tr.status = 'missing'; return; }
      if (!validCell(c, now)) { tr.status = 'stale'; return; }
      var at = Date.parse(c.valid);
      if (tr.status === 'identity-uncertain') return;
      if (last && at < last.at) return;
      if (last && at === last.at) { tr.status = 'tracking'; return; }
      if (last && (at - last.at > 45 * MIN || distance(last.cell, c) > Math.max(30, (at - last.at) / MIN * 3))) {
        tr.status = 'identity-uncertain'; return;
      }
      tr.status = 'tracking';
      tr.predictions.forEach(function (p) {
        if (!p.result && p.issuedAt < at && Math.abs(p.validAt - at) <= 3 * MIN) {
          p.result = { at: at, errorKm: distance(p.point, c), reference: 'NEXRAD tracked-cell position' };
        }
      });
      tr.samples.push({ at: at, receivedAt: now, cell: { id: c.id, site: c.site, stormId: c.stormId,
        lat: c.lat, lon: c.lon, maxDbz: c.maxDbz, top: c.top, mesoRank: c.mesoRank,
        tvs: c.tvs, maxSize: c.maxSize, speedKt: c.speedKt, fromDeg: c.fromDeg, valid: c.valid } });
      tr.samples = tr.samples.slice(-36);
      if (finite(c.speedKt) && c.speedKt > 0 && finite(c.fromDeg) && now - at <= 5 * MIN) {
        tr.predictions.push({ issuedAt: now, validAt: now + 15 * MIN,
          point: global.Cells.project(c, 15 + (now - at) / MIN) });
      }
      tr.predictions = tr.predictions.slice(-100);
    });
    save();
  }
  function impact(track, loc, now) {
    var last = track && track.samples[track.samples.length - 1];
    if (!last || track.status !== 'tracking' || now - last.at > 15 * MIN) return null;
    var c = last.cell;
    if (!finite(c.fromDeg) || !finite(c.speedKt) || c.speedKt <= 0) return null;
    var p = global.Cells.project(c, Math.max(0, now - last.at) / MIN);
    var a = global.Cells.approach(Object.assign({}, c, p), loc.lat, loc.lon);
    return a.approaching && a.etaMin <= 90 ? a : null;
  }
  function insideRing(point, ring) {
    var yes = false;
    for (var i = 0, j = ring.length - 1; i < ring.length; j = i++) {
      var a = ring[i], b = ring[j];
      if ((a[1] > point.lat) !== (b[1] > point.lat) &&
          point.lon < (b[0] - a[0]) * (point.lat - a[1]) / (b[1] - a[1]) + a[0]) yes = !yes;
    }
    return yes;
  }
  function contains(point, geometry) {
    if (!geometry) return false;
    var polygons = geometry.type === 'Polygon' ? [geometry.coordinates] :
      geometry.type === 'MultiPolygon' ? geometry.coordinates : [];
    return polygons.some(function (rings) {
      return rings.length && insideRing(point, rings[0]) &&
        !rings.slice(1).some(function (ring) { return insideRing(point, ring); });
    });
  }
  function warningsAt(point, features, now) {
    return (features || []).filter(function (f) {
      var p = f.properties || f;
      var end = Date.parse(p.ends || p.expires);
      return finite(end) && end > now && contains(point, f.geometry);
    }).map(function (f) { return (f.properties || f).event; });
  }
  function planWindow(data, loc, prefs, now) {
    var p = prefs || {}, duration = Math.max(1, Math.min(6, Number(p.duration) || 1));
    var rows = hours(data).filter(function (h) { return h.at >= now && h.at < now + 48 * HOUR; });
    var candidates = [];
    rows.forEach(function (h, i) {
      var group = rows.slice(i, i + duration);
      if (group.length !== duration || group.some(function (v, j) { return v.at !== h.at + j * HOUR; })) return;
      var ok = group.every(function (v) {
        var localHour = new Date(v.at + (data.utc_offset_seconds || 0) * 1000).getUTCHours();
        return finite(v.temp) && finite(v.rain) && finite(v.pop) && finite(v.gust) && finite(v.code) &&
          v.code < 95 && v.temp >= p.minTemp && v.temp <= p.maxTemp &&
          v.pop <= p.maxPop && v.rain < 0.1 && v.gust <= p.maxGust &&
          localHour >= p.startHour && localHour + 1 <= p.endHour &&
          (!p.daylight || (global.Astro.sunPosition(new Date(v.at), loc.lat, loc.lon).altitude > 0 &&
            global.Astro.sunPosition(new Date(v.at + HOUR), loc.lat, loc.lon).altitude > 0));
      });
      if (ok) candidates.push({ start: h.at, end: h.at + duration * HOUR,
        maxPop: Math.max.apply(null, group.map(function (v) { return v.pop; })),
        maxGust: Math.max.apply(null, group.map(function (v) { return v.gust; })) });
    });
    return candidates.slice(0, 3);
  }
  function targetSummary(loc, data, sounding, ensemble, at) {
    var h = hours(data).find(function (x) { return Math.abs(x.at - at) <= HOUR / 2; });
    var cv = null;
    if (h && sounding && !sounding.__cachedAt && sounding.hourly) {
      var idx = sounding.hourly.time.findIndex(function (t) {
        return Math.abs(U.epochOf(t, sounding.utc_offset_seconds) - at) <= HOUR / 2;
      });
      if (idx >= 0) cv = global.Derive.convective(sounding, idx, finite(h.wind) && finite(h.direction) ? {
        speed: h.wind, dir: h.direction,
        temp: h.temp, dewpoint: h.dewpoint } : null);
    }
    return { hour: h, convective: cv,
      daylight: global.Astro.daylightRemaining(new Date(at), loc.lat, loc.lon),
      scenarios: scenarios(ensemble, at) };
  }
  global.Intelligence = { key: key, read: read, save: save, location: location, hours: hours,
    capture: capture, changes: changes, scenarios: scenarios, distance: distance,
    validCell: validCell, follow: follow, unfollow: unfollow, ingest: ingest, impact: impact,
    contains: contains, warningsAt: warningsAt, planWindow: planWindow,
    targetSummary: targetSummary, storageOK: function () { return storageOK; },
    reset: function () { memory = empty(); save(); },
    // Drop the in-memory copy so the next read() goes back to storage —
    // what a fresh page load does. For tests of on-read migrations.
    forget: function () { memory = null; } };
})(window);
