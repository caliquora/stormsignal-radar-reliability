/* Decision-engine regressions. No dependencies; timestamps are deterministic. */
'use strict';
const assert = require('assert/strict'), fs = require('fs'), vm = require('vm'), path = require('path');
const saved = {}, ctx = { console, Date, Math, localStorage: {
  getItem: k => saved[k] || null, setItem: (k, v) => { saved[k] = v; }
}, document: { getElementById: () => null } };
ctx.window = ctx; vm.createContext(ctx);
['config', 'util', 'derive', 'astro', 'cells', 'intelligence'].forEach(n =>
  vm.runInContext(fs.readFileSync(path.join(__dirname, '../js/' + n + '.js'), 'utf8'), ctx));
const I = ctx.Intelligence, now = Date.parse('2026-09-20T12:00:00Z'), H = 3600000, M = 60000;
const loc = { lat: 35.47, lon: -97.52, name: 'Oklahoma City' };
const other = { lat: 41.60, lon: -93.60, name: 'Des Moines' };
let count = 0;
function test(name, fn) { I.reset(); fn(); count++; console.log('PASS ' + name); }
function data(offset = 0) {
  const hourly = { time: [], temperature_2m: [], precipitation: [], precipitation_probability: [],
    wind_speed_10m: [], wind_gusts_10m: [], wind_direction_10m: [], dew_point_2m: [], visibility: [], weather_code: [] };
  for (let i = 1; i <= 48; i++) {
    hourly.time.push(new Date(now + i * H + offset * 1000).toISOString().slice(0, 16));
    Object.entries({ temperature_2m: 20, precipitation: 0, precipitation_probability: 10,
      wind_speed_10m: 3, wind_gusts_10m: 5, wind_direction_10m: 180, dew_point_2m: 15,
      visibility: 16000, weather_code: 0 }).forEach(([k, v]) => hourly[k].push(v));
  }
  return { hourly, utc_offset_seconds: offset };
}
function cell(minutes = 0, overrides = {}) {
  return Object.assign({ id: 'KTLX-A1', site: 'KTLX', stormId: 'A1', lat: 35.47, lon: -97.70,
    maxDbz: 50, top: 35, mesoRank: 0, tvs: false, maxSize: 0.5,
    speedKt: 20, fromDeg: 270, valid: new Date(now + minutes * M).toISOString() }, overrides);
}
test('hourly epochs are correct across timezones', () => assert.equal(I.hours(data(-18000))[0].at, now + H));
test('nulls remain unknown, not zero', () => { const d = data(); d.hourly.precipitation[0] = null; assert.equal(I.hours(d)[0].rain, null); });
test('cached forecasts never become a new historical forecast', () => {
  const d = data(); d.__cachedAt = now - H; I.capture(loc, d, now); assert.equal(I.location(loc).snapshots.length, 0);
});
test('forecast history survives location switches', () => {
  I.capture(loc, data(), now); I.capture(other, data(), now); assert.equal(I.location(loc).snapshots.length, 1);
});
test('repeated payloads do not invent a new forecast run', () => {
  I.capture(loc, data(), now); I.capture(loc, data(), now + 10 * M); assert.equal(I.location(loc).snapshots.length, 1);
});
test('rain timing compares the same future hours', () => {
  const a = data(), b = data(); a.hourly.precipitation[4] = 1; b.hourly.precipitation[1] = 1;
  const changes = I.changes({ hours: I.hours(a) }, { hours: I.hours(b) }, now);
  assert.equal(changes[0].kind, 'timing'); assert.equal(changes[0].delta, -180);
});
test('missing rain never becomes a forecast drying out', () => {
  const a = data(), b = data(); a.hourly.precipitation[0] = 1; b.hourly.precipitation[0] = null;
  assert.equal(I.changes({ hours: I.hours(a) }, { hours: I.hours(b) }, now).length, 0);
});
test('expired forecast hours do not create false timing changes', () => {
  const a = data(), b = data(); a.hourly.precipitation[0] = 1;
  assert.equal(I.changes({ hours: I.hours(a) }, { hours: I.hours(b) }, now + 2 * H).length, 0);
});
test('scenarios omit incomplete models instead of declaring them dry', () => {
  const d = data(); ctx.VaneConfig.MODELS.forEach((m, i) => {
    d.hourly['precipitation_' + m.id] = Array(48).fill(i === 0 ? null : 0);
  });
  const s = I.scenarios(d, now); assert.equal(s[0].models.length, 4); assert.equal(s[0].dry, true);
});
test('stale and future scans cannot be followed', () => {
  assert.equal(I.follow(cell(-30), now), false); assert.equal(I.follow(cell(30), now), false);
});
test('re-fetching a scan does not add fake evidence', () => {
  I.follow(cell(), now); I.ingest([cell()], now + M); assert.equal(I.read().tracks['KTLX-A1'].samples.length, 1);
});
test('missing followed cells pause projection without auto-switching', () => {
  I.follow(cell(), now); I.ingest([cell(5, { id: 'KTLX-B2' })], now + 5 * M);
  assert.equal(I.read().following[0], 'KTLX-A1'); assert.equal(I.impact(I.read().tracks['KTLX-A1'], loc, now + 5 * M), null);
});
test('long gaps and implausible jumps suspend cell identity', () => {
  I.follow(cell(), now); I.ingest([cell(60)], now + 60 * M);
  assert.equal(I.read().tracks['KTLX-A1'].status, 'identity-uncertain');
  I.follow(cell(), now); I.ingest([cell(5, { lon: -90 })], now + 5 * M);
  assert.equal(I.read().tracks['KTLX-A1'].status, 'identity-uncertain');
});
test('old scans do not reverse the storm history', () => {
  I.follow(cell(), now); I.ingest([cell(5)], now + 5 * M); I.ingest([cell(2)], now + 6 * M);
  assert.equal(I.read().tracks['KTLX-A1'].samples.length, 2);
});
test('storm position forecast is checked only by a later matching scan', () => {
  const c = cell(); I.follow(c, now);
  const predicted = ctx.Cells.project(c, 15); I.ingest([cell(15, predicted)], now + 15 * M);
  assert.ok(I.read().tracks[c.id].predictions[0].result.errorKm < 0.01);
});
test('stale tracks do not continue issuing closest approach advice', () => {
  I.follow(cell(), now); assert.equal(I.impact(I.read().tracks['KTLX-A1'], loc, now + 20 * M), null);
});
test('warning geometry supports polygon holes', () => {
  const g = { type: 'Polygon', coordinates: [[[0,0],[4,0],[4,4],[0,4],[0,0]], [[1,1],[2,1],[2,2],[1,2],[1,1]]] };
  assert.equal(I.contains({lat:3,lon:3}, g), true); assert.equal(I.contains({lat:1.5,lon:1.5}, g), false);
});
test('expired official warning polygons are omitted', () => {
  assert.equal(I.warningsAt(loc, [{ geometry: null, properties: { expires: new Date(now - M).toISOString() } }], now).length, 0);
});
/* Verification moved to js/verify.js (one engine, retrospective, every
 * finished day). What this module still owes: shedding the archive older
 * installs stored, so it stops eating the localStorage budget. */
test('the retired hourly-verification archive is stripped on read', () => {
  const k = I.key(loc);
  saved['vane.intelligence.v1'] = JSON.stringify({ version: 1, tracks: {}, following: [], plans: [], targets: [],
    locations: { [k]: { name: 'Oklahoma City', touched: now, snapshots: [],
      predictions: Array.from({ length: 1800 }, (_, i) => ({ id: 'm:' + i, value: 20 })) } } });
  I.forget();
  const entry = I.read().locations[k];
  assert.ok(entry, 'the location and its snapshots survive');
  assert.equal(entry.predictions, undefined, 'the archive does not');
  assert.ok(!JSON.parse(saved['vane.intelligence.v1']).locations[k].predictions,
    'and the stripped shape is written back, so the bytes are actually reclaimed');
});
test('new locations no longer carry a prediction archive', () => {
  assert.equal(I.location(other).predictions, undefined);
  assert.ok(Array.isArray(I.location(other).snapshots));
});
const prefs = { duration: 2, startHour: 0, endHour: 24, maxPop: 20, maxGust: 10, minTemp: 5, maxTemp: 30, daylight: false };
test('activity windows require contiguous complete hours', () => {
  const d = data(); d.hourly.time = d.hourly.time.filter((_, i) => i % 2 === 0);
  assert.equal(I.planWindow(d, loc, prefs, now).length, 0);
});
test('missing gusts and thunderstorms exclude an activity window', () => {
  const d = data(); d.hourly.wind_gusts_10m.fill(null); assert.equal(I.planWindow(d, loc, prefs, now).length, 0);
  const storm = data(); storm.hourly.weather_code.fill(95); assert.equal(I.planWindow(storm, loc, prefs, now).length, 0);
});
test('activity hours use the location timezone', () => {
  const windows = I.planWindow(data(-18000), loc, { ...prefs, startHour: 8, endHour: 10 }, now);
  assert.equal(windows[0].start, now + H); assert.equal(windows[0].end, now + 3 * H);
});
test('forecast storage survives reload and remains bounded by location', () => {
  for (let i = 0; i < 20; i++) I.capture({ lat: 10 + i, lon: -80, name: 'Point' }, data(), now + i);
  assert.equal(Object.keys(I.read().locations).length, 12);
  vm.runInContext(fs.readFileSync(path.join(__dirname, '../js/intelligence.js'), 'utf8'), ctx);
  assert.equal(Object.keys(ctx.Intelligence.read().locations).length, 12);
});
console.log(count + ' decision-engine tests passed');
