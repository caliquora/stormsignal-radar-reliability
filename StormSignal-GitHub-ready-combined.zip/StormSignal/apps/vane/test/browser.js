/* Deterministic browser test: real captured API payloads replayed offline.
 * The browser timezone is deliberately Asia/Tokyo (UTC+9) against an Oklahoma
 * forecast (UTC-5) — a 14 hour gap — to prove the timezone handling. */
const { chromium } = require('playwright');
const fs = require('fs');
const path = require('path');

const fx = n => fs.readFileSync(path.join(__dirname, 'fixtures', n), 'utf8');
const BASE = process.env.VANE_URL || 'http://127.0.0.1:8000/index.html';
const PNG = Buffer.from(
  'iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mNk+M9QDwADhgGAWjR9awAAAABJRU5ErkJggg==',
  'base64');
// A 1×1 fully transparent PNG: MRMS seeing no echo at all (a clear sky).
const CLEAR_PNG = (() => {
  const zlib = require('zlib');
  const crcT = Array.from({ length: 256 }, (_, n) => { let c = n; for (let k = 0; k < 8; k++) c = c & 1 ? 0xedb88320 ^ (c >>> 1) : c >>> 1; return c >>> 0; });
  const crc = b => { let c = 0xffffffff; for (const x of b) c = crcT[(c ^ x) & 255] ^ (c >>> 8); return (c ^ 0xffffffff) >>> 0; };
  const chunk = (t, d) => { const l = Buffer.alloc(4); l.writeUInt32BE(d.length); const td = Buffer.concat([Buffer.from(t), d]);
    const c = Buffer.alloc(4); c.writeUInt32BE(crc(td)); return Buffer.concat([l, td, c]); };
  const ihdr = Buffer.from([0, 0, 0, 1, 0, 0, 0, 1, 8, 6, 0, 0, 0]);
  return Buffer.concat([Buffer.from([137, 80, 78, 71, 13, 10, 26, 10]), chunk('IHDR', ihdr),
    chunk('IDAT', zlib.deflateSync(Buffer.from([0, 0, 0, 0, 0]))), chunk('IEND', Buffer.alloc(0))]);
})();
let maskBlank = false;          // serve MRMS mask tiles empty: a clear sky

const json = body => ({ status: 200, contentType: 'application/json', body });

/* The captured grid predates the CAPE layer, so its CAPE is SYNTHETIC:
 * stable (0 J/kg) across the western 40% of the grid's own points, then a
 * smooth ramp to 3000 J/kg in the east. Chosen to exercise both the colour
 * ramp and the rule that CAPE under 100 J/kg is left clear — the stable
 * band is wide enough to stay on screen now that the field is drawn
 * bilinearly on the lattice (the 20% padding puts the lattice's first
 * columns off screen). Every other value is the real capture. */
function gridWithCape(raw, scale) {
  const g = JSON.parse(raw);
  const lons = g.map(p => p.longitude), w = Math.min(...lons), e = Math.max(...lons);
  const k = scale === undefined ? 1 : scale;
  g.forEach(p => { const f = (p.longitude - w) / ((e - w) || 1);
    p.current.cape = Math.round(k * 3000 * Math.max(0, (f - 0.4) / 0.6)); });
  return JSON.stringify(g);
}
// Knobs for the field-layer checks: how many grid fetches, the CAPE scale
// the next fetch returns, and whether it fails.
let gridHits = 0, gridCapeScale = 1, gridFail = false, gridDelay = 0, lastGridUrl = '';
let stormEnvHits = 0, stormEnvDelay = 0;
/* The Storm Odds model's hourly inputs for every requested point, starting
 * at the current UTC hour like Open-Meteo's forecast_hours. West to east:
 * a cool, capped, still column to a hot, moist, sheared one. A single point
 * (the Vane AI card) gets the primed column. */
function stormEnvFixture(url) {
  const q = new URL(url).searchParams;
  const lats = q.get('latitude').split(',').map(Number), lons = q.get('longitude').split(',').map(Number);
  const n = +q.get('forecast_hours') || 12, h0 = Math.floor(Date.now() / 3600000) * 3600000;
  const time = Array.from({ length: n }, (_, i) => new Date(h0 + i * 3600000).toISOString().slice(0, 16));
  const w = Math.min(...lons), e = Math.max(...lons);
  const rows = lats.map((lat, k) => {
    const f = e > w ? (lons[k] - w) / (e - w) : 1, all = v => time.map(() => v);
    return { latitude: lat, longitude: lons[k], hourly: { time,
      cape: all(Math.round(3500 * f)), convective_inhibition: all(Math.round(150 * (1 - f) + 10)),
      lifted_index: all(+(6 - 15 * f).toFixed(1)), dew_point_2m: all(+(6 + 16 * f).toFixed(1)),
      total_column_integrated_water_vapour: all(+(12 + 33 * f).toFixed(1)),
      wind_speed_10m: all(6), wind_direction_10m: all(170), wind_speed_850hPa: all(+(5 + 15 * f).toFixed(1)),
      wind_direction_850hPa: all(190), wind_speed_500hPa: all(+(5 + 22 * f).toFixed(1)), wind_direction_500hPa: all(250) } };
  });
  return JSON.stringify(rows.length === 1 ? rows[0] : rows);
}

(async () => {
  // CHROMIUM_PATH lets this run against a preinstalled browser; otherwise
  // Playwright's own download is used.
  const browser = await chromium.launch(
    process.env.CHROMIUM_PATH ? { executablePath: process.env.CHROMIUM_PATH } : {});
  const ctx = await browser.newContext({
    viewport: { width: 1280, height: 1700 },
    timezoneId: 'Asia/Tokyo',
    serviceWorkers: 'block',   // let page.route mocks win; SW is tested separately
    locale: 'en-US'
  });
  const page = await ctx.newPage();

  const errors = [];
  // The rate-limit test serves deliberate 429s; the resource-load errors
  // they log are the test working, not the app failing.
  page.on('console', m => {
    if (m.type() === 'error' && !expect429) errors.push(m.text());
  });
  page.on('pageerror', e => errors.push('PAGEERROR: ' + e.message));

  // ── Replay captured payloads ─────────────────────────────────────────
  // Four different shapes come from the same host; route by query signature.
  /* Open-Meteo returns the 15-minute series starting at the *current* quarter
   * hour, so a payload captured this morning has no bar covering now and the
   * nowcast correctly reports it has nothing to say. Re-stamp the series onto
   * the current quarter hour, written the way the API writes it: local
   * wall-clock for the forecast location, with no zone suffix. The values are
   * left exactly as captured — only the labels move, and converting those
   * labels back is the thing under test. */
/* The captured sounding covers a fixed 24-hour window, and Chase mode steps
   * forward from whichever hour contains "now". Once wall-clock time drifts
   * within two hours of the end of that window, stepping clamps and the hour-
   * stepping assertions fail on the calendar rather than on a code change.
   *
   * Re-stamped the same way the station list and the 15-minute series already
   * are: the values stay exactly as captured and only the labels move, written
   * as location wall-clock the way Open-Meteo writes them. "Now" is placed two
   * hours into the array so stepping has room in both directions. */
  const REPLAY_ENSEMBLE_DAILY = () => {
    // Daily granularity, same aging fix: day zero moves to today, values stay.
    const j = JSON.parse(fx('ensemble-daily.json'));
    const DAY = 86400000;
    const off = (j.utc_offset_seconds || 0) * 1000;
    const start = Math.floor((Date.now() + off) / DAY) * DAY;
    const pad = n => String(n).padStart(2, '0');
    j.daily.time = j.daily.time.map((_, i) => {
      const d = new Date(start + i * DAY);
      return `${d.getUTCFullYear()}-${pad(d.getUTCMonth() + 1)}-${pad(d.getUTCDate())}`;
    });
    return JSON.stringify(j);
  };

  const REPLAY_ENSEMBLE = () => {
    /* Same aging problem as the sounding: the agreement card reads the next
     * 24 hours from "now", and a captured window drifts out from under it.
     * Values stay exactly as captured; only the labels move. */
    const j = JSON.parse(fx('ensemble.json'));
    const HOUR = 3600 * 1000;
    const off = (j.utc_offset_seconds || 0) * 1000;
    const start = Math.floor((Date.now() + off) / HOUR) * HOUR - 2 * HOUR;
    const pad = n => String(n).padStart(2, '0');
    j.hourly.time = j.hourly.time.map((_, i) => {
      const d = new Date(start + i * HOUR);
      return `${d.getUTCFullYear()}-${pad(d.getUTCMonth() + 1)}-${pad(d.getUTCDate())}` +
        `T${pad(d.getUTCHours())}:${pad(d.getUTCMinutes())}`;
    });
    return JSON.stringify(j);
  };

  const REPLAY_SOUNDING = () => {
    const j = JSON.parse(fx('sounding.json'));
    /* The app asks for 48 hours (chase-day odds read the next two 00Z
     * profiles); the capture holds 24. Serve the captured day twice so the
     * payload has the requested shape and a 00Z hour lies ahead at any
     * clock time — no value is invented, the second day repeats the first. */
    Object.keys(j.hourly).forEach(k => { j.hourly[k] = j.hourly[k].concat(j.hourly[k]); });
    const HOUR = 3600 * 1000;
    const off = (j.utc_offset_seconds || 0) * 1000;
    const start = Math.floor((Date.now() + off) / HOUR) * HOUR - 2 * HOUR;
    const pad = n => String(n).padStart(2, '0');
    j.hourly.time = j.hourly.time.map((_, i) => {
      const d = new Date(start + i * HOUR);
      return `${d.getUTCFullYear()}-${pad(d.getUTCMonth() + 1)}-${pad(d.getUTCDate())}` +
        `T${pad(d.getUTCHours())}:${pad(d.getUTCMinutes())}`;
    });
    return JSON.stringify(j);
  };

  let modelChartHits = 0;
  const hrrrTileHits = [];
  let modelChart429s = 0;          // route serves this many 429s before data
  let expect429 = false;           // silences the resource-load console error
  const mchartRows = JSON.parse(fx('mchart-grid.json'));
  const forecast = (() => {
    const j = JSON.parse(fx('forecast.json'));
    const off = (j.utc_offset_seconds || 0) * 1000;
    const step = 15 * 60 * 1000;
    const start = Math.floor((Date.now() + off) / step) * step;
    const pad = n => String(n).padStart(2, '0');
    j.minutely_15.time = j.minutely_15.time.map((_, i) => {
      const d = new Date(start + i * step);
      return `${d.getUTCFullYear()}-${pad(d.getUTCMonth() + 1)}-${pad(d.getUTCDate())}` +
        `T${pad(d.getUTCHours())}:${pad(d.getUTCMinutes())}`;
    });
    /* The nowcast checks reproduce "the station says rain, the model says
     * dry" — so the model's near term must BE dry, whatever the sky was doing
     * the day the fixture was captured. A re-capture once caught drizzle and
     * turned seven of them red. Neutralised here rather than hand-editing
     * the capture, so the JSON stays a faithful record and the next
     * re-capture cannot do it again. */
    const wet = c => c >= 51 && c !== 45 && c !== 48;
    j.minutely_15.precipitation = j.minutely_15.precipitation.map(() => 0);
    j.minutely_15.weather_code = j.minutely_15.weather_code.map(c => (wet(c) ? 3 : c));
    j.current.precipitation = 0;
    if (wet(j.current.weather_code)) j.current.weather_code = 3;
    return JSON.stringify(j);
  })();

  await page.route('**://api.open-meteo.com/**', async r => {
    const u = r.request().url();
    // Per-model DAILY runs (the model viewer) vs per-model HOURLY (agreement).
    if (u.includes('daily=') && u.includes('models=')) return r.fulfill(json(fx('model-daily.json')));
    // The model chart's CONUS lattice: row-band chunks, told apart by the
    // first latitude in the request.
    if (u.includes('hourly=precipitation%2Cpressure_msl')) {
      modelChartHits++;
      if (modelChart429s > 0) {
        modelChart429s--;
        return r.fulfill({ status: 429, contentType: 'application/json',
                           body: '{"error":true,"reason":"Minutely API request limit exceeded."}' });
      }
      const lm = /latitude=([\d.]+)/.exec(u);
      const row = Math.round(((lm ? parseFloat(lm[1]) : 22) - 22) / (30 / 35));
      const rows = mchartRows.slice(row * 80, (row + 4) * 80);
      return r.fulfill(json(JSON.stringify(rows)));
    }
    if (u.includes('models=')) return r.fulfill(json(REPLAY_ENSEMBLE()));
    // Vane Storm Odds inputs: synthetic, stable in the west of the request
    // and primed for storms in the east, so the field has a gradient.
    if (u.includes('total_column_integrated_water_vapour')) {
      stormEnvHits++;
      if (stormEnvDelay) await new Promise(res => setTimeout(res, stormEnvDelay));
      return r.fulfill(json(stormEnvFixture(u)));
    }
    // The multi-point grid first: it now asks for CAPE too, and must not be
    // mistaken for the single-point sounding request below.
    if (/latitude=[-\d.]+%2C/.test(u) || /latitude=[-\d.]+,/.test(u)) {
      gridHits++;
      lastGridUrl = u;
      if (gridDelay) await new Promise(res => setTimeout(res, gridDelay));
      if (gridFail) return r.fulfill({ status: 503, contentType: 'application/json', body: '{}' });
      return r.fulfill(json(gridWithCape(fx('grid.json'), gridCapeScale)));
    }
    if (u.includes('cape')) return r.fulfill(json(REPLAY_SOUNDING()));
    return r.fulfill(json(forecast));
  });
  await page.route('**://ensemble-api.open-meteo.com/**', r => r.fulfill(json(REPLAY_ENSEMBLE_DAILY())));
  await page.route('**://archive-api.open-meteo.com/**', r => r.fulfill(json(fx('normals.json'))));
  await page.route('**://air-quality-api.open-meteo.com/**', r => r.fulfill(json(fx('air.json'))));
  await page.route('**://geocoding-api.open-meteo.com/**', r => r.fulfill(json(fx('geocode.json'))));
  await page.route('**://api.weather.gov/alerts/**', r => r.fulfill(json(fx('alerts.json'))));
  await page.route('**://api.weather.gov/points/**', r => r.fulfill(json(JSON.stringify({
    properties: {
      cwa: 'OUN',
      observationStations: 'https://api.weather.gov/gridpoints/OUN/1,1/stations'
    }
  }))));
  // Two different shapes under /products: the office's listing and one product.
  await page.route('**://api.weather.gov/products/types/**', r => r.fulfill(json(fx('afd-list.json'))));
  await page.route('**://api.weather.gov/products/*', r => r.fulfill(json(fx('afd.json'))));
  await page.route('**://api.weather.gov/gridpoints/**', r => r.fulfill(json(JSON.stringify({
    features: [{ properties: { stationIdentifier: 'KOUN', name: 'Norman Westheimer' } }]
  }))));
  /* The observation is swappable so one test can put real rain in it: the
   * reported bug was the app telling somebody standing in the rain that no
   * rain was expected, and it can only be reproduced by making the station
   * and the model disagree. */
  let stationWx = { present: [], text: 'Mostly Clear',
                    raw: 'KOUN 131253Z 19014G26KT 10SM FEW045 29/19' };
  await page.route('**://api.weather.gov/stations/**', r => r.fulfill(json(JSON.stringify({
    properties: {
      timestamp: new Date(Date.now() - 12 * 60000).toISOString(),
      temperature: { value: 29.4 }, dewpoint: { value: 19.0 },
      windSpeed: { value: 25.2 }, windDirection: { value: 190 },
      windGust: { value: 47.0 }, visibility: { value: 16090 },
      presentWeather: stationWx.present,
      textDescription: stationWx.text, rawMessage: stationWx.raw
    }
  }))));
  await page.route('**://www.spc.noaa.gov/products/outlook/**', r => r.fulfill(json(fx('spc.json'))));
  await page.route('**://www.spc.noaa.gov/climo/reports/**', r =>
    r.fulfill({ status: 200, contentType: 'text/csv', body: fx('reports.csv') }));
  /* NWS local storm reports (Iowa State). Down at first, so the SPC
   * fallback is exercised; the real feed is served later, re-stamped so
   * its newest report is ten minutes old. */
  let lsrUp = false;
  const lsrFixture = () => {
    const g = JSON.parse(fx('lsr.geojson'));
    const newest = Math.max(...g.features.map(f => Date.parse(f.properties.valid)));
    const shift = Date.now() - 10 * 60000 - newest;
    g.features.forEach(f => { f.properties.valid = new Date(Date.parse(f.properties.valid) + shift).toISOString(); });
    return JSON.stringify(g);
  };
  await page.route('**mesonet.agron.iastate.edu/geojson/lsr.geojson**', r => lsrUp
    ? r.fulfill(json(lsrFixture()))
    : r.fulfill({ status: 503, contentType: 'application/json', body: '{}' }));
  // HRRR future radar: WMS imagery + the run-naming sidecar. hrrrDelayMs
  // slows the WMS to a realistic latency for the double-buffer test.
  let hrrrDelayMs = 0;
  await page.route('**/cgi-bin/wms/hrrr/refd.cgi**', async r => {
    hrrrTileHits.push(r.request().url());
    if (hrrrDelayMs) await new Promise(res => setTimeout(res, hrrrDelayMs));
    r.fulfill({ status: 200, contentType: 'image/png',
                body: fs.readFileSync(path.join(__dirname, 'fixtures', 'hrrr-refd.png')) });
  });
  /* HRRR CAPE at 3 km from Unidata's THREDDS. Down until the HRRR checks,
   * so the CAPE checks before them exercise the sampled-grid fallback. Like
   * the real server, only runs at least two hours old are published; a run
   * not yet there answers 500, as THREDDS does. */
  let hrrrCapeUp = false;
  const capeTileHits = [];
  const utcRun = ms => { const d = new Date(ms), p = n => String(n).padStart(2, '0');
    return `${d.getUTCFullYear()}${p(d.getUTCMonth() + 1)}${p(d.getUTCDate())}_${p(d.getUTCHours())}00`; };
  await page.route('**thredds.ucar.edu/**', r => {
    const u = r.request().url();
    const run = (/HRRR_CONUS_2p5km_(\d{8}_\d{4})/.exec(u) || [])[1] || '';
    const newest = utcRun(Math.floor(Date.now() / 3600000) * 3600000 - 2 * 3600000);
    if (!hrrrCapeUp || run > newest) {
      return r.fulfill({ status: 500, contentType: 'text/html', body: '<html>Problem creating dataset</html>' });
    }
    if (!/width=8&/.test(u)) capeTileHits.push(u);
    r.fulfill({ status: 200, contentType: 'image/png',
                body: fs.readFileSync(path.join(__dirname, 'fixtures', 'hrrr-refd.png')) });
  });
  await page.route('**/data/gis/images/4326/hrrr/refd_0000.json**', r => r.fulfill(json(JSON.stringify({
    model_init_utc: new Date(Math.floor(Date.now() / 3600000) * 3600000).toISOString().slice(0, 19) + 'Z',
    forecast_minute: 0, model_forecast_utc: ''
  }))));
  await page.route('**://api.rainviewer.com/**', r => r.fulfill(json(fx('radar.json'))));
  await page.route('**nexrad_attr**', r => r.fulfill(json(fx('cells.json'))));
  /* "Online" means Level II data arrived in the last 20 minutes, so a captured
   * stations fixture goes stale the moment it is more than 20 minutes old and
   * every radar in it reads as down. Shift the whole file forward by a single
   * constant so the newest reading lands on now — relative staleness, and so
   * which radars count as online, is preserved exactly as captured. */
  const stations = (() => {
    const j = JSON.parse(fx('stations.json'));
    const times = j.features
      .map(f => Date.parse((f.properties.latency || {}).levelTwoLastReceivedTime || ''))
      .filter(t => !isNaN(t));
    const delta = Date.now() - Math.max.apply(null, times);
    j.features.forEach(f => {
      const l = f.properties.latency || {};
      const t = Date.parse(l.levelTwoLastReceivedTime || '');
      if (!isNaN(t)) l.levelTwoLastReceivedTime = new Date(t + delta).toISOString();
    });
    return JSON.stringify(j);
  })();
  await page.route('**://api.weather.gov/radar/stations**', r => r.fulfill(json(stations)));
  /* Radar freshness probes, mutable so the live-radar test can "produce a new
   * scan" by changing an answer. Registered after the broad stations glob so
   * the per-station path wins (Playwright checks newest routes first). */
  let mosaicValidTime = '2026-08-14T15:00:00Z';
  let siteScanStamp = '2026-08-14T15:02:00Z';
  await page.route('**mesonet.agron.iastate.edu/json/tms.json**', r => r.fulfill(json(JSON.stringify({
    services: [{ id: 'ridge_uscomp_n0q', utc_valid: mosaicValidTime }]
  }))));
  await page.route('**://api.weather.gov/radar/stations/K**', r => r.fulfill(json(JSON.stringify({
    properties: { latency: { levelTwoLastReceivedTime: siteScanStamp } }
  }))));

  await page.route('**tilecache.rainviewer.com/**', r =>
    r.fulfill({ status: 200, contentType: 'image/png', body: PNG }));
  /* Radar tiles: a 1x1 placeholder is enough for the map, but the 3D view
   * reads real pixels out of these, so single-site N0Q requests are served a
   * genuine captured tile. Without it the suite would only ever exercise the
   * fallback silhouette and never the radar-derived shape. */
  const realTile = (() => {
    // A real captured KOAX N0Q tile, committed as a fixture so the suite
    // exercises the radar-derived shape in CI too — the scripts/tiles cache
    // it was taken from is git-ignored and does not exist on a fresh clone.
    try { return fs.readFileSync(path.join(__dirname, 'fixtures', 'ridge-n0q.png')); }
    catch (e) { return null; }
  })();
  await page.route('**mesonet.agron.iastate.edu/cache/**', r => {
    const u = r.request().url();
    const body = maskBlank && /q2-hsr|mrms::lcref/.test(decodeURIComponent(u)) ? CLEAR_PNG
      : (realTile && /ridge::\w+-N0Q-/.test(u)) ? realTile : PNG;
    r.fulfill({ status: 200, contentType: 'image/png', body: body,
                headers: { 'Access-Control-Allow-Origin': '*' } });
  });
  await page.route('**arcgisonline.com/**', r =>
    r.fulfill({ status: 200, contentType: 'image/png', body: PNG }));

  /* No request may carry an API key of any kind — the AI layer is gone,
   * and with it every excuse for a key to exist in this app. */
  const keyLeaks = [];
  page.on('request', r => {
    const h = r.headers();
    if (h['x-api-key'] || h['authorization']) keyLeaks.push(r.url());
  });

  /* Notifications, recorded instead of shown: headless has no notification
   * surface, so the constructor is replaced with a recorder that reports
   * permission granted. What the app tried to say lands in __notifs. */
  await page.addInitScript(() => {
    window.__notifs = [];
    window.__notifObjs = [];             // the live objects, so a test can tap or swipe one
    window.Notification = class {
      constructor(title, opts) {
        window.__notifs.push({ title, body: (opts || {}).body || '', tag: (opts || {}).tag || '',
                               kind: ((opts || {}).data || {}).kind || null });
        window.__notifObjs.push(this);
      }
      close() { if (this.onclose) this.onclose(); }
      static requestPermission() { return Promise.resolve('granted'); }
    };
    window.Notification.permission = 'granted';
  });

  await page.goto(BASE, { waitUntil: 'load', timeout: 30000 });
  await page.waitForTimeout(3500);

  const checks = [];
  const check = (name, actual, pass) => checks.push({ name, actual, pass });

  /* Sections are sections at every width now, so a test that wants the radar
   * has to go to the Radar tab exactly as a user does. Idempotent — asking
   * for the tab you are already on is a no-op. */
  const showTab = async (name) => {
    const sel = `.tabbar button[data-tab="${name}"]`;
    if (!await page.locator(sel).isVisible()) return false;
    if (await page.getAttribute(sel, 'aria-selected') === 'true') return true;
    await page.click(sel);
    await page.waitForTimeout(700);
    return true;
  };

  /* The radar header carries three controls now; the rest moved into two
   * disclosures. These reach through them so the tests exercise the same
   * path a user takes rather than poking hidden elements. */
  const openSitePanel = async () => {
    await showTab('radar');
    if (!await page.locator('#site-panel').isVisible()) await page.click('#site-btn');
    await page.waitForTimeout(400);
  };
  const setSource = async (value) => {
    await openSitePanel();
    await page.selectOption('#radar-source', value);
    await page.waitForTimeout(1200);
    await page.click('#site-close');
    await page.waitForTimeout(200);
  };
  const openRadarOpts = async () => {
    await showTab('radar');
    if (!await page.locator('#radar-opts').isVisible()) await page.click('#radar-opts-btn');
    await page.waitForTimeout(400);
  };

  // ── Simple mode ──────────────────────────────────────────────────────
  /* The chart's nine-lattice fetch is the heaviest thing the app can ask
   * for, and firing it at boot rate-limited the sounding out from under a
   * user (HTTP 429, photographed). It must cost nothing until Outlook. */
  check('the chart lattice is not fetched at boot',
    modelChartHits + ' fetches', modelChartHits === 0);

  /* Chase and Outlook bring their own code (js/lazy.js): none of it may be
   * parsed at boot, and a render the app asked for while the code was away
   * must land the moment it arrives. */
  const boot = await page.evaluate(() => ({
    absent: ['Storm3D', 'Shot', 'ModelChart', 'OutlookChart', 'Meteogram', 'US_OUTLINES']
      .filter(n => n in window),
    tags: Array.from(document.scripts).map(s => s.getAttribute('src') || '')
      .filter(src => /(storm3d|shot|modelchart|outlookchart|meteogram|usstates|ui-chase|ui-outlook)\.js/.test(src)),
    stubbed: !!(UI.renderCells.lazyBundle && UI.renderModels.lazyBundle),
    loaded: [Lazy.loaded('chase'), Lazy.loaded('outlook')]
  }));
  // Storm reports are offered in Simple mode too, but off until asked for.
  const simpleReports = await page.evaluate(() => ({
    mode: document.body.dataset.mode,
    chaseOnly: document.getElementById('chip-reports').classList.contains('chase-only'),
    on: document.getElementById('chip-reports').classList.contains('on'),
    drawn: document.querySelectorAll('.lsr-icon').length
  }));
  check('Simple mode offers storm reports, off until asked for', JSON.stringify(simpleReports),
    simpleReports.mode === 'simple' && !simpleReports.chaseOnly && !simpleReports.on && simpleReports.drawn === 0);
  check('Chase and Outlook code is not loaded at boot',
    JSON.stringify(boot), boot.absent.length === 0 && boot.tags.length === 0 &&
    boot.stubbed && !boot.loaded[0]);
  const replayed = await page.evaluate(() => {
    const st = Vane.state;
    document.getElementById('params').textContent = '';
    UI.renderParams(st);                       // queued: the chase code is not here
    const before = document.getElementById('params').textContent.length;
    return Lazy.need('chase').then(() => ({
      before, after: document.getElementById('params').textContent.length,
      real: !UI.renderParams.lazyBundle && typeof Storm3D === 'object' && typeof Shot === 'object'
    }));
  });
  check('a render queued before the Chase code arrived is replayed when it does',
    JSON.stringify(replayed), replayed.before === 0 && replayed.after > 0 && replayed.real);
  const temp = await page.textContent('#now-temp');
  check('hero temperature rendered', temp, /^\d+$/.test(temp));
  check('condition rendered', await page.textContent('#now-cond'), true);
  check('feels-like + wind', await page.textContent('#now-feels'), true);

  const obs = await page.textContent('#now-obs-text');
  check('NWS observation shown and labelled', obs, /KOUN/.test(obs));

  const nowcast = await page.textContent('#nowcast-headline');
  const bars = await page.locator('#nowcast-chart .nc-bar').count();
  check('nowcast headline is a real answer (TZ fix)', nowcast,
    !/not available/.test(nowcast) && nowcast.length > 10);
  check('nowcast draws quarter-hour bars', bars + ' bars', bars >= 1 && bars <= 8);

  /* The learners must be findable on day one, not only after they have
   * data: "I can't find the new ML additions" was the field report. On a
   * fresh device the scorecard and the microclimate note both announce
   * what they are doing and when they will speak. The scorecard lives on
   * Outlook, whose code loads on first entry (js/lazy.js) — so the test
   * goes there, the way a person looking for it would. */
  await showTab('outlook');
  await page.waitForFunction(() => window.Lazy.loaded('outlook'));
  const learnersDayOne = await page.evaluate(() => ({
    scorecard: (() => { const el = document.getElementById('scorecard');
      return el && !el.hidden ? el.textContent : null; })(),
    micro: (() => { const el = document.getElementById('microclimate');
      return el && !el.hidden ? el.textContent : null; })()
  }));
  await showTab('now');
  check('the scorecard announces itself before it has scores',
    (learnersDayOne.scorecard || 'hidden').slice(0, 56),
    !!learnersDayOne.scorecard && /verifying each agency/i.test(learnersDayOne.scorecard) &&
    /learned on this device/i.test(learnersDayOne.scorecard));
  check('and the microclimate note says it is learning, day one',
    (learnersDayOne.micro || 'hidden').slice(0, 56),
    !!learnersDayOne.micro && /learning how the forecast leans/i.test(learnersDayOne.micro) &&
    /verified days/i.test(learnersDayOne.micro));

  /* ── Vane AI: "AI and ML are not obvious" ─────────────────────────────
   * One card, always on Now, every model in it with what it says here and
   * how it has done; the same AI mark wherever a model speaks. */
  await page.waitForFunction(() => /Here: /.test((document.querySelector('#ai-hub-list') || {}).textContent || ''), null, { timeout: 15000 }).catch(() => {});
  const hub = await page.evaluate(() => {
    const card = document.getElementById('ai-hub');
    const rows = Array.from(card.querySelectorAll('.ai-row'));
    return { visible: !card.hidden && card.offsetHeight > 0, chip: !!card.querySelector('h2 .ai-chip'),
      count: document.getElementById('ai-hub-count').textContent,
      names: rows.map(r => r.querySelector('.ai-row-name').textContent),
      first: rows[0] ? rows[0].textContent : '', folded: card.querySelectorAll('details.ai-more .ai-row').length,
      insightChip: !!document.querySelector('#ai-hub #insight-card') && !!document.querySelector('#ai-hub h2 .ai-chip'),
      oddsBtn: (() => { const b = document.getElementById('layer-odds'); return { hidden: b.hidden, chip: !!b.querySelector('.ai-chip') }; })() };
  });
  check('a Vane AI card sits on Now, always, with the AI mark', JSON.stringify({ visible: hub.visible, chip: hub.chip, count: hub.count }),
    hub.visible && hub.chip && /^\d+ models$/.test(hub.count) && +hub.count.split(' ')[0] >= 7);
  check('it lists every model, three up front and the rest folded', hub.names.join(' | '),
    hub.names[0] === 'Storm odds' && hub.names.includes('Rain timing') && hub.names.includes('Storm-cell models') &&
    hub.names.includes('Chase-day odds') && hub.names.includes('Local scorecard') && hub.folded === hub.names.length - 3);
  check('Storm odds says what it expects here, and its record', hub.first.slice(0, 140),
    /Here: (\d+(\.\d)?%|under ½%) chance of a severe storm report within 40 km in the next 3 hours/.test(hub.first) &&
    /AUC 0\.\d\d vs 0\.\d\d for CAPE × shear/.test(hub.first) && stormEnvHits >= 1);
  check('Insight now lives inside the Vane AI card, and the map layer carries the same AI mark', JSON.stringify({ insight: hub.insightChip, layer: hub.oddsBtn }),
    hub.insightChip && !hub.oddsBtn.hidden && hub.oddsBtn.chip);
  // "See it on the map": Radar, with Vane's model drawn as a field.
  await page.click('#ai-hub .ai-row[data-model="odds"] .ai-row-go');
  await page.waitForTimeout(2500);
  const oddsMap = await page.evaluate(() => {
    const c = document.querySelector('.map-field-under');
    const d = c.getContext('2d').getImageData(0, 0, c.width, c.height).data;
    const col = x => { let n = 0, s = 0;
      for (let y = 0; y < c.height; y += 7) { s++; if (d[(y * c.width + x) * 4 + 3] > 0) n++; } return n / s; };
    return { tab: document.querySelector('.tabbar button.on, .tabbar button[aria-selected="true"]') && document.querySelector('.tabbar button[aria-selected="true"]').dataset.tab,
      active: Layers.active(), west: col(Math.round(c.width * 0.15)), east: col(Math.round(c.width * 0.85)),
      legend: document.getElementById('field-legend').textContent,
      leads: Array.from(document.querySelectorAll('#field-legend .cape-kind')).map(b => b.textContent) };
  });
  check('"See it on the map" opens Radar with Storm odds on', JSON.stringify({ tab: oddsMap.tab, active: oddsMap.active }),
    oddsMap.tab === 'radar' && oddsMap.active === 'odds');
  check('the field paints where the environment is primed, not where it is stable',
    JSON.stringify({ w: +oddsMap.west.toFixed(2), e: +oddsMap.east.toFixed(2) }), oddsMap.east > 0.5 && oddsMap.west < oddsMap.east);
  check('its legend says it is Vane\'s own model, what the number is, and its record', oddsMap.legend.slice(oddsMap.legend.indexOf('Vane Storm Odds'), oddsMap.legend.indexOf('Vane Storm Odds') + 120),
    /Vane Storm Odds — Vane’s own AI model/.test(oddsMap.legend) && /within 40 km in the 3 hours from/.test(oddsMap.legend) &&
    /AUC 0\.\d\d vs 0\.\d\d/.test(oddsMap.legend) && /Not a warning/.test(oddsMap.legend) &&
    oddsMap.leads.join('|') === 'Now|+3 h|+6 h|+9 h');
  await page.click('#field-legend .cape-kind[data-lead="3"]');
  const lead3 = await page.evaluate(() => ({ lead: Layers.state.oddsLead, idx: Layers.state.oddsIdx,
    at: Layers.state.oddsTimes[Layers.state.oddsIdx], pressed: document.querySelector('#field-legend .cape-kind[aria-pressed="true"]').textContent }));
  check('and steps ahead three hours at a tap', JSON.stringify({ lead: lead3.lead, pressed: lead3.pressed }),
    lead3.lead === 3 && lead3.pressed === '+3 h' && Math.abs(lead3.at - (Date.now() + 3 * 3600000)) <= 90 * 60000);
  await page.evaluate(() => Layers.setOddsLead(0));

  /* Photographed: Storm odds painted over Mexico and the open Pacific, a
   * model trained on US weather and US reports speaking where it never
   * learned. Across the Rio Grande it must draw Texas and nothing else. */
  const homeOdds = await page.evaluate(() => { const m = Radar.getMap(); return { c: m.getCenter(), z: m.getZoom() }; });
  await page.evaluate(() => Radar.getMap().setView([28.5, -100], 6, { animate: false }));
  await page.waitForFunction(() => !Layers.state.loading && Layers.state.lattice && Layers.state.lattice.s < 26.5, null, { timeout: 15000 }).catch(() => {});
  await page.waitForTimeout(400);
  const border = await page.evaluate(() => ({ mexico: (Layers.sample(26.2, -101.5) || {}).odds, texas: (Layers.sample(31, -99.5) || {}).odds,
    outside: Layers.state.oddsOutside, legend: document.getElementById('field-legend').textContent }));
  check('Storm odds are drawn over the US only, where the model was trained',
    JSON.stringify({ mexico: border.mexico, texas: border.texas && +border.texas.toFixed(4), outside: border.outside }),
    border.mexico === null && typeof border.texas === 'number' && border.outside > 0 && /Drawn over the US only/.test(border.legend));
  await page.evaluate(v => Radar.getMap().setView(v.c, v.z, { animate: false }), homeOdds);
  await page.waitForTimeout(800);
  await page.evaluate(() => document.getElementById('layer-odds').click());
  await page.waitForTimeout(300);

  /* Also found reproducing it: switch to CAPE while Storm Odds' slower
   * fetch is still out, and CAPE was handed Storm Odds' rows — no CAPE in
   * them, so a blank map. CAPE must draw CAPE. */
  stormEnvDelay = 1500;
  await page.evaluate(() => { document.getElementById('layer-odds').click(); });
  await page.waitForTimeout(150);
  await page.evaluate(() => { document.getElementById('layer-cape').click(); });
  await page.waitForTimeout(4000);
  stormEnvDelay = 0;
  const switched = await page.evaluate(() => {
    const c = document.querySelector('.map-field-under'), d = c.getContext('2d').getImageData(0, 0, c.width, c.height).data;
    let painted = 0; for (let i = 3; i < d.length; i += 4 * 97) if (d[i] > 0) painted++;
    return { active: Layers.active(), capeRows: Layers.state.grid.filter(p => typeof p.cape === 'number').length,
             rows: Layers.state.grid.length, painted, oddsBtn: document.getElementById('layer-odds').classList.contains('on') };
  });
  check('switching layers mid-fetch draws the layer you chose, from its own data', JSON.stringify(switched),
    switched.active === 'cape' && switched.capeRows === switched.rows && switched.rows > 0 && switched.painted > 0 && !switched.oddsBtn);
  await page.evaluate(() => document.getElementById('layer-cape').click());
  await page.waitForTimeout(300);
  await page.evaluate(() => document.querySelector('.tabbar button[data-tab="now"]').click());
  await page.waitForTimeout(300);

  /* ── Vane Insight ────────────────────────────────────────────────────
   * The fifth layer: the learners fused into sentences, each line tagged
   * with the learner that produced it, on the Now tab from boot. */
  const insight = await page.evaluate(() => {
    const card = document.getElementById('insight-card');
    if (!card || card.hidden) return null;
    return {
      lines: Array.from(card.querySelectorAll('.insight-line')).map(li => ({
        tag: li.querySelector('.insight-tag').textContent,
        text: li.querySelector('.insight-text').textContent
      })),
      foot: card.querySelector('.insight-foot').textContent
    };
  });
  check('Insight is on the Now tab from boot, lines tagged by learner',
    insight ? insight.lines.map(l => l.tag).join(' | ') : 'hidden',
    !!insight && insight.lines.length >= 1 &&
    insight.lines.every(l => l.tag.length > 2 && l.text.length > 10));
  check('and it owns up to being on-device composition, not an AI service',
    (insight ? insight.foot : '').slice(0, 60),
    !!insight && /on-device learners/.test(insight.foot) &&
    /No cloud AI service, no key/.test(insight.foot));
  check('a consensus line offers Vane’s number beside the official one',
    (insight ? (insight.lines.find(l => l.tag === 'Consensus') || { text: 'none' }).text : 'hidden').slice(0, 70),
    !!insight && insight.lines.some(l => l.tag === 'Consensus' &&
      (/official/.test(l.text) || /agencies agree/.test(l.text))));

  const insightRich = await page.evaluate(() => {
    // A learned scorecard and an inbound motion fit deepen the read.
    const results = [];
    for (let i = 0; i < 4; i++) {
      results.push({ date: '2026-09-1' + (5 + i), station: 'KOUN', obsHi: 33, obsLo: 22,
        n: 24, err: { gfs_seamless: { hi: 2, lo: 1 }, ecmwf_ifs025: { hi: 0.8, lo: 0.6 } } });
    }
    localStorage.setItem('vane.scorecard.v1', JSON.stringify(
      { loc: window.Vane.state.location.lat.toFixed(2) + ',' + window.Vane.state.location.lon.toFixed(2),
        pending: {}, results }));
    window.Vane.state.motion = {
      stationary: false, overheadNow: false,
      vector: { toward: 'NE', speed: 32, east: 22, north: 22, towardDeg: 45 },
      eta: { minutes: 25, dbz: 34, distanceKm: 18, dir: 'SW' },
      pairs: 5, spanMin: 50, residualKmh: 3
    };
    window.UI.renderInsight(window.Vane.state);
    return Array.from(document.querySelectorAll('#insight-card .insight-line'))
      .map(li => li.querySelector('.insight-tag').textContent);
  });
  check('with learners fed, the read deepens: motion, consensus and scorecard speak',
    insightRich.join(' | '),
    insightRich.indexOf('VaneMotion') !== -1 &&
    insightRich.indexOf('Consensus') !== -1 &&
    insightRich.indexOf('Scorecard') !== -1);
  await page.evaluate(() => {
    localStorage.removeItem('vane.scorecard.v1');
    window.Vane.state.motion = null;
    window.UI.renderInsight(window.Vane.state);
    window.UI.renderModels(window.Vane.state);
  });

  const hours = await page.locator('#hourly .hour').count();
  const firstHour = await page.locator('#hourly .hour .hour-t').first().textContent();
  check('24 hourly cells in simple mode', hours, hours === 24);
  check('hourly starts at "Now" (TZ fix)', firstHour, firstHour === 'Now');

  check('7 daily rows', await page.locator('#daily .day').count(),
    (await page.locator('#daily .day').count()) === 7);
  check('10 detail cells', await page.locator('#details .detail').count(),
    (await page.locator('#details .detail').count()) === 10);
  check('8 astro cells', await page.locator('#astro .detail').count(),
    (await page.locator('#astro .detail').count()) === 8);
  check('daylight note', await page.textContent('#astro-note'), true);

  // Details reads sunrise straight from Open-Meteo (location clock); the astro
  // panel computes it locally. They must agree despite the Tokyo browser TZ.
  const detailTexts = await page.locator('#details .detail').allTextContents();
  const astroTexts = await page.locator('#astro .detail').allTextContents();
  const grab = (arr, label) => {
    const hit = arr.find(t => t.startsWith(label)) || '';
    const m = hit.match(/(\d{1,2}:\d{2}\s*(AM|PM)?)/);
    return m ? m[1] : '';
  };
  const dSunrise = grab(detailTexts, 'Sunrise');
  const aSunrise = grab(astroTexts, 'Sunrise');
  const dSunset = grab(detailTexts, 'Sunset');
  const aSunset = grab(astroTexts, 'Sunset');
  const mins = t => {
    const m = t.match(/(\d{1,2}):(\d{2})\s*(AM|PM)?/);
    if (!m) return NaN;
    let h = +m[1] % 12;
    if (m[3] === 'PM') h += 12;
    return h * 60 + (+m[2]);
  };
  check('astro sunrise matches API sunrise (TZ fix)', `${dSunrise} vs ${aSunrise}`,
    Math.abs(mins(dSunrise) - mins(aSunrise)) <= 3);
  check('astro sunset matches API sunset (TZ fix)', `${dSunset} vs ${aSunset}`,
    Math.abs(mins(dSunset) - mins(aSunset)) <= 3);

  const aqi = await page.textContent('#air .aqi-dial').catch(() => null);
  check('air quality dial', aqi, !!aqi && /^\d+$/.test(aqi));
  check('AQI category', await page.textContent('#air .aqi-cat').catch(() => null), true);

  const alerts = await page.locator('#alerts .alert').count();
  check('NWS alert banner', alerts + ' alert(s)', alerts >= 1);

  await showTab('radar');
  await page.waitForTimeout(1500);
  const radarTiles = await page.locator('#map img.leaflet-tile').count();
  const radarTime = await page.textContent('#radar-time');
  const radarKind = await page.textContent('#radar-kind');
  check('radar tiles rendered', radarTiles, radarTiles > 0);
  check('radar frame clock', radarTime, /\d/.test(radarTime));
  check('radar frame labelled observed/forecast', radarKind, /observed|forecast/.test(radarKind));
  // The legend must be generated from the live source, not hardcoded: NEXRAD
  // gets the real dBZ ramp, RainViewer gets the blue ramp it actually serves.
  const src = await page.evaluate(() => window.Radar.getSource());
  const legSteps = await page.locator('#radar-legend .legend-step').count();
  const legNote = await page.textContent('#radar-legend .legend-note');
  check('radar source auto-picked for the location', src, src === 'nexrad');
  check('legend matches NEXRAD dBZ ramp', legSteps + ' steps', legSteps === 14);
  check('legend names its source', legNote.slice(0, 40), /dBZ/.test(legNote));

  const legendMatchesTiles = await page.evaluate(() => {
    // Every swatch colour must appear in the source's own scale table.
    const scale = window.Radar.legend().scale.map(r => (r.length === 3 ? r[1] : r[0]).toLowerCase());
    return Array.from(document.querySelectorAll('#radar-legend .legend-swatch')).every(el => {
      const m = getComputedStyle(el).backgroundColor.match(/\d+/g);
      const hex = '#' + m.slice(0, 3).map(v => (+v).toString(16).padStart(2, '0')).join('');
      return scale.indexOf(hex) !== -1;
    });
  });
  check('every legend swatch comes from the live scale', legendMatchesTiles, legendMatchesTiles);

  // Switching to the global source must swap the legend with it.
  await setSource('global');
  const globalNote = await page.textContent('#radar-legend .legend-note');
  check('global source relabels the legend as RainViewer dBZ', globalNote.slice(0, 60),
    /RainViewer global composite \(dBZ\)/.test(globalNote));
  // And its swatches are RainViewer's published palette, not the NWS ramp.
  const rvSwatches = await page.evaluate(() => {
    const scale = Radar.RV_SCALE.map(s => s[1].toLowerCase());
    const sw = Array.from(document.querySelectorAll('#radar-legend .legend-swatch'));
    return sw.length === scale.length && sw.every((el, i) => {
      const m = getComputedStyle(el).backgroundColor.match(/\d+/g);
      return '#' + m.slice(0, 3).map(v => (+v).toString(16).padStart(2, '0')).join('') === scale[i];
    });
  });
  check('global legend swatches are RainViewer\'s published palette', rvSwatches, rvSwatches);
  await setSource('nexrad');

  const paneOrder = await page.evaluate(() => {
    const z = n => {
      const el = document.querySelector('.leaflet-' + n + '-pane');
      return el ? +getComputedStyle(el).zIndex : null;
    };
    return { radar: z('radar'), features: z('features'), labels: z('labels') };
  });
  check('features draw above radar tiles',
    `radar ${paneOrder.radar} < features ${paneOrder.features}`,
    paneOrder.features > paneOrder.radar);
  check('labels draw above everything',
    `features ${paneOrder.features} < labels ${paneOrder.labels}`,
    paneOrder.labels > paneOrder.features);

  // ── Radar site selection ─────────────────────────────────────────────
  await page.click('#site-btn');
  await page.waitForTimeout(1200);
  check('site panel opens', await page.locator('#site-panel').isVisible(),
    await page.locator('#site-panel').isVisible());

  const siteRows = await page.locator('#site-list .site-row').count();
  check('radar sites listed', siteRows + ' rows', siteRows > 10);

  const siteSummary = await page.textContent('#site-summary');
  check('summary reports how many radars are scanning storms', siteSummary.slice(0, 60),
    /precipitation mode/.test(siteSummary));

  // Nearest-first ordering.
  const orderOk = await page.evaluate(() => {
    const l = window.Sites.near(window.Vane.state.location.lat, window.Vane.state.location.lon);
    return l.every((s, i) => i === 0 || l[i - 1].distance <= s.distance);
  });
  check('sites ordered nearest first', orderOk, orderOk);

  // Search by identifier.
  await page.fill('#site-search', 'KTLX');
  await page.waitForTimeout(500);
  const searchRows = await page.locator('#site-list .site-row').count();
  const firstId = await page.locator('#site-list .site-id').first().textContent();
  check('search finds a radar by identifier', `${searchRows} -> ${firstId}`, firstId === 'KTLX');

  // Search by city name.
  await page.fill('#site-search', 'wichita');
  await page.waitForTimeout(500);
  check('search finds a radar by city',
    await page.locator('#site-list .site-name').first().textContent(),
    /wichita/i.test(await page.locator('#site-list .site-name').first().textContent()));

  // Active-only filter must actually narrow the list.
  await page.fill('#site-search', '');
  await page.waitForTimeout(400);
  const counts = await page.evaluate(() => {
    const s = window.Vane.state.location;
    return {
      all: window.Sites.near(s.lat, s.lon).length,
      active: window.Sites.near(s.lat, s.lon, { activeOnly: true }).length
    };
  });
  await page.check('#site-active-only');
  await page.waitForTimeout(500);
  const activeSummary = await page.textContent('#site-summary');
  check('active-only filter narrows to storm-scanning radars',
    `${counts.all} -> ${counts.active}`,
    counts.active > 0 && counts.active < counts.all);
  check('summary discloses list truncation', activeSummary.slice(-40),
    /Showing the nearest|matches\./.test(activeSummary));
  await page.uncheck('#site-active-only');
  await page.waitForTimeout(400);

  // Selecting a site switches the source and moves the map to it.
  await page.fill('#site-search', 'KDDC');
  await page.waitForTimeout(500);
  await page.locator('#site-list .site-row').first().click();
  await page.waitForTimeout(1500);

  const chosen = await page.evaluate(() => window.Radar.getSite());
  check('selecting a site switches to single-radar mode',
    await page.evaluate(() => window.Radar.getSource()),
    (await page.evaluate(() => window.Radar.getSource())) === 'site');
  check('chosen site is the one clicked', chosen && chosen.id, chosen && chosen.id === 'KDDC');
  const centre = await page.evaluate(() => window.Radar.center());
  check('map centres on the radar',
    `${centre.lat.toFixed(2)},${centre.lng.toFixed(2)}`,
    Math.abs(centre.lat - chosen.lat) < 0.5 && Math.abs(centre.lng - chosen.lon) < 0.5);
  // The button names what you are looking at, callsign first so it is still
  // scannable at a glance, with the city for anyone who does not think in
  // four-letter radar IDs.
  check('site button shows the active radar',
    await page.textContent('#site-btn'),
    /^KDDC\b/.test(await page.textContent('#site-btn')));

  // Velocity products are the point of single-site mode.
  check('product picker appears', await page.locator('#radar-product').isVisible(),
    await page.locator('#radar-product').isVisible());
  const products = await page.locator('#radar-product option').allTextContents();
  check('velocity products offered', products.join(', '),
    products.some(p => /velocity/i.test(p)));

  await page.selectOption('#radar-product', 'N0U');
  await page.waitForTimeout(1200);
  const velNote = await page.textContent('#radar-legend .legend-note');
  check('velocity legend replaces the dBZ scale', velNote.slice(0, 60),
    /toward the radar/.test(velNote) || /velocity/i.test(velNote));
  const velSwatches = await page.locator('#radar-legend .legend-swatch').count();
  check('velocity ramp drawn', velSwatches + ' steps', velSwatches === 9);

  // A single scan cannot animate, and the UI must not pretend otherwise.
  check('play disabled for a single scan',
    await page.getAttribute('#radar-play', 'disabled') !== null,
    await page.getAttribute('#radar-play', 'disabled') !== null);
  check('play button relabelled', await page.textContent('#radar-play'),
    (await page.textContent('#radar-play')) === 'Latest scan');

  // Coverage ring gives range context.
  const ringLayers = await page.evaluate(() => {
    let n = 0;
    window.Radar.getMap().eachLayer(() => n++);
    return n;
  });
  check('coverage ring drawn', ringLayers + ' layers', ringLayers > 3);

  const attrSite = await page.textContent('.leaflet-control-attribution');
  check('single-site credits the NEXRAD provider, not RainViewer',
    /Iowa State/.test(attrSite) ? 'Iowa State Mesonet' : attrSite.slice(-40),
    /Iowa State/.test(attrSite) && !/RainViewer/.test(attrSite));

  // Back to the mosaic.
  await setSource('nexrad');
  check('returning to the mosaic restores animation',
    await page.getAttribute('#radar-play', 'disabled'),
    (await page.getAttribute('#radar-play', 'disabled')) === null);
  check('mosaic legend restored', await page.textContent('#radar-legend .legend-note'),
    /mosaic/.test(await page.textContent('#radar-legend .legend-note')));

  await setSource('global');
  const attrGlobal = await page.textContent('.leaflet-control-attribution');
  check('global source credits RainViewer', /RainViewer/.test(attrGlobal) ? 'RainViewer' : attrGlobal.slice(-40),
    /RainViewer/.test(attrGlobal));
  await setSource('nexrad');

  check('place labels render above the radar',
    await page.evaluate(() => {
      const p = document.querySelector('.leaflet-labels-pane');
      const r = document.querySelector('.leaflet-radar-pane');
      return !!p && !!r && +getComputedStyle(p).zIndex > +getComputedStyle(r).zIndex;
    }), true);

  // ── Visual system ────────────────────────────────────────────────────
  const skyGroup = await page.getAttribute('body', 'data-sky');
  const skyBand = await page.getAttribute('body', 'data-band');
  check('sky theme applied from condition', skyGroup, !!skyGroup);
  check('sky band from sun altitude', skyBand,
    ['day', 'golden', 'twilight', 'night'].indexOf(skyBand) !== -1);
  const sky0 = await page.evaluate(() =>
    getComputedStyle(document.documentElement).getPropertyValue('--sky-0').trim());
  check('sky gradient token set', sky0, /^#|rgb/.test(sky0));

  const heroIcon = await page.locator('#now-icon svg.wx-icon').count();
  check('hero uses an SVG icon, not emoji', heroIcon, heroIcon === 1);
  check('hourly cells use SVG icons',
    await page.locator('#hourly .hour svg.wx-icon').count(),
    (await page.locator('#hourly .hour svg.wx-icon').count()) > 20);
  check('daily rows use SVG icons',
    await page.locator('#daily .day svg.wx-icon').count(),
    (await page.locator('#daily .day svg.wx-icon').count()) === 7);
  check('icon carries an accessible label',
    await page.getAttribute('#now-icon svg', 'aria-label'), true);

  /* The mockup redesign: cards are solid surfaces with a hairline border —
   * no translucency anywhere, so text never fights what scrolls under it. */
  const cardSkin = await page.evaluate(() => {
    const s = getComputedStyle(document.querySelector('.card'));
    const m = s.backgroundColor.match(/rgba?\(([\d.\s,]+)\)/);
    const parts = m ? m[1].split(',').map(Number) : [];
    return { alpha: parts.length === 4 ? parts[3] : 1,
             border: parseFloat(s.borderTopWidth) };
  });
  check('cards are solid surfaces with a hairline border',
    JSON.stringify(cardSkin), cardSkin.alpha === 1 && cardSkin.border >= 1);

  // Contrast: white text over the darkest sky stop must clear WCAG AA.
  const contrast = await page.evaluate(() => {
    const hex = getComputedStyle(document.documentElement).getPropertyValue('--sky-0').trim();
    const m = hex.match(/^#?([0-9a-f]{2})([0-9a-f]{2})([0-9a-f]{2})$/i);
    if (!m) return null;
    const lin = v => { v /= 255; return v <= 0.03928 ? v / 12.92 : Math.pow((v + 0.055) / 1.055, 2.4); };
    const L = 0.2126 * lin(parseInt(m[1], 16)) + 0.7152 * lin(parseInt(m[2], 16)) + 0.0722 * lin(parseInt(m[3], 16));
    return (1.05) / (L + 0.05);
  });
  check('white text clears WCAG AA on the sky', contrast && contrast.toFixed(2),
    contrast !== null && contrast >= 4.5);

  await showTab('outlook');
  // ── Meteogram ────────────────────────────────────────────────────────
  check('meteogram drawn', await page.locator('#meteogram svg.meteogram').count(),
    (await page.locator('#meteogram svg.meteogram').count()) === 1);
  check('meteogram temperature line',
    await page.locator('#meteogram .mg-templine').count(),
    (await page.locator('#meteogram .mg-templine').count()) === 1);
  check('meteogram night bands',
    await page.locator('#meteogram .mg-night rect').count(),
    (await page.locator('#meteogram .mg-night rect').count()) > 0);
  check('meteogram cloud band',
    await page.locator('#meteogram .mg-cloud rect').count(),
    (await page.locator('#meteogram .mg-cloud rect').count()) > 10);
  check('meteogram wind arrows',
    await page.locator('#meteogram .mg-wind g').count(),
    (await page.locator('#meteogram .mg-wind g').count()) > 5);
  check('meteogram ensemble envelope',
    await page.locator('#meteogram .mg-envelope').count(),
    (await page.locator('#meteogram .mg-envelope').count()) === 1);
  const readoutChips = await page.locator('#meteogram .mg-chip').count();
  check('meteogram readout chips', readoutChips, readoutChips >= 5);

  // Hover moves the readout to a different hour.
  const beforeHover = await page.textContent('#meteogram .mg-chip-time');
  await page.locator('#meteogram svg.meteogram').hover({ position: { x: 700, y: 100 } });
  await page.waitForTimeout(300);
  const afterHover = await page.textContent('#meteogram .mg-chip-time');
  check('meteogram hover scrubs', `${beforeHover} -> ${afterHover}`, beforeHover !== afterHover);

  // Range switch
  await page.click('.mg-range[data-hours="72"]');
  await page.waitForTimeout(600);
  check('meteogram range switch redraws',
    await page.locator('#meteogram svg.meteogram').count(),
    (await page.locator('#meteogram svg.meteogram').count()) === 1);
  await page.click('.mg-range[data-hours="24"]');
  await page.waitForTimeout(400);

  // ── Model ensemble ───────────────────────────────────────────────────
  const modelSummary = await page.textContent('#models-summary');
  check('ensemble summary in plain English', modelSummary.slice(0, 70),
    /confidence|agreement|diverge/i.test(modelSummary));
  check('5 model pills', await page.locator('#model-legend .model-pill').count(),
    (await page.locator('#model-legend .model-pill').count()) === 5);
  check('spread chart has one line per model',
    await page.locator('#spread-chart .sp-line').count(),
    (await page.locator('#spread-chart .sp-line').count()) === 5);
  check('spread envelope drawn', await page.locator('#spread-chart .sp-band').count(),
    (await page.locator('#spread-chart .sp-band').count()) === 1);
  // The fixture is a dry day, so the strip correctly collapses to a sentence.
  const agCells = await page.locator('#agreement .ag-cell').count();
  const agText = await page.textContent('#agreement');
  check('rain agreement resolves', agCells ? agCells + ' cells' : agText.slice(0, 50),
    agCells === 24 || /None of the \d+ models/.test(agText));

  // ── Map field layers ─────────────────────────────────────────────────
  await openRadarOpts();
  await page.click('#layer-wind');
  await page.waitForTimeout(2200);
  check('wind layer canvas added', await page.locator('.map-field').count(),
    (await page.locator('.map-field').count()) === 1);
  check('wind layer button active',
    await page.getAttribute('#layer-wind', 'class'),
    /\bon\b/.test(await page.getAttribute('#layer-wind', 'class')));
  const windPainted = await page.evaluate(() => {
    const c = document.querySelector('.map-field');
    if (!c) return 0;
    const ctx = c.getContext('2d');
    const d = ctx.getImageData(0, 0, c.width, c.height).data;
    let n = 0;
    for (let i = 3; i < d.length; i += 4 * 97) if (d[i] > 0) n++;
    return n;
  });
  check('wind field actually painted', windPainted + ' sampled px', windPainted > 0);
  check('wind legend shown', await page.locator('#field-legend').isVisible(),
    await page.locator('#field-legend').isVisible());

  await openRadarOpts();
  await page.click('#layer-temp');
  await page.waitForTimeout(2200);
  const tempPainted = await page.evaluate(() => {
    const c = document.querySelector('.map-field-under');
    const ctx = c.getContext('2d');
    const d = ctx.getImageData(0, 0, c.width, c.height).data;
    let n = 0;
    for (let i = 3; i < d.length; i += 4 * 97) if (d[i] > 0) n++;
    return n;
  });
  check('temperature field painted', tempPainted + ' sampled px', tempPainted > 0);
  check('temp active, wind released',
    await page.getAttribute('#layer-temp', 'class') + ' | ' + await page.getAttribute('#layer-wind', 'class'),
    /\bon\b/.test(await page.getAttribute('#layer-temp', 'class')) &&
    !/\bon\b/.test(await page.getAttribute('#layer-wind', 'class')));
  // ── CAPE: instability on the radar ───────────────────────────────────
  // Switching straight from Temp to CAPE: one canvas, so Temp must release.
  await openRadarOpts();
  await page.click('#layer-cape');
  await page.waitForTimeout(2200);
  const capeField = await page.evaluate(() => {
    const c = document.querySelector('.map-field-under');
    const d = c.getContext('2d').getImageData(0, 0, c.width, c.height).data;
    // Columns: the synthetic CAPE is stable in the west, ramping to 3000 J/kg in the east.
    const col = x => { let n = 0, s = 0;
      for (let y = 0; y < c.height; y += 7) { s++; if (d[(y * c.width + x) * 4 + 3] > 0) n++; }
      return n / s; };
    return { west: col(Math.round(c.width * 0.22)), east: col(Math.round(c.width * 0.8)),
             legend: document.getElementById('field-legend').textContent,
             atPin: Layers.sample(Vane.state.location.lat, Vane.state.location.lon) };
  });
  check('the CAPE layer paints where there is fuel', JSON.stringify({ w: capeField.west, e: capeField.east }),
    capeField.east > 0.5);
  check('and leaves the stable side of the map clear, not pale', capeField.west.toFixed(2),
    capeField.west < capeField.east);
  // A storm must read against its fuel, not be tinted by it.
  const capeStack = await page.evaluate(() => {
    const m = Radar.getMap();
    return { field: +m.getPane('fieldUnder').style.zIndex, radar: +m.getPane('radar').style.zIndex,
             tiles: +getComputedStyle(m.getPane('tilePane')).zIndex };
  });
  check('the CAPE field draws beneath the radar, above the base map',
    `tiles ${capeStack.tiles} < field ${capeStack.field} < radar ${capeStack.radar}`,
    capeStack.tiles < capeStack.field && capeStack.field < capeStack.radar);
  check('CAPE is interpolated from the grid like the other fields',
    capeField.atPin && Math.round(capeField.atPin.cape) + ' J/kg at the pin',
    !!capeField.atPin && capeField.atPin.cape > 0 && capeField.atPin.cape < 3000);
  check('its legend says it is fuel, not storms', capeField.legend.slice(0, 80),
    /J\/kg/.test(capeField.legend) && /Fuel for storms, not storms/.test(capeField.legend));
  check('with the 3 km HRRR field down, the coarse grid says that is what it is',
    capeField.legend.slice(capeField.legend.indexOf('The 3 km'), capeField.legend.indexOf('The 3 km') + 90),
    /The 3 km HRRR field is unavailable right now/.test(capeField.legend) && /coarse \d+-point grid/.test(capeField.legend));
  check('CAPE active, Temp released',
    await page.getAttribute('#layer-cape', 'class') + ' | ' + await page.getAttribute('#layer-temp', 'class'),
    /\bon\b/.test(await page.getAttribute('#layer-cape', 'class')) &&
    !/\bon\b/.test(await page.getAttribute('#layer-temp', 'class')));
  check('the CAPE legend says when its values are valid',
    capeField.legend.slice(capeField.legend.indexOf('valid'), capeField.legend.indexOf('valid') + 50),
    /valid \d{1,2}:\d\d( [AP]M)?, refreshed every 15 min/.test(capeField.legend));

  /* "CAPE didn't update": a field left on screen used to keep its first
   * values until the map was panned away. Now a stale field re-samples by
   * itself, and the legend follows. Here the next sample is stable air. */
  const hitsBefore = gridHits;
  gridCapeScale = 0;
  const refreshed = await page.evaluate(() => {
    Layers.state.fetchedAt = Date.now() - Layers.REFRESH_MS - 1000;   // sixteen minutes on
    return Layers.refreshIfStale().then(did => ({ did,
      peak: Layers.maxInView('cape'),
      legend: document.getElementById('field-legend').textContent,
      fresh: Date.now() - Layers.state.fetchedAt < 5000 }));
  });
  gridCapeScale = 1;
  check('a CAPE field left on screen re-samples itself when it goes stale',
    JSON.stringify({ did: refreshed.did, fetches: gridHits - hitsBefore, fresh: refreshed.fresh }),
    refreshed.did && gridHits - hitsBefore === 1 && refreshed.fresh);
  check('and over stable air the legend says so, rather than leaving a blank map unexplained',
    refreshed.legend.slice(0, 90),
    /No CAPE above 100 J\/kg anywhere in view right now/.test(refreshed.legend) && /stable/.test(refreshed.legend));
  const notYet = await page.evaluate(() => Layers.refreshIfStale());
  check('a fresh field is not re-fetched', String(notYet), notYet === false);

  /* Zoomed out to the nation, 42 points sat hundreds of km apart and put a
   * third of the map in the wrong CAPE band; a wide view now asks for 80. */
  const pointsIn = url => decodeURIComponent(/latitude=([^&]+)/.exec(url)[1]).split(',').length;
  const localPts = pointsIn(lastGridUrl);
  const homeView = await page.evaluate(() => { const m = Radar.getMap(); return { c: m.getCenter(), z: m.getZoom() }; });
  await page.evaluate(() => Radar.getMap().setView([38, -96], 4, { animate: false }));
  await page.waitForTimeout(1500);
  const widePts = pointsIn(lastGridUrl);
  check('a national view samples a denser grid than a local one', `local ${localPts} · national ${widePts}`,
    localPts === 42 && widePts === 80);
  await page.evaluate(v => Radar.getMap().setView(v.c, v.z, { animate: false }), homeView);
  await page.waitForTimeout(1500);

  /* The race behind "it didn't update": pan while a fetch is in flight.
   * The pan must not be answered with the old view's grid and forgotten. */
  gridDelay = 900;
  const hitsRace = gridHits;
  await page.evaluate(() => {
    Layers.state.fetchedAt = 0;
    Layers.refreshIfStale();                                   // fetch #1, slow
    setTimeout(() => Radar.getMap().setView([28.5, -88], 6, { animate: false }), 100);  // pan mid-fetch
  });
  await page.waitForTimeout(3200);
  gridDelay = 0;
  const raced = await page.evaluate(() => ({
    covers: Layers.state.bounds.contains(Radar.getMap().getBounds()),
    centre: Radar.getMap().getCenter()
  }));
  check('a pan that lands mid-fetch is re-sampled once the fetch is back',
    JSON.stringify({ fetches: gridHits - hitsRace, covers: raced.covers }),
    gridHits - hitsRace === 2 && raced.covers);
  await page.evaluate(loc => Radar.getMap().setView([loc.lat, loc.lon], 7, { animate: false }),
    await page.evaluate(() => Vane.state.location));
  await page.waitForTimeout(1500);

  /* A pan whose fetch fails: the old grid does not reach the new view, so
   * that part of the map is blank. It used to stay blank, unexplained,
   * until the next pan or fifteen minutes; now the legend says why and the
   * one-minute check retries. */
  gridFail = true;
  const failedPan = await page.evaluate(() => new Promise(done => {
    const m = Radar.getMap();
    m.once('moveend', () => setTimeout(() => done({ failed: Layers.state.failed,
      legend: document.getElementById('field-legend').textContent }), 900));
    m.setView([m.getCenter().lat + 8, m.getCenter().lng + 12], m.getZoom(), { animate: false });
  }));
  check('a pan whose fetch failed says so in the legend', failedPan.legend.slice(0, 120),
    failedPan.failed && /Could not load CAPE for this part of the map/.test(failedPan.legend));
  gridFail = false;
  const hitsRetry = gridHits;
  const retried = await page.evaluate(() => Layers.refreshIfStale().then(did => ({ did,
    covers: Radar.getMap() && !Layers.uncovered(), failed: Layers.state.failed,
    legend: document.getElementById('field-legend').textContent })));
  check('and the next minute\'s check fetches it, without waiting fifteen minutes',
    JSON.stringify({ did: retried.did, fetches: gridHits - hitsRetry, failed: retried.failed }),
    retried.did && gridHits - hitsRetry === 1 && !retried.failed && retried.covers &&
    !/Could not load CAPE/.test(retried.legend));
  await page.evaluate(loc => Radar.getMap().setView([loc.lat, loc.lon], 7, { animate: false }),
    await page.evaluate(() => Vane.state.location));
  await page.waitForTimeout(1500);

  await openRadarOpts();
  await page.click('#layer-cape');
  await page.waitForTimeout(600);
  check('CAPE toggles off again', await page.getAttribute('#layer-cape', 'class'),
    !/\bon\b/.test(await page.getAttribute('#layer-cape', 'class')));

  // A grid that cannot load says so, instead of the button quietly
  // switching itself back off.
  gridFail = true;
  await openRadarOpts();
  await page.click('#layer-cape');
  await page.waitForTimeout(1500);
  gridFail = false;
  const failMsg = await page.evaluate(() => ({ text: document.getElementById('status-bar').textContent,
    on: document.getElementById('layer-cape').classList.contains('on') }));
  check('a CAPE layer that cannot load explains itself', failMsg.text.slice(0, 80),
    /CAPE layer could not load the model grid/.test(failMsg.text) && !failMsg.on);
  await page.evaluate(() => UI.status(''));

  /* ── CAPE at 3 km: the HRRR's own field ──────────────────────────────
   * "It still isn't looking right": 42–80 sampled points can never look
   * like the CAPE maps chasers read. Over the US the layer is now the
   * HRRR's 3 km field from THREDDS, in the parcel the chaser picks. */
  hrrrCapeUp = true;
  capeTileHits.length = 0;
  await openRadarOpts();
  await page.click('#layer-cape');
  await page.waitForTimeout(2000);
  const expectRun = utcRun(Math.floor(Date.now() / 3600000) * 3600000 - 2 * 3600000);
  const hr = await page.evaluate(() => {
    const pane = Radar.getMap().getPane('fieldUnder');
    return { info: Layers.capeInfo(), tiles: pane.querySelectorAll('img.leaflet-tile').length,
             paneZ: +pane.style.zIndex, radarZ: +Radar.getMap().getPane('radar').style.zIndex,
             legend: document.getElementById('field-legend').textContent,
             chips: Array.from(document.querySelectorAll('#field-legend .cape-kind')).map(b => b.textContent + (b.getAttribute('aria-pressed') === 'true' ? '*' : '')) };
  });
  check('over the US, CAPE is the HRRR\'s own 3 km field from the newest published run',
    JSON.stringify({ source: hr.info.source, run: hr.info.run, tiles: hr.tiles }),
    hr.info.source === 'hrrr' && hr.info.run === expectRun && hr.tiles > 0 && hr.paneZ < hr.radarZ);
  const firstTile = decodeURIComponent(capeTileHits[0] || '');
  check('mixed-layer CAPE by default, at the hour nearest now, on the Spectral scale',
    firstTile.slice(firstTile.indexOf('layers='), firstTile.indexOf('layers=') + 90),
    /layers=Convective_available_potential_energy_pressure_difference_layer/.test(firstTile) &&
    /elevation=4500/.test(firstTile) && /styles=raster\/div-Spectral-inv/.test(firstTile) &&
    firstTile.includes('time=' + new Date(Math.round(Date.now() / 3600000) * 3600000).toISOString()) &&
    /colorscalerange=100,4000/.test(firstTile) && /belowmincolor=transparent/.test(firstTile));
  check('its legend names the parcel, the model, the run and the hour', hr.legend.slice(hr.legend.indexOf('Mixed-layer CAPE'), hr.legend.indexOf('Mixed-layer CAPE') + 80),
    /Mixed-layer CAPE from the HRRR model at 3 km, \d\dZ run, valid \d{1,2}:\d\d/.test(hr.legend) &&
    hr.chips.join('|') === 'Surface|Mixed-layer*|Most unstable');
  capeTileHits.length = 0;
  await page.click('#field-legend .cape-kind[data-kind="mu"]');
  await page.waitForTimeout(1200);
  const mu = await page.evaluate(() => ({ kind: Layers.capeInfo().kind, saved: Settings.get('capeKind'),
    legend: document.getElementById('field-legend').textContent }));
  check('one tap shows most-unstable CAPE — the fuel of storms at night above a stable surface',
    JSON.stringify({ kind: mu.kind, saved: mu.saved, tiles: capeTileHits.length }),
    mu.kind === 'mu' && mu.saved === 'mu' && capeTileHits.length > 0 &&
    capeTileHits.every(u => /elevation=12750/.test(decodeURIComponent(u))) &&
    /Most unstable CAPE from the HRRR/.test(mu.legend) && /elevated instability/.test(mu.legend));
  const home = await page.evaluate(() => { const m = Radar.getMap(); return { c: m.getCenter(), z: m.getZoom() }; });
  await page.evaluate(() => Radar.getMap().setView([48, 10], 5, { animate: false }));
  await page.waitForTimeout(1800);
  const abroad = await page.evaluate(() => ({ source: Layers.capeInfo().source,
    tiles: Radar.getMap().getPane('fieldUnder').querySelectorAll('img.leaflet-tile').length,
    legend: document.getElementById('field-legend').textContent }));
  check('outside HRRR coverage it falls back to the sampled grid, and says so',
    abroad.legend.slice(abroad.legend.indexOf('Outside'), abroad.legend.indexOf('Outside') + 70),
    abroad.source === 'grid' && abroad.tiles === 0 && /Outside the HRRR.s US coverage/.test(abroad.legend));
  await page.evaluate(v => Radar.getMap().setView(v.c, v.z, { animate: false }), home);
  await page.waitForTimeout(1800);
  const back = await page.evaluate(() => Object.assign({}, Layers.capeInfo(), { loading: Layers.state.loading,
    center: Radar.getMap().getCenter() }));
  check('and back over the US, the 3 km field returns', back.source + ' · run ' + back.run, back.source === 'hrrr');
  await page.evaluate(() => Settings.save({ capeKind: 'ml' }));
  await openRadarOpts();
  await page.click('#layer-cape');
  await page.waitForTimeout(400);

  check('chase panels hidden in simple mode',
    await page.locator('#convective-card').isHidden(),
    await page.locator('#convective-card').isHidden());

  await showTab('outlook');
  // ── Extended outlook ─────────────────────────────────────────────────
  const olTitle = await page.textContent('#outlook-title');
  check('outlook names its own length from the data', olTitle, /^\d{2}-day outlook$/.test(olTitle));

  const boxes = await page.locator('#outlook-chart .ol-box').count();
  const olDays = await page.evaluate(() => window.Vane.state.outlook.days.length);
  check('one box plot per usable day', `${boxes} boxes / ${olDays} days`, boxes === olDays);
  check('every drawn day has members behind it',
    await page.evaluate(() => window.Vane.state.outlook.days.every(d => d.members > 0)), true);

  const olSpread = await page.evaluate(() => {
    const d = window.Vane.state.outlook.days;
    return { first: d[0].tmax.spread, last: d[d.length - 1].tmax.spread };
  });
  check('ensemble spread widens with lead time',
    `${olSpread.first.toFixed(1)} → ${olSpread.last.toFixed(1)} °C`,
    olSpread.last > olSpread.first * 2);

  const horizon = await page.evaluate(() => window.Vane.state.outlook.horizon);
  check('skill horizon measured, not assumed', 'index ' + horizon,
    horizon > 0 && horizon < olDays);
  check('horizon drawn on the chart', await page.locator('#outlook-chart .ol-horizon').count(),
    (await page.locator('#outlook-chart .ol-horizon').count()) === 1);
  check('range beyond the horizon is visibly demoted',
    await page.locator('#outlook-chart .ol-beyond').count(),
    (await page.locator('#outlook-chart .ol-beyond').count()) === 1);

  // The core honesty claim: no precise number is printed past the horizon.
  const olNumbers = await page.evaluate(() => {
    const h = window.Vane.state.outlook.horizon;
    const step = (980 - 46 - 14) / window.Vane.state.outlook.days.length;
    const cut = 46 + step * h;
    return Array.from(document.querySelectorAll('#outlook-chart .ol-axis-temp'))
      .filter(t => +t.getAttribute('x') > cut).length;
  });
  check('no daily temperature is printed past the horizon', olNumbers + ' past it', olNumbers === 0);
  const arrows = await page.locator('#outlook-chart .ol-axis-anom').count();
  check('past the horizon it shows a lean, not a value', arrows + ' anomaly glyphs', arrows > 0);

  check('climatological band drawn as the reference',
    await page.locator('#outlook-chart .ol-normal-band').count(),
    (await page.locator('#outlook-chart .ol-normal-band').count()) === 1);
  check('deterministic run drawn for comparison',
    await page.locator('#outlook-chart .ol-deterministic').count(),
    (await page.locator('#outlook-chart .ol-deterministic').count()) === 1);

  const olNote = await page.textContent('#outlook-note');
  check('the note refuses the extended-range claim', olNote.slice(0, 60),
    /do not extend how far ahead/.test(olNote) && /measure it/.test(olNote));
  check('the note sources the normals', 'ERA5 + year range',
    /ERA5/.test(olNote) && /\d{4}–\d{4}/.test(olNote));

  const olSummary = await page.textContent('#outlook-summary');
  check('outlook summary is a sentence, not a number dump', olSummary.slice(0, 70),
    olSummary.length > 40 && !/^Loading/.test(olSummary));

  // ── Forecaster's discussion, with no API key ─────────────────────────
  check('discussion card shown', await page.locator('#afd-card').isVisible(),
    await page.locator('#afd-card').isVisible());
  check('discussion credits the issuing office and time',
    await page.textContent('#afd-src'), /Norman OK/.test(await page.textContent('#afd-src')));

  const afdSections = await page.locator('#afd-section, #afd-body .afd-section').count();
  check('product split into collapsible sections', afdSections + ' sections', afdSections >= 5);
  const afdNames = await page.locator('#afd-body .afd-section summary strong').allTextContents();
  check('first section is what this mode needs first', afdNames[0], afdNames[0] === 'KEY MESSAGES');
  check('raw product text present, unedited',
    (await page.textContent('#afd-body .afd-raw')).slice(0, 40),
    /Heat wave continues/.test(await page.textContent('#afd-body')));

  // Without a key the forecaster's own bullets are the summary, free.
  const kmCount = await page.locator('#afd-brief .afd-km li').count();
  check('key messages surfaced without any model', kmCount + ' bullets', kmCount === 3);
  check('no key ask and no third-party AI anywhere on the card',
    await page.evaluate(() => document.getElementById('afd-card').textContent.slice(0, 400)),
    await page.evaluate(() => {
      const t = document.getElementById('afd-card').textContent;
      return !/API key|Anthropic|OpenAI|sign in/i.test(t);
    }));

  /* The on-device summary: the browser's own Summarizer, stubbed here with
   * one faithful point, one invented number and one more faithful point.
   * The invention must be dropped and counted; each kept point must carry
   * the forecaster's own sentence, highlighted in the product below. */
  const local = await page.evaluate(() => {
    window.Summarizer = {
      availability: () => Promise.resolve('downloadable'),
      create: (o) => {
        if (o && o.monitor) { const t = new EventTarget(); o.monitor(t); }
        return Promise.resolve({
          inputQuota: 4000, measureInputUsage: t => Promise.resolve(t.length / 4),
          summarize: () => Promise.resolve('* The heat wave continues, with dangerous heat each afternoon.\n' +
            '* Snow is expected Tuesday with 6 inches.\n' +
            '* Isolated thunderstorms may produce damaging wind gusts.'),
          destroy() {}
        });
      }
    };
    window.Vane.state.afdSummary = null;
    UI.renderDiscussion(window.Vane.state, {});
    return new Promise(r => setTimeout(r, 50)).then(() => {
      const btn = Array.from(document.querySelectorAll('#afd-brief button'))
        .find(b => /Plain-English version, made on this device/.test(b.textContent));
      const offer = { shown: !!btn && !btn.hidden,
        msg: (document.querySelector('#afd-brief .afd-local-msg') || {}).textContent || '' };
      btn.click();
      return new Promise(r => setTimeout(r, 200)).then(() => ({
        offer,
        points: Array.from(document.querySelectorAll('#afd-brief .afd-local li')).map(li => ({
          point: li.querySelector('.afd-local-point').textContent,
          quote: li.querySelector('.afd-local-quote').textContent })),
        note: (document.querySelector('#afd-brief .afd-local-note') || {}).textContent || '',
        marks: Array.from(document.querySelectorAll('#afd-body .afd-mark')).map(m => m.textContent)
      }));
    });
  });
  check('a plain-English version is offered where the browser has an on-device model',
    local.offer.msg.slice(0, 80), local.offer.shown && /no key, nothing sent anywhere/.test(local.offer.msg));
  check('its faithful points are kept, each with the forecaster\'s own sentence',
    local.points.map(p => p.point.slice(0, 30)).join(' | '),
    local.points.length === 2 &&
    local.points[0].quote === 'Heat wave continues with dangerous heat each afternoon.' &&
    /damaging wind gusts, are possible/.test(local.points[1].quote));
  check('an invented number is dropped, and the drop is admitted',
    local.note.slice(0, 120), /1 point that could not be matched to the discussion was left out/.test(local.note) &&
    !local.points.some(p => /Snow/.test(p.point)));
  check('and the sentences it rests on are highlighted in the product itself',
    local.marks.length + ' marks', local.marks.length >= 2);
  await page.evaluate(() => { delete window.Summarizer; window.Vane.state.afdSummary = null;
    UI.renderDiscussion(window.Vane.state, {}); });

  check('no request in the entire run carried an API key',
    keyLeaks.length ? keyLeaks[0] : 'none did', keyLeaks.length === 0);

  await page.screenshot({ path: path.join(__dirname, 'shot-simple.png'), fullPage: true });

  // ── Storm cells: rotation and areas of interest ──────────────────────
  // Move to a location with live mesocyclone detections in the fixture.
  await page.evaluate(() => window.Vane.setLocation(
    { lat: 42.8997, lon: -94.6912, name: 'Storm test', admin: 'Iowa, US' }));
  await page.waitForTimeout(3500);

  // ── Chase mode ───────────────────────────────────────────────────────
  await page.click('.mode-switch button[data-mode="chase"]');
  await page.waitForTimeout(3500);
  // The Chase tab only exists in Chase mode, so it can only be reached now.
  await showTab('chase');
  await page.waitForTimeout(1200);

  const cellRows = await page.locator('#cells .cell-row').count();
  const cellsSummary = await page.textContent('#cells .cells-summary');
  check('areas of interest listed', cellRows + ' rows', cellRows > 0);
  check('summary counts cells and rotation', cellsSummary.slice(0, 60), /cells? of interest/.test(cellsSummary));

  const reasons = await page.locator('#cells .cell-row').first().locator('.cell-reason').count();
  check('each cell shows why it was flagged', reasons, reasons > 0);

  const scores = await page.locator('#cells .cell-score').allTextContents();
  const nums = scores.map(Number);
  check('cells ranked by threat score', nums.slice(0, 5).join(','),
    nums.every((v, i) => i === 0 || nums[i - 1] >= v));

  const rotationShown = await page.evaluate(() => {
    const list = window.Cells.near(42.8997, -94.6912, 400, 10);
    return list.filter(c => c.mesoRank > 0 || c.tvs).length;
  });
  check('mesocyclone detections surfaced', rotationShown + ' rotating',
    rotationShown > 0);

  const disclosure = await page.textContent('#cells-note');
  check('rotation source is disclosed, not implied', disclosure.slice(0, 60),
    /Mesocyclone Detection Algorithm/.test(disclosure));
  check('false-alarm limits stated', 'false-alarm + TVS caveat',
    /false-alarm/.test(disclosure) && /not a confirmed tornado/.test(disclosure));

  /* ── Per-cell trend learning ─────────────────────────────────────────
   * A single volume scan is one point, so the fixture list must show no
   * tendencies. Feed a cell three earlier scans with a climbing core and
   * the fitted trend appears on its row, evidence attached. */
  check('one scan, no verdict: a fresh list carries no trend lines',
    await page.locator('#cells .cell-trend').count(),
    (await page.locator('#cells .cell-trend').count()) === 0);
  check('and the disclosure says trends are fitted here, from scans, never snapshots',
    /fitted in your browser/.test(disclosure) && /three scans/.test(disclosure), true);

  const trendLine = await page.evaluate(() => {
    const top = window.Cells.near(42.8997, -94.6912, 400, 10)[0];
    const now = Date.now();
    [[-15, top.maxDbz - 13], [-10, top.maxDbz - 9], [-5, top.maxDbz - 4]].forEach(([min, dbz]) => {
      window.Cells.ingest([{ id: top.id, maxDbz: dbz, top: top.top - 8 - min / 5,
        valid: new Date(now + min * 60000).toISOString() }], now + min * 60000);
    });
    window.Cells.ingest([{ id: top.id, maxDbz: top.maxDbz, top: top.top,
      valid: new Date(now).toISOString() }], now);
    window.UI.renderCells(window.Vane.state);
    const el = document.querySelector('#cells .cell-trend');
    window.__modelRow = (() => {
      const rows = Array.from(document.querySelectorAll('#cells .cell-model')).map(r => r.textContent);
      return { rows, note: document.getElementById('cells-model-note').textContent,
        titles: Array.from(document.querySelectorAll('#cells .cell-title')).map(t => t.textContent) };
    })();
    return el ? el.textContent : null;
  });
  // The trained models (js/stormmodel.js): the cell with four scans of
  // history gets the 20-minute outlook; every convective cell gets the
  // severe-report probability; the disclosure carries the held-out scores.
  const modelRows = await page.evaluate(() => window.__modelRow);
  check('cells carry the trained severe-report probability',
    modelRows.rows.length + ' rows; ' + (modelRows.rows[0] || '').slice(0, 60),
    modelRows.rows.length > 0 && modelRows.rows.every(r => /Next 30 min.*severe (under 1|\d+)%/.test(r)));
  check('and the watched cell gets its 20-minute core outlook',
    modelRows.rows.filter(r => /core \d+→\d+ dBZ by 20 min/.test(r)).length + ' with an outlook',
    modelRows.rows.filter(r => /core \d+→\d+ dBZ by 20 min/.test(r)).length === 1);
  check('cells carry hail chances where the radar sees hail, and say when the track is corrected',
    (modelRows.rows.find(r => /hail 1″\+/.test(r)) || 'no hail line').slice(0, 90),
    modelRows.rows.some(r => /hail 1″\+ (under 1|\d+)%/.test(r)) &&
    modelRows.titles.some(t => /, model track/.test(t)));
  check('the map draws the corrected track, not the straight line',
    JSON.stringify(await page.evaluate(() => {
      const c = Cells.state.cells.find(x => x.modelMotion);
      if (!c) return { none: true };
      const to = Cells.project(c, 30), kx = 111.32 * Math.cos(c.lat * Math.PI / 180);
      return { e: +((to.lon - c.lon) * kx).toFixed(2), modelE: +(c.modelMotion.east / 2).toFixed(2) };
    })),
    await page.evaluate(() => {
      const c = Cells.state.cells.find(x => x.modelMotion);
      if (!c) return false;
      const to = Cells.project(c, 30), kx = 111.32 * Math.cos(c.lat * Math.PI / 180);
      return Math.abs((to.lon - c.lon) * kx - c.modelMotion.east / 2) < 0.01;
    }));
  check('the disclosure states what the models were trained on and how they scored',
    modelRows.note.slice(modelRows.note.indexOf('The Model lines'), modelRows.note.indexOf('The Model lines') + 110),
    /trained on \d+ days of archived storm attributes/.test(modelRows.note) &&
    /days they never saw/.test(modelRows.note) && /AUC 0\.\d+ vs 0\.\d+/.test(modelRows.note) &&
    /storms over empty country get fewer reports/.test(modelRows.note));
  check('a core climbing across four scans reads as strengthening, numbers shown',
    (trendLine || 'no line').slice(0, 64),
    !!trendLine && /Strengthening/.test(trendLine) && /dBZ over 4 scans/.test(trendLine) &&
    /dBZ\/10 min/.test(trendLine));
  await page.evaluate(() => {
    window.Cells.resetTrends();
    window.UI.renderCells(window.Vane.state);
  });

  const layersWithCells = await page.evaluate(() => {
    let n = 0;
    window.Radar.getMap().eachLayer(() => n++);
    return n;
  });
  check('cells drawn on the radar', layersWithCells + ' map layers', layersWithCells > 5);

  // Locate should fly the map to the cell.
  const beforeCentre = await page.evaluate(() => window.Radar.center());
  // Each row now carries Locate and Follow storm, both styled .cell-focus.
  await page.locator('#cells .cell-row').first().locator('.cell-focus', { hasText: 'Locate' }).click();
  await page.waitForTimeout(900);
  const afterCentre = await page.evaluate(() => window.Radar.center());
  check('locate flies the map to the cell',
    `${beforeCentre.lat.toFixed(2)} -> ${afterCentre.lat.toFixed(2)}`,
    Math.abs(beforeCentre.lat - afterCentre.lat) > 0.01 ||
    Math.abs(beforeCentre.lng - afterCentre.lng) > 0.01);

  // Locate navigates to the Radar section, which is the point of it — come
  // back to Chase for the rest of these checks.
  await showTab('chase');
  await page.waitForTimeout(600);

  // The on-map toggle must actually remove the overlay, not just hide a label.
  await page.uncheck('#cells-on-map');
  await page.waitForTimeout(800);
  const layersWithout = await page.evaluate(() => {
    let n = 0;
    window.Radar.getMap().eachLayer(() => n++);
    return n;
  });
  check('on-map toggle removes cell markers',
    `${layersWithCells} -> ${layersWithout}`, layersWithout < layersWithCells);
  await page.check('#cells-on-map');
  await page.waitForTimeout(800);
  const layersBack = await page.evaluate(() => {
    let n = 0;
    window.Radar.getMap().eachLayer(() => n++);
    return n;
  });
  check('re-enabling restores them', `${layersWithout} -> ${layersBack}`, layersBack > layersWithout);

  // ── Shot planner ─────────────────────────────────────────────────────
  check('shot planner appears in chase mode', await page.locator('#shot-card').isVisible(),
    await page.locator('#shot-card').isVisible());

  const verdict = await page.textContent('#shot-verdict');
  check('verdict is a sentence a chaser can act on', verdict.slice(0, 60),
    verdict.length > 25);
  check('verdict is classified, not just styled',
    await page.getAttribute('#shot-verdict', 'class'),
    /shot-(go|good|marginal|silhouette|no-shot|too-close|too-far|night)/.test(
      await page.getAttribute('#shot-verdict', 'class')));

  const shotRows = await page.locator('#shot-read .shot-row').count();
  const shotText = await page.textContent('#shot-read');
  check('light, structure, range and framing all read', shotRows + ' rows', shotRows >= 5);
  check('framing gives a focal length', shotText, /\d+ mm/.test(shotText));
  check('structure is justified by VIL density', shotText, /g\/m³/.test(shotText));

  // The 3D view must actually paint, and must paint the storm rather than the
  // background gradient — a canvas that stays empty looks identical to one
  // that failed.
  const painted = await page.evaluate(() => {
    const c = document.getElementById('storm3d');
    const x = c.getContext('2d');
    const d = x.getImageData(0, 0, c.width, c.height).data;
    let n = 0;
    for (let i = 3; i < d.length; i += 4 * 37) if (d[i] > 0) n++;
    return n;
  });
  check('storm renders in 3D', painted + ' sampled px', painted > 50);

  const model3d = await page.evaluate(() => {
    const s = window.Vane.state;
    const cv = s.convective;
    return window.Storm3D.model(s.shotCell, {
      lclKm: cv && cv.lcl != null ? cv.lcl / 1000 : null,
      shearMs: cv && cv.shear6 ? cv.shear6.magnitude : 0
    });
  });
  check('3D heights come from the measured echo top',
    `top ${model3d.topKm.toFixed(1)} km, core ${model3d.coreKm.toFixed(1)} km`,
    model3d.topKm > 0 && model3d.coreKm > 0 && model3d.coreKm <= model3d.topKm);
  check('cloud base comes from the derived LCL', model3d.hasLcl, model3d.hasLcl === true);

  // The reflectivity field is read out of the tiles asynchronously.
  await page.waitForTimeout(2500);
  await page.evaluate(() => window.UI.renderShot(window.Vane.state));
  await page.waitForTimeout(800);

  const fieldInfo = await page.evaluate(() => {
    const f = window.Vane.state.shotField;
    if (!f) return null;
    const s = window.Vane.state, cv = s.convective;
    const m = window.Storm3D.model(s.shotCell, {
      lclKm: cv && cv.lcl != null ? cv.lcl / 1000 : null,
      shearMs: cv && cv.shear6 ? cv.shear6.magnitude : 0
    });
    const cols = window.Storm3D.columns(m, f.field);
    const tallest = cols.length ? cols.reduce((a, c) => (c.z1 > a.z1 ? c : a)) : null;
    return {
      size: f.field.size, maxDbz: f.field.maxDbz, columns: cols.length,
      topKm: m.topKm, tallestZ: tallest ? tallest.z1 : null,
      strongest: tallest ? tallest.dbz : null
    };
  });
  check('reflectivity field read back out of the radar tiles',
    fieldInfo ? `${fieldInfo.size}² grid, max ${fieldInfo.maxDbz} dBZ` : 'no field',
    !!fieldInfo && fieldInfo.maxDbz > 0);
  if (fieldInfo) {
    check('the 3D is built from that field, not a generic shape',
      fieldInfo.columns + ' columns', fieldInfo.columns > 20);
    check('the strongest return reaches the measured echo top',
      `${fieldInfo.strongest} dBZ at ${fieldInfo.tallestZ.toFixed(2)} km of ${fieldInfo.topKm.toFixed(2)}`,
      Math.abs(fieldInfo.tallestZ - fieldInfo.topKm) < 1e-6);
  }

  const note3d = await page.textContent('#shot-3d-note');
  check('the 3D panel refuses to imply volumetric data', note3d.slice(0, 80),
    /a model, not a scan/.test(note3d));
  check('the panel says which shape you are looking at', 'radar-derived or fallback',
    /actual 0\.5° reflectivity field/.test(note3d) || /generic silhouette/.test(note3d));
  check('vertical exaggeration is stated, not hidden', /exaggerated/.test(note3d),
    /\d(\.\d)?× exaggerated/.test(note3d));

  // Orbit exposes the controls; "from here" does not, because there is nothing
  // to orbit when the camera is your own eyes.
  await page.click('.view-switch button[data-view="orbit"]');
  await page.waitForTimeout(700);
  check('orbit view exposes rotation controls',
    await page.locator('#shot-3d-controls').isVisible(),
    await page.locator('#shot-3d-controls').isVisible());
  const azBefore = await page.evaluate(() => window.Storm3D.state.azimuth);
  await page.click('#shot-3d-controls button[data-orbit="15"]');
  await page.waitForTimeout(400);
  const azAfter = await page.evaluate(() => window.Storm3D.state.azimuth);
  check('rotating actually moves the camera', `${azBefore} -> ${azAfter}`, azBefore !== azAfter);
  await page.click('.view-switch button[data-view="observer"]');
  await page.waitForTimeout(600);
  check('from-here view hides them again',
    await page.locator('#shot-3d-controls').isHidden(),
    await page.locator('#shot-3d-controls').isHidden());

  // The vantage is the deliverable: it must be on the inflow flank and it must
  // never be in front of the core.
  const target = await page.evaluate(() => {
    const p = window.Vane.state.shotPlan;
    return p && p.target ? {
      inCorePath: p.target.inCorePath,
      off: ((p.target.bearingFromStorm - p.target.stormTowardDeg) % 360 + 360) % 360,
      standoff: p.target.standoffKm
    } : null;
  });
  check('a vantage is solved', target ? 'yes' : 'no cell moving', !!target);
  if (target) {
    check('vantage sits on the inflow flank', Math.round(target.off) + '° off the track',
      target.off >= 90 && target.off <= 150);
    check('vantage is never in the storm path', target.inCorePath, target.inCorePath === false);
    check('standoff is a sane distance', target.standoff + ' km',
      target.standoff >= 12 && target.standoff <= 40);
  }
  check('the planner states it is not a routing or safety system',
    (await page.textContent('#shot-target')).slice(-90),
    /not a routing or safety system/.test(await page.textContent('#shot-target')));

  // Showing the vantage draws it with the sight line it was solved for.
  await page.locator('#shot-target button').first().click();
  await page.waitForTimeout(900);
  const vantageDrawn = await page.evaluate(() => {
    let n = 0;
    window.Radar.getMap().eachLayer(l => { if (l instanceof L.Polyline && l.options.dashArray === '5 5') n++; });
    return n;
  });
  check('vantage drawn with its sight line', vantageDrawn + ' sight lines', vantageDrawn >= 1);

  // ── Dual pane ────────────────────────────────────────────────────────
  await openRadarOpts();
  await page.click('#pair-btn');
  await page.waitForTimeout(2600);
  check('second pane opens', await page.locator('#pane-b').isVisible(),
    await page.locator('#pane-b').isVisible());
  const pairInfo = await page.evaluate(() => {
    const p = window.Radar.getPair();
    const s = window.Radar.getSite();
    return p ? { product: p.product, source: window.Radar.getSource(), site: s && s.id } : null;
  });
  check('dual pane pairs velocity against the same radar',
    pairInfo && `${pairInfo.site} ${pairInfo.source} + ${pairInfo.product}`,
    !!pairInfo && pairInfo.source === 'site' && !!pairInfo.site && pairInfo.product === 'N0U');

  /* Braces, deliberately: a bare `=> map.setView(...)` RETURNS the map —
   * setView returns `this` — and Playwright then tries to serialize the
   * entire Leaflet object graph back to the test. That worked by luck until
   * the graph grew (207 site markers pushed it over), at which point the
   * serializer failed as "execution context was destroyed" and sent this
   * suite on a long hunt for a navigation that never happened. Never return
   * a Leaflet object from an evaluate. */
  await page.evaluate(() => { window.Radar.getMap().setView([41.5, -95.5], 8); });
  await page.waitForTimeout(1000);
  const synced = await page.evaluate(() => {
    const a = window.Radar.getMap().getCenter();
    const b = window.Radar.getPair().map.getCenter();
    return { d: Math.abs(a.lat - b.lat) + Math.abs(a.lng - b.lng),
             z: window.Radar.getMap().getZoom() === window.Radar.getPair().map.getZoom() };
  });
  check('panes stay locked to the same view', synced.d.toFixed(4) + '° apart',
    synced.d < 0.02 && synced.z);

  // A map that never learns its size renders as an empty rectangle, which is
  // indistinguishable from a dead tile feed.
  const paneSized = await page.evaluate(() => {
    const s = window.Radar.getPair().map.getSize();
    return { x: s.x, y: s.y };
  });
  check('second pane knows its own size', `${paneSized.x}×${paneSized.y}`,
    paneSized.x > 50 && paneSized.y > 50);

  const paneTiles = await page.locator('#map2 img.leaflet-tile').count();
  check('second pane actually loads tiles', paneTiles + ' tiles', paneTiles > 0);

  await page.selectOption('#pair-product', 'N0S');
  await page.waitForTimeout(900);
  check('second pane can switch to storm-relative velocity',
    await page.evaluate(() => window.Radar.getPair().product),
    (await page.evaluate(() => window.Radar.getPair().product)) === 'N0S');
  check('pane note explains what the product shows',
    await page.textContent('#pair-note'),
    /storm motion removed/.test(await page.textContent('#pair-note')));

  await openRadarOpts();
  await page.click('#pair-btn');
  await page.waitForTimeout(900);
  check('closing the pane tears the second map down',
    await page.evaluate(() => window.Radar.getPair()),
    (await page.evaluate(() => window.Radar.getPair())) === null);

  // Panning after the close must not throw: the sync handlers were bound to
  // the main map, which outlives the pane.
  const errsBefore = errors.length;
  await page.evaluate(() => { window.Radar.getMap().setView([41.0, -96.0], 7); });
  await page.waitForTimeout(700);
  check('closing unbinds the sync handlers', (errors.length - errsBefore) + ' new errors',
    errors.length === errsBefore);

  // Dual pane leaves the radar on a single site; put the mosaic back so the
  // playback assertions below are not testing a single scan.
  await setSource('nexrad');

  /* The grid is split: four headline parameters, and the rest inside a
   * disclosure that is folded on a phone and open on a desktop. Both halves
   * are the same grid markup, so every check below reads across both — a
   * parameter that moved between them is a presentation change, not a
   * missing number, and this must not start passing because one half
   * silently emptied. */
  const headlineParams = await page.locator('#params .param').count();
  const restParams = await page.locator('#params-rest .param').count();
  const paramTexts = await page.locator('#params .param, #params-rest .param').allTextContents();
  const findParam = label => (paramTexts.find(t => t.startsWith(label)) || '');
  check('convective params rendered', `${headlineParams} headline + ${restParams} folded`,
    headlineParams + restParams >= 12);
  check('the four that decide the day lead the card',
    (await page.locator('#params .param .param-label').allTextContents()).join(', '),
    headlineParams === 4);
  check('CAPE has a value', findParam('CAPE'), /\d+ J\/kg/.test(findParam('CAPE')));
  check('0-6 km shear resolves (regression)', findParam('0–6 km shear'),
    /\d+ kt/.test(findParam('0–6 km shear')));
  check('0-1 km SRH resolves', findParam('0–1 km SRH'),
    /-?\d+ m²\/s²/.test(findParam('0–1 km SRH')));
  check('Bunkers right mover', findParam('Storm motion (RM)'),
    /[NSEW]+ \d+ kt/.test(findParam('Storm motion (RM)')));
  check('plain-language read', await page.textContent('#params .param-summary').catch(() => ''),
    true);
  const oddsText = await page.textContent('#params .param-odds').catch(() => '');
  check('chase-day odds for the coming evening(s)', oddsText,
    /Severe report within 100 km: (this evening|\w{3} evening) (\d+%|under 1%)/.test(oddsText) &&
    /AUC 0\.\d\d vs 0\.\d\d/.test(oddsText) && /cannot see a cap break/.test(oddsText));

  const hodoDots = await page.locator('#hodograph circle').count();
  const hodoRings = await page.locator('#hodograph .hodo-ring').count();
  check('hodograph plotted', `${hodoDots} dots / ${hodoRings} rings`, hodoDots > 8 && hodoRings > 1);
  check('hodograph layer key', await page.locator('#hodo-key .hodo-key-row').count(),
    (await page.locator('#hodo-key .hodo-key-row').count()) === 4);

  // 1000 and 975 hPa are underground at OKC's 371 m elevation and are correctly
  // dropped, so 11 requested levels yield 9 usable ones plus the surface row.
  const profRows = await page.locator('#profile tbody tr').count();
  check('wind profile table drops underground levels', profRows, profRows === 10);
  check('surface row highlighted', await page.locator('#profile .sfc-row').count(),
    (await page.locator('#profile .sfc-row').count()) === 1);

  const spc = await page.textContent('#spc');
  check('SPC risk resolved for point', spc, /TSTM|MRGL|SLGT|ENH|MDT|HIGH|outside any/.test(spc));
  const reports = await page.textContent('#reports');
  check('with the NWS feed down, SPC\'s reports stand in (2/2/2)', reports.slice(0, 40),
    /2 tornado/.test(reports) && /2 wind/.test(reports) && /2 hail/.test(reports));
  const reportRows = await page.locator('#reports .report-row').count();
  const reportText = await page.textContent('#reports');
  check('storm reports resolve for the current location',
    reportRows ? reportRows + ' rows' : reportText.slice(30, 80),
    reportRows === 6 || /none within 400 km/.test(reportText));

  /* ── Every kind of storm report (NWS LSRs via Iowa State) ────────────
   * "Can they be like hail, wind, tornado, and others?" A real busy day:
   * 197 reports across tornado, funnel, hail, wind, flood, snow and other. */
  lsrUp = true;
  await page.evaluate(() => Vane.loadReports());
  await page.waitForTimeout(800);
  const lsr = await page.evaluate(() => {
    const kinds = ['tornado', 'funnel', 'hail', 'wind', 'flood', 'winter', 'other'];
    const onMap = {};
    kinds.forEach(k => { onMap[k] = document.querySelectorAll('.lsr-icon.lsr-' + k).length; });
    const glyphs = {};
    kinds.forEach(k => { const e = document.querySelector('.lsr-icon.lsr-' + k + ' span'); glyphs[k] = e ? e.textContent : null; });
    return { counts: SPC.summary(), onMap, glyphs,
      filters: Array.from(document.querySelectorAll('#report-filters .report-filter')).map(b => b.textContent),
      card: document.getElementById('reports').textContent };
  });
  check('storm reports come in every kind, not only tornado, wind and hail',
    JSON.stringify(lsr.counts),
    lsr.counts.tornado === 40 && lsr.counts.hail === 30 && lsr.counts.wind === 61 &&
    lsr.counts.flood === 46 && lsr.counts.winter === 8 && lsr.counts.funnel === 5 && lsr.counts.other === 7);
  check('each kind is drawn on the radar with its own letter, not colour alone',
    JSON.stringify(lsr.glyphs),
    Object.values(lsr.onMap).every(n => n > 0) &&
    lsr.glyphs.tornado === 'T' && lsr.glyphs.hail === 'H' && lsr.glyphs.wind === 'W' &&
    lsr.glyphs.funnel === 'F' && lsr.glyphs.winter === 'S' && lsr.glyphs.flood === '≈');
  check('the filter chips are the legend, with counts', lsr.filters.join(' | '),
    lsr.filters.length === 7 && lsr.filters.some(f => /Hail 30/.test(f)) && lsr.filters.some(f => /Snow \/ ice 8/.test(f)));
  const hailOff = await page.evaluate(() => {
    document.querySelector('#report-filters .report-filter[data-kind="hail"]').click();
    const off = { hail: document.querySelectorAll('.lsr-icon.lsr-hail').length,
                  tornado: document.querySelectorAll('.lsr-icon.lsr-tornado').length,
                  pressed: document.querySelector('#report-filters .report-filter[data-kind="hail"]').getAttribute('aria-pressed') };
    document.querySelector('#report-filters .report-filter[data-kind="hail"]').click();
    return Object.assign(off, { back: document.querySelectorAll('.lsr-icon.lsr-hail').length,
                                saved: JSON.stringify(Settings.get('reportTypes')) });
  });
  check('a kind can be hidden from the map, and brought back',
    JSON.stringify(hailOff),
    hailOff.hail === 0 && hailOff.tornado === 40 && hailOff.pressed === 'false' && hailOff.back === 30 &&
    hailOff.saved === '{}');
  const popup = await page.evaluate(() => {
    const m = document.querySelector('.lsr-icon.lsr-hail');
    return m ? m.getAttribute('title') : '';
  });
  check('each report says what and how big', popup, /^Hail \d+(\.\d+)?″ \((measured|est\.)\)$/.test(popup) || /^Hail \d/.test(popup));
  check('the reports card lists every kind nearby', lsr.card.slice(0, 120),
    /40 tornado/.test(lsr.card) && /46 flood \/ heavy rain/.test(lsr.card) && /8 snow \/ ice/.test(lsr.card));

  /* "Can I click on storm reports and see more detail": the biggest hail
   * report, tapped, reads in full — size against a yardstick, SPC criteria,
   * county, distance from you, who reported it — and its radar button
   * rewinds the loop to that moment. */
  const tapped = await page.evaluate(() => {
    const hail = SPC.state.reports.filter(r => r.category === 'hail').sort((a, b) => b.magValue - a.magValue)[0];
    const m = SPC.state.reportLayer.getLayers().find(l => { const p = l.getLatLng(); return p.lat === hail.lat && p.lng === hail.lon; });
    m.fire('click', { latlng: m.getLatLng() });
    const el = document.querySelector('.lsr-popup .leaflet-popup-content');
    return { hail, text: el ? el.textContent : '', buttons: el ? Array.from(el.querySelectorAll('.lsr-action')).map(b => b.textContent) : [] };
  });
  check('a tapped report reads in full', tapped.text.slice(60, 220),
    /golf ball|hen egg|tennis ball|baseball|softball|grapefruit|teacup|larger than/.test(tapped.text) &&
    /Significant severe hail|Severe hail/.test(tapped.text) && /County/.test(tapped.text) &&
    /\d+ mi [NSEW]{1,3} of [A-Z]/.test(tapped.text) && /Reported by .+ · NWS [A-Z]{3}/.test(tapped.text));
  check('with the radar at that moment and the NWS text a tap away', tapped.buttons.join(' | '),
    tapped.buttons.length === 2 && /Radar at this time/.test(tapped.buttons[0]) && /NWS report/.test(tapped.buttons[1]));
  const rewound = await page.evaluate(() => {
    document.querySelector('.lsr-popup .lsr-action[data-radar-at]').click();
    const at = +document.querySelector('.lsr-popup .lsr-action[data-radar-at]').getAttribute('data-radar-at');
    return { at, hist: Vane.state.radarHistory, kind: document.getElementById('radar-kind').textContent,
             near: Radar.frameNear(at), open: !!document.querySelector('.lsr-popup') };
  });
  check('"Radar at this time" rewinds the loop to the report', JSON.stringify(rewound),
    rewound.near && rewound.near.gapMs <= 5 * 60000 && rewound.open &&
    (rewound.hist ? rewound.kind === 'archive' && rewound.hist >= rewound.at : rewound.kind === 'observed'));
  await page.evaluate(() => { Radar.getMap().closePopup(); document.getElementById('mode-live').click(); });
  await page.waitForTimeout(300);

  check('alert full text expandable', await page.locator('#alerts-full details').count(),
    (await page.locator('#alerts-full details').count()) >= 1);
  check('48 hourly cells in chase mode', await page.locator('#hourly .hour').count(),
    (await page.locator('#hourly .hour').count()) === 48);

  await page.screenshot({ path: path.join(__dirname, 'shot-chase.png'), fullPage: true });

  // ── Interactions ─────────────────────────────────────────────────────
  await showTab('chase');
  await page.waitForTimeout(600);
  await page.click('#cv-next'); await page.waitForTimeout(300);
  await page.click('#cv-next'); await page.waitForTimeout(300);
  const hourLabel = await page.textContent('#cv-hour');
  check('hour stepping advances', hourLabel, /\+2h/.test(hourLabel));
  await page.click('#cv-prev'); await page.waitForTimeout(300);
  check('hour stepping goes back', await page.textContent('#cv-hour'), /\+1h/.test(await page.textContent('#cv-hour')));

  // Units
  const beforeUnits = await page.textContent('#now-temp');
  await page.click('#units-btn'); await page.waitForTimeout(600);
  const afterUnits = await page.textContent('#now-temp');
  check('unit toggle converts', `${beforeUnits}F -> ${afterUnits}C`, beforeUnits !== afterUnits);
  check('unit label updated', await page.textContent('#units-label'),
    (await page.textContent('#units-label')) === '°C');
  await page.click('#units-btn'); await page.waitForTimeout(400);

  // Settings
  await page.click('#settings-btn'); await page.waitForTimeout(500);
  check('settings opens', await page.locator('#settings').isVisible(), await page.locator('#settings').isVisible());
  check('9 alert filter chips', await page.locator('#settings-body .filter-chip').count(),
    (await page.locator('#settings-body .filter-chip').count()) === 9);
  // Turn off the heat family and confirm the Heat Advisory disappears
  const heatChip = page.locator('#settings-body .filter-chip', { hasText: 'Heat / cold' });
  await heatChip.locator('input').uncheck();
  await page.waitForTimeout(600);
  await page.click('#settings-close');
  await page.waitForTimeout(400);
  const alertsAfter = await page.locator('#alerts .alert').count();
  check('alert filter removes heat advisory', `${alerts} -> ${alertsAfter}`, alertsAfter < alerts);
  await page.screenshot({ path: path.join(__dirname, 'shot-settings.png') });

  // Search
  await page.fill('#search-input', 'Norman');
  await page.waitForTimeout(1200);
  const results = await page.locator('#search-results .result-btn').count();
  check('search returns results', results, results > 0);

  /* The dropdowns must be opaque panels, not glass. On iOS the topbar's own
   * backdrop-filter becomes the backdrop root for its children, so a
   * dropdown hanging below it gets no blur of the page at all — place names
   * interleaved with the card text behind them, photographed by a user as
   * unreadable soup. Asserting alpha === 1 also guards against anyone
   * "restoring" the glass look without reading why it left. */
  const dropOpaque = await page.evaluate(() => {
    const read = sel => {
      const cs = getComputedStyle(document.querySelector(sel));
      const m = cs.backgroundColor.match(/rgba?\(([\d.\s,]+)\)/);
      const parts = m ? m[1].split(',').map(Number) : [];
      return { alpha: parts.length === 4 ? parts[3] : 1, blur: cs.backdropFilter };
    };
    return { search: read('#search-results'), saved: read('#saved-list') };
  });
  check('the search dropdown is an opaque panel, not glass',
    `alpha ${dropOpaque.search.alpha}, backdrop "${dropOpaque.search.blur}"`,
    dropOpaque.search.alpha === 1 && dropOpaque.search.blur === 'none');
  check('and so is the saved-locations list',
    `alpha ${dropOpaque.saved.alpha}, backdrop "${dropOpaque.saved.blur}"`,
    dropOpaque.saved.alpha === 1 && dropOpaque.saved.blur === 'none');
  if (results) {
    await page.locator('#search-results .result-btn').first().click();
    await page.waitForTimeout(2500);
    check('search changes location', await page.textContent('#place-name'),
      (await page.textContent('#place-name')) === 'Norman');
  }

  // Coordinate paste
  await page.fill('#search-input', '35.22,-97.44');
  await page.waitForTimeout(900);
  const coordResults = await page.locator('#search-results .result-btn').count();
  check('coordinate paste parsed locally', coordResults, coordResults === 1);

  // Keyboard
  await page.keyboard.press('Escape');
  await page.click('body');
  await page.keyboard.press('m');
  await page.waitForTimeout(700);
  check('M toggles back to simple', await page.getAttribute('body', 'data-mode'),
    (await page.getAttribute('body', 'data-mode')) === 'simple');
  await page.keyboard.press('?');
  await page.waitForTimeout(300);
  check('? opens help', await page.locator('#help').isVisible(), await page.locator('#help').isVisible());
  // Counted against the config rather than a literal, so adding a shortcut
  // fails only when the help stops listing it.
  const declaredKeys = await page.evaluate(() => window.VaneConfig.SHORTCUTS.length);
  check('help lists every shortcut',
    `${await page.locator('#help-list dt').count()} of ${declaredKeys}`,
    (await page.locator('#help-list dt').count()) === declaredKeys);
  await page.keyboard.press('Escape');
  await page.waitForTimeout(200);
  check('Escape closes help', await page.locator('#help').isHidden(), await page.locator('#help').isHidden());

  // Radar controls
  const playBefore = await page.textContent('#radar-play');
  await page.keyboard.press(' ');
  await page.waitForTimeout(400);
  const playAfter = await page.textContent('#radar-play');
  check('Space toggles radar playback', `${playBefore} -> ${playAfter}`,
    playBefore !== playAfter && /Play|Pause/.test(playAfter));

  /* ── Installable ─────────────────────────────────────────────────────
   * The manifest and the service worker are only half of it; the failure
   * people actually ship is an Install button that does nothing on iOS, or a
   * manifest whose icons 404. Both are checked against the running page. */
  const manifest = await page.evaluate(async () => {
    const link = document.querySelector('link[rel="manifest"]');
    if (!link) return null;
    const res = await fetch(link.href);
    if (!res.ok) return { error: res.status };
    return await res.json();
  });
  check('the manifest is served and parses', manifest && (manifest.error || manifest.name),
    !!manifest && !manifest.error);

  const assets = await page.evaluate(async (m) => {
    const urls = m.icons.map(i => i.src).concat(m.screenshots.map(s => s.src));
    const out = [];
    for (const u of urls) {
      const res = await fetch(new URL(u, location.href).href);
      if (!res.ok) out.push(u + ' -> ' + res.status);
    }
    return out;
  }, manifest);
  check('every icon and screenshot the manifest names is actually served',
    assets.length ? assets.join(', ') : 'all present', assets.length === 0);

  check('iOS gets a home-screen icon it will actually use',
    await page.evaluate(() => {
      const l = document.querySelector('link[rel="apple-touch-icon"]');
      return l ? l.getAttribute('href') : 'missing';
    }),
    (await page.evaluate(() => !!document.querySelector('link[rel="apple-touch-icon"]'))) === true);
  check('iOS is told to run it full screen',
    await page.evaluate(() => {
      const m = document.querySelector('meta[name="apple-mobile-web-app-capable"]');
      return m ? m.content : 'missing';
    }),
    (await page.evaluate(() => {
      const m = document.querySelector('meta[name="apple-mobile-web-app-capable"]');
      return m && m.content === 'yes';
    })) === true);

  const iosStatus = await page.evaluate(() => {
    // Pretend to be an iPhone for one call: the point is that Vane shows
    // instructions instead of a dead button, and that is pure logic.
    const real = navigator.userAgent;
    Object.defineProperty(navigator, 'userAgent',
      { value: 'Mozilla/5.0 (iPhone; CPU iPhone OS 17_0 like Mac OS X)', configurable: true });
    const s = window.Install.status();
    Object.defineProperty(navigator, 'userAgent', { value: real, configurable: true });
    return s;
  });
  check('on iOS Vane explains Add to Home Screen instead of offering a dead button',
    iosStatus.state + ', can=' + iosStatus.can,
    iosStatus.state === 'ios' && iosStatus.can === false &&
    /Add to Home Screen/.test(iosStatus.note));

  // The badge is the closest thing a web app has to a widget, so the counting
  // rule is worth pinning: severe and above only.
  const badge = await page.evaluate(() => {
    const a = s => ({ id: s, severity: s, event: s + ' Warning', headline: '' });
    return {
      mixed: window.Settings.badgeCount([a('Extreme'), a('Severe'), a('Moderate'), a('Minor')]),
      none: window.Settings.badgeCount([]),
      api: 'setAppBadge' in navigator
    };
  });
  check('the app icon badge counts severe alerts and nothing softer',
    `${badge.mixed} of 4 (API ${badge.api ? 'present' : 'absent'})`, badge.mixed === 2 && badge.none === 0);

  const launch = await page.evaluate(async () => {
    const tags = Array.from(document.querySelectorAll('link[rel="apple-touch-startup-image"]'));
    const bad = [];
    for (const t of tags.slice(0, 6)) {
      const r = await fetch(t.href);
      if (!r.ok) bad.push(t.getAttribute('href'));
    }
    return { count: tags.length, bad: bad };
  });
  check('iOS launch screens are declared and served',
    launch.count + ' images' + (launch.bad.length ? ', missing ' + launch.bad.join(', ') : ''),
    launch.count >= 20 && launch.bad.length === 0);

  check('the install offer can be dismissed for good', await page.evaluate(() => {
    window.Install.dismiss();
    const gone = !window.Install.shouldOfferBanner();
    localStorage.removeItem(window.Install.DISMISS_KEY);
    return gone;
  }), true);

  // Manifest shortcuts deep-link into a tab; the app must honour them.
  await page.goto(BASE + '?mode=chase&tab=radar', { waitUntil: 'load' });
  await page.waitForTimeout(3000);
  const launched = await page.evaluate(() => ({
    mode: document.body.dataset.mode,
    tab: document.body.dataset.mtab,
    url: location.search
  }));
  check('a manifest shortcut opens the right mode and tab',
    `${launched.mode}/${launched.tab}`,
    launched.mode === 'chase' && launched.tab === 'radar');
  check('and the launch parameters are stripped so a refresh does not re-force them',
    launched.url === '' ? 'clean' : launched.url, launched.url === '');
  await page.goto(BASE, { waitUntil: 'load' });
  await page.waitForTimeout(3000);

  /* ── Phone: information architecture ─────────────────────────────────
   * Vane's own research says this runs on a phone in a moving vehicle, but it
   * was laid out at desktop width first. These assertions are the guard rail
   * on the correction — they encode what "mobile-first" actually means here
   * rather than leaving it to a screenshot nobody re-reads. */
  await page.setViewportSize({ width: 390, height: 844 });
  await page.waitForTimeout(1600);

  check('phone gets a bottom tab bar',
    await page.evaluate(() => getComputedStyle(document.querySelector('.tabbar')).display),
    (await page.evaluate(() => getComputedStyle(document.querySelector('.tabbar')).display)) === 'grid');

  const tabTargets = await page.evaluate(() =>
    Array.from(document.querySelectorAll('.tabbar button'))
      .filter(b => b.offsetParent !== null)
      .map(b => { const r = b.getBoundingClientRect(); return Math.min(r.width, r.height); }));
  check('tab bar targets clear the 44px guideline',
    Math.min.apply(null, tabTargets) + 'px smallest', Math.min.apply(null, tabTargets) >= 44);

  /* Every visible control, measured.
   *
   * Two exemptions, both the same one in WCAG 2.2 SC 2.5.8: a target that is
   * a word inside a sentence is excluded, because the only way to give it 44
   * square pixels is to stop it being a word inside a sentence. That covers
   * the source links in the footer and the glossary terms, which are literally
   * words in sentences that happen to be pressable. They are exempted by name
   * here rather than silently, and the checks below hold them to what they can
   * be held to: reachable by keyboard, and not hairline-thin vertically. */
  const targets = await page.evaluate(() => {
    const inProse = el => !!el.closest('p, li, .param-note, .cell-reason');
    return Array.from(document.querySelectorAll('button, select, input, [role="tab"], a'))
      .filter(e => e.offsetParent !== null)
      .filter(e => !e.classList.contains('skip') && !e.classList.contains('sr-only'))
      .filter(e => !e.classList.contains('gl-term'))
      .filter(e => !(e.tagName === 'A' && inProse(e)))
      .map(e => {
        /* A checkbox or radio wrapped in its <label> is tapped through the
         * label — the browser toggles it from anywhere on the text — so the
         * label is the target WCAG 2.5.8 measures, not the 20px glyph. */
        const lab = (e.type === 'checkbox' || e.type === 'radio') && e.closest('label');
        const r = (lab || e).getBoundingClientRect();
        return { id: e.id || e.className || e.tagName, w: Math.round(r.width), h: Math.round(r.height) };
      })
      .filter(t => t.w > 2 && t.h > 2);
  });
  const undersized = targets.filter(t => t.h < 44 || t.w < 44);
  check('every control meets the 44px touch target',
    undersized.length ? undersized.map(t => `${t.id} ${t.w}x${t.h}`).join(', ')
                      : targets.length + ' controls, all >= 44px',
    undersized.length === 0);

  /* The exemption is not a free pass. An inline term still has to be usable:
   * focusable in sequence, and tall enough to hit — the phone stylesheet gives
   * them vertical padding for exactly this reason. */
  const glossTargets = await page.evaluate(() =>
    Array.from(document.querySelectorAll('.gl-term'))
      .filter(e => e.offsetParent !== null)
      .map(e => ({
        h: Math.round(e.getBoundingClientRect().height),
        button: e.tagName === 'BUTTON' && !e.disabled,
        labelled: !!e.getAttribute('aria-label')
      })));
  check('glossary terms are real, reachable controls',
    glossTargets.length + ' terms on screen',
    glossTargets.length > 0 && glossTargets.every(t => t.button && t.labelled));
  check('and tall enough to hit on a phone',
    Math.min.apply(null, glossTargets.map(t => t.h)) + 'px shortest',
    glossTargets.every(t => t.h >= 20));

  const tiny = await page.evaluate(() =>
    Array.from(document.querySelectorAll('p, li, span, td'))
      .filter(e => e.offsetParent !== null && e.textContent.trim().length > 20)
      .filter(e => parseFloat(getComputedStyle(e).fontSize) < 12).length);
  check('no body copy under 12px on a phone', tiny + ' elements', tiny === 0);

  // Tabs must actually filter, and the radar must fill the screen on its own.
  const nowCards = await page.evaluate(() =>
    Array.from(document.querySelectorAll('main > section')).filter(e => e.offsetParent !== null).length);
  await page.click('.tabbar button[data-tab="radar"]');
  await page.waitForTimeout(1200);
  const radarTab = await page.evaluate(() => ({
    cards: Array.from(document.querySelectorAll('main > section')).filter(e => e.offsetParent !== null).map(e => e.id),
    mapH: Math.round(document.getElementById('map').getBoundingClientRect().height),
    mapTop: Math.round(document.getElementById('map').getBoundingClientRect().top),
    page: document.documentElement.scrollHeight
  }));
  check('tabs filter the page rather than stacking it',
    `now ${nowCards} cards -> radar ${radarTab.cards.length}`,
    radarTab.cards.length < nowCards && radarTab.cards.indexOf('radar-card') !== -1);
  check('radar is on screen without scrolling', 'map top at ' + radarTab.mapTop + 'px',
    radarTab.mapTop < 844);
  check('radar fills the phone screen', radarTab.mapH + 'px tall', radarTab.mapH > 420);

  // A deliberate tab choice survives a mode switch; only the stale one moves.
  await page.click('.mode-switch button[data-mode="chase"]');
  await page.waitForTimeout(1600);
  check('a deliberate tab choice survives a mode switch',
    await page.evaluate(() => document.body.dataset.mtab),
    (await page.evaluate(() => document.body.dataset.mtab)) === 'radar');
  await page.click('.mode-switch button[data-mode="simple"]');
  await page.waitForTimeout(900);
  await page.click('.tabbar button[data-tab="now"]');
  await page.click('.mode-switch button[data-mode="chase"]');
  // Somewhere with cells in the fixture, so the 3D assertions below actually
  // run instead of skipping on a hidden canvas.
  await page.evaluate(() => window.Vane.setLocation(
    { lat: 42.8997, lon: -94.6912, name: 'Storm test', admin: 'Iowa, US' }));
  await page.waitForTimeout(4000);
  const chaseTab = await page.evaluate(() => ({
    tab: document.body.dataset.mtab,
    page: document.documentElement.scrollHeight,
    cards: Array.from(document.querySelectorAll('main > section')).filter(e => e.offsetParent !== null).map(e => e.id)
  }));
  check('chase mode from the Now tab moves you to the new content', chaseTab.tab,
    chaseTab.tab === 'chase');
  /* It was 8,838px — about ten screens to reach the wind profile. Chase mode
   * is inherently dense and five technical panels will always be a scroll, but
   * this is a page rather than an expedition: the two you act on lead, and the
   * two you look things up in are folded. */
  /* The bound was 5,600px. It rose to 6,000 when two decision tools joined
   * the tab — followed storms and target compare, both folded on a phone,
   * costing 244px of summary between them. The point of the check holds:
   * the panels you act on lead (asserted below), every lookup panel and
   * tool is folded, and the tab is a third shorter than the 8,838px stack. */
  check('chase is no longer one enormous stack', chaseTab.page + 'px (was 8838)',
    chaseTab.page < 6000);

  /* Measured on the <details> box, not its children: current Chrome hides a
   * closed details' body with `content-visibility`, so the child still reports
   * a bounding box even though it occupies no space. The element's own height
   * is what actually tells you whether it is folded. */
  const folds = await page.evaluate(() =>
    Array.from(document.querySelectorAll('.phone-fold')).map(d => ({
      open: d.open,
      total: Math.round(d.getBoundingClientRect().height),
      summaryH: Math.round(d.querySelector('summary').getBoundingClientRect().height)
    })));
  check('reference panels are folded on a phone, not deleted',
    folds.map(f => `${f.total}px vs ${f.summaryH}px summary`).join('; '),
    folds.length >= 2 && folds.every(f =>
      !f.open && f.summaryH >= 44 && f.total <= f.summaryH + 4));

  // And they open when tapped, rather than being a dead label.
  await page.evaluate(() => document.querySelector('.phone-fold').open = true);
  await page.waitForTimeout(400);
  const opened = await page.evaluate(() => {
    const d = document.querySelector('.phone-fold');
    return Math.round(d.getBoundingClientRect().height);
  });
  check('and they open to reveal the panel', opened + 'px open',
    opened > folds[0].summaryH + 100);
  await page.evaluate(() => document.querySelector('.phone-fold').open = false);
  check('the two panels you act on lead the chase tab',
    chaseTab.cards.slice(0, 2).join(', '),
    chaseTab.cards[0] === 'shot-card' && chaseTab.cards[1] === 'cells-card');

  // The 3D must be draggable, not button-only.
  const orbitWorks = await page.evaluate(async () => {
    const c = document.getElementById('storm3d');
    if (!c || c.offsetParent === null) return 'no canvas';
    const before = window.Storm3D.state.azimuth;
    const box = c.getBoundingClientRect();
    const opts = { bubbles: true, pointerId: 1, clientX: box.left + 60, clientY: box.top + 60 };
    c.dispatchEvent(new PointerEvent('pointerdown', opts));
    c.dispatchEvent(new PointerEvent('pointermove',
      Object.assign({}, opts, { clientX: box.left + 160 })));
    c.dispatchEvent(new PointerEvent('pointerup', opts));
    return { before: before, after: window.Storm3D.state.azimuth };
  });
  check('the 3D canvas is on screen to be dragged', orbitWorks === 'no canvas' ? 'hidden' : 'visible',
    typeof orbitWorks === 'object');
  if (typeof orbitWorks === 'object') {
    check('the 3D storm can be dragged, not just buttoned',
      `${Math.round(orbitWorks.before)}° -> ${Math.round(orbitWorks.after)}°`,
      orbitWorks.before !== orbitWorks.after);
    check('the canvas claims the gesture so the page does not steal it',
      await page.evaluate(() => document.getElementById('storm3d').style.touchAction),
      (await page.evaluate(() => document.getElementById('storm3d').style.touchAction)) === 'none');
  }

  await page.click('.mode-switch button[data-mode="simple"]');
  await page.waitForTimeout(1200);

  /* ── Phone layout ────────────────────────────────────────────────────
   * Grid items default to `min-width: auto`, so any card holding a wide
   * scrolling strip can push its own track past the viewport and hand the
   * scrollbar to the document. That is invisible on a desktop run and makes
   * the whole app pan sideways on a phone, so it is asserted rather than
   * eyeballed. */
  await page.setViewportSize({ width: 390, height: 844 });
  await page.waitForTimeout(1500);
  const overflow = await page.evaluate(() => ({
    scroll: document.documentElement.scrollWidth,
    client: document.documentElement.clientWidth
  }));
  check('page does not scroll sideways on a phone',
    `${overflow.scroll} vs viewport ${overflow.client}`,
    overflow.scroll <= overflow.client + 1);

  const wideCards = await page.evaluate(() =>
    Array.from(document.querySelectorAll('main > section'))
      .filter(el => el.getBoundingClientRect().width > window.innerWidth + 1)
      .map(el => el.id || el.className));
  check('no card is wider than the phone', wideCards.length ? wideCards.join(', ') : 'none',
    wideCards.length === 0);

  // The wide content must still be reachable — clipped, not deleted. Checked
  // on the tab that actually holds it, since the others are display:none and
  // a hidden element trivially "does not overflow".
  await page.click('.tabbar button[data-tab="now"]');
  await page.waitForTimeout(700);
  const hourlyScrolls = await page.evaluate(() => {
    const el = document.querySelector('#hourly');
    return el ? { w: el.clientWidth, s: el.scrollWidth } : null;
  });
  check('wide panels scroll inside themselves instead',
    hourlyScrolls ? `#hourly ${hourlyScrolls.s} in ${hourlyScrolls.w}` : 'missing',
    !!hourlyScrolls && hourlyScrolls.s > hourlyScrolls.w);
  await page.setViewportSize({ width: 1280, height: 1700 });
  await page.waitForTimeout(800);


  /* ── Redesign: findability, disclosure, and explained jargon ─────────
   * A UX audit of the shipped app measured what "not user friendly" meant
   * in numbers: 12 cards and 5,438px of desktop scroll with no navigation
   * at all, 16 controls on the Radar tab, 62 occurrences of jargon on the
   * Chase tab with nothing explaining any of it. These assertions hold the
   * corrections in place. */
  await page.setViewportSize({ width: 1280, height: 1700 });
  await page.waitForTimeout(900);
  await page.click('.tabbar button[data-tab="now"]');
  await page.waitForTimeout(900);

  const deskNav = await page.evaluate(() => {
    const bar = document.querySelector('.tabbar');
    const cs = getComputedStyle(bar);
    return { display: cs.display, position: cs.position,
             visible: bar.getBoundingClientRect().height > 0 };
  });
  // Grid (the old pill bar) or flex (the mockup's full-width underline nav):
  // the requirement is that it exists and stays put, not its layout model.
  check('the desktop has section navigation at all',
    `${deskNav.display} / ${deskNav.position}`,
    deskNav.visible && (deskNav.display === 'grid' || deskNav.display === 'flex') &&
    deskNav.position === 'sticky');

  const deskShape = await page.evaluate(() => ({
    cards: Array.from(document.querySelectorAll('main > section.card'))
      .filter(c => c.offsetParent !== null).length,
    height: document.documentElement.scrollHeight
  }));
  check('desktop Simple mode is no longer twelve cards in one column',
    `${deskShape.cards} cards, ${deskShape.height}px (was 12 / 5438px)`,
    deskShape.cards <= 8 && deskShape.height < 3000);

  // Every card must be reachable: a section filter that hides a card no tab
  // shows is worse than no filter at all.
  const orphaned = await page.evaluate(() => {
    const tabs = Array.from(document.querySelectorAll('.tabbar button')).map(b => b.dataset.tab);
    return Array.from(document.querySelectorAll('main > section.card'))
      .filter(c => !c.dataset.tab || tabs.indexOf(c.dataset.tab) === -1)
      .map(c => c.id || c.className);
  });
  check('every card belongs to a section you can navigate to',
    orphaned.length ? orphaned.join(', ') : 'none orphaned', orphaned.length === 0);

  // ── Radar header density ────────────────────────────────────────────
  await showTab('radar');
  await page.waitForTimeout(1200);
  const headControls = await page.evaluate(() =>
    Array.from(document.querySelectorAll('#radar-card .card-head button, #radar-card .card-head select'))
      .filter(e => e.offsetParent !== null).map(e => e.id));
  check('the radar header is three controls, not nine',
    headControls.join(', '), headControls.length <= 3);
  check('Play sits beside the bar it drives',
    await page.evaluate(() => !!document.querySelector('.radar-scrub #radar-play')), true);

  // Everything that moved is still reachable, and still one press away.
  await page.click('#radar-opts-btn');
  await page.waitForTimeout(500);
  const optsVisible = await page.evaluate(() => ['layer-wind', 'layer-temp', 'layer-cape', 'pair-btn', 'radar-opacity']
    .filter(id => { const e = document.getElementById(id); return e && e.offsetParent !== null; }));
  check('nothing was removed from the radar, only moved one press away',
    optsVisible.join(', '), optsVisible.length === 5);
  await page.click('#radar-opts-btn');
  await page.waitForTimeout(400);

  check('the options sheet closes again', await page.locator('#radar-opts').isVisible() === false, true);

  // The keyboard route must survive a control moving behind a disclosure.
  await page.keyboard.press('o');
  await page.waitForTimeout(400);
  check('O opens radar options from the keyboard',
    await page.locator('#radar-opts').isVisible(), await page.locator('#radar-opts').isVisible());
  await page.keyboard.press('o');
  await page.waitForTimeout(300);

  // ── The rain answer sits with the temperature ───────────────────────
  await showTab('now');
  await page.waitForTimeout(900);
  const rainLine = await page.evaluate(() => {
    const el = document.getElementById('hero-rain');
    if (!el || el.hidden) return null;
    return { text: el.textContent, top: Math.round(el.getBoundingClientRect().top + window.scrollY) };
  });
  check('the rain answer is in the hero, not a card below it',
    rainLine ? `"${rainLine.text}" at y=${rainLine.top}` : 'absent',
    !!rainLine && /rain|Rain|Raining/.test(rainLine.text) && rainLine.top < 600);

  // It has to agree with the chart it summarises — two numbers that disagree
  // are worse than one number.
  const agree = await page.evaluate(() => {
    const hero = (document.getElementById('hero-rain').textContent || '').toLowerCase();
    const full = (document.getElementById('nowcast-headline').textContent || '').toLowerCase();
    const wet = s => !/no rain/.test(s);
    return { hero, full, same: wet(hero) === wet(full) };
  });
  check('and it agrees with the nowcast it summarises',
    `${agree.hero.slice(0, 28)} | ${agree.full.slice(0, 28)}`, agree.same);

  // ── Glossary ────────────────────────────────────────────────────────
  await showTab('outlook');
  await page.waitForTimeout(1200);
  const glossCount = await page.locator('main .gl-term:visible').count();
  check('jargon is decorated where it appears', glossCount + ' terms marked', glossCount > 0);

  const headingsClean = await page.evaluate(() =>
    document.querySelectorAll('main h1 .gl-term, main h2 .gl-term, main summary .gl-term').length);
  check('but never inside a heading or a control', headingsClean + ' in headings', headingsClean === 0);

  // Every decorated term must resolve — a dotted underline that opens nothing
  // is worse than plain text.
  const resolvable = await page.evaluate(() =>
    Array.from(document.querySelectorAll('main .gl-term'))
      .map(b => b.dataset.term)
      .filter(t => !t || !window.Glossary.get(t)));
  check('every marked term resolves to a definition',
    resolvable.length ? resolvable.join(', ') : 'all resolve', resolvable.length === 0);

  // Visible only: terms on the sections you are not looking at are in the DOM
  // but cannot be pressed, and pressing them is what is under test here.
  const firstTerm = page.locator('main .gl-term:visible').first();
  const termWord = await firstTerm.textContent();
  await firstTerm.click();
  await page.waitForTimeout(400);
  const popped = await page.evaluate(() => {
    const p = document.getElementById('gl-pop');
    if (!p || p.hidden) return null;
    const r = p.getBoundingClientRect();
    return { title: p.querySelector('.gl-pop-title').textContent,
             what: p.querySelector('.gl-pop-what').textContent,
             onScreen: r.left >= 0 && r.right <= window.innerWidth };
  });
  check(`pressing "${termWord}" explains it`,
    popped ? popped.title + ' — ' + popped.what.slice(0, 40) : 'nothing opened',
    !!popped && popped.what.length > 30);
  check('the definition stays inside the viewport',
    popped && popped.onScreen, !!popped && popped.onScreen);

  await page.keyboard.press('Escape');
  await page.waitForTimeout(300);
  check('Escape dismisses it',
    await page.evaluate(() => document.getElementById('gl-pop').hidden), true);

  /* Decoration runs off a MutationObserver, so the thing that would go wrong
   * quietly is accumulation: one more underline on every re-render until the
   * card is a field of dots. Render the same content repeatedly and count. */
  const before = await page.locator('main .gl-term').count();
  await page.evaluate(() => {
    for (let i = 0; i < 5; i++) window.UI.renderOutlook(window.Vane.state);
  });
  await page.waitForTimeout(900);
  const after = await page.locator('main .gl-term').count();
  check('re-rendering does not accumulate underlines',
    `${before} -> ${after}`, after === before);

  // ── Chase parameters fold ───────────────────────────────────────────
  await page.click('.mode-switch button[data-mode="chase"]');
  await page.waitForTimeout(3000);
  await showTab('chase');
  await page.waitForTimeout(1500);
  const split = await page.evaluate(() => ({
    headline: document.querySelectorAll('#params .param').length,
    folded: document.querySelectorAll('#params-rest .param').length,
    readFirst: !!document.querySelector('#params > *:first-child.param-summary')
  }));
  check('the read leads the parameter card, not trails it',
    split.readFirst ? 'summary is first' : 'summary is buried', split.readFirst);
  check('the parameter grid is split, not truncated',
    `${split.headline} shown + ${split.folded} folded`,
    split.headline === 4 && split.folded >= 8);

  await page.setViewportSize({ width: 390, height: 844 });
  await page.waitForTimeout(1200);
  const foldedHeight = await page.evaluate(() => {
    const d = document.querySelector('.param-more');
    return { closed: Math.round(d.getBoundingClientRect().height), open: d.open };
  });
  check('and it is genuinely folded on a phone',
    `${foldedHeight.closed}px closed`,
    !foldedHeight.open && foldedHeight.closed < 90);
  await page.evaluate(() => { document.querySelector('.param-more').open = true; });
  await page.waitForTimeout(500);
  const openedHeight = await page.evaluate(() =>
    Math.round(document.querySelector('.param-more').getBoundingClientRect().height));
  check('opening it reveals every remaining parameter',
    `${openedHeight}px open`, openedHeight > foldedHeight.closed + 200);

  await page.setViewportSize({ width: 1280, height: 1700 });
  await page.waitForTimeout(1200);

  /* The fold has to actually open at desktop width. The stylesheet used to
   * try `display: block !important` on a closed <details>' children, which
   * does nothing — Chrome hides the body with `content-visibility` and no
   * declaration on the children defeats it. That silently emptied the
   * Hodograph and Wind profile cards on every desktop.
   *
   * Measured by painted content, not by a bounding box: the box lies here,
   * which is exactly why the bug survived. */
  const deskFolds = await page.evaluate(() =>
    Array.from(document.querySelectorAll('.phone-fold'))
      .filter(d => d.offsetParent !== null)
      .map(d => {
        const body = d.querySelector(':scope > *:not(summary)');
        return {
          id: d.parentNode.id || d.className,
          open: d.open,
          bodyH: body ? Math.round(body.getBoundingClientRect().height) : 0,
          summaryShown: getComputedStyle(d.querySelector('summary')).display !== 'none'
        };
      }));
  check('folded panels stand open at desktop width',
    deskFolds.map(f => `${f.id} ${f.open ? 'open' : 'CLOSED'} ${f.bodyH}px`).join('; '),
    deskFolds.length >= 2 && deskFolds.every(f => f.open && f.bodyH > 40));
  check('and drop the disclosure control they no longer need',
    deskFolds.filter(f => f.summaryShown).length + ' summaries shown',
    deskFolds.every(f => !f.summaryShown));

  // A panel the user folded stays folded — the viewport does not overrule them.
  await page.evaluate(() => {
    const d = document.querySelector('.phone-fold');
    d.dataset.userSet = '1';
    d.open = false;
  });
  await page.setViewportSize({ width: 390, height: 844 });
  await page.waitForTimeout(700);
  await page.setViewportSize({ width: 1280, height: 1700 });
  await page.waitForTimeout(900);
  check('a panel you folded yourself is not re-opened by a resize',
    await page.evaluate(() => document.querySelector('.phone-fold').open) === false, true);
  await page.evaluate(() => {
    const d = document.querySelector('.phone-fold');
    delete d.dataset.userSet;
    d.open = true;
  });

  await page.click('.mode-switch button[data-mode="simple"]');
  await page.waitForTimeout(1500);


  /* ── The reported bug: it is raining and the app says it is not ──────
   * Open-Meteo's 15-minute precipitation is model output. When it misses a
   * shower, the nowcast used to print "No rain expected in the next 2 hours"
   * to somebody standing in the rain — and a forecast that contradicts the
   * window is not one anybody reads again.
   *
   * Reproduced end to end: the fixture's model stays dry, and the nearest
   * station starts reporting rain. */
  await page.setViewportSize({ width: 1280, height: 1700 });
  await page.waitForTimeout(800);
  await showTab('now');
  await page.waitForTimeout(700);

  const dryFirst = await page.textContent('#nowcast-headline');
  check('with a dry model and a dry station, the forecast stands',
    dryFirst.slice(0, 44), /no rain/i.test(dryFirst));

  stationWx = {
    present: [{ intensity: null, modifier: null, weather: 'rain', rawString: 'RA' }],
    text: 'Rain',
    raw: 'KOUN 131253Z 19014G26KT 4SM RA BKN012 22/21 A2990'
  };
  await page.evaluate(() => window.Vane.load());
  await page.waitForTimeout(3200);

  const wetHead = await page.textContent('#nowcast-headline');
  check('a station reporting rain overrides the model that missed it',
    wetHead, /rain is falling now|raining now/i.test(wetHead));
  check('and the "no rain expected" claim is gone',
    wetHead, !/no rain/i.test(wetHead));

  const heroWet = await page.evaluate(() => {
    const el = document.getElementById('hero-rain');
    return el && !el.hidden ? el.textContent : null;
  });
  check('the hero agrees with it rather than contradicting it',
    heroWet, !!heroWet && !/no rain/i.test(heroWet));

  const note = await page.evaluate(() => {
    const el = document.getElementById('nowcast-observed');
    return el && !el.hidden
      ? { text: el.textContent, conflict: el.classList.contains('conflict') } : null;
  });
  check('the observation is shown, with its station and its age',
    note && note.text.slice(0, 70),
    !!note && /KOUN/.test(note.text) && /min ago|just now/.test(note.text));
  check('and the disagreement is stated, not silently resolved',
    note && note.conflict, !!note && note.conflict &&
    /missed this/i.test(note.text));

  /* Half the card agreeing is worse than none of it. A sun captioned "Clear"
   * beside a line reading "Light rain now" is the same broken promise, moved
   * up one line — so the condition, the icon and the sky follow too. */
  const heroAgrees = await page.evaluate(() => ({
    cond: document.getElementById('now-cond').textContent,
    icon: document.getElementById('now-icon').innerHTML,
    sky: getComputedStyle(document.documentElement).getPropertyValue('--sky-0').trim()
  }));
  check('the hero condition follows the observation, not the model',
    heroAgrees.cond, /rain/i.test(heroAgrees.cond));
  check('and so does the icon',
    heroAgrees.icon.length + ' chars of svg',
    heroAgrees.icon.length > 0 && !/id="sun"|<circle[^>]*r="9"/.test(heroAgrees.icon));

  // Back to a dry report: the override must release, not stick.
  stationWx = { present: [], text: 'Mostly Clear',
                raw: 'KOUN 131253Z 19014G26KT 10SM FEW045 29/19' };
  await page.evaluate(() => window.Vane.load());
  await page.waitForTimeout(3200);
  const backDry = await page.textContent('#nowcast-headline');
  check('a station that clears releases the override',
    backDry.slice(0, 44), /no rain/i.test(backDry));
  check('and the hero goes back to the model condition',
    await page.textContent('#now-cond'),
    !/rain/i.test(await page.textContent('#now-cond')));

  /* Fog is the false positive that would make this a nuisance: BR is present
   * weather, and reading it as precipitation would fire the override on every
   * misty morning. */
  stationWx = {
    present: [{ intensity: null, modifier: null, weather: 'fog_mist', rawString: 'BR' }],
    text: 'Fog/Mist', raw: 'KOUN 131253Z 19014G26KT 3SM BR FEW045 22/21'
  };
  await page.evaluate(() => window.Vane.load());
  await page.waitForTimeout(3200);
  const foggy = await page.textContent('#nowcast-headline');
  check('fog is not rain', foggy.slice(0, 44), /no rain/i.test(foggy));

  stationWx = { present: [], text: 'Mostly Clear',
                raw: 'KOUN 131253Z 19014G26KT 10SM FEW045 29/19' };
  await page.evaluate(() => window.Vane.load());
  await page.waitForTimeout(3000);

  /* ── The photographed contradiction: radar wet, fresh station dry ────
   * "Precipitation is falling now." over a station that reported nothing
   * falling minutes earlier and a dry model. Radar-only rain against a
   * fresh dry report is genuinely ambiguous — the headline must hedge, not
   * assert. Driven by injecting the radar reading directly, because the
   * fixture tiles cannot be made wet over the pin on demand. */
  const hedge = await page.evaluate(() => {
    window.Vane.state.overhead = { dbz: 28, at: Date.now() };
    window.UI.renderNowcast(window.Vane.state);
    const note = document.getElementById('nowcast-observed');
    return {
      head: document.getElementById('nowcast-headline').textContent,
      note: note && !note.hidden ? note.textContent : ''
    };
  });
  check('radar-only rain over a fresh dry station is hedged, not asserted',
    hedge.head.slice(0, 60),
    /radar shows precipitation overhead/i.test(hedge.head) &&
    /station last reported nothing falling/i.test(hedge.head));
  check('and the note explains the ambiguity instead of picking a winner',
    hedge.note.slice(0, 60),
    /may have started since the station reported/i.test(hedge.note) &&
    /evaporating/i.test(hedge.note));
  await page.evaluate(() => {
    window.Vane.state.overhead = null;
    window.UI.renderNowcast(window.Vane.state);
  });

  /* ── VaneMotion smoke: honesty on degenerate input ───────────────────
   * The fixture serves the SAME tile for every mosaic product, so the six
   * sampled frames are identical. Identical frames must never learn a
   * moving echo or fabricate an arrival time: the only honest outcomes are
   * no verdict (blank tiles over the pin) or a stationary fit with no ETA.
   * The real recovery maths runs on synthetic fields in the unit suite. */
  const motion = await page.evaluate(() =>
    window.Motion.learn({
      lat: window.Vane.state.location.lat,
      lon: window.Vane.state.location.lon
    }).then(m => {
      window.Vane.state.motion = m;
      window.UI.renderNowcast(window.Vane.state);
      const box = document.getElementById('nowcast-motion');
      return { m: m, hidden: !box || box.hidden, text: box ? box.textContent : '' };
    }));
  check('identical radar frames never learn a moving echo',
    motion.m ? `stationary=${motion.m.stationary} eta=${JSON.stringify(motion.m.eta)}` : 'no verdict',
    motion.m === null || (motion.m.stationary === true && motion.m.eta === null));
  check('and the motion line is honest: hidden, or stationary with its on-device label',
    motion.hidden ? 'hidden' : motion.text.slice(0, 70),
    motion.hidden
      ? motion.m === null
      : /stationary/i.test(motion.text) &&
        /learned in your browser/i.test(motion.text) &&
        !/reaches you/i.test(motion.text));
  await page.evaluate(() => {
    window.Vane.state.motion = null;
    window.UI.renderNowcast(window.Vane.state);
  });

  /* ── VaneMotion grades its own calls, end to end ─────────────────────
   * Four past arrival calls, and an archived mosaic that turns wet over the
   * pin at chosen moments. The frames are a real 40 dBZ colour from the
   * published ramp, so the grading runs through the same archive fetch and
   * pixel-exact dBZ decode the app uses on live data. Expected: two hits
   * (rain 5 min after the call), one late (25 min after), one miss. */
  const wetPng = Buffer.from(await page.evaluate(() => {
    const c = document.createElement('canvas'); c.width = c.height = 256;
    const x = c.getContext('2d'), col = window.Reflectivity.colourFor(40);
    x.fillStyle = `rgb(${col.r},${col.g},${col.b})`; x.fillRect(0, 0, 256, 256);
    return c.toDataURL('image/png').split(',')[1];
  }), 'base64');
  const base = Math.floor(Date.now() / 300000) * 300000, MINUTE = 60000;
  const wetSpans = [[-270, -260], [-190, -180], [-100, -90]]
    .map(([a, b]) => [base + a * MINUTE, base + b * MINUTE]);
  const archiveHits = [];
  await page.route(u => /USCOMP-N0Q-\d{12}/.test(u.href), r => {
    const s = /USCOMP-N0Q-(\d{4})(\d\d)(\d\d)(\d\d)(\d\d)/.exec(r.request().url());
    const t = Date.UTC(+s[1], +s[2] - 1, +s[3], +s[4], +s[5]);
    archiveHits.push(t);
    const wet = wetSpans.some(([a, b]) => t >= a && t < b);
    r.fulfill({ status: 200, contentType: 'image/png', body: wet ? wetPng : PNG,
                headers: { 'Access-Control-Allow-Origin': '*' } });
  });
  const graded = await page.evaluate(({ base, MINUTE }) => {
    const loc = window.Vane.state.location;
    const call = (issued, lead) => ({ issuedAt: base + issued * MINUTE,
      predictedAt: base + (issued + lead) * MINUTE, leadMin: lead, dbz: 34,
      distanceKm: 18, dir: 'SW', result: null });
    localStorage.setItem('vane.motionskill.v1', JSON.stringify({
      loc: loc.lat.toFixed(2) + ',' + loc.lon.toFixed(2),
      // The fifth is the forecast model's call on the same rain as the
      // first: graded the same way, but never counted as VaneMotion's.
      calls: [call(-300, 25), call(-220, 25), call(-150, 25), call(-80, 25),
              Object.assign(call(-300, 30), { by: 'model' })]
    }));
    return window.MotionSkill.settleDue(loc, { limit: 5 }).then(changed => {
      const s = JSON.parse(localStorage.getItem('vane.motionskill.v1'));
      return { changed, outcomes: s.calls.map(c => c.result && c.result.outcome),
               errors: s.calls.map(c => c.result && c.result.errorMin),
               summary: window.MotionSkill.summary(loc),
               model: window.MotionSkill.skillBy(loc, 'model') };
    });
  }, { base, MINUTE });
  check('VaneMotion grades its past calls against the archived mosaic',
    JSON.stringify({ o: graded.outcomes, e: graded.errors }),
    graded.changed && JSON.stringify(graded.outcomes) === JSON.stringify(['hit', 'hit', 'late', 'miss', 'hit']) &&
    graded.errors[0] === 5 && graded.errors[2] === 25 && graded.errors[4] === 0);
  check('the forecast model\'s calls are graded the same way, but kept apart',
    JSON.stringify({ motionN: graded.summary.n, modelN: graded.model.n }),
    graded.summary.n === 4 && graded.model.n === 1 && graded.model.hits === 1);
  check('and stops reading the archive once rain has arrived',
    archiveHits.length + ' frames read', archiveHits.length > 0 && archiveHits.length < 40);

  const skillShown = await page.evaluate(() => {
    window.Vane.state.motion = {
      stationary: false, overheadNow: false,
      vector: { toward: 'NE', speed: 32, east: 22, north: 22, towardDeg: 45 },
      eta: { minutes: 25, dbz: 34, distanceKm: 18, dir: 'SW' },
      pairs: 5, spanMin: 50, residualKmh: 3
    };
    window.UI.renderNowcast(window.Vane.state);
    window.UI.renderInsight(window.Vane.state);
    const ins = Array.from(document.querySelectorAll('#insight-card .insight-line'))
      .find(li => li.querySelector('.insight-tag').textContent === 'VaneMotion');
    return { motion: document.getElementById('nowcast-motion').textContent,
             insight: ins ? ins.textContent : '' };
  });
  check('the nowcast states its own record, misses included',
    skillShown.motion.slice(-90),
    /2 of 4 arrival calls landed within ±10 min \(1 late, 1 never came\)/.test(skillShown.motion));
  check('and Insight carries the same record beside the call',
    /2 of 4 arrival calls landed/.test(skillShown.insight), true);

  /* Self-calibration, through the real store and renderer: six graded
   * calls where rain came 8 min after the raw fit's time. */
  const calShown = await page.evaluate(() => {
    const loc = window.Vane.state.location, T = Date.now() - 2 * 86400000;
    const calls = [8, 7, 9, 8, 8, 9].map((e, i) => {
      const raw = T + i * 3600000 + 25 * 60000;
      return { issuedAt: raw - 25 * 60000, predictedAt: raw, rawPredictedAt: raw, calMin: 0,
        leadMin: 25, result: { outcome: 'hit', arrivedAt: raw + e * 60000, errorMin: e } };
    });
    localStorage.setItem('vane.motionskill.v1', JSON.stringify({
      loc: loc.lat.toFixed(2) + ',' + loc.lon.toFixed(2), calls }));
    const raw = { stationary: false, overheadNow: false, source: 'nexrad',
      vector: { toward: 'NE', speed: 32, east: 22, north: 22, towardDeg: 45 },
      eta: { minutes: 25, dbz: 34, distanceKm: 18, dir: 'SW' }, pairs: 5, spanMin: 50, residualKmh: 3 };
    const m = window.MotionSkill.calibrate(loc, raw);
    window.Vane.state.motion = m;
    window.UI.renderNowcast(window.Vane.state);
    return { minutes: m.eta.minutes, raw: raw.eta.minutes,
             text: document.getElementById('nowcast-motion').textContent };
  });
  check('VaneMotion applies its learned timing correction, and says so',
    calShown.text.slice(calShown.text.indexOf('reaches'), calShown.text.indexOf('reaches') + 150),
    calShown.raw === 25 && calShown.minutes === 29 &&
    /reaches you in about 29 minutes\. That is 4 min later than the raw fit said/.test(calShown.text) &&
    /over 6 graded calls here/.test(calShown.text));
  await page.unroute(u => /USCOMP-N0Q-\d{12}/.test(u.href));
  await page.evaluate(() => {
    localStorage.removeItem('vane.motionskill.v1');
    window.Vane.state.motion = null;
    window.UI.renderNowcast(window.Vane.state);
    window.UI.renderInsight(window.Vane.state);
  });

  /* ── VaneMotion outside the US, end to end ───────────────────────────
   * London, on RainViewer. Six frames ten minutes apart, the newest eight
   * minutes old, drawn in RainViewer's published Universal Blue colours
   * with an echo stepping east toward the pin — served as real tiles at
   * the real tile coordinates, so the fit runs through the same stitching,
   * readback and Universal Blue decode as on live data. */
  const LONDON = { lat: 51.5, lon: -0.12 };
  const rvNow = Date.now(), rvLatest = Math.floor((rvNow - 8 * 60000) / 600000) * 600000;
  const rvFrames = [0, 1, 2, 3, 4, 5].map(k => ({
    t: rvLatest - (5 - k) * 600000,
    url: 'https://tilecache.rainviewer.com/v2/radar/vanetest' + k + '/256/{z}/{x}/{y}/2/0_0.png'
  }));
  const rvTiles = await page.evaluate(({ pin, frames }) => {
    const R = window.Reflectivity, z = 7, out = {};
    const px = R.lonToTileX(pin.lon, z) * 256, py = R.latToTileY(pin.lat, z) * 256;
    const rings = [[12, 25], [8, 35], [4, 45]].map(([r, d]) => [r, R.colourForRainViewer(d)]);
    frames.forEach((f, k) => {
      const cx = px - 60 + 7 * k, cy = py;              // 7 px (~5 km) east per frame
      for (let tx = Math.floor((px - 120) / 256); tx <= Math.floor((px + 120) / 256); tx++) {
        for (let ty = Math.floor((py - 120) / 256); ty <= Math.floor((py + 120) / 256); ty++) {
          const c = document.createElement('canvas'); c.width = c.height = 256;
          const g = c.getContext('2d');
          rings.forEach(([r, col]) => {
            g.fillStyle = `rgb(${col.r},${col.g},${col.b})`;
            g.beginPath(); g.arc(cx - tx * 256, cy - ty * 256, r, 0, 2 * Math.PI); g.fill();
          });
          out['vanetest' + k + '/256/' + z + '/' + tx + '/' + ty] = c.toDataURL('image/png').split(',')[1];
        }
      }
    });
    return out;
  }, { pin: LONDON, frames: rvFrames });
  const rvHits = [];
  await page.route(u => /\/v2\/radar\/vanetest/.test(u.href), r => {
    const m = /(vanetest\d\/256\/\d+\/\d+\/\d+)\//.exec(r.request().url());
    rvHits.push(r.request().url());
    const b64 = m && rvTiles[m[1]];
    r.fulfill({ status: 200, contentType: 'image/png', body: b64 ? Buffer.from(b64, 'base64') : PNG,
                headers: { 'Access-Control-Allow-Origin': '*' } });
  });
  const rv = await page.evaluate(({ pin, frames }) =>
    window.Motion.learn({ lat: pin.lat, lon: pin.lon, frames }).then(m => {
      const st = window.Vane.state, keep = st.motion;
      st.motion = m;
      window.UI.renderNowcast(st);
      const text = document.getElementById('nowcast-motion').textContent;
      st.motion = keep;
      window.UI.renderNowcast(st);
      return { m, text };
    }), { pin: LONDON, frames: rvFrames });
  check('VaneMotion learns motion from RainViewer frames outside the US',
    rv.m ? `${rv.m.source} → ${rv.m.vector.toward} ${rv.m.vector.speed} km/h, resid ${rv.m.residualKmh}` : 'no verdict',
    !!rv.m && rv.m.source === 'rainviewer' && rv.m.vector.toward === 'E' &&
    Math.abs(rv.m.vector.speed - 32) <= 6 && rv.m.residualKmh <= 3);
  check('its zoom stays inside RainViewer\'s free cache (7 and below)',
    rvHits.length + ' tiles', rvHits.length > 0 && rvHits.every(u => /\/256\/7\//.test(u)));
  check('and the arrival call is counted from now, not from the 8-minute-old frame',
    rv.m && rv.m.eta ? `${rv.m.eta.minutes} min, frame ${Math.round((rvNow - rv.m.observedAt) / 60000)} min old` : 'no eta',
    !!(rv.m && rv.m.eta) && rv.m.observedAt === rvLatest && rv.m.eta.minutes < 20);
  check('the motion line names RainViewer as the source',
    rv.text.slice(-90), /RainViewer's global radar composite/.test(rv.text));

  /* Coverage: a blank tile over a place with no radar is not clear sky. */
  const blackPng = Buffer.from(await page.evaluate(() => {
    const c = document.createElement('canvas'); c.width = c.height = 256;
    const x = c.getContext('2d'); x.fillStyle = '#000'; x.fillRect(0, 0, 256, 256);
    return c.toDataURL('image/png').split(',')[1];
  }), 'base64');
  let covered = true;
  await page.route(u => /\/v2\/coverage\//.test(u.href), r =>
    r.fulfill({ status: 200, contentType: 'image/png', body: covered ? PNG : blackPng,
                headers: { 'Access-Control-Allow-Origin': '*' } }));
  const kinshasa = { lat: -4.3, lon: 15.3 };
  const srcCovered = await page.evaluate(loc => { Reflectivity.clearCache(); return Vane.radarSource(loc); }, LONDON);
  covered = false;
  const srcNone = await page.evaluate(loc => { Reflectivity.clearCache(); return Vane.radarSource(loc); }, kinshasa);
  const srcUs = await page.evaluate(() => Vane.radarSource({ lat: 35.47, lon: -97.5 }));
  check('radar source: NEXRAD at home, RainViewer where it sees, none where nothing does',
    [srcUs && srcUs.kind, srcCovered && srcCovered.kind, srcNone && srcNone.kind].join(' / '),
    srcUs.kind === 'nexrad' && srcCovered.kind === 'rainviewer' && srcCovered.frames.length > 0 &&
    srcNone.kind === 'none');
  const noRadar = await page.evaluate(() => {
    const st = window.Vane.state;
    st.radarCoverage = false; st.motion = null;
    window.UI.renderNowcast(st);
    const box = document.getElementById('nowcast-motion');
    const out = { hidden: box.hidden, text: box.textContent };
    st.radarCoverage = null;
    window.UI.renderNowcast(st);
    return out;
  });
  check('with no radar, the nowcast says so instead of reporting clear sky',
    noRadar.text.slice(0, 70),
    !noRadar.hidden && /No public weather radar covers this location/.test(noRadar.text));
  await page.unroute(u => /\/v2\/radar\/vanetest/.test(u.href));
  await page.unroute(u => /\/v2\/coverage\//.test(u.href));

  /* ── Notifications: location, motion and outlook ─────────────────────
   * "I need vane to give me notifications based on my location or outlook."
   * Everything is opt-in, deduped, and fired through one door that also
   * works on Android (SW showNotification there; the constructor here,
   * because this suite runs without a service worker). */
  const inboundFit = {
    stationary: false,
    vector: { toward: 'NE', speed: 32, east: 22, north: 22, towardDeg: 45 },
    eta: { minutes: 25, dbz: 34, distanceKm: 18, dir: 'SW' },
    overheadNow: false, pairs: 5, spanMin: 50, residualKmh: 3
  };
  const rainOff = await page.evaluate(fit => {
    window.__notifs.length = 0;
    localStorage.removeItem('vane.notified.rain.v1');
    window.Settings.save({ notifyRain: false });
    window.Settings.notifyMotion(fit);
    return window.__notifs.length;
  }, inboundFit);
  check('rain heads-up is opt-in: silent until switched on', rainOff, rainOff === 0);

  const rain = await page.evaluate(fit => {
    window.Settings.save({ notifyRain: true });
    window.Settings.notifyMotion(fit);
    const first = window.__notifs.slice();
    window.Settings.notifyMotion(fit);        // same approach, minutes later
    return { first, total: window.__notifs.length };
  }, inboundFit);
  check('an inbound echo becomes one notification with the evidence in it',
    rain.first.length && rain.first[0].title,
    rain.first.length === 1 &&
    /Rain in about 25 minutes/.test(rain.first[0].title) &&
    /34 dBZ/.test(rain.first[0].body) &&
    /Learned in your browser/.test(rain.first[0].body));
  check('and the same approach never becomes a drumbeat',
    rain.total + ' total', rain.total === 1);

  const outlook = await page.evaluate(() => {
    window.__notifs.length = 0;
    localStorage.removeItem('vane.notified.spc.v1');
    window.Settings.save({ notifyOutlook: true });
    window.Settings.notifyOutlook(1, { rank: 4, label: 'Enhanced' });
    window.Settings.notifyOutlook(1, { rank: 4, label: 'Enhanced' });   // same again
    window.Settings.notifyOutlook(1, { rank: 5, label: 'Moderate' });   // upgrade
    window.Settings.notifyOutlook(2, { rank: 2, label: 'Marginal' });   // below floor
    return window.__notifs.slice();
  });
  check('the SPC outlook notifies once, again only on upgrade, never below Slight',
    outlook.map(n => n.title).join(' | '),
    outlook.length === 2 &&
    /Day 1: Enhanced/.test(outlook[0].title) &&
    /Day 1: Moderate/.test(outlook[1].title));

  /* ── Notifications that learn (js/notifylearn.js) ────────────────────
   * Five rain heads-ups swiped away unread: the sixth must wait for heavier
   * rain, closer in — and Settings must say so, and undo it. */
  const learned = await page.evaluate(fit => {
    NotifyLearn.reset();
    window.__notifs.length = 0; window.__notifObjs.length = 0;
    Settings.save({ notifyRain: true });
    for (let i = 0; i < 5; i++) {
      localStorage.removeItem('vane.notified.rain.v1');
      Settings.notifyMotion(fit);
      window.__notifObjs[window.__notifObjs.length - 1].onclose();   // swiped away
    }
    const kinds = window.__notifs.map(n => n.kind);
    const quiet = NotifyLearn.policyFor('rain').quiet;
    localStorage.removeItem('vane.notified.rain.v1');
    const before = window.__notifs.length;
    Settings.notifyMotion(fit);                                       // 25 min, 34 dBZ
    const sixth = window.__notifs.length - before;
    UI.renderSettings(() => {});
    const text = document.getElementById('settings-body').textContent;
    const back = Array.from(document.querySelectorAll('#settings-body button'))
      .find(b => b.textContent === 'Back to normal');
    back.click();
    const after = NotifyLearn.policyFor('rain');
    return { kinds, quiet, sixth, text, after };
  }, inboundFit);
  check('every notification carries its kind for learning', learned.kinds.join(','),
    learned.kinds.length === 5 && learned.kinds.every(k => k === 'rain'));
  check('five unread rain heads-ups make the next light, distant one wait', JSON.stringify({ q: learned.quiet, sixth: learned.sixth }),
    learned.quiet && learned.sixth === 0);
  check('Settings says what was learned, with the numbers',
    learned.text.slice(learned.text.indexOf('Rain heads-ups'), learned.text.indexOf('Rain heads-ups') + 130),
    /Rain heads-ups: opened 0 of 5\. You rarely open these, so they now fire only for rain of 35 dBZ or more within 20 minutes/.test(learned.text));
  check('and "Back to normal" undoes it for good', JSON.stringify(learned.after),
    learned.after.quiet === false && learned.after.pinned === true);

  // Official alerts: a family dismissed again and again is only suggested,
  // and muting it still lets an Extreme alert through.
  const alertLearn = await page.evaluate(() => {
    NotifyLearn.reset();
    window.__notifs.length = 0; window.__notifObjs.length = 0;
    Settings.save({ notify: true, notifyMinSeverity: 'Severe' });
    const flood = i => ({ id: 'fl' + i + Math.random(), event: 'Flood Warning', headline: 'Flood Warning', severity: 'Severe' });
    for (let i = 0; i < 6; i++) {
      Settings.notifyNew([flood(i)]);
      window.__notifObjs[window.__notifObjs.length - 1].onclose();
    }
    const stillNotified = (() => { const b = window.__notifs.length; Settings.notifyNew([flood(99)]); return window.__notifs.length - b; })();
    UI.renderSettings(() => {});
    const offer = Array.from(document.querySelectorAll('#settings-body button'))
      .find(b => /Stop notifying for Flood/.test(b.textContent));
    const offered = !!offer;
    if (offer) offer.click();
    const b0 = window.__notifs.length;
    Settings.notifyNew([flood(100)]);
    const severeAfterMute = window.__notifs.length - b0;
    Settings.notifyNew([{ id: 'x' + Math.random(), event: 'Flash Flood Emergency', headline: 'Flash Flood Emergency', severity: 'Extreme' }]);
    const extremeAfterMute = window.__notifs.length - b0 - severeAfterMute;
    const kind = window.__notifs[0].kind;
    NotifyLearn.reset();
    return { stillNotified, offered, severeAfterMute, extremeAfterMute, kind };
  });
  check('a dismissed alert family keeps notifying until the user decides', alertLearn.stillNotified + ' shown',
    alertLearn.stillNotified === 1 && alertLearn.kind === 'alert:flood');
  check('Settings offers to mute it, with the evidence', String(alertLearn.offered), alertLearn.offered);
  check('muted, a Severe flood alert stays quiet but an Extreme one still comes through',
    JSON.stringify({ severe: alertLearn.severeAfterMute, extreme: alertLearn.extremeAfterMute }),
    alertLearn.severeAfterMute === 0 && alertLearn.extremeAfterMute === 1);

  // Taps and swipes the service worker handled while the page was closed.
  const drained = await page.evaluate(() => {
    NotifyLearn.reset();
    return caches.open('vane-watch').then(c => c.put('./notify-log', new Response(JSON.stringify(
      [0, 1, 2, 3, 4].map(i => ({ kind: 'spc', action: 'dismiss', t: i }))))))
      .then(() => NotifyLearn.drainSW())
      .then(n => caches.open('vane-watch').then(c => c.match('./notify-log'))
        .then(left => ({ n, quiet: NotifyLearn.policyFor('spc').quiet, left: !!left })))
      .then(r => { NotifyLearn.reset(); return r; });
  });
  check('outcomes the service worker logged are learned from on the next open',
    JSON.stringify(drained), drained.n === 5 && drained.quiet && !drained.left);

  const watchBlob = await page.evaluate(() =>
    window.Settings.syncWatch(
      { lat: 35.47, lon: -97.52, name: 'Oklahoma City' },
      [{ id: 'a1' }, { id: 'a2' }]
    ).then(() => caches.open('vane-watch'))
     .then(c => c.match('/watch-state'))
     .then(hit => hit ? hit.json() : null));
  check('the background watch state mirrors location, floor and seen alerts',
    JSON.stringify(watchBlob && { lat: watchBlob.lat, floor: watchBlob.floor, seen: watchBlob.seen }),
    !!watchBlob && watchBlob.lat === 35.47 && watchBlob.floor >= 3 &&
    watchBlob.seen.length === 2 && watchBlob.name === 'Oklahoma City');

  await page.evaluate(() => {
    window.Settings.save({ notifyRain: false, notifyOutlook: false });
    localStorage.removeItem('vane.notified.rain.v1');
    localStorage.removeItem('vane.notified.spc.v1');
    window.__notifs.length = 0;
  });

  /* ── Settings say they save ──────────────────────────────────────────
   * "I have no way to save settings": changes always committed instantly,
   * but the sheet never said so and its only button read Close. Now it
   * announces autosave, flashes Saved ✓ on every change, and says Done. */
  await page.click('#settings-btn');
  await page.waitForTimeout(500);
  check('the settings sheet says changes save themselves',
    await page.locator('.settings-autosave').textContent(),
    /saves the moment you change it/i.test(await page.locator('.settings-autosave').textContent()));
  check('and its button promises Done, not discard',
    await page.locator('#settings-close').textContent(),
    (await page.locator('#settings-close').textContent()).trim() === 'Done');
  const savedFlash = await page.evaluate(() => {
    const rows = Array.from(document.querySelectorAll('#settings-body .settings-row'));
    const r = rows.find(x => /Keep screen awake/.test(x.textContent));
    r.querySelector('input').click();
    const shown = !document.getElementById('settings-saved').hidden;
    r.querySelector('input').click();          // put it back
    return { shown, text: document.getElementById('settings-saved').textContent };
  });
  check('flipping a toggle flashes the proof it stuck',
    JSON.stringify(savedFlash), savedFlash.shown && /Saved/.test(savedFlash.text));
  const persisted = await page.evaluate(() => {
    window.Settings.save({ hour12: false });
    // read back through a fresh load from storage, not the in-memory object
    return JSON.parse(localStorage.getItem('vane.settings.v1')).hour12;
  });
  check('and the change is in storage the moment it is made',
    'hour12=' + persisted, persisted === false);
  await page.evaluate(() => window.Settings.save({ hour12: true }));
  await page.click('#settings-close');
  await page.waitForTimeout(300);

  /* ── The local scorecard: on-device model verification ──────────────
   * Rendered from seeded history first (ranking, best-first, honest
   * labelling), then the full settle cycle against a routed day of METARs. */
  const seededBoard = await page.evaluate(() => {
    const results = [];
    for (let i = 0; i < 4; i++) {
      results.push({ date: '2026-09-1' + (5 + i), station: 'KOUN', obsHi: 33, obsLo: 22, n: 24,
        err: { gfs_seamless: { hi: 2, lo: 1 }, ecmwf_ifs025: { hi: 0.8, lo: 0.6 } } });
    }
    localStorage.setItem('vane.scorecard.v1', JSON.stringify(
      { loc: window.Vane.state.location.lat.toFixed(2) + ',' + window.Vane.state.location.lon.toFixed(2),
        pending: {}, results }));
    window.UI.renderModels(window.Vane.state);
    const rows = Array.from(document.querySelectorAll('#scorecard .scorecard-row'));
    return {
      names: rows.map(r => r.querySelector('.scorecard-name').textContent),
      bestFirst: rows.length && rows[0].classList.contains('best'),
      note: document.querySelector('#scorecard .scorecard-note').textContent
    };
  });
  check('the scorecard ranks the agencies by measured error, best first',
    seededBoard.names.join(' > '),
    seededBoard.names[0] === 'ECMWF' && seededBoard.names[1] === 'GFS' && seededBoard.bestFirst);
  check('and owns up to being a local, on-device verification',
    seededBoard.note.slice(0, 70),
    /KOUN/.test(seededBoard.note) && /on this device/i.test(seededBoard.note) &&
    /day-ahead/i.test(seededBoard.note));

  // A routed day of real-shaped METARs: max 33 °C, min 22 °C, 24 readings.
  await page.route('**/stations/KOUN/observations?start=**', r => {
    const features = [];
    for (let h = 0; h < 24; h++) {
      features.push({ properties: { temperature: { value: 22 + 11 * Math.sin(Math.PI * h / 23) } } });
    }
    features[12].properties.temperature.value = 33;   // the true high
    features[0].properties.temperature.value = 22;    // the true low
    r.fulfill(json(JSON.stringify({ features })));
  });
  const settled = await page.evaluate(() => {
    const key = 'vane.scorecard.v1';
    const store = JSON.parse(localStorage.getItem(key));
    const past = new Date(Date.now() - 2 * 86400000).toISOString().slice(0, 10);
    store.pending[past] = { off: 0, models: {
      gfs_seamless: { hi: 35, lo: 24 }, ecmwf_ifs025: { hi: 32.5, lo: 21.5 }
    } };
    localStorage.setItem(key, JSON.stringify(store));
    return window.Verify.settle(window.Vane.state.location, { station: 'KOUN' })
      .then(changed => {
        const after = JSON.parse(localStorage.getItem(key));
        const r = after.results[after.results.length - 1];
        return { changed, days: after.results.length,
                 gfsHi: r.err.gfs_seamless.hi, ecmwfHi: r.err.ecmwf_ifs025.hi,
                 pendingLeft: Object.keys(after.pending).length };
      });
  });
  check('a finished day settles the bet against the station thermometer',
    JSON.stringify(settled),
    settled.changed === true && settled.days === 5 && settled.pendingLeft === 0 &&
    settled.gfsHi === 2 && Math.abs(settled.ecmwfHi - (-0.5)) < 1e-9);

  /* ── The microclimate correction ─────────────────────────────────────
   * The learned lean of the displayed forecast at this exact spot, offered
   * under the week card next to the official numbers — never silently
   * applied — and "running true" said out loud when there is no lean. */
  const microNote = await page.evaluate(() => {
    const key = 'vane.scorecard.v1';
    const store = JSON.parse(localStorage.getItem(key));
    store.results.forEach(r => { r.blendErr = { hi: 2, lo: -1 }; });
    store.results.push({ date: '2026-09-19', station: 'KOUN', obsHi: 33, obsLo: 22,
      n: 24, err: {}, blendErr: { hi: 2, lo: -1 } });
    localStorage.setItem(key, JSON.stringify(store));
    window.UI.renderDaily(window.Vane.state);
    const el = document.getElementById('microclimate');
    return el.hidden ? null : el.textContent;
  });
  check('a persistent lean becomes an offered correction, evidence attached',
    (microNote || '').slice(0, 76),
    !!microNote && /warm on highs/.test(microNote) && /cool on lows/.test(microNote) &&
    /KOUN/.test(microNote) && /reads closer to/.test(microNote) &&
    /Learned on this device/.test(microNote));
  const microOfficial = await page.evaluate(() => {
    // The official numbers stay untouched: the correction is offered beside
    // them, and the day rows still show the model's own figures.
    const d = window.Vane.state.data.daily;
    const shown = document.querySelector('#daily .day .day-hi').textContent;
    const official = Math.round(d.temperature_2m_max[0] * 9 / 5 + 32) + '°';
    return { shown, official };
  });
  check('while the official forecast stays exactly what the model said',
    JSON.stringify(microOfficial), microOfficial.shown === microOfficial.official);

  const microTrue = await page.evaluate(() => {
    const key = 'vane.scorecard.v1';
    const store = JSON.parse(localStorage.getItem(key));
    store.results.forEach((r, i) => { r.blendErr = { hi: i % 2 ? 0.4 : -0.4, lo: 0.2 }; });
    localStorage.setItem(key, JSON.stringify(store));
    window.UI.renderDaily(window.Vane.state);
    return document.getElementById('microclimate').textContent;
  });
  check('and a forecast running true is praised, not "corrected"',
    microTrue.slice(0, 60),
    /running true/.test(microTrue) && /Nothing to correct/.test(microTrue));

  /* Weather-aware: cloudy days here run 3° warm on highs, clear days true.
   * On a cloudy day the card must say so, and say the test it passed. */
  const microRegime = await page.evaluate(() => {
    const key = 'vane.scorecard.v1';
    const store = JSON.parse(localStorage.getItem(key));
    const base = store.results[0];
    store.results = [];
    for (let i = 0; i < 16; i++) {
      const cloudy = i % 2 === 0, wob = (i % 3 - 1) * 0.3;
      store.results.push(Object.assign({}, base, { date: '2026-09-' + String(i + 1).padStart(2, '0'),
        blendErr: { hi: (cloudy ? 3 : 0) + wob, lo: 0.6 - wob },
        regime: { sky: cloudy ? 'cloudy' : 'clear', wind: 'south' } }));
    }
    localStorage.setItem(key, JSON.stringify(store));
    const d = window.Vane.state.data.daily;
    const keep = [d.cloud_cover_mean, d.wind_direction_10m_dominant];
    d.cloud_cover_mean = d.time.map(() => 92);
    d.wind_direction_10m_dominant = d.time.map(() => 180);
    window.UI.renderDaily(window.Vane.state);
    const text = document.getElementById('microclimate').textContent;
    d.cloud_cover_mean = keep[0]; d.wind_direction_10m_dominant = keep[1];
    window.UI.renderDaily(window.Vane.state);
    return text;
  });
  check('on a cloudy day the correction knows cloudy days run warm here, and shows its test',
    microRegime.slice(microRegime.indexOf('On cloudy'), microRegime.indexOf('On cloudy') + 120),
    /On cloudy days like today it leans further: highs \d\.\d° warmer/.test(microRegime) &&
    /Weather-aware: tested day by day on the 16 verified days here, it cut the typical miss from \d\.\d° to \d\.\d°/.test(microRegime));

  await page.evaluate(() => {
    localStorage.removeItem('vane.scorecard.v1');
    window.UI.renderModels(window.Vane.state);
    window.UI.renderDaily(window.Vane.state);
  });

  /* ── Rain chances, calibrated against the station ────────────────────
   * Forty past hours recorded at 60%, then the station archive answers:
   * rain was reported in 10 of them. Through the real fetch, CSV parse,
   * binning, journal table and Insight line. */
  const rcBase = Math.floor((Date.now() - 3 * 86400000) / 3600000) * 3600000;
  await page.route(u => /cgi-bin\/request\/asos\.py/.test(u.href) && /data=wxcodes/.test(u.href), r => {
    const rows = ['station,valid,wxcodes,p01m'];
    for (let i = 0; i < 40; i++) {
      const t = new Date(rcBase + i * 3600000 + 55 * 60000).toISOString().slice(0, 16).replace('T', ' ');
      rows.push('OUN,' + t + ',' + (i % 4 === 0 ? '-RA' : (i % 4 === 1 ? 'VCSH' : 'M')) + ',0.00');
    }
    r.fulfill({ status: 200, contentType: 'text/plain', body: rows.join('\n'),
                headers: { 'Access-Control-Allow-Origin': '*' } });
  });
  const rc = await page.evaluate(base => {
    const loc = Vane.state.location, pending = {};
    for (let i = 0; i < 40; i++) pending[base + i * 3600000] = 60;
    localStorage.setItem('vane.raincal.v1', JSON.stringify({
      loc: loc.lat.toFixed(2) + ',' + loc.lon.toFixed(2), pending, bins: [], hours: 0, station: null }));
    return RainCal.settle(loc, { station: 'KOUN' }).then(changed => {
      const sum = RainCal.summary(loc);
      // A forecast hour at 60% within the next day, so Insight has a chance to speak to.
      const h = Vane.state.data.hourly, keep = h.precipitation_probability.slice();
      for (let i = 0; i < h.precipitation_probability.length; i++) h.precipitation_probability[i] = 10;
      const idx = h.time.findIndex(t => U.epochOf(t, Vane.state.data.utc_offset_seconds) > Date.now() + 3 * 3600000);
      h.precipitation_probability[idx] = 60;
      UI.renderInsight(Vane.state);
      const line = Array.from(document.querySelectorAll('#insight-card .insight-line'))
        .find(li => li.querySelector('.insight-tag').textContent === 'Rain chances');
      h.precipitation_probability.splice(0, keep.length, ...keep);
      return { changed, sum, insight: line ? line.textContent : '' };
    });
  }, rcBase);
  check('rain chances are verified hour by hour against the station archive',
    JSON.stringify({ c: rc.changed, h: rc.sum.hours, rows: rc.sum.rows.map(r => r.lo + ':' + r.wet + '/' + r.n) }),
    rc.changed && rc.sum.hours === 40 && rc.sum.rows.length === 1 && rc.sum.rows[0].wet === 10 &&
    rc.sum.rows[0].observed === 25 && rc.sum.station === 'KOUN');
  check('Insight offers what a 60% chance has meant here, with its evidence',
    rc.insight.slice(0, 120),
    /gives 60% around/.test(rc.insight) && /only seen rain 32% of the time/.test(rc.insight) &&
    /40 hours checked against KOUN/.test(rc.insight));
  await showTab('outlook');
  const rcJournal = await page.evaluate(() => {
    DecisionUI.render(Vane.state);
    return document.getElementById('decision-journal').textContent;
  });
  check('the accountability card shows the reliability table',
    rcJournal.slice(rcJournal.indexOf('Rain chances'), rcJournal.indexOf('Rain chances') + 160),
    /Rain chances: 40 hours verified/.test(rcJournal) && /60–69%25%40/.test(rcJournal) &&
    /"in the vicinity" does not/.test(rcJournal));
  await page.unroute(u => /cgi-bin\/request\/asos\.py/.test(u.href) && /data=wxcodes/.test(u.href));
  await page.evaluate(() => localStorage.removeItem('vane.raincal.v1'));
  await showTab('now');


  /* ── Installed on a phone: the status bar must not eat the search ────
   * `black-translucent` + viewport-fit=cover runs the page under the iOS
   * status bar so the sky gradient can reach the top of the screen. The
   * shipped app paid for that without reserving the inset: the search field
   * rendered underneath the clock, and on a phone that is the only way to
   * change location. Reported from a real iPhone, reproduced here with
   * Chromium's safe-area emulation so env() resolves to real numbers. */
  await page.setViewportSize({ width: 390, height: 844 });
  await page.waitForTimeout(700);
  const cdp = await ctx.newCDPSession(page);
  const setInsets = (top, right, bottom, left) =>
    cdp.send('Emulation.setSafeAreaInsetsOverride', { insets: { top, right, bottom, left } });

  await setInsets(59, 0, 34, 0);           // iPhone 15-class portrait
  await page.waitForTimeout(500);

  const notchPortrait = await page.evaluate(() => {
    const search = document.getElementById('search-input').getBoundingClientRect();
    const tabBtn = document.querySelector('.tabbar button').getBoundingClientRect();
    return { searchTop: Math.round(search.top), searchH: Math.round(search.height),
             tabBottom: Math.round(tabBtn.bottom) };
  });
  check('the search field clears the iOS status bar',
    `top at ${notchPortrait.searchTop}px vs a 59px inset`,
    notchPortrait.searchTop >= 59 && notchPortrait.searchH > 20);
  check('and the tab bar clears the home indicator',
    `buttons end at ${notchPortrait.tabBottom}px of ${844 - 34}px usable`,
    notchPortrait.tabBottom <= 844 - 34 + 1);

  // Landscape: the notch moves to the side, the dash-mount case from F8.
  await page.setViewportSize({ width: 844, height: 390 });
  await setInsets(0, 59, 21, 59);
  await page.waitForTimeout(700);
  const notchLandscape = await page.evaluate(() => {
    const search = document.getElementById('search-input').getBoundingClientRect();
    const card = document.querySelector('main > section.card').getBoundingClientRect();
    return { searchLeft: Math.round(search.left), cardLeft: Math.round(card.left) };
  });
  check('landscape keeps the search out from under the notch',
    `search at x=${notchLandscape.searchLeft}`, notchLandscape.searchLeft >= 59);
  check('and cards stay inside the display corners',
    `card at x=${notchLandscape.cardLeft}`, notchLandscape.cardLeft >= 59);

  // Cleared insets must fall back to the plain padding — the fix has to be
  // env(), not a hardcoded 59px that would indent every ordinary browser.
  await setInsets(0, 0, 0, 0);
  await page.setViewportSize({ width: 390, height: 844 });
  await page.waitForTimeout(700);
  const flat = await page.evaluate(() =>
    Math.round(document.getElementById('search-input').getBoundingClientRect().top));
  check('without insets the padding falls back to normal',
    `search top at ${flat}px`, flat < 30);

  /* Two desktop regressions this uncovered, both in the sticky machinery.
   *
   * First: `html, body { height: 100% }` capped the body at one viewport
   * tall, and a sticky element only sticks within its parent — so the topbar
   * (and the search field in it) rode off screen after one screen of
   * scrolling. That is the same "cannot change location" failure as the
   * status-bar bug, reached by scrolling instead of installing.
   *
   * Second: both bars were sticky at `top: 0`, and the section nav slid
   * behind the taller, higher-z topbar on the first scroll — navigation
   * hidden exactly when someone reaches for it. */
  await page.setViewportSize({ width: 1280, height: 900 });
  await page.waitForTimeout(700);
  await page.evaluate(() => window.scrollTo(0, 900));
  await page.waitForTimeout(500);
  const stuck = await page.evaluate(() => {
    const bar = document.querySelector('.topbar').getBoundingClientRect();
    const tab = document.querySelector('.tabbar').getBoundingClientRect();
    const search = document.getElementById('search-input').getBoundingClientRect();
    return { scrollY: Math.round(window.scrollY),
             topbarTop: Math.round(bar.top), topbarBottom: Math.round(bar.bottom),
             tabTop: Math.round(tab.top), searchVisible: search.top >= 0 && search.height > 0 };
  });
  check('the header stays pinned a full screen down the page',
    `topbar at y=${stuck.topbarTop} after scrolling ${stuck.scrollY}px`,
    stuck.topbarTop === 0 && stuck.topbarBottom > 40);
  check('so the search field is still reachable while scrolled',
    stuck.searchVisible, stuck.searchVisible);
  check('and the section nav sits below the header, not behind it',
    `nav top ${stuck.tabTop}px vs header bottom ${stuck.topbarBottom}px`,
    stuck.tabTop >= stuck.topbarBottom);
  await page.evaluate(() => window.scrollTo(0, 0));
  await page.waitForTimeout(400);






  /* ── The options sheet has a way out, and the map has layer switches ──
   * Photographed from a phone: the Options sheet open, the button that
   * closes it scrolled away with the card header, and no other exit — a
   * panel with no visible way out is a trap. */
  await page.setViewportSize({ width: 390, height: 844 });
  await page.waitForTimeout(1000);
  await showTab('radar');
  await page.waitForTimeout(800);
  await page.click('#radar-opts-btn');
  await page.waitForTimeout(500);
  check('the options sheet opens with a Done button on a phone',
    await page.locator('#radar-opts-done').isVisible(),
    await page.locator('#radar-opts-done').isVisible());
  await page.click('#radar-opts-done');
  await page.waitForTimeout(400);
  check('and Done actually closes it',
    await page.locator('#radar-opts').isVisible() === false, true);
  await page.setViewportSize({ width: 1280, height: 1700 });
  await page.waitForTimeout(900);
  await showTab('radar');
  await page.waitForTimeout(600);
  await page.click('#radar-opts-btn');
  await page.waitForTimeout(400);
  await page.keyboard.press('Escape');
  await page.waitForTimeout(300);
  check('Escape closes it on a keyboard',
    await page.locator('#radar-opts').isVisible() === false, true);

  /* Layer switches: warnings off must remove the polygons from the map —
   * genuinely, so a tornado warning is one tap from coming back and the
   * chip can never lie about what is drawn. */
  await page.evaluate(() => window.Vane.setMode('chase'));
  await page.waitForTimeout(2500);
  await showTab('radar');
  await page.waitForTimeout(800);
  const warnCount = () => page.evaluate(() => {
    let n = 0;
    window.Radar.getMap().eachLayer(l => {
      if (l.feature && l.feature.properties && l.feature.properties.event) n++;
    });
    return n;
  });
  const warnsBefore = await warnCount();
  check('warnings are on the map to begin with', warnsBefore + ' polygons', warnsBefore > 0);
  await page.click('#radar-opts-btn');
  await page.waitForTimeout(400);
  await page.click('#chip-warnings');
  await page.waitForTimeout(400);
  check('the warnings chip removes them', (await warnCount()) + ' after toggle',
    (await warnCount()) === 0);
  await page.click('#chip-warnings');
  await page.waitForTimeout(400);
  check('and brings them back', (await warnCount()) + ' restored', (await warnCount()) > 0);

  // The cells chip and the cells-card checkbox are the same switch.
  await page.click('#chip-cells');
  await page.waitForTimeout(500);
  check('the cells chip unchecks the cells-card box too',
    await page.evaluate(() => document.getElementById('cells-on-map').checked),
    (await page.evaluate(() => document.getElementById('cells-on-map').checked)) === false);
  await page.click('#chip-cells');
  await page.waitForTimeout(400);

  /* ── Future radar: HRRR simulated reflectivity ───────────────────────
   * The Forecast regime owns the whole track: ninety leads across the full
   * slider width, real WMS imagery per lead, honest chrome throughout. */
  await showTab('radar');
  await page.waitForTimeout(500);
  check('the Live track spans exactly the observed hour',
    await page.evaluate(() => +document.getElementById('radar-frame').max),
    (await page.evaluate(() => +document.getElementById('radar-frame').max)) === 11);
  const leadScrub = async (idx) => {
    await page.evaluate(v => {
      const s = document.getElementById('radar-frame');
      s.value = String(v);
      s.dispatchEvent(new Event('input', { bubbles: true }));
    }, idx);
  };
  await page.click('#mode-forecast');
  await page.waitForTimeout(900);
  check('the Forecast track spans all ninety leads',
    await page.evaluate(() => +document.getElementById('radar-frame').max),
    (await page.evaluate(() => +document.getElementById('radar-frame').max)) === 89);
  await leadScrub(23);                       // +360 min
  await page.waitForTimeout(900);
  check('scrubbing the forecast track lands on its lead',
    await page.evaluate(() => window.Radar.futureShowing()),
    (await page.evaluate(() => window.Radar.futureShowing())) === 360);
  check('as real WMS imagery, not a repainted canvas',
    hrrrTileHits.length + ' tile requests',
    hrrrTileHits.some(u => u.includes('refd_0360')));
  const frBadge = await page.textContent('#fr-badge');
  check('the badge names the model and the lead', frBadge, /HRRR \+6h/.test(frBadge));
  check('and what the colours are', frBadge, /simulated reflectivity — forecast/.test(frBadge));
  const frKind = await page.evaluate(() => ({
    text: document.getElementById('radar-kind').textContent,
    cls: document.getElementById('radar-kind').className,
    clock: document.getElementById('radar-time').textContent
  }));
  check('the timeline tag flips to FORECAST with a real valid time',
    JSON.stringify(frKind),
    frKind.text === 'forecast' && /tag-forecast/.test(frKind.cls) &&
    frKind.clock.length > 1 && frKind.clock !== '—');

  /* "The forecast radar is not smooth": advancing the lead used to discard
   * every visible tile before the next lead's had arrived, so each step
   * blanked the map for a WMS round-trip. Double-buffered now — the old
   * frame must hold the screen while the next loads, then hand over. The
   * WMS route is slowed to a realistic latency so the transition window is
   * actually open when we look. */
  const visibleWms = () => page.evaluate(() => {
    const out = [];
    document.querySelectorAll('.leaflet-tile-pane .leaflet-layer').forEach(l => {
      const op = parseFloat(l.style.opacity || '1');
      if (op < 0.05) return;
      l.querySelectorAll('img.leaflet-tile-loaded').forEach(img => {
        if (/cgi-bin\/wms\/hrrr/.test(img.src)) out.push(img.src);
      });
    });
    return out;
  });
  await page.waitForTimeout(800);                  // let +6h finish swapping in
  hrrrDelayMs = 1500;
  await leadScrub(24);                             // +375 min, tiles now slow
  await page.waitForTimeout(700);                  // inside the loading window
  const held = await visibleWms();
  check('the last frame holds the screen while the next lead loads',
    held.length + ' tiles still visible mid-load',
    held.length > 0 && held.every(u => u.includes('refd_0360')));
  hrrrDelayMs = 0;
  await page.waitForTimeout(2600);
  const took = await visibleWms();
  check('and the new lead takes over once its tiles arrive',
    took.length + ' tiles of ' + (took[0] || '').replace(/^.*layers=/, '').slice(0, 9),
    took.length > 0 && took.every(u => u.includes('refd_0375')));
  check('with a bounded pair of forecast layers, not one per lead',
    await page.evaluate(() => {
      let n = 0;
      window.Radar.getMap().eachLayer(l => {
        if (l.options && l.options.layers && /^refd_/.test(l.options.layers)) n++;
      });
      return n;
    }), (await page.evaluate(() => {
      let n = 0;
      window.Radar.getMap().eachLayer(l => {
        if (l.options && l.options.layers && /^refd_/.test(l.options.layers)) n++;
      });
      return n;
    })) <= 2);

  await page.click('#mode-live');
  await page.waitForTimeout(600);
  const backState2 = await page.evaluate(() => ({
    future: window.Radar.futureShowing(),
    badge: document.getElementById('fr-badge').hidden,
    max: +document.getElementById('radar-frame').max
  }));
  check('Live restores observed radar and its track',
    JSON.stringify(backState2),
    backState2.future === null && backState2.badge === true && backState2.max === 11);

  /* ── Zoom suspension ─────────────────────────────────────────────────
   * "When I zoom in on the radar the app crashes": all twelve mounted
   * frames refetched a viewport of tiles on every zoom step — measured at
   * ~48 requests per step on a phone viewport — and iOS killed the page.
   * During a zoom only the visible frame may stay mounted; afterwards the
   * rest return one at a time; and a scrub mid-suspension mounts its
   * frame on demand rather than waiting its turn. */
  const zoomSusp = await page.evaluate(() => new Promise(resolve => {
    const mesonetLayers = () => {
      let n = 0;
      window.Radar.getMap().eachLayer(l => { if (l._url && /mesonet/.test(l._url)) n++; });
      return n;
    };
    const before = mesonetLayers();
    window.Radar.getMap().once('zoomstart', () => {
      const during = mesonetLayers();
      window.Radar.goto(2);                       // scrub while suspended
      const scrubbed = mesonetLayers();
      setTimeout(() => resolve({ before, during, scrubbed, after: mesonetLayers() }), 3500);
    });
    window.Radar.getMap().zoomIn();
  }));
  // 12 observed frames plus the two HRRR WMS buffers = 14 mesonet layers.
  check('a zoom unmounts every hidden radar frame for the gesture',
    JSON.stringify(zoomSusp),
    zoomSusp.before >= 12 && zoomSusp.during <= 2);
  check('a scrub during the gesture mounts its frame on demand',
    zoomSusp.scrubbed + ' mounted after scrub', zoomSusp.scrubbed >= zoomSusp.during);
  check('and the whole loop is quietly re-armed once the zoom settles',
    zoomSusp.after + ' of ' + zoomSusp.before + ' back', zoomSusp.after === zoomSusp.before);
  await page.evaluate(() => window.Radar.getMap().zoomOut());
  await page.waitForTimeout(4000);

  /* Play crosses now on a deliberate press, and the track re-scopes with
   * the regime as the loop travels. */
  await leadScrub(11);                       // the newest observed frame
  await page.waitForTimeout(400);
  await page.click('#radar-play');
  await page.waitForTimeout(2000);
  const crossed = await page.evaluate(() => ({
    future: window.Radar.futureShowing(),
    max: +document.getElementById('radar-frame').max
  }));
  check('a playing loop crosses now into the forecast',
    JSON.stringify(crossed), crossed.future !== null && crossed.max === 89);
  await page.evaluate(() => window.Radar.pause());
  await page.click('#mode-forecast');
  await page.waitForTimeout(600);
  await leadScrub(5);                        // +90 min, between play stops
  await page.waitForTimeout(500);
  await page.click('#radar-play');
  await page.waitForTimeout(2400);
  const playedTo = await page.evaluate(() => window.Radar.futureShowing());
  check('Play pressed in the future continues deeper into it',
    '+' + playedTo + ' min', playedTo > 90);
  await page.evaluate(() => window.Radar.pause());
  await page.click('#mode-live');
  await page.waitForTimeout(600);

  await setSource('global');
  const globalSeg = await page.evaluate(() =>
    document.getElementById('mode-forecast').disabled);
  check('the global source disables the Forecast regime', globalSeg, globalSeg === true);
  await setSource('nexrad');
  await page.waitForTimeout(800);

  /* ── History · Live · Forecast ───────────────────────────────────────
   * "Make it so I can select between forecast radar and current and
   * historical." One segmented control, three regimes; IEM archives the
   * national mosaic by the five-minute stamp, so History replays any
   * past hour with the same scrubber and loop as the live one. */
  const segState = () => page.evaluate(() => ({
    history: document.getElementById('mode-history').classList.contains('on'),
    live: document.getElementById('mode-live').classList.contains('on'),
    forecast: document.getElementById('mode-forecast').classList.contains('on'),
    kind: document.getElementById('radar-kind').textContent,
    max: +document.getElementById('radar-frame').max
  }));
  check('the timeline offers all three regimes',
    await page.evaluate(() => document.querySelectorAll('#radar-mode button').length),
    (await page.evaluate(() => document.querySelectorAll('#radar-mode button').length)) === 3);
  check('and starts in Live', JSON.stringify(await segState()), (await segState()).live);

  await page.click('#mode-forecast');
  await page.waitForTimeout(900);
  check('Forecast jumps the thumb to the first HRRR lead',
    await page.evaluate(() => window.Radar.futureShowing()),
    (await page.evaluate(() => window.Radar.futureShowing())) === 15);
  check('and the segment follows', JSON.stringify(await segState()), (await segState()).forecast);

  await page.click('#mode-history');
  await page.waitForTimeout(400);
  check('History opens the archive picker',
    await page.locator('#history-bar').isVisible(), true);
  await page.fill('#history-when', '2026-08-15T13:15');
  await page.evaluate(() => document.getElementById('history-when')
    .dispatchEvent(new Event('change', { bubbles: true })));
  await page.waitForTimeout(900);
  const hist = await segState();
  check('an archived hour replays: twelve frames, no future half',
    JSON.stringify(hist), hist.history && hist.max === 11);
  check('tagged as archive, dated on the clock',
    await page.textContent('#radar-time'),
    hist.kind === 'archive' && /Aug|Jan|Feb|Mar|Apr|May|Jun|Jul|Sep|Oct|Nov|Dec/
      .test(await page.textContent('#radar-time')));
  check('the frames are stamped mosaic layers',
    await page.evaluate(() => window.Radar.historyShowing() > 0), true);

  // A fresh scan arriving cannot update the past out from under the viewer.
  mosaicValidTime = '2026-08-14T15:25:00Z';
  await page.evaluate(() => document.dispatchEvent(new Event('visibilitychange')));
  await page.waitForTimeout(1500);
  check('a new live scan leaves the archive alone',
    (await segState()).kind, (await segState()).kind === 'archive');

  /* "The historic radar is showing forecast": Play was pressed earlier in
   * this run, which arms the observed loop to cross into the HRRR future —
   * and that arming used to survive into History, so a played archived
   * hour ran off its twelfth frame into TODAY'S forecast. The archive must
   * loop inside its own hour, forever. */
  await page.click('#radar-play');
  await page.waitForTimeout(8000);                 // 12 frames and then some
  const histLoop = await segState();
  const histFuture = await page.evaluate(() => window.Radar.futureShowing());
  await page.click('#radar-play');
  await page.waitForTimeout(300);
  check('a played archive loops its own hour, never today\'s forecast',
    JSON.stringify({ kind: histLoop.kind, future: histFuture, max: histLoop.max }),
    histLoop.kind === 'archive' && histFuture === null && histLoop.max === 11);

  await page.click('#mode-live');
  await page.waitForTimeout(700);
  const backLive = await segState();
  check('Live returns to the present on its own full-width track',
    JSON.stringify(backLive),
    backLive.live && backLive.kind === 'observed' && backLive.max === 11);

  await openRadarOpts();

  // Every chip, not just the two that happened to be convenient: the SPC
  // chip shipped calling a function that did not exist, and threw on every
  // tap — invisible to a suite that never tapped it.
  await page.click('#chip-spc');
  await page.waitForTimeout(400);
  const spcOff = await page.evaluate(() => ({
    chip: document.getElementById('chip-spc').classList.contains('on'),
    setting: window.Settings.get('showSpc')
  }));
  check('the SPC chip actually toggles', JSON.stringify(spcOff),
    spcOff.chip === false && spcOff.setting === false);
  await page.click('#chip-spc');
  await page.waitForTimeout(300);
  await page.click('#chip-reports');
  await page.waitForTimeout(400);
  const repOff = await page.evaluate(() => window.Settings.get('showReports'));
  check('and so does the reports chip', 'showReports=' + repOff, repOff === false);
  await page.click('#chip-reports');
  await page.waitForTimeout(300);

  /* On a phone the map eats every drag, so controls that scroll away are
   * gone for good — the radar's control row must stay pinned. And leaving
   * Chase must take the chase-only drawings with it: a user photographed
   * Simple mode still wearing SPC outlines and mesoscale boxes with no
   * controls left to remove them. */
  await page.setViewportSize({ width: 390, height: 844 });
  await page.waitForTimeout(1000);
  await showTab('radar');
  await page.waitForTimeout(800);
  await page.evaluate(() => window.scrollTo(0, 600));
  await page.waitForTimeout(500);
  const stickyHead = await page.evaluate(() => {
    const r = document.querySelector('#radar-card .card-head').getBoundingClientRect();
    const tb = document.querySelector('.topbar').getBoundingClientRect();
    return { top: Math.round(r.top), tbBottom: Math.round(tb.bottom),
             visible: r.top >= 0 && r.top < 400 && r.height > 0 };
  });
  check('the radar controls stay pinned below the topbar while scrolled',
    `controls at y=${stickyHead.top}, topbar ends ${stickyHead.tbBottom}`,
    stickyHead.visible && stickyHead.top >= stickyHead.tbBottom - 2);
  await page.evaluate(() => window.scrollTo(0, 0));
  await page.setViewportSize({ width: 1280, height: 1700 });
  await page.waitForTimeout(900);
  await showTab('radar');
  await page.waitForTimeout(500);

  const spcOnMap = () => page.evaluate(() => {
    let n = 0;
    window.Radar.getMap().eachLayer(l => {
      if (l.feature && l.feature.properties && l.feature.properties.DN !== undefined) n++;
    });
    return n;
  });
  const spcInChase = await spcOnMap();
  check('SPC outlines are on the map in Chase', spcInChase + ' outline layers', spcInChase > 0);
  await page.evaluate(() => window.Vane.setMode('simple'));
  await page.waitForTimeout(1500);
  check('leaving Chase takes them with it', (await spcOnMap()) + ' remain', (await spcOnMap()) === 0);
  await page.evaluate(() => window.Vane.setMode('chase'));
  await page.waitForTimeout(2500);
  check('and returning redraws them', (await spcOnMap()) + ' redrawn', (await spcOnMap()) > 0);
  await page.evaluate(() => window.Vane.setMode('simple'));
  await page.waitForTimeout(1500);
  await showTab('now');
  await page.waitForTimeout(500);

  /* ── The wrong date, end to end ──────────────────────────────────────
   * Every weekday in the 7-day card ran one day behind: a date-only string
   * parsed as UTC midnight is the previous evening in every US timezone.
   * Asserted against the ISO dates themselves, so the check cannot share
   * the bug with the code it guards. */
  await showTab('now');
  await page.waitForTimeout(800);
  const dayLabels = await page.evaluate(() => {
    const isos = window.Vane.state.data.daily.time.slice(0, 7);
    const names = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];
    return Array.from(document.querySelectorAll('#daily .day-name')).map((el, i) => {
      const m = isos[i].match(/^(\d{4})-(\d{2})-(\d{2})/);
      const want = names[new Date(+m[1], +m[2] - 1, +m[3]).getDay()] + ' ' + (+m[3]);
      return { got: el.textContent, want: i === 0 ? 'Today' : want };
    });
  });
  check('every 7-day row is captioned with its own weekday',
    dayLabels.map(d => d.got).join(', '),
    dayLabels.length === 7 && dayLabels.every(d => d.got === d.want));

  /* ── Model forecasts: GFS, Euro, and five more, each by name ────────── */
  await showTab('outlook');
  await page.waitForTimeout(1000);
  check('the model viewer renders',
    await page.locator('#modelcast-card').isVisible(),
    await page.locator('#modelcast-card').isVisible());
  const chipCount = await page.locator('#mc-chips .mc-chip').count();
  check('one chip per agency plus All', chipCount + ' chips', chipCount === 8);
  const allLines = await page.locator('#mc-chart .mc-hi').count();
  check('the overlay draws every agency\'s run', allLines + ' high lines', allLines === 7);

  await page.locator('#mc-chips .mc-chip', { hasText: 'GFS' }).click();
  await page.waitForTimeout(500);
  const gfsRows = await page.locator('#mc-strip .mc-day').count();
  check('focusing GFS opens its ten-day strip', gfsRows + ' rows', gfsRows === 10);
  const gfsHi = await page.locator('#mc-strip .mc-day-hi').first().textContent();
  check('with real temperatures in display units', gfsHi, /^\d+°$/.test(gfsHi));
  const focusDrawn = await page.evaluate(() => ({
    focus: document.querySelectorAll('#mc-chart .mc-focus').length,
    dim: document.querySelectorAll('#mc-chart .mc-dim').length
  }));
  check('the focused run comes forward, the rest recede',
    `${focusDrawn.focus} focused, ${focusDrawn.dim} dimmed`,
    focusDrawn.focus === 1 && focusDrawn.dim === 6);

  await page.locator('#mc-chips .mc-chip', { hasText: 'ARPEGE' }).click();
  await page.waitForTimeout(500);
  const arpRows = await page.locator('#mc-strip .mc-day').count();
  const horizonNote = await page.locator('.mc-horizon').textContent().catch(() => '');
  check('a short-horizon model shows only its real days',
    arpRows + ' rows for ARPEGE', arpRows === 4);
  check('and says where its horizon ends instead of padding',
    horizonNote.slice(0, 60), /publishes 4 days/.test(horizonNote));

  await page.locator('#mc-chips .mc-chip', { hasText: 'All' }).click();
  await page.waitForTimeout(400);
  check('All collapses the strip back to the overlay',
    await page.locator('#mc-strip').isVisible() === false, true);

  /* ── Model charts: the classic synoptic frame ────────────────────────
   * "All the weather models should look like this" — a Tropical Tidbits
   * screenshot. The card renders the same grammar from the agency's grid:
   * greens for precip, isobars every 4 hPa, H and L where the pressure
   * field actually turns. The fixture plants a deep low with a rain
   * shield, so all three must be on the canvas. */
  check('the model chart card is on the page',
    await page.locator('#mchart-card').isVisible(), true);
  const chartPx = await page.evaluate(() => {
    const cv = document.getElementById('mchart-canvas');
    const g = cv.getContext('2d');
    const img = g.getImageData(0, 0, cv.width, cv.height).data;
    let green = 0, dark = 0, paper = 0;
    for (let i = 0; i < img.length; i += 16) {
      const r = img[i], gg = img[i + 1], b = img[i + 2];
      if (gg > r + 20 && gg > b + 20) green++;
      else if (r < 90 && gg < 90 && b < 90) dark++;
      else if (r > 230 && gg > 230) paper++;
    }
    return { green, dark, paper };
  });
  check('rain shades green, isobars draw dark, on chart paper',
    JSON.stringify(chartPx),
    chartPx.green > 200 && chartPx.dark > 100 && chartPx.paper > 1000);
  const chartTitle = await page.textContent('#mchart-title');
  check('the frame is titled with model, lead and valid time', chartTitle,
    /GFS · \+\d+h · valid/.test(chartTitle));
  await page.click('#mchart-next');
  await page.waitForTimeout(300);
  const stepped = await page.textContent('#mchart-title');
  check('the arrow steps one forecast hour', stepped,
    stepped !== chartTitle && /\+\d+h/.test(stepped));
  /* "I can't find the models on mobile" — the card sat below the full
   * forecaster's discussion, and a single dropped request out of nine at
   * boot hid it entirely with no second chance. It leads the section now,
   * and opening Outlook reloads a chart that has no data. */
  const chartAbove = await page.evaluate(() => {
    const chart = document.getElementById('mchart-card');
    const afd = document.getElementById('afd-card');
    return chart.compareDocumentPosition(afd) & Node.DOCUMENT_POSITION_FOLLOWING ? 'leads' : 'trails';
  });
  check('the chart leads the Outlook section', chartAbove, chartAbove === 'leads');
  await page.evaluate(() => {
    window.ModelChart.state.rows = [];
    window.ModelChart.state.id = null;
    document.getElementById('mchart-card').hidden = true;
  });
  await showTab('now');
  await page.waitForTimeout(400);
  await showTab('outlook');
  await page.waitForTimeout(1500);
  check('a boot-time load failure heals on opening Outlook',
    await page.locator('#mchart-card').isVisible(), true);

  /* The API answers a burst with HTTP 429 (photographed in the field, and
   * it starved the sounding). getJSON itself now retries 429s patiently,
   * for every caller — two rate-limited chunks must delay the chart by
   * seconds, not kill it. */
  expect429 = true;
  // The healing test's load may still be in flight; the deliberate 429s
  // must hit THIS load, not whichever request happens along next.
  await page.waitForFunction(() => !window.ModelChart.state.loading);
  await page.evaluate(() => {
    window.ModelChart.state.rows = [];
    window.ModelChart.state.id = null;
    document.getElementById('mchart-card').hidden = true;
  });
  modelChart429s = 2;
  await showTab('now');
  await page.waitForTimeout(300);
  await showTab('outlook');
  await page.waitForTimeout(12000);        // both 429'd chunks retry after 8 s
  expect429 = false;
  check('a rate-limited chunk retries instead of killing the chart',
    'rows=' + await page.evaluate(() => window.ModelChart.state.rows.length),
    (await page.evaluate(() => window.ModelChart.state.rows.length)) === 2880);
  check('and the card recovered', await page.locator('#mchart-card').isVisible(), true);
  modelChart429s = 0;                       // nothing deliberate left over
  await page.waitForFunction(() => !window.ModelChart.state.loading);

  const chartHitsBefore = modelChartHits;
  await page.click('#mchart-chips .mc-chip:nth-child(1)');   // ECMWF; GFS is the default
  // Nine chunks through three lanes: poll for the retitle instead of racing it.
  let retitled = '';
  for (let t = 0; t < 20; t++) {
    await page.waitForTimeout(400);
    retitled = await page.textContent('#mchart-title');
    if (/ECMWF/.test(retitled)) break;
  }
  check('picking another agency fetches its run',
    (modelChartHits - chartHitsBefore) + ' row-band fetches',
    modelChartHits - chartHitsBefore === 9);
  check('and retitles the frame', retitled, /ECMWF/.test(retitled));
  await page.click('#mchart-chips .mc-chip:nth-child(6)');   // HRRR
  let hrrrTitle = '';
  for (let t = 0; t < 20; t++) {
    await page.waitForTimeout(400);
    hrrrTitle = await page.textContent('#mchart-title');
    if (/HRRR/.test(hrrrTitle)) break;
  }
  check('HRRR charts alongside the global agencies', hrrrTitle, /HRRR/.test(hrrrTitle));
  await page.click('#mchart-chips .mc-chip:nth-child(2)');
  await page.waitForTimeout(800);
  await showTab('now');
  await page.waitForTimeout(500);

  /* ── Warning popups survive the tap that opens them ──────────────────
   * Reported from a phone: tap a warning polygon and the popup opens and
   * closes in the same gesture. Two bugs stacked. First, the polygons were
   * usually not there at all: setPolygons culled against map.getBounds()
   * while the radar section was display:none, where a zero-size map's
   * bounds intersect nothing — every warning silently dropped. Second, a
   * tap on a canvas layer arrives twice (pointer, then the synthesized
   * mouse click ~10ms later) and Leaflet's popup toggle read the pair as
   * open-then-close. A mouse sends one click, which is how both shipped. */
  await page.evaluate(() => window.Vane.setMode('chase'));
  await page.waitForTimeout(2500);
  await showTab('radar');
  await page.waitForTimeout(1500);

  const polyCount = await page.evaluate(() => {
    let n = 0;
    window.Radar.getMap().eachLayer(l => { if (l.feature) n++; });
    return n;
  });
  check('warning polygons exist on a map that loaded while hidden',
    polyCount + ' polygon layer(s)', polyCount > 0);

  const polyPt = await page.evaluate(() => {
    const m = window.Radar.getMap();
    m.setView([35.5, -97.45], 8, { animate: false });
    return true;
  });
  await page.waitForTimeout(900);
  const clickAt = await page.evaluate(() => {
    const m = window.Radar.getMap();
    const c = m.latLngToContainerPoint([35.5, -97.45]);
    const r = document.getElementById('map').getBoundingClientRect();
    return { x: r.left + c.x, y: r.top + c.y };
  });
  await page.mouse.click(clickAt.x, clickAt.y);
  await page.waitForTimeout(250);
  check('tapping a warning opens its popup',
    (await page.locator('.leaflet-popup').count()) + ' popup',
    (await page.locator('.leaflet-popup').count()) === 1);

  /* The touch ghost, synthesized directly: on a phone the browser follows
   * the tap with a second click on the same layer ~10ms later, which
   * Leaflet's stock toggle read as "close" — the reported bug. Fired here
   * inside the guard window, it must be ignored. */
  const ghostSurvived = await page.evaluate(() => {
    const m = window.Radar.getMap();
    // The warning layer specifically: SPC outlook polygons are features too.
    let poly = null;
    m.eachLayer(l => {
      if (!poly && l.feature && l.feature.properties && l.feature.properties.event) poly = l;
    });
    poly.fire('click', { latlng: L.latLng(35.5, -97.45) }, true);   // the ghost
    return document.querySelectorAll('.leaflet-popup').length === 1;
  });
  check('the synthesized ghost click cannot close it', ghostSurvived, ghostSurvived);

  await page.waitForTimeout(800);
  check('and the popup is still open a second later',
    (await page.locator('.leaflet-popup').count()) + ' popup',
    (await page.locator('.leaflet-popup').count()) === 1);

  // A genuine second tap, outside the guard window, still toggles it away.
  await page.mouse.click(clickAt.x, clickAt.y);
  await page.waitForTimeout(400);
  check('a deliberate second tap still dismisses it',
    (await page.locator('.leaflet-popup').count()) + ' popups',
    (await page.locator('.leaflet-popup').count()) === 0);

  /* ── Radars are pickable on the map itself ───────────────────────────
   * In single-site mode every WSR-88D is a dot coloured by live status;
   * tapping one switches to it. On the mosaic they are absent — 159 dots
   * over a national composite would explain nothing. */
  await openSitePanel();
  await page.fill('#site-search', 'KTLX');
  await page.waitForTimeout(600);
  await page.locator('#site-list .site-row').first().click();
  await page.waitForTimeout(1500);

  const dotCount = await page.evaluate(() => {
    let n = 0;
    window.Radar.getMap().eachLayer(l => {
      if (l.options && l.options.pane === 'features' && l.getTooltip && l.getTooltip()) n++;
    });
    return n;
  });
  check('single-site mode shows every other radar as a dot',
    dotCount + ' site dots', dotCount > 100);

  await page.evaluate(() => {
    const m = window.Radar.getMap();
    const s = window.Sites.state.sites.find(x => x.id === 'KVNX');
    m.setView([s.lat, s.lon], 7, { animate: false });
  });
  await page.waitForTimeout(900);
  const dotAt = await page.evaluate(() => {
    const m = window.Radar.getMap();
    const s = window.Sites.state.sites.find(x => x.id === 'KVNX');
    const c = m.latLngToContainerPoint([s.lat, s.lon]);
    const r = document.getElementById('map').getBoundingClientRect();
    return { x: r.left + c.x, y: r.top + c.y };
  });
  await page.mouse.click(dotAt.x, dotAt.y);
  await page.waitForTimeout(1200);
  check('tapping a dot switches to that radar',
    await page.evaluate(() => window.Radar.getSite().id),
    (await page.evaluate(() => window.Radar.getSite().id)) === 'KVNX');
  check('and the header follows',
    await page.textContent('#site-btn'),
    /^KVNX\b/.test(await page.textContent('#site-btn')));

  await setSource('nexrad');
  const mosaicDots = await page.evaluate(() => {
    let n = 0;
    window.Radar.getMap().eachLayer(l => {
      if (l.options && l.options.pane === 'features' && l.getTooltip && l.getTooltip()) n++;
    });
    return n;
  });
  check('the mosaic carries no site dots', mosaicDots + ' dots', mosaicDots === 0);

  await page.evaluate(() => window.Vane.setMode('simple'));
  await page.waitForTimeout(1500);
  await showTab('now');
  await page.waitForTimeout(600);

  /* ── Live radar: new scans arrive on their own ───────────────────────
   * The mosaic regenerates every ~5 minutes and the app used to learn about
   * it at the next full data refresh — up to ten minutes of stale "latest".
   * The watcher polls a tiny valid-time signal and rebuilds tiles only when
   * it changes. A synthetic visibilitychange is the test's poll trigger: the
   * watcher probes immediately on returning to the app. */
  await showTab('radar');
  await page.waitForTimeout(1200);
  // Tiles are images, or canvases when the clutter filter composites them
  // (they carry the raw frame's URL as data-src).
  const radarSrcs = () => page.evaluate(() =>
    Array.from(document.querySelectorAll('#map .leaflet-radar-pane img, #map .leaflet-radar-pane canvas[data-src]'))
      .slice(0, 4).map(i => i.src || i.getAttribute('data-src')));

  // First probe primes the watcher; nothing may rebuild for data it has.
  await page.evaluate(() => document.dispatchEvent(new Event('visibilitychange')));
  await page.waitForTimeout(900);
  const primedSrcs = await radarSrcs();
  await page.evaluate(() => document.dispatchEvent(new Event('visibilitychange')));
  await page.waitForTimeout(900);
  const unchangedSrcs = await radarSrcs();
  check('an unchanged composite re-fetches no tiles',
    unchangedSrcs.length + ' tiles, untouched',
    unchangedSrcs.length > 0 && unchangedSrcs.join() === primedSrcs.join());

  // The mosaic publishes a new valid time: every frame layer rebuilds with a
  // fresh cache-busting generation, without user action.
  mosaicValidTime = '2026-08-14T15:05:00Z';
  await page.evaluate(() => document.dispatchEvent(new Event('visibilitychange')));
  await page.waitForTimeout(1600);
  const freshSrcs = await radarSrcs();
  check('a new composite refreshes the radar by itself',
    freshSrcs[0] ? freshSrcs[0].slice(-24) : 'no tiles',
    freshSrcs.length > 0 && /_g=\d+/.test(freshSrcs[0]) &&
      freshSrcs.join() !== unchangedSrcs.join());

  /* Des Moines, 9:44 PM: the map speckled with "rain" — wind farms and
   * migrating birds — under a sky every station around reported CLEAR.
   * Each frame is now masked by NOAA's quality-controlled MRMS composite at
   * the same time; where MRMS sees nothing, nothing is drawn. */
  maskBlank = true;
  await page.evaluate(() => { Radar.setClean(false); Radar.setClean(true); });
  await page.waitForTimeout(2500);
  const visibleRadar = () => page.evaluate(() => {
    const layers = Array.from(document.querySelectorAll('#map .leaflet-radar-pane .leaflet-layer'))
      .filter(l => +getComputedStyle(l).opacity > 0);
    let canvases = 0, painted = 0, imgs = 0;
    layers.forEach(l => {
      l.querySelectorAll('canvas').forEach(c => { canvases++;
        const d = c.getContext('2d').getImageData(0, 0, c.width, c.height).data;
        for (let i = 3; i < d.length; i += 4) if (d[i]) painted++; });
      imgs += l.querySelectorAll('img').length;
    });
    return { canvases, painted, imgs, clean: Radar.cleanOn(),
      note: (document.querySelector('.legend-note') || {}).textContent || '' };
  });
  const clearSky = await visibleRadar();
  check('under a clear sky the mosaic draws no clutter: MRMS sees nothing, so nothing is drawn',
    JSON.stringify({ canvases: clearSky.canvases, painted: clearSky.painted }),
    clearSky.clean && clearSky.canvases > 0 && clearSky.painted === 0 && /filtered out \(NOAA MRMS/.test(clearSky.note));
  await page.evaluate(() => document.getElementById('chip-clean').click());
  await page.waitForTimeout(2000);
  const rawView = await visibleRadar();
  check('and "Filter clutter" off shows the raw mosaic, for the chaser reading fine lines',
    JSON.stringify({ imgs: rawView.imgs, clean: rawView.clean, saved: await page.evaluate(() => Settings.get('radarClean')) }),
    !rawView.clean && rawView.imgs > 0 && rawView.canvases === 0 && /unfiltered/.test(rawView.note) &&
    await page.evaluate(() => Settings.get('radarClean') === false));
  await page.evaluate(() => document.getElementById('chip-clean').click());
  maskBlank = false;
  await page.waitForTimeout(1500);
  const frameMax = await page.getAttribute('#radar-frame', 'max');
  check('and the hour of history is still twelve frames', frameMax, frameMax === '11');

  // A viewer who scrubbed back chose a moment; a refresh must not steal it.
  await page.evaluate(() => window.Radar.goto(4));
  mosaicValidTime = '2026-08-14T15:10:00Z';
  await page.evaluate(() => document.dispatchEvent(new Event('visibilitychange')));
  await page.waitForTimeout(1600);
  check('a refresh preserves a scrubbed position',
    'frame ' + await page.evaluate(() => window.Radar.frameIndex()),
    (await page.evaluate(() => window.Radar.frameIndex())) === 4);

  // A playing loop keeps playing through the swap.
  await page.evaluate(() => window.Radar.play());
  mosaicValidTime = '2026-08-14T15:15:00Z';
  await page.evaluate(() => document.dispatchEvent(new Event('visibilitychange')));
  await page.waitForTimeout(1600);
  check('a playing loop survives the refresh',
    await page.evaluate(() => window.Radar.isPlaying()),
    await page.evaluate(() => window.Radar.isPlaying()));
  await page.evaluate(() => window.Radar.pause());
  await showTab('now');
  await page.waitForTimeout(600);

  /* The service-worker checks — the update rollout and real notifications —
   * live in test/sw.js. They wait on Chrome's own worker-lifecycle clock,
   * and a timeout there used to throw from here and hide the report for
   * every other check in this file. Run: node test/sw.js */

  // ── Report ───────────────────────────────────────────────────────────
  console.log('\n' + '─'.repeat(74));
  let pass = 0, fail = 0;
  checks.forEach(c => {
    const mark = c.pass ? '\x1b[32m✓\x1b[0m' : '\x1b[31m✗\x1b[0m';
    c.pass ? pass++ : fail++;
    console.log(`${mark} ${c.name.padEnd(44)} ${String(c.actual).slice(0, 60)}`);
  });
  console.log('─'.repeat(74));
  console.log(`${pass} passed, ${fail} failed`);
  console.log('\nconsole errors:', errors.length ? errors.slice(0, 8).join(' | ') : 'none');

  await browser.close();
  process.exit(fail ? 1 : 0);
})();
