/* Regression: a deployment must replace a warm HTTP cache in the new shell. */
'use strict';
const assert = require('assert/strict');
const fs = require('fs');
const path = require('path');
const vm = require('vm');
const root = path.join(__dirname, '..');
const origin = 'https://vane.test/';
const handlers = {}, shells = new Map(), requests = [];
const state = { skipped: false, claimed: false };
shells.set('vane-v37-shell', new Map());
shells.set('vane-watch', new Map([['/watch-state', 'saved alert preferences']]));
const context = {
  URL, Promise,
  Request: class extends Request {
    constructor(url, options) { super(new URL(url, origin), options); }
  },
  self: {
    location: { origin: origin.slice(0, -1) },
    addEventListener: (name, fn) => { handlers[name] = fn; },
    skipWaiting: async () => { state.skipped = true; },
    clients: { claim: async () => { state.claimed = true; } }
  },
  caches: {
    keys: async () => [...shells.keys()],
    delete: async key => shells.delete(key),
    open: async key => {
      if (!shells.has(key)) shells.set(key, new Map());
      return {
        add: async input => {
          const req = input instanceof Request ? input : new Request(new URL(input, origin));
          requests.push(req);
          const file = new URL(req.url).pathname.replace(/^\//, '') || 'index.html';
          // Simulated browser HTTP cache: all unversioned assets still have
          // old, fresh entries until this request explicitly revalidates.
          const bytes = ['reload', 'no-cache', 'no-store'].includes(req.cache)
            ? fs.readFileSync(path.join(root, file)) : Buffer.from('previous release');
          shells.get(key).set(file, bytes);
        }
      };
    }
  }
};
vm.runInNewContext(fs.readFileSync(path.join(root, 'sw.js'), 'utf8'), context);
(async () => {
  let job;
  handlers.install({ waitUntil: promise => { job = promise; } });
  await job;
  const newest = [...shells.keys()].find(k => k.endsWith('-shell') && k !== 'vane-v37-shell');
  for (const file of ['index.html', 'css/style.css', 'js/app.js', 'js/intelligence-ui.js']) {
    assert.deepEqual(shells.get(newest).get(file), fs.readFileSync(path.join(root, file)), file + ' must be from the current release');
  }
  assert.ok(state.skipped);
  handlers.activate({ waitUntil: promise => { job = promise; } });
  await job;
  assert.equal(shells.has('vane-v37-shell'), false);
  assert.equal(shells.get('vane-watch').get('/watch-state'), 'saved alert preferences');
  assert.ok(state.claimed);
  console.log('PASS warm HTTP cache is replaced with current HTML, CSS and JS; old shell removed; alert preferences preserved');
})().catch(error => { console.error(error); process.exitCode = 1; });
