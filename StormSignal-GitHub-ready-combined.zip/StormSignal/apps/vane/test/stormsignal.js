'use strict';
const assert = require('node:assert/strict');
const fs = require('node:fs');
const vm = require('node:vm');
const S = require('../js/stormsignal.js');
let n=0; function test(name, fn) {fn(); n++;console.log('PASS '+name);}
const now = Date.parse('2026-11-12T12:00:00Z');
test('unknown is not fresh',()=>assert.equal(S.assess({},now).status,'unknown'));
test('fetch time never substitutes for observation',()=>assert.equal(S.assess({checkedAt:now},now).status,'unknown'));
test('source timestamp must include timezone',()=>assert.equal(S.epoch('2026-11-12T12:00:00'),null));
test('recent metadata ages into delayed without a fetch',()=>{
 assert.equal(S.assess({observedAt:now-60000},now).status,'recent');
 assert.equal(S.assess({observedAt:now-60000},now+16*60000).status,'stale');});
test('cached metadata not fresh',()=>assert.equal(S.assess({observedAt:now,cached:true},now).status,'cached'));
test('future clock anomaly rejected',()=>assert.equal(S.assess({observedAt:now+3*60000},now).status,'clock-error'));
test('recent feed is not pixel freshness',()=>assert.equal(S.assess({observedAt:now},now).spatialFreshness,'unknown'));
test('motion requires verified frames',()=>assert.equal(S.assess({observedAt:now},now).canEstimateMotion,false));
test('recent verified frames allow estimation not safety guarantee',()=>assert.equal(S.assess({observedAt:now,frameTimesVerified:true},now).canEstimateMotion,true));
test('description explains spatial blind spot',()=>assert.match(S.describe(S.assess({},now)),/Local freshness is unknown/));
test('unchanged metadata is deduplicated despite check time',()=>{
 const t=S.createTimeline(); t.add(S.assess({source:'X',observedAt:now},now),now);
 assert.equal(t.add(S.assess({source:'X',observedAt:now,checkedAt:now+1000},now+1000),now+1000),false);
 assert.equal(t.entries().length,1);
});
test('aging transition is recorded without a new scan',()=>{
 const t=S.createTimeline();t.add(S.assess({source:'X',observedAt:now},now),now);
 t.add(S.assess({source:'X',observedAt:now},now+16*60000),now+16*60000);
 assert.equal(t.entries()[0].status,'stale'); assert.equal(t.entries().length,2);
});
test('timeline is bounded and source changes visible',()=>{
 const t=S.createTimeline(2);['A','B','C'].forEach(source=>t.add(S.assess({source},now),now));
 assert.equal(t.entries().length,2); assert.equal(t.entries()[0].source,'C');
});
test('model and requested clocks cannot be mistaken for observations',()=>{
 assert.match(S.frameDescription({forecast:true,time:now/1000}),/MODEL FORECAST/);
 assert.match(S.frameDescription({time:now/1000,timeBasis:'request'}),/not verified scan time/);
 assert.match(S.frameDescription({archive:true,time:now/1000}),/ARCHIVE/);
});
const context={window:{StormSignal:S,Reflectivity:{sample:()=>{throw Error('must not sample unverified frames');}},VaneConfig:{},U:{}},Promise,Float32Array,Date};
vm.runInNewContext(fs.readFileSync(require.resolve('../js/motion.js'),'utf8'),context);
(async()=>{
 assert.equal(await context.window.Motion.learn({lat:41,lon:-93}),null);n++;console.log('PASS unknown rolling frame times withhold motion');
 assert.equal(await context.window.Motion.learn({lat:41,lon:-93,frames:[{t:now},{t:now}]}),null);n++;console.log('PASS duplicate frame times withhold motion');
 assert.equal(await context.window.Motion.learn({lat:41,lon:-93,frames:[{t:now-3600000}]}),null);n++;console.log('PASS stale frame times withhold motion');
 console.log(n+' StormSignal checks passed');
})().catch(e=>{console.error(e);process.exitCode=1;});
