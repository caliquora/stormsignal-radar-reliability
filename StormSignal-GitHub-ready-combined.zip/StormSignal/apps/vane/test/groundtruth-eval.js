'use strict';

const assert = require('assert/strict');
const fs = require('fs'), path = require('path'), vm = require('vm');
const E = require('../scripts/train/groundtruth-eval.js');

const days = E.scheduledDays(), split = E.splitDays(days.slice().reverse());
assert.equal(days.length, 50);
assert.deepEqual(Object.fromEntries(Object.entries(split).map(([k, v]) => [k, v.length])),
  { train: 26, val: 12, test: 12 });
assert.deepEqual(split.test, ['2023-04-16', '2023-05-06', '2023-05-26', '2023-06-15',
  '2023-07-05', '2023-07-25', '2024-04-11', '2024-05-01', '2024-05-21', '2024-06-10',
  '2024-06-30', '2024-07-20']);
assert.throws(() => E.splitDays([days[0], days[0]]), /Duplicate/);

const sandbox = {};
vm.runInNewContext(fs.readFileSync(path.join(__dirname, '../js/groundtruth-weights.js'), 'utf8'), sandbox);
const W = JSON.parse(JSON.stringify(sandbox.GroundTruthWeights));
// Freeze the failed 1547a342 case as a regression fixture. Future honestly
// passing weights must not require changing the gate's expected behavior.
const recorded = { m0: { logloss: 0.12795, auc: 0.914 },
  m1: { logloss: 0.12277, auc: 0.923 }, gt: { logloss: 0.12342, auc: 0.924 } };
const audit = E.gate(recorded, [{ day: 0.231, night: 0.031 }, { day: 0.914, night: 0.439 }], 0.041);
assert.equal(audit.ship, false);
assert.deepEqual(audit.failed, ['noWorseThanRadarPeople']);
assert.ok(Math.abs(audit.groundTruthMinusRadarPeopleLogLoss - 0.00065) < 1e-12);
assert.ok(Math.abs(audit.excessOverRadarPeopleLimit - 0.00015) < 1e-12);
if (W.ship) {
  assert.ok(W.eval.gate, 'Shipping requires saved full-precision gate evidence');
  const input = W.eval.gate.inputs;
  assert.equal(E.gate(input.metrics, input.witnessCurve, input.syntheticRecoveryError).ship, true);
}
assert.equal(W.eval.heldOutDays, split.test.length);

const curve = [{ day: 0.2, night: 0.1 }, { day: 0.5, night: 0.3 }];
const passing = { m0: { logloss: 0.13, auc: 0.91 }, m1: { logloss: 0.12, auc: 0.92 },
  gt: { logloss: 0.1205, auc: 0.93 } };
assert.equal(E.gate(passing, curve, 0.04).ship, true, 'The original inclusive no-worse boundary passes');
const above = structuredClone(passing); above.gt.logloss = above.m1.logloss + 0.0005 + 1e-12;
assert.equal(E.gate(above, curve, 0.04).ship, false, 'No rounding away a failed gate');
const equalAuc = structuredClone(passing); equalAuc.gt.auc = equalAuc.m0.auc;
assert.equal(E.gate(equalAuc, curve, 0.04).checks.beatsRadarOnlyAuc, false);
assert.equal(E.gate(passing, curve, 0.1).checks.syntheticRecovery, false);
const invalid = structuredClone(passing); invalid.gt.auc = null;
assert.equal(E.gate(invalid, curve, 0.04).ship, false);
assert.equal(E.gate(passing, [{ day: 0.8, night: 0.2 }, { day: 0.7, night: 0.3 }], 0.04).ship, false);

const sparse = E.calibration(2422, 3400, 70000);
assert.equal(sparse.residualScans, -978);
assert.ok(Math.abs(sparse.relativeBias + 978 / 3400) < 1e-12);
assert.equal(E.calibration(1, 0, 1).predictedToObserved, null);

// A deliberately tied population feature verifies identical denominators
// across models, lower-bin tie assignment, and absence of division by zero.
const rows = Array.from({ length: 10 }, (_, i) => ({
  day: i < 5 ? '2023-04-16' : '2023-05-06', xd: [0, i < 4 ? 0 : i], y: i % 2,
  p: (i + 1) / 12
}));
const strata = E.stratify(rows, { m0: 0.5, m1: 1, gt: 0.8 }, (m, r) => m * r.p, () => 0.9);
assert.equal(strata.populationQuintiles[0].n, 4);
assert.equal(strata.populationQuintiles.reduce((s, q) => s + q.n, 0), 10);
assert.equal(strata.byDay.reduce((s, d) => s + d.observedPositiveScans, 0), 5);
for (const model of ['m0', 'm1', 'gt']) {
  const predicted = strata.populationQuintiles.reduce((s, q) => s + q.models[model].predictedPositiveScans, 0);
  const byDay = strata.byDay.reduce((s, q) => s + q.models[model].predictedPositiveScans, 0);
  assert.ok(Math.abs(predicted - byDay) < 1e-12);
}

// Production remains disabled at both the runtime guard and page wiring.
vm.runInNewContext(fs.readFileSync(path.join(__dirname, '../js/popgrid.js'), 'utf8'), sandbox);
vm.runInNewContext(fs.readFileSync(path.join(__dirname, '../js/groundtruth.js'), 'utf8'), sandbox);
assert.equal(sandbox.GroundTruth.assess(new Array(13).fill(0), new Array(6).fill(0), { ...W, ship: false }), null);
assert.doesNotMatch(fs.readFileSync(path.join(__dirname, '../index.html'), 'utf8'),
  /<script[^>]+src=["'][^"']*groundtruth(?:-weights)?\.js/i);
console.log('Ground Truth evaluation: split, gate boundaries, sparse calibration, shared strata and disabled runtime passed');
