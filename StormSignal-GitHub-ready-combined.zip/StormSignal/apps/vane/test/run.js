#!/usr/bin/env node
/* Vane test suite.
 *
 * The browser modules are plain IIFEs that attach to `window`, so they load
 * into Node under a minimal shim — no build step, no test framework, no
 * dependencies. Run with: node test/run.js
 *
 * Focus is the derived meteorology and parsing logic. Rendering is not tested
 * here; it has no branching worth asserting and would need a DOM. */

'use strict';

const fs = require('fs');
const path = require('path');
const vm = require('vm');

/* ── Minimal browser shim ───────────────────────────────────────────────── */

const store = {};
const noop = () => {};

const windowShim = {
  localStorage: {
    getItem: k => (k in store ? store[k] : null),
    setItem: (k, v) => { store[k] = String(v); },
    removeItem: k => { delete store[k]; }
  },
  navigator: { geolocation: null, userAgent: 'Mozilla/5.0 (X11; Linux x86_64)', maxTouchPoints: 0 },
  location: { protocol: 'https:', hostname: 'example.com', search: '' },
  isSecureContext: true,
  addEventListener: noop,
  matchMedia: q => ({ matches: false, media: q }),
  document: {
    addEventListener: noop,
    getElementById: () => null,
    createElement: () => ({ setAttribute: noop, appendChild: noop, style: {} }),
    createElementNS: () => ({ setAttribute: noop, appendChild: noop, style: {} }),
    querySelectorAll: () => [],
    hidden: false
  },
  Notification: undefined,
  fetch: () => Promise.reject(new Error('network disabled in tests'))
};
windowShim.window = windowShim;

const sandbox = vm.createContext(windowShim);

['js/config.js', 'js/util.js', 'js/api.js', 'js/settings.js', 'js/derive.js',
 'js/astro.js', 'js/spc.js', 'js/models.js', 'js/cells.js', 'js/sites.js',
 'js/glossary.js', 'js/brief.js', 'js/notifylearn.js', 'js/outlook.js', 'js/reflectivity.js', 'js/motion.js', 'js/motionskill.js', 'js/verify.js', 'js/raincal.js', 'js/insight.js', 'js/shot.js', 'js/storm3d.js', 'js/stormmodel.js', 'js/stormmodel-weights.js', 'js/chaseday.js', 'js/chaseday-weights.js', 'js/popgrid.js', 'js/stormodds.js', 'js/stormodds-weights.js', 'js/install.js', 'js/update.js', 'js/live.js', 'js/modelcast.js', 'js/radar.js', 'js/layers.js', 'js/modelchart.js'].forEach(f => {
  const code = fs.readFileSync(path.join(__dirname, '..', f), 'utf8');
  vm.runInContext(code, sandbox, { filename: f });
});

const { U, Derive, Astro, SPC, Settings, VaneConfig, Models, Cells, Sites, Brief, Outlook, Shot,
        Storm3D, Reflectivity, Motion, MotionSkill, Verify, Insight, Install, Glossary, Updates, Live,
        Modelcast, Layers, ModelChart, API, RainCal, NotifyLearn, StormModel, StormModelWeights, ChaseDay, ChaseDayWeights, StormOdds, StormOddsWeights, PopGrid, Radar } = sandbox;

// theme.js touches document/window on load, so read its palette table directly
// rather than executing it in the shim.
const THEME_SRC = fs.readFileSync(path.join(__dirname, '..', 'js/theme.js'), 'utf8');

/* ── Tiny assertion harness ─────────────────────────────────────────────── */

let passed = 0, failed = 0;
const failures = [];

// A test that returns a promise is settled before the report is printed;
// without this, a rejected assertion inside a `.then` would count as a pass.
const pending = [];

function record(name, err) {
  if (err) {
    failed++;
    failures.push({ name, err });
    process.stdout.write('\x1b[31mF\x1b[0m');
  } else {
    passed++;
    process.stdout.write('\x1b[32m.\x1b[0m');
  }
}

function test(name, fn) {
  let out;
  try {
    out = fn();
  } catch (err) {
    record(name, err);
    return;
  }
  if (out && typeof out.then === 'function') {
    pending.push(out.then(() => record(name, null), err => record(name, err)));
    return;
  }
  record(name, null);
}

function eq(actual, expected, msg) {
  if (actual !== expected) {
    throw new Error(`${msg || ''}\n    expected: ${expected}\n    actual:   ${actual}`);
  }
}

function near(actual, expected, tol, msg) {
  if (!(Math.abs(actual - expected) <= tol)) {
    throw new Error(`${msg || ''}\n    expected: ${expected} ±${tol}\n    actual:   ${actual}`);
  }
}

function ok(cond, msg) {
  if (!cond) throw new Error(msg || 'expected truthy');
}

// The sandbox has its own intrinsics, so `instanceof Date` never matches a Date
// constructed inside it. Duck-type instead.
function isDate(v) {
  return !!v && typeof v.getTime === 'function' && !isNaN(v.getTime());
}

/* ── Unit conversion ────────────────────────────────────────────────────── */

test('cToF: freezing point', () => eq(U.cToF(0), 32));
test('cToF: boiling point', () => eq(U.cToF(100), 212));
test('cToF: -40 is the crossover', () => eq(U.cToF(-40), -40));
test('msToKt: 1 m/s', () => near(U.msToKt(1), 1.9438, 0.001));
test('msToMph: 10 m/s', () => near(U.msToMph(10), 22.369, 0.001));
test('mmToIn: 25.4 mm is one inch', () => near(U.mmToIn(25.4), 1, 1e-9));
test('temp() rounds and appends degree', () => eq(U.temp(20.4, false), '20°'));
test('temp() converts when imperial', () => eq(U.temp(0, true), '32°'));
test('temp() handles null', () => eq(U.temp(null, true), '--'));
test('precip() imperial uses inches', () => eq(U.precip(25.4, true), '1.00"'));
test('speed() metric uses km/h', () => eq(U.speed(10, false), '36 km/h'));

/* ── Wind vector maths ──────────────────────────────────────────────────── */

test('windToUV: a north wind blows toward the south', () => {
  const { u, v } = U.windToUV(10, 0);
  near(u, 0, 1e-9, 'u');
  near(v, -10, 1e-9, 'v');
});

test('windToUV: a west wind blows toward the east', () => {
  const { u, v } = U.windToUV(10, 270);
  near(u, 10, 1e-9, 'u');
  near(v, 0, 1e-9, 'v');
});

test('uvToWind inverts windToUV across all quadrants', () => {
  [0, 45, 90, 135, 180, 225, 270, 315].forEach(dir => {
    const { u, v } = U.windToUV(15, dir);
    const back = U.uvToWind(u, v);
    near(back.speed, 15, 1e-9, `speed at ${dir}`);
    near((back.dir + 360) % 360, dir, 1e-6, `dir at ${dir}`);
  });
});

test('compass: cardinal points', () => {
  eq(U.compass(0), 'N');
  eq(U.compass(90), 'E');
  eq(U.compass(180), 'S');
  eq(U.compass(270), 'W');
  eq(U.compass(360), 'N');
});

test('compass: wraps negative degrees', () => eq(U.compass(-90), 'W'));

test('haversine: OKC to Norman is about 30 km', () => {
  near(U.haversine(35.4676, -97.5164, 35.2226, -97.4395), 28.3, 2);
});

test('haversine: identical points are zero', () => {
  eq(U.haversine(40, -100, 40, -100), 0);
});

/* ── parseLocal ─────────────────────────────────────────────────────────── */

test('parseLocal reads Open-Meteo wall-clock strings without shifting zone', () => {
  const d = U.parseLocal('2026-08-13T07:15');
  eq(d.getFullYear(), 2026);
  eq(d.getMonth(), 7);
  eq(d.getDate(), 13);
  eq(d.getHours(), 7);
  eq(d.getMinutes(), 15);
});

/* ── Timezone handling ──────────────────────────────────────────────────── */

// Regression: Open-Meteo returns wall-clock times in the forecast location's
// zone. Comparing them to Date.now() as if they were device-local silently
// discarded every nowcast block whenever the viewer sat in another timezone.
test('epochOf converts location wall-clock to a true epoch', () => {
  // 07:15 in UTC-5 is 12:15 UTC.
  eq(U.epochOf('2026-08-13T07:15', -18000), Date.UTC(2026, 7, 13, 12, 15));
});

test('epochOf is unaffected by the device timezone', () => {
  eq(U.epochOf('2026-08-13T00:00', 0), Date.UTC(2026, 7, 13, 0, 0));
});

test('epochOf handles positive offsets', () => {
  // 09:00 in UTC+9 is 00:00 UTC.
  eq(U.epochOf('2026-08-13T09:00', 32400), Date.UTC(2026, 7, 13, 0, 0));
});

test('epochOf rejects malformed input', () => {
  ok(isNaN(U.epochOf('not-a-time', 0)));
});

test('fmtEpoch renders a true epoch on the location clock', () => {
  const epoch = Date.UTC(2026, 7, 13, 12, 15);
  eq(U.fmtEpoch(epoch, -18000, false), '07:15');
  eq(U.fmtEpoch(epoch, -18000, true), '7:15 AM');
  eq(U.fmtEpoch(epoch, 32400, false), '21:15');
});

test('epochOf and fmtEpoch round-trip', () => {
  const iso = '2026-08-13T16:45';
  eq(U.fmtEpoch(U.epochOf(iso, -18000), -18000, false), '16:45');
});

/* ── Nowcast ────────────────────────────────────────────────────────────── */

function fakeMinutely(mmSeries) {
  const base = new Date();
  base.setSeconds(0, 0);
  const time = mmSeries.map((_, i) => {
    const t = new Date(base.getTime() + i * 15 * 60000);
    const p = n => String(n).padStart(2, '0');
    return `${t.getFullYear()}-${p(t.getMonth() + 1)}-${p(t.getDate())}T${p(t.getHours())}:${p(t.getMinutes())}`;
  });
  return {
    minutely_15: {
      time,
      precipitation: mmSeries,
      precipitation_probability: mmSeries.map(mm => (mm > 0 ? 80 : 5)),
      weather_code: mmSeries.map(() => 61)
    }
  };
}

test('nowcast: all-dry series reports dry', () => {
  const nc = Derive.nowcast(fakeMinutely([0, 0, 0, 0, 0, 0, 0, 0]));
  eq(nc.state, 'dry');
  eq(nc.any, false);
});

test('nowcast: rain later reports "starting" with a start time', () => {
  const nc = Derive.nowcast(fakeMinutely([0, 0, 0, 1.0, 1.0, 0, 0, 0]));
  eq(nc.state, 'starting');
  ok(isDate(nc.startTime), 'startTime should be a Date');
  eq(nc.durationMin, 30, 'two wet 15-min blocks is 30 minutes');
  eq(nc.continues, false);
  // The real instant, for timing against the radar: mid-way through the
  // first wet block, which holds the fifteen minutes before its stamp.
  eq(nc.startAt, nc.blocks[3].at - 7.5 * 60000);
  eq(nc.blocks[3].at - nc.blocks[2].at, 15 * 60000);
});

test('nowcast: rain now that stops reports "stopping"', () => {
  const nc = Derive.nowcast(fakeMinutely([2.0, 2.0, 0, 0, 0, 0, 0, 0]));
  eq(nc.state, 'stopping');
  ok(isDate(nc.stopTime), 'stopTime should be a Date');
});

test('nowcast: rain throughout reports "ongoing"', () => {
  const nc = Derive.nowcast(fakeMinutely([1, 1, 1, 1, 1, 1, 1, 1]));
  eq(nc.state, 'ongoing');
});

test('nowcast: rain to the end of the window sets continues', () => {
  const nc = Derive.nowcast(fakeMinutely([0, 0, 1, 1, 1, 1, 1, 1]));
  eq(nc.state, 'starting');
  eq(nc.continues, true);
});

test('nowcast: sub-trace amounts do not count as rain', () => {
  const nc = Derive.nowcast(fakeMinutely([0.01, 0.02, 0.01, 0, 0, 0, 0, 0]));
  eq(nc.state, 'dry');
});

test('nowcast: caps the window at eight 15-minute blocks', () => {
  const nc = Derive.nowcast(fakeMinutely(new Array(20).fill(0)));
  eq(nc.blocks.length, 8);
});

test('nowcast: returns null without minutely data', () => {
  eq(Derive.nowcast({}), null);
});

test('intensityLabel bands', () => {
  eq(Derive.intensityLabel(0), 'none');
  eq(Derive.intensityLabel(0.1), 'trace');
  eq(Derive.intensityLabel(0.5), 'light');
  eq(Derive.intensityLabel(2), 'moderate');
  eq(Derive.intensityLabel(9), 'heavy');
});

/* ── Profile / shear / storm motion ─────────────────────────────────────── */

// Synthetic sounding: westerly wind veering with height, speed increasing.
function fakeSounding(levels) {
  const hourly = { time: ['2026-08-13T18:00'] };
  const heights = { 1000: 100, 925: 800, 850: 1500, 700: 3100, 500: 5900 };
  Object.keys(levels).forEach(p => {
    hourly[`wind_speed_${p}hPa`] = [levels[p].speed];
    hourly[`wind_direction_${p}hPa`] = [levels[p].dir];
    hourly[`geopotential_height_${p}hPa`] = [heights[p]];
    hourly[`temperature_${p}hPa`] = [10];
  });
  return { hourly, elevation: 0 };
}

const straightHodo = fakeSounding({
  1000: { speed: 5, dir: 270 },
  925: { speed: 10, dir: 270 },
  850: { speed: 15, dir: 270 },
  700: { speed: 20, dir: 270 },
  500: { speed: 30, dir: 270 }
});

test('buildProfile anchors at the 10 m surface wind', () => {
  const prof = Derive.buildProfile(straightHodo, 0, { speed: 5, dir: 270 });
  ok(prof, 'profile should build');
  eq(prof.levels[0].agl, 10);
  eq(prof.levels[0].surface, true);
});

test('buildProfile sorts levels bottom-up', () => {
  const prof = Derive.buildProfile(straightHodo, 0, { speed: 5, dir: 270 });
  for (let i = 1; i < prof.levels.length; i++) {
    ok(prof.levels[i].agl >= prof.levels[i - 1].agl, 'heights must ascend');
  }
});

// Pressure levels below the model's surface elevation are underground and must
// not appear in the profile — at a 371 m site, 1000 and 975 hPa typically are.
test('buildProfile drops levels below the surface', () => {
  const elevated = fakeSounding({
    1000: { speed: 5, dir: 270 }, 925: { speed: 10, dir: 270 },
    850: { speed: 15, dir: 270 }, 700: { speed: 20, dir: 270 },
    500: { speed: 30, dir: 270 }
  });
  elevated.elevation = 900;          // 1000 hPa (100 m) and 925 hPa (800 m) are below ground
  const prof = Derive.buildProfile(elevated, 0, { speed: 5, dir: 270 });
  ok(prof, 'profile should still build from the remaining levels');
  ok(prof.levels.every(l => l.agl >= 0), 'no level may sit below ground');
  eq(prof.levels.filter(l => l.p === 1000).length, 0, '1000 hPa must be dropped');
  eq(prof.levels.filter(l => l.p === 925).length, 0, '925 hPa must be dropped');
  eq(prof.levels.filter(l => l.p === 500).length, 1, '500 hPa must survive');
});

test('buildProfile measures heights above ground, not above sea level', () => {
  const s = fakeSounding({
    1000: { speed: 5, dir: 270 }, 925: { speed: 10, dir: 270 },
    850: { speed: 15, dir: 270 }, 700: { speed: 20, dir: 270 },
    500: { speed: 30, dir: 270 }
  });
  s.elevation = 500;                 // 850 hPa sits at 1500 m MSL -> 1000 m AGL
  const prof = Derive.buildProfile(s, 0, { speed: 5, dir: 270 });
  const l850 = prof.levels.filter(l => l.p === 850)[0];
  eq(l850.agl, 1000);
});

test('buildProfile rejects a sounding with too few usable levels', () => {
  eq(Derive.buildProfile(fakeSounding({ 1000: { speed: 5, dir: 270 } }), 0, null), null);
});

test('windAt interpolates linearly between levels', () => {
  const prof = Derive.buildProfile(straightHodo, 0, { speed: 5, dir: 270 });
  const w = Derive.windAt(prof.levels, 1150);   // midway between 800 m and 1500 m
  const mid = U.uvToWind(w.u, w.v);
  near(mid.speed, 12.5, 0.3, 'speed should be halfway between 10 and 15 m/s');
});

test('windAt returns null far above the top of the profile', () => {
  const prof = Derive.buildProfile(straightHodo, 0, { speed: 5, dir: 270 });
  eq(Derive.windAt(prof.levels, 50000), null);
});

// Regression: 500 hPa sits near 5.9 km, so asking for the 6 km wind fell off
// the top of the profile and blanked out 0-6 km shear — the single parameter a
// chaser looks at first. Requests now include 400 hPa, and windAt clamps within
// a bounded margin so elevated sites still get an answer.
test('windAt clamps to the top level just above the profile', () => {
  const prof = Derive.buildProfile(straightHodo, 0, { speed: 5, dir: 270 });
  const w = Derive.windAt(prof.levels, 6000);          // top level is 5900 m
  ok(w, '6 km must resolve even when the profile tops at 5.9 km');
  eq(w.clamped, true, 'the result should be marked as clamped');
  near(U.uvToWind(w.u, w.v).speed, 30, 1e-6);
});

test('0-6 km shear resolves on a profile topping out below 6 km', () => {
  const prof = Derive.buildProfile(straightHodo, 0, { speed: 5, dir: 270 });
  const s = Derive.bulkShear(prof.levels, 6000);
  ok(s, '0-6 km shear must not be null');
  near(s.magnitude, 25, 0.5);
});

test('requested pressure levels bracket 6 km AGL', () => {
  // 400 hPa is ~7.2 km, so 6 km is interpolated rather than extrapolated.
  ok(VaneConfig.LEVELS.indexOf(400) !== -1, 'LEVELS must include 400 hPa');
});

test('bulkShear: unidirectional profile gives the speed difference', () => {
  const prof = Derive.buildProfile(straightHodo, 0, { speed: 5, dir: 270 });
  const s = Derive.bulkShear(prof.levels, 5900);
  near(s.magnitude, 25, 0.5, '30 m/s aloft minus 5 m/s at the surface');
});

test('bulkShear: no shear when wind is constant with height', () => {
  const flat = fakeSounding({
    1000: { speed: 10, dir: 270 }, 925: { speed: 10, dir: 270 },
    850: { speed: 10, dir: 270 }, 700: { speed: 10, dir: 270 },
    500: { speed: 10, dir: 270 }
  });
  const prof = Derive.buildProfile(flat, 0, { speed: 10, dir: 270 });
  near(Derive.bulkShear(prof.levels, 5900).magnitude, 0, 1e-6);
});

test('stormMotion: right mover deviates right of a westerly shear vector', () => {
  const prof = Derive.buildProfile(straightHodo, 0, { speed: 5, dir: 270 });
  const m = Derive.stormMotion(prof.levels);
  ok(m, 'motion should compute');
  // Shear points east (+u). Right of that is south (−v), so the right mover
  // must sit south of the mean wind and the left mover north of it.
  ok(m.right.v < m.mean.v, 'right mover should be south of the mean wind');
  ok(m.left.v > m.mean.v, 'left mover should be north of the mean wind');
});

test('stormMotion: RM and LM are 15 m/s apart (2 × the 7.5 m/s deviation)', () => {
  const prof = Derive.buildProfile(straightHodo, 0, { speed: 5, dir: 270 });
  const m = Derive.stormMotion(prof.levels);
  const du = m.right.u - m.left.u, dv = m.right.v - m.left.v;
  near(Math.sqrt(du * du + dv * dv), 15, 0.01);
});

test('stormMotion: returns null when there is no shear to deviate from', () => {
  const flat = fakeSounding({
    1000: { speed: 10, dir: 270 }, 925: { speed: 10, dir: 270 },
    850: { speed: 10, dir: 270 }, 700: { speed: 10, dir: 270 },
    500: { speed: 10, dir: 270 }
  });
  const prof = Derive.buildProfile(flat, 0, { speed: 10, dir: 270 });
  eq(Derive.stormMotion(prof.levels), null);
});

test('srh: zero for a perfectly straight hodograph relative to the mean wind', () => {
  const prof = Derive.buildProfile(straightHodo, 0, { speed: 5, dir: 270 });
  const mean = Derive.meanWind(prof.levels, 0, 3000);
  near(Derive.srh(prof.levels, 3000, mean), 0, 1e-6);
});

test('srh: a veering (clockwise-curving) hodograph gives positive helicity', () => {
  const curved = fakeSounding({
    1000: { speed: 8, dir: 160 },
    925: { speed: 12, dir: 190 },
    850: { speed: 16, dir: 220 },
    700: { speed: 22, dir: 250 },
    500: { speed: 30, dir: 270 }
  });
  const prof = Derive.buildProfile(curved, 0, { speed: 6, dir: 150 });
  const m = Derive.stormMotion(prof.levels);
  const h = Derive.srh(prof.levels, 3000, m.right);
  ok(h > 0, `veering profile should give positive SRH, got ${h}`);
});

test('srh: a backing hodograph gives negative helicity', () => {
  const backing = fakeSounding({
    1000: { speed: 8, dir: 270 },
    925: { speed: 12, dir: 250 },
    850: { speed: 16, dir: 220 },
    700: { speed: 22, dir: 190 },
    500: { speed: 30, dir: 160 }
  });
  const prof = Derive.buildProfile(backing, 0, { speed: 6, dir: 280 });
  const m = Derive.stormMotion(prof.levels);
  const h = Derive.srh(prof.levels, 3000, m.right);
  ok(h < 0, `backing profile should give negative SRH, got ${h}`);
});

test('convective assembles parameters from a full sounding', () => {
  const s = fakeSounding({
    1000: { speed: 8, dir: 160 }, 925: { speed: 12, dir: 190 },
    850: { speed: 16, dir: 220 }, 700: { speed: 22, dir: 250 },
    500: { speed: 30, dir: 270 }
  });
  s.hourly.cape = [2400];
  s.hourly.convective_inhibition = [-40];
  s.hourly.lifted_index = [-7];
  s.hourly.freezing_level_height = [4200];
  s.hourly.boundary_layer_height = [1400];

  const cv = Derive.convective(s, 0, { speed: 6, dir: 150 });
  eq(cv.cape, 2400);
  eq(cv.li, -7);
  ok(cv.shear6 && cv.shear6.magnitude > 0, 'should compute 0-6 km shear');
  ok(cv.motion, 'should compute storm motion');
  ok(typeof cv.srh1 === 'number', 'should compute 0-1 km SRH');
  ok(cv.index > 0, 'supercell index should be positive in this environment');
});

test('convectiveSummary describes a strongly sheared, unstable environment in words', () => {
  const cv = { cape: 3000, cin: -30, shear6: { magnitude: 25 }, srh1: 300 };
  const text = Derive.convectiveSummary(cv);
  ok(/Strong instability/.test(text), text);
  ok(/supercell-supportive/.test(text), text);
});

test('convectiveSummary flags a capped environment', () => {
  const cv = { cape: 2000, cin: -180, shear6: { magnitude: 20 }, srh1: 100 };
  ok(/cap in place/.test(Derive.convectiveSummary(cv)));
});

/* ── Astronomy ──────────────────────────────────────────────────────────── */

test('sunTimes: sunrise precedes solar noon precedes sunset', () => {
  const t = Astro.sunTimes(new Date('2026-06-21T12:00:00Z'), 35.47, -97.52);
  ok(t.sunrise < t.solarNoon, 'sunrise before noon');
  ok(t.solarNoon < t.sunset, 'noon before sunset');
});

test('sunTimes: OKC June solstice day length is about 14h 30m', () => {
  const t = Astro.sunTimes(new Date('2026-06-21T12:00:00Z'), 35.47, -97.52);
  const hours = (t.sunset - t.sunrise) / 3600000;
  near(hours, 14.4, 0.4, `got ${hours} hours`);
});

test('sunTimes: OKC December solstice day length is about 9h 45m', () => {
  const t = Astro.sunTimes(new Date('2026-12-21T12:00:00Z'), 35.47, -97.52);
  const hours = (t.sunset - t.sunrise) / 3600000;
  near(hours, 9.8, 0.4, `got ${hours} hours`);
});

test('sunTimes: civil dusk falls after sunset', () => {
  const t = Astro.sunTimes(new Date('2026-08-13T12:00:00Z'), 35.47, -97.52);
  ok(t.dusk > t.sunset, 'dusk should follow sunset');
});

test('sunTimes: polar night yields null sunrise at high latitude', () => {
  const t = Astro.sunTimes(new Date('2026-12-21T12:00:00Z'), 78, 15);
  eq(t.sunrise, null);
});

test('sunPosition: sun is up at local solar noon in summer', () => {
  const t = Astro.sunTimes(new Date('2026-06-21T12:00:00Z'), 35.47, -97.52);
  const p = Astro.sunPosition(t.solarNoon, 35.47, -97.52);
  ok(p.altitude > 70, `expected a high sun, got ${p.altitude}`);
});

test('sunPosition: sun is below the horizon at local midnight', () => {
  const t = Astro.sunTimes(new Date('2026-06-21T12:00:00Z'), 35.47, -97.52);
  const p = Astro.sunPosition(t.nadir, 35.47, -97.52);
  ok(p.altitude < 0, `expected a sun below the horizon, got ${p.altitude}`);
});

test('moonIllumination: fraction stays within 0..1 across a synodic month', () => {
  for (let d = 0; d < 30; d++) {
    const date = new Date(Date.UTC(2026, 7, 1 + d));
    const m = Astro.moonIllumination(date);
    ok(m.fraction >= 0 && m.fraction <= 1, `fraction ${m.fraction} out of range on day ${d}`);
    ok(m.phase >= 0 && m.phase <= 1, `phase ${m.phase} out of range on day ${d}`);
  }
});

test('moonIllumination: full moon of 2026-08-28 is near fully lit', () => {
  const m = Astro.moonIllumination(new Date('2026-08-28T04:00:00Z'));
  ok(m.fraction > 0.9, `expected a near-full moon, got ${m.fraction}`);
});

test('phaseName returns a label and a glyph', () => {
  const p = Astro.phaseName(0.5);
  eq(p[1], 'Full moon');
  ok(typeof p[2] === 'string' && p[2].length > 0);
});

test('daylightRemaining counts down to sunset during the afternoon', () => {
  const t = Astro.sunTimes(new Date('2026-08-13T12:00:00Z'), 35.47, -97.52);
  const beforeSunset = new Date(t.sunset.getTime() - 90 * 60000);
  const r = Astro.daylightRemaining(beforeSunset, 35.47, -97.52);
  near(r.minutesToSunset, 90, 1);
  ok(r.isDaylight, 'should still be daylight 90 minutes before sunset');
});

/* ── SPC geometry ───────────────────────────────────────────────────────── */

const square = {
  type: 'Polygon',
  coordinates: [[[-100, 35], [-95, 35], [-95, 40], [-100, 40], [-100, 35]]]
};

test('pointInGeometry: interior point is inside', () => {
  eq(SPC.pointInGeometry(37.5, -97.5, square), true);
});

test('pointInGeometry: exterior point is outside', () => {
  eq(SPC.pointInGeometry(37.5, -90, square), false);
});

test('pointInGeometry: point beyond the latitude range is outside', () => {
  eq(SPC.pointInGeometry(45, -97.5, square), false);
});

test('pointInGeometry: respects holes in a polygon', () => {
  const withHole = {
    type: 'Polygon',
    coordinates: [
      [[-100, 35], [-95, 35], [-95, 40], [-100, 40], [-100, 35]],
      [[-98, 37], [-97, 37], [-97, 38], [-98, 38], [-98, 37]]
    ]
  };
  eq(SPC.pointInGeometry(37.5, -97.5, withHole), false, 'inside the hole');
  eq(SPC.pointInGeometry(36, -99, withHole), true, 'inside the ring but not the hole');
});

test('pointInGeometry: handles MultiPolygon', () => {
  const multi = {
    type: 'MultiPolygon',
    coordinates: [
      square.coordinates,
      [[[-90, 30], [-85, 30], [-85, 33], [-90, 33], [-90, 30]]]
    ]
  };
  eq(SPC.pointInGeometry(31.5, -87.5, multi), true);
  eq(SPC.pointInGeometry(31.5, -97.5, multi), false);
});

test('pointInGeometry: null geometry is not a match', () => {
  eq(SPC.pointInGeometry(37, -97, null), false);
});

test('riskAt returns the highest-ranked overlapping outlook polygon', () => {
  SPC.state.features = [
    { properties: { DN: 2, LABEL: 'TSTM' }, geometry: square },
    { properties: { DN: 4, LABEL: 'SLGT' }, geometry: square }
  ];
  const r = SPC.riskAt(37.5, -97.5);
  eq(r.code, 'SLGT', 'nested polygons should resolve to the higher risk');
  SPC.state.features = [];
});

test('riskAt returns null outside every polygon', () => {
  SPC.state.features = [{ properties: { DN: 4 }, geometry: square }];
  eq(SPC.riskAt(10, 10), null);
  SPC.state.features = [];
});

test('riskIn point-tests any feature set without touching the map state', () => {
  const feats = [
    { properties: { DN: 3, LABEL: 'MRGL' }, geometry: square },
    { properties: { DN: 5, LABEL: 'ENH' }, geometry: square }
  ];
  eq(SPC.riskIn(feats, 37.5, -97.5, 'cat').code, 'ENH');
  eq(SPC.riskIn(feats, 10, 10, 'cat'), null);
  eq(SPC.state.features.length, 0, 'the map state stays untouched');
});

/* ── Notification decisions ─────────────────────────────────────────────
 * The pure logic behind "rain on the way" and the SPC outlook heads-up.
 * The Notification plumbing itself is exercised in the browser suite. */

test('rain heads-up fires for a close inbound echo, once per approach', () => {
  const inbound = {
    stationary: false,
    vector: { toward: 'NE', speed: 32 },
    eta: { minutes: 25, dbz: 34, distanceKm: 18, dir: 'SW' }
  };
  const now = Date.now();
  eq(Settings.shouldNotifyMotion(inbound, 0, now), true, 'first sighting notifies');
  eq(Settings.shouldNotifyMotion(inbound, now - 10 * 60000, now), false,
    'the same approach ten minutes later is silence, not a drumbeat');
  eq(Settings.shouldNotifyMotion(inbound, now - 50 * 60000, now), true,
    'a fresh approach after the suppression window notifies again');
});

test('rain heads-up refuses distant, stationary and verdict-less fits', () => {
  const now = Date.now();
  const far = { stationary: false, vector: { toward: 'E', speed: 20 },
                eta: { minutes: 70, dbz: 30, distanceKm: 40, dir: 'W' } };
  eq(Settings.shouldNotifyMotion(far, 0, now), false, 'an hour out is not an interruption');
  eq(Settings.shouldNotifyMotion({ stationary: true, eta: null }, 0, now), false);
  eq(Settings.shouldNotifyMotion(null, 0, now), false);
  eq(Settings.shouldNotifyMotion({ stationary: false, eta: null }, 0, now), false,
    'moving but nothing inbound says nothing');
});

test('the rain heads-up text carries the evidence and the on-device label', () => {
  const text = Settings.motionNotifyText({
    vector: { toward: 'NE', speed: 32 },
    eta: { minutes: 25, dbz: 34, distanceKm: 18, dir: 'SW' }
  });
  ok(/34 dBZ/.test(text), 'names the echo strength');
  ok(/18 km to the SW/.test(text), 'names where it is');
  ok(/about 25 min/.test(text), 'names when it arrives');
  ok(/Learned in your browser/.test(text), 'and owns up to being an on-device fit');
});

test('outlook heads-up: once per day per outlook day, upgrades only', () => {
  const d = '2026-09-19';
  const slgt = { rank: 3, label: 'Slight' };
  const mdt = { rank: 5, label: 'Moderate' };
  const first = Settings.outlookNotifyPick(null, d, 1, slgt);
  eq(first.day1, 3, 'a Slight day 1 notifies');
  eq(Settings.outlookNotifyPick(first, d, 1, slgt), null, 'the same category again is silence');
  const upgraded = Settings.outlookNotifyPick(first, d, 1, mdt);
  eq(upgraded.day1, 5, 'an upgrade breaks the silence');
  const day2 = Settings.outlookNotifyPick(upgraded, d, 2, slgt);
  eq(day2.day2, 3, 'day 2 tracks independently');
  eq(day2.day1, 5, 'without forgetting day 1');
});

test('outlook heads-up: below Slight never notifies, a new day resets', () => {
  const mrgl = { rank: 2, label: 'Marginal' };
  eq(Settings.outlookNotifyPick(null, '2026-09-19', 1, mrgl), null,
    'Marginal is background noise, not a notification');
  eq(Settings.outlookNotifyPick(null, '2026-09-19', 1, null), null);
  const yesterday = { date: '2026-09-18', day1: 5 };
  const today = Settings.outlookNotifyPick(yesterday, '2026-09-19', 1, { rank: 3, label: 'Slight' });
  eq(today.day1, 3, 'yesterday\'s Moderate does not mute today\'s Slight');
});

/* ── The local scorecard: on-device model verification ──────────────────── */

function fakeModelDaily(dates, perModel) {
  // perModel: { gfs_seamless: [[hi,lo], ...aligned with dates] }
  const daily = { time: dates };
  Object.keys(perModel).forEach(id => {
    daily['temperature_2m_max_' + id] = perModel[id].map(d => d && d[0]);
    daily['temperature_2m_min_' + id] = perModel[id].map(d => d && d[1]);
  });
  return { daily, utc_offset_seconds: -18000 };
}

test('recording keeps only days still to come, and overwrites toward day-ahead', () => {
  const md = fakeModelDaily(['2026-09-19', '2026-09-20', '2026-09-21'], {
    gfs_seamless: [[30, 20], [31, 21], [32, 22]],
    ecmwf_ifs025: [[29, 19], [30, 20], [31, 21]]
  });
  let store = Verify.recordInto(Verify.emptyStore('35.47,-97.52'), '35.47,-97.52', md, '2026-09-19');
  eq(store.pending['2026-09-19'], undefined, 'today is no longer a prediction');
  eq(store.pending['2026-09-20'].models.gfs_seamless.hi, 31);
  eq(store.pending['2026-09-21'].models.ecmwf_ifs025.lo, 21);

  // A later run revises tomorrow; the revision wins — that is the day-ahead.
  const rev = fakeModelDaily(['2026-09-20'], { gfs_seamless: [[33, 23]] });
  store = Verify.recordInto(store, '35.47,-97.52', rev, '2026-09-19');
  eq(store.pending['2026-09-20'].models.gfs_seamless.hi, 33);
});

test('moving the pin starts a fresh scorecard — climates do not blend', () => {
  let store = Verify.emptyStore('35.47,-97.52');
  store.results.push({ date: '2026-09-18', err: {} });
  const md = fakeModelDaily(['2026-09-20'], { gfs_seamless: [[31, 21]] });
  store = Verify.recordInto(store, '39.74,-104.99', md, '2026-09-19');
  eq(store.loc, '39.74,-104.99');
  eq(store.results.length, 0, 'Oklahoma\'s scores say nothing about Denver');
});

test('settling scores every model against the thermometer, absolutely', () => {
  const store = Verify.emptyStore('35.47,-97.52');
  store.pending['2026-09-18'] = { off: -18000, models: {
    gfs_seamless: { hi: 35, lo: 24 },      // 2 warm on the high, 2 warm on the low
    ecmwf_ifs025: { hi: 32.5, lo: 21.5 }   // half a degree cool on both
  } };
  const ok1 = Verify.settleResult(store, '2026-09-18', 'KOKC', { hi: 33, lo: 22, n: 24 });
  eq(ok1, true);
  eq(store.pending['2026-09-18'], undefined, 'the bet is settled and closed');
  const r = store.results[0];
  eq(r.err.gfs_seamless.hi, 2, 'signed: two degrees warm');
  eq(r.err.gfs_seamless.lo, 2);
  near(r.err.ecmwf_ifs025.hi, -0.5, 1e-9,
    'signed: a cool miss keeps its sign for the microclimate fit');
});

test('the leaderboard scores magnitude: warm and cool misses weigh the same', () => {
  // One model alternates ±2°; another is always 1° warm. The alternator has
  // the WORSE leaderboard score even though its mean signed error is zero.
  const results = [];
  for (let i = 0; i < 4; i++) {
    results.push({ date: 'd' + i, err: {
      gfs_seamless: { hi: i % 2 ? 2 : -2, lo: 0 },
      ecmwf_ifs025: { hi: 1, lo: 0 }
    } });
  }
  const b = Verify.board(results);
  eq(b.rows[0].short, 'ECMWF', 'consistently 1° warm beats alternating ±2°');
  near(b.rows[1].maeHi, 2, 1e-9, 'the alternator\'s misses do not cancel');
});

test('a half-measured day is discarded, never guessed', () => {
  const store = Verify.emptyStore('x');
  store.pending['2026-09-18'] = { off: 0, models: { gfs_seamless: { hi: 30, lo: 20 } } };
  const ok1 = Verify.settleResult(store, '2026-09-18', 'KOKC', { hi: 31, lo: 24, n: 5 });
  eq(ok1, false, 'five METARs cannot bound a day\'s extremes');
  eq(store.results.length, 0, 'no result is better than a fabricated one');
  eq(store.pending['2026-09-18'], undefined, 'and the unverifiable bet is dropped');
});

test('the leaderboard ranks by combined MAE and withholds thin samples', () => {
  const results = [];
  for (let i = 0; i < 4; i++) {
    results.push({ date: 'd' + i, err: {
      gfs_seamless: { hi: 2, lo: 1 },        // combined 1.5
      ecmwf_ifs025: { hi: 1, lo: 0.5 }       // combined 0.75 — should lead
    } });
  }
  // ICON shows up only twice: not enough days to be ranked honestly.
  results[0].err.icon_seamless = { hi: 0, lo: 0 };
  results[1].err.icon_seamless = { hi: 0, lo: 0 };

  const b = Verify.board(results);
  eq(b.rows.length, 2, 'a perfect two-day fluke is not a ranking');
  eq(b.rows[0].short, 'ECMWF');
  near(b.rows[0].mae, 0.75, 1e-9);
  near(b.rows[1].mae, 1.5, 1e-9);
  eq(b.rows[0].n, 4);
  eq(b.days, 4);
});

test('the blend forecast is recorded beside the agencies, and survives both orders', () => {
  const md = fakeModelDaily(['2026-09-20'], { gfs_seamless: [[31, 21]] });
  const blend = { daily: { time: ['2026-09-20'],
    temperature_2m_max: [30.5], temperature_2m_min: [20.5] }, utc_offset_seconds: -18000 };

  // Blend first, agencies second…
  let store = Verify.recordBlendInto(Verify.emptyStore('x'), 'x', blend, '2026-09-19');
  store = Verify.recordInto(store, 'x', md, '2026-09-19');
  eq(store.pending['2026-09-20'].blend.hi, 30.5, 'the blend rides along');
  eq(store.pending['2026-09-20'].models.gfs_seamless.hi, 31);

  // …and agencies first, blend second.
  store = Verify.recordInto(Verify.emptyStore('x'), 'x', md, '2026-09-19');
  store = Verify.recordBlendInto(store, 'x', blend, '2026-09-19');
  eq(store.pending['2026-09-20'].blend.lo, 20.5);
  eq(store.pending['2026-09-20'].models.gfs_seamless.lo, 21, 'without evicting the agencies');
});

test('settling a day with a blend prediction records its signed lean', () => {
  const store = Verify.emptyStore('x');
  store.pending['2026-09-18'] = { off: 0,
    models: { gfs_seamless: { hi: 35, lo: 24 } },
    blend: { hi: 35.5, lo: 21 } };
  Verify.settleResult(store, '2026-09-18', 'KOKC', { hi: 33, lo: 22, n: 24 });
  const r = store.results[0];
  near(r.blendErr.hi, 2.5, 1e-9, 'the displayed forecast ran 2.5° warm');
  near(r.blendErr.lo, -1, 1e-9, 'and 1° cool on the low');
});

test('the microclimate fit finds a persistent lean and shrinks it honestly', () => {
  // Six days, every one of them 2° warm on highs and 1° cool on lows.
  const results = [];
  for (let i = 0; i < 6; i++) {
    results.push({ date: 'd' + i, err: {}, blendErr: { hi: 2, lo: -1 } });
  }
  const m = Verify.microclimate(results);
  eq(m.n, 6);
  near(m.biasHi, 2, 1e-9);
  near(m.biasLo, -1, 1e-9);
  near(m.corrHi, -2 * 0.6, 1e-9, 'six days earn 60% of the full correction');
  near(m.corrLo, 1 * 0.6, 1e-9);
  eq(m.meaningful, true);
});

test('an alternating lean is no lean: the fit refuses to correct noise', () => {
  const results = [];
  for (let i = 0; i < 6; i++) {
    results.push({ date: 'd' + i, err: {},
      blendErr: { hi: i % 2 ? 2 : -2, lo: i % 2 ? 1.5 : -1.5 } });
  }
  const m = Verify.microclimate(results);
  near(m.biasHi, 0, 1e-9, 'warm and cool days cancel');
  eq(m.meaningful, false, 'nothing systematic, nothing corrected');
  near(m.maeHi, 2, 1e-9, 'but the honest scatter is still reported');
});

test('the microclimate fit needs its minimum days, and ignores blendless results', () => {
  eq(Verify.microclimate([{ date: 'a', err: {}, blendErr: { hi: 3, lo: 3 } },
                          { date: 'b', err: {}, blendErr: { hi: 3, lo: 3 } }]), null,
    'two days is an anecdote');
  eq(Verify.microclimate([{ date: 'a', err: { gfs_seamless: { hi: 1, lo: 1 } } },
                          { date: 'b', err: {} }, { date: 'c', err: {} }]), null,
    'agency-only history says nothing about the displayed blend');
});

/* ── Vane Insight: the learned consensus and the situational read ───────── */

const FMT = {
  temp: c => Math.round(c) + '°',
  temp0: c => Math.max(1, Math.round(c)) + '°',
  dist: km => Math.round(km) + ' km',
  speed: kmh => Math.round(kmh) + ' km/h',
  clock: ms => new Date(ms).toISOString().slice(11, 16)
};

/* ── On-device summary grounding ────────────────────────────────────────── */

const AFD_TEXT = JSON.parse(fs.readFileSync(path.join(__dirname, 'fixtures', 'afd.json'), 'utf8')).productText;

test('a faithful plain-English point is kept, with the forecaster\'s exact sentence', () => {
  const g = Brief.groundPoint('Isolated thunderstorms may produce damaging wind gusts.', AFD_TEXT);
  eq(g.ok, true);
  eq(g.quote, 'Isolated thunderstorms, some with damaging wind gusts, are possible in northwest and far western Oklahoma this afternoon and evening.');
});

test('a point with a number the forecaster never wrote is dropped', () => {
  const g = Brief.groundPoint('Snow is expected Tuesday with 6 inches.', AFD_TEXT);
  eq(g.ok, false); ok(/number not in the discussion: 6/.test(g.why), g.why);
});

test('a point mostly in other words than the forecaster\'s is dropped', () => {
  // Sounds right, but the discussion never says weekend, index or values.
  const g = Brief.groundPoint('Dangerous heat continues through the weekend with heat index values up to 110.', AFD_TEXT);
  eq(g.ok, false);
});

test('summary bullets are split however the model marks them', () => {
  eq(Brief.bullets('* one thing here\n- another thing\n• third thing!\n1. fourth thing\n\nok').length, 4);
});

test('the discussion splits into its own sentences, bullets included', () => {
  const ss = Brief.sentences(AFD_TEXT);
  ok(ss.indexOf('Heat wave continues with dangerous heat each afternoon.') !== -1);
  ok(!ss.some(x => /^Updated at/.test(x)), 'stamps are not sentences');
});

/* ── The trained storm models ───────────────────────────────────────────── */

const liveCell = over => Cells.parse([{ type: 'Feature', geometry: { type: 'Point', coordinates: [-97.5, 35.4] },
  properties: Object.assign({ nexrad: 'TLX', storm_id: 'A1', tvs: 'NONE', meso: 'NONE', posh: 0, poh: 20,
    max_size: 0.25, vil: 30, max_dbz: 55, max_dbz_height: 18.5, top: 38, drct: 230, sknt: 25,
    valid: '2026-05-06T21:00:00Z' }, over || {}) }])[0];

test('training reads an archive row into exactly the features the app builds live', () => {
  const T = require('../scripts/train/train.js');
  const dir = fs.mkdtempSync(path.join(require('os').tmpdir(), 'vane-'));
  const file = path.join(dir, 'a.csv');
  fs.writeFileSync(file, 'VALID,STORM_ID,NEXRAD,AZIMUTH,RANGE,TVS,MESO,POSH,POH,MAX_SIZE,VIL,MAX_DBZ,MAZ_DBZ_H,TOP,DRCT,SKNT,LAT,LON\n' +
    '202605062100,A1,TLX,200,40,TVS,3,50,90,1.75,62,66,24.5,48.0,230,25,35.4,-97.5\n');
  const row = T.readAttrs(file)[0];
  const live = liveCell({ tvs: 'TVS', meso: '3', posh: 50, poh: 90, max_size: 1.75, vil: 62,
    max_dbz: 66, max_dbz_height: 24.5, top: 48 });
  eq(JSON.stringify(StormModel.featuresOf(row.cell, null).x),
     JSON.stringify(StormModel.featuresOf(live, null).x));
});

test('the trend features need three scans over eight minutes, as everywhere else', () => {
  const c = liveCell(), t0 = Date.parse('2026-05-06T21:00:00Z');
  const two = [{ t: t0, dbz: 50, top: 30 }, { t: t0 + 300000, dbz: 55, top: 32 }];
  eq(StormModel.featuresOf(c, two).hasTrend, false);
  const three = two.concat([{ t: t0 + 600000, dbz: 60, top: 34 }]);
  const f = StormModel.featuresOf(c, three);
  eq(f.hasTrend, true);
  near(f.x[11], 10, 1e-9, '+10 dBZ per 10 min');
  near(f.x[12], 4, 1e-9, '+4 kft per 10 min');
  // Scans older than twenty minutes fall out of the window.
  const old = [{ t: t0 - 30 * 60000, dbz: 20, top: 10 }].concat(three);
  near(StormModel.featuresOf(c, old).x[11], 10, 1e-9);
});

test('every shipped model beat its baseline on days it never saw', () => {
  const W = StormModelWeights;
  ok(W.meta.days >= 30 && W.meta.heldOutDays >= 6, 'a real sample, really held out');
  if (W.intensity.ship) ok(W.intensity.eval.maeModel < W.intensity.eval.maePersistence &&
    W.intensity.eval.maeModel < W.intensity.eval.maeTrend, 'intensity beat persistence and trend');
  if (W.severe.ship) ok(W.severe.eval.bss > 0, 'severe beat climatology');
  eq(W.intensity.use.length, StormModel.FEATURES.length, 'intensity uses every feature');
  ok(W.severe.use.every(i => i < 11), 'severe uses no trend column: it speaks from one scan');
});

test('the intensity outlook waits for a trend; the severe probability does not', () => {
  const c = liveCell(), t0 = Date.parse('2026-05-06T21:00:00Z');
  eq(StormModel.intensity(c, null), null);
  const rising = [0, 1, 2, 3].map(k => ({ t: t0 + k * 300000, dbz: 45 + 3 * k, top: 30 + k }));
  const it = StormModel.intensity(c, rising);
  ok(it && it.dbzNow === 55 && Math.abs(it.delta) <= 25, JSON.stringify(it));
  const p = StormModel.severe(c);
  ok(p > 0 && p < 1, 'a probability');
});

test('the severe probability rises with the radar\'s own rotation and hail signals', () => {
  const plain = StormModel.severe(liveCell({ max_dbz: 50, vil: 15, poh: 10, max_size: 0, top: 25 }));
  const nasty = StormModel.severe(liveCell({ tvs: 'TVS', meso: '6', posh: 80, poh: 100, max_size: 2.5,
    vil: 70, max_dbz: 68, top: 50 }));
  ok(nasty > plain * 3, plain.toFixed(3) + ' → ' + nasty.toFixed(3));
});

test('outlooks are graded against the scan twenty minutes on, beside no-change', () => {
  StormModel.resetSession();
  const t0 = Date.parse('2026-05-06T21:00:00Z');
  StormModel.note('TLX-A1', t0, { dbzNow: 55, dbz20: 60 });
  StormModel.note('TLX-A1', t0, { dbzNow: 55, dbz20: 60 });       // same scan again: one call
  StormModel.grade(() => [{ t: t0 + 10 * 60000, dbz: 58 }]);
  eq(StormModel.sessionSkill().n, 0, 'window not reached yet');
  StormModel.grade(() => [{ t: t0 + 21 * 60000, dbz: 62 }]);
  const sk = StormModel.sessionSkill();
  eq(sk.n, 1); eq(sk.mae, 2); eq(sk.maePersist, 7);
  StormModel.resetSession();
});

test('hail probabilities are coherent and rise with the radar\'s hail signals', () => {
  const small = StormModel.hail(liveCell({ posh: 0, poh: 20, max_size: 0.25, vil: 20, max_dbz: 52 }));
  const big = StormModel.hail(liveCell({ posh: 90, poh: 100, max_size: 2.75, vil: 75, max_dbz: 68, top: 52 }));
  ok(small && big, 'models shipped');
  ok(big.p1 > small.p1 * 3, small.p1.toFixed(3) + ' → ' + big.p1.toFixed(3));
  ok(big.p175 <= big.p1 && small.p175 <= small.p1, 'golf ball+ never above 1″+');
});

test('shipped hail and track models beat their baselines on held-out days', () => {
  const W = StormModelWeights;
  ['hail1', 'hail175'].forEach(k => { if (W[k].ship) ok(W[k].eval.bss > 0 && W[k].eval.auc > W[k].eval.aucBaseline, k); });
  ['single', 'watched'].forEach(k => {
    const e = W.track[k].eval;
    if (W.track[k].ship) ok(e.kmModel < e.kmStraightLine && (e.kmObserved === null || e.kmModel < e.kmObserved), k);
  });
});

test('track features: the table\'s straight line, and the motion actually observed', () => {
  // From the west at 20 kt: ~18.5 km east in 30 minutes.
  const c = liveCell({ drct: 270, sknt: 20 });
  const f = StormModel.trackFeaturesOf(c, null);
  near(f.scitE, 18.52, 0.01); near(f.scitN, 0, 1e-9); eq(f.hasObs, false);
  const t0 = Date.parse('2026-05-06T21:00:00Z');
  const h = [{ t: t0 - 10 * 60000, lat: 35.4 - 0.05, lon: -97.5 }, { t: t0, lat: 35.4, lon: -97.5 }];
  const g = StormModel.trackFeaturesOf(c, h);
  eq(g.hasObs, true);
  near(g.obsN, 0.05 * 111.32 * 3, 0.01, 'moved north 5.6 km in 10 min');
  near(g.obsE, 0, 1e-9);
});

test('the corrected track drives closest approach, and the heading follows it', () => {
  const c = liveCell({ drct: 270, sknt: 20 });
  const before = Cells.approach(c, 35.4, -97.0);
  c.modelMotion = { east: 0, north: 40, speedKmh: 40 };      // the model says due north
  const after = Cells.approach(c, 35.4, -97.0);
  near(before.towardDeg, 90, 1e-6);
  near(after.towardDeg, 0, 1e-6);
  ok(before.approaching && !after.approaching, 'a pin to the east is no longer in its path');
  const to = Cells.project(c, 30);
  near(to.lat - c.lat, 20 / 111.32, 1e-9);
});

test('tracks are graded against the scan thirty minutes on, beside the straight line', () => {
  StormModel.resetSession();
  const t0 = Date.parse('2026-05-06T21:00:00Z');
  StormModel.noteTrack('TLX-A1', t0, { lat: 35.5, lon: -97.5 }, { lat: 35.4, lon: -97.3 });
  StormModel.grade(() => [{ t: t0 + 30 * 60000, lat: 35.5, lon: -97.5, dbz: 50 }]);
  const sk = StormModel.sessionSkill().track;
  eq(sk.n, 1); near(sk.km, 0, 1e-9);
  ok(sk.kmStraight > 20, 'the straight line was ' + sk.kmStraight.toFixed(1) + ' km off');
  StormModel.resetSession();
});

/* ── Notifications that learn ───────────────────────────────────────────── */

const outcomes = (store, kind, opens, dismisses) => {
  for (let i = 0; i < opens; i++) NotifyLearn.recordOutcome(store, kind, 'open');
  for (let i = 0; i < dismisses; i++) NotifyLearn.recordOutcome(store, kind, 'dismiss');
  return store;
};

test('two dismissals are not a pattern; five unread heads-ups go quiet', () => {
  const s = NotifyLearn.empty();
  outcomes(s, 'rain', 0, 2);
  eq(NotifyLearn.policy(s, 'rain').quiet, false, 'not before five outcomes');
  outcomes(s, 'rain', 0, 3);
  eq(NotifyLearn.policy(s, 'rain').quiet, true, '0 of 5 opened');
  near(NotifyLearn.policy(s, 'rain').engagement, 1 / 7, 1e-9, 'smoothed open rate');
});

test('opening them again brings them back; "back to normal" sticks', () => {
  const s = outcomes(NotifyLearn.empty(), 'spc', 0, 6);
  eq(NotifyLearn.policy(s, 'spc').quiet, true);
  outcomes(s, 'spc', 4, 0);                          // (4+1)/(10+2) > 0.4
  eq(NotifyLearn.policy(s, 'spc').quiet, false, 'restored by use');
  const p = outcomes(NotifyLearn.empty(), 'rain', 0, 8);
  p.kinds.rain.quiet = false; p.kinds.rain.pinned = true;
  outcomes(p, 'rain', 0, 8);
  eq(NotifyLearn.policy(p, 'rain').quiet, false, 'pinned: never re-quieted');
});

test('official alerts never quiet themselves — they are only ever suggested', () => {
  const s = outcomes(NotifyLearn.empty(), 'alert:flood', 0, 9);
  eq(NotifyLearn.policy(s, 'alert:flood').quiet, false);
  eq(NotifyLearn.alertAllowed(s, 'flood', 3), true, 'not muted until the user says so');
  const sg = NotifyLearn.suggestions(s);
  eq(sg.length, 1); eq(sg[0].family, 'flood'); eq(sg[0].dismiss, 9);
  eq(NotifyLearn.suggestions(outcomes(NotifyLearn.empty(), 'alert:heat', 3, 3)).length, 0,
    'opened half the time: no suggestion');
});

test('a muted family still lets Extreme alerts through', () => {
  const s = NotifyLearn.empty();
  s.mute.tornado = true;
  eq(NotifyLearn.alertAllowed(s, 'tornado', 3), false, 'Severe: muted');
  eq(NotifyLearn.alertAllowed(s, 'tornado', 4), true, 'Extreme: always');
  eq(NotifyLearn.suggestions(outcomes(s, 'alert:tornado', 0, 9)).length, 0, 'already muted');
});

test('quiet rain heads-ups need heavier rain, closer in', () => {
  const now = Date.now(), fit = (minutes, dbz) => ({ stationary: false, eta: { minutes, dbz } });
  eq(Settings.shouldNotifyMotion(fit(30, 40), 0, now, false), true, 'normal: 30 min out is fine');
  eq(Settings.shouldNotifyMotion(fit(30, 40), 0, now, true), false, 'quiet: too far out');
  eq(Settings.shouldNotifyMotion(fit(15, 30), 0, now, true), false, 'quiet: too light');
  eq(Settings.shouldNotifyMotion(fit(15, 40), 0, now, true), true, 'quiet: heavy and close');
});

test('quiet outlook notices wait for Enhanced', () => {
  eq(!!Settings.outlookNotifyPick(null, '2026-10-03', 1, { rank: 3 }), true, 'Slight, normally');
  eq(Settings.outlookNotifyPick(null, '2026-10-03', 1, { rank: 3 }, 4), null, 'Slight, quiet');
  eq(!!Settings.outlookNotifyPick(null, '2026-10-03', 1, { rank: 4 }, 4), true, 'Enhanced, quiet');
});

/* ── Rain chances, calibrated here ─────────────────────────────────────── */

test('present weather: rain on you counts, rain in the vicinity and dry thunder do not', () => {
  ['-RA', 'RA', '+TSRA', '-SHSN', 'RA BR', '-RADZ', 'FZDZ', 'GR', 'UP', 'BR -RA'].forEach(w =>
    ok(RainCal.wetCodes(w), w + ' is wet'));
  ['M', '', 'BR', 'FG', 'VCSH', 'VCTS', 'TS', 'HZ', 'VCTSRA', null].forEach(w =>
    ok(!RainCal.wetCodes(w), w + ' is not'));
});

test('the station CSV becomes one wet-or-dry verdict per reported hour', () => {
  const csv = 'station,valid,wxcodes,p01m\n' +
    'OUN,2026-09-20 12:15,M,0.00\nOUN,2026-09-20 12:55,-RA,0.00\n' +   // 12Z: wet by code
    'OUN,2026-09-20 13:55,M,0.51\n' +                                     // 13Z: wet by amount
    'OUN,2026-09-20 14:55,VCSH,0.00\n' +                                  // 14Z: dry
    'OUN,2026-09-20 15:55,M,0.10\n';                                      // 15Z: trace, dry
  const h = RainCal.hourlyWet(csv), at = hh => Date.parse('2026-09-20T' + hh + ':00:00Z');
  eq(h[at('12')], true); eq(h[at('13')], true); eq(h[at('14')], false); eq(h[at('15')], false);
  eq(at('16') in h, false, 'an hour with no report has no verdict');
});

test('only chances shown six to forty-eight hours ahead are recorded, the latest one sticking', () => {
  const now = Date.parse('2026-10-03T12:00:00Z');
  const hourly = { time: ['2026-10-03T14:00', '2026-10-03T20:00', '2026-10-05T20:00'],
                   precipitation_probability: [90, 40, 70] };
  let s = RainCal.recordInto(RainCal.empty('k'), 'k', hourly, 0, now);
  eq(Object.keys(s.pending).length, 1, '2 h ahead is too near, 56 h too far');
  eq(s.pending[Date.parse('2026-10-03T20:00:00Z')], 40);
  s = RainCal.recordInto(s, 'k', { time: hourly.time, precipitation_probability: [90, 60, 70] },
    0, now + 30 * 60000);
  eq(s.pending[Date.parse('2026-10-03T20:00:00Z')], 60, 'a later forecast overwrites');
});

test('verified hours land in their 10% band; unreported hours wait, then expire', () => {
  const t0 = Date.parse('2026-10-01T00:00:00Z');
  const s = RainCal.empty('k');
  s.pending[t0] = 42; s.pending[t0 + 3600000] = 47; s.pending[t0 + 7200000] = 45;
  s.pending[t0 - 5 * 86400000] = 30;                 // ancient, never reported
  const changed = RainCal.settleInto(s, { [t0]: true, [t0 + 3600000]: false }, t0 + 86400000, 'KOUN');
  eq(changed, true);
  eq(s.bins[4].n, 2); eq(s.bins[4].wet, 1);
  eq(Object.keys(s.pending).map(Number).join(), String(t0 + 7200000), 'no report yet: still waiting');
  eq(s.station, 'KOUN');
});

test('a band says nothing before twenty hours, then shrinks toward the forecast', () => {
  const s = RainCal.empty('k');
  s.bins[6] = { n: 19, wet: 2, popSum: 19 * 65 };
  eq(RainCal.calibrate(65, s), null, 'nineteen hours is not enough');
  s.bins[6] = { n: 40, wet: 8, popSum: 40 * 65 };    // rained 20% of the time
  const c = RainCal.calibrate(65, s);
  eq(c.raw, 20);
  eq(c.observed, Math.round(100 * (8 + 10 * 0.65) / 50), 'shrunk as if ten hours agreed with 65%');
  const r = RainCal.reliability(s);
  eq(r.rows[0].forecast, 65); eq(r.rows[0].observed, 20); eq(r.rows[0].ready, true);
});

test('Insight states the calibrated chance with its evidence, and admits agreement', () => {
  const at = Date.parse('2026-10-03T20:00:00Z');
  const wet = Insight.compose({ rainCal: { cal: { pop: 60, observed: 31, n: 44 }, station: 'KOUN', at } }, FMT);
  const line = wet.find(l => l.tag === 'Rain chances');
  ok(line && /gives 60% around 20:00/.test(line.text) && /only seen rain 31% of the time/.test(line.text) &&
     /44 hours checked against KOUN/.test(line.text), line && line.text);
  const fair = Insight.compose({ rainCal: { cal: { pop: 40, observed: 43, n: 30 }, station: 'EGLL', at } }, FMT);
  ok(/verified about right here: rain in 43%/.test(fair.find(l => l.tag === 'Rain chances').text));
});

/* ── The weather-aware microclimate ─────────────────────────────────────── */

test('a day\'s regime: sky from mean cloud, wind by quarter', () => {
  eq(JSON.stringify(Verify.regimeOf(10, 180)), '{"sky":"clear","wind":"south"}');
  eq(JSON.stringify(Verify.regimeOf(50, 350)), '{"sky":"partly cloudy","wind":"north"}');
  eq(JSON.stringify(Verify.regimeOf(90, 260)), '{"sky":"cloudy","wind":"west"}');
  eq(Verify.regimeOf(null, null), null);
});

test('the regime rides from forecast to verified day', () => {
  const data = { utc_offset_seconds: 0, daily: { time: ['2026-10-03', '2026-10-04'],
    temperature_2m_max: [20, 22], temperature_2m_min: [10, 12],
    cloud_cover_mean: [10, 85], wind_direction_10m_dominant: [180, 90] } };
  const s = Verify.recordBlendInto(Verify.emptyStore('k'), 'k', data, '2026-10-03');
  eq(s.pending['2026-10-04'].blend.sky, 85);
  Verify.settleResult(s, '2026-10-04', 'KOUN', { hi: 21, lo: 11, n: 24 });
  eq(JSON.stringify(s.results[0].regime), '{"sky":"cloudy","wind":"east"}');
});

// Verified days with a chosen lean per sky regime (forecast minus observed).
const regimeDays = spec => {
  const out = [];
  spec.forEach(([sky, hi, lo, n]) => { for (let i = 0; i < n; i++) {
    const wob = (i % 3 - 1) * 0.3;     // a little day-to-day noise
    out.push({ blendErr: { hi: hi + wob, lo: lo - wob }, regime: { sky, wind: 'south' } });
  } });
  return out;
};

test('when the sky explains the lean, the weather-aware fit earns its place', () => {
  // Cloudy days run 3° warm on highs; clear days run true.
  const days = regimeDays([['cloudy', 3, 0.5, 8], ['clear', 0, 0.5, 8]]);
  const fit = Verify.regimeFit(days);
  eq(fit.ready, true);
  ok(fit.wins && fit.looAware < fit.looPlain, `aware ${fit.looAware.toFixed(2)} vs plain ${fit.looPlain.toFixed(2)}`);
  const cloudy = Verify.regimeCorrection(fit, { sky: 'cloudy', wind: 'south' });
  const clear = Verify.regimeCorrection(fit, { sky: 'clear', wind: 'south' });
  ok(cloudy.corrHi < -2 && clear.corrHi > -1, `cloudy ${cloudy.corrHi.toFixed(2)}, clear ${clear.corrHi.toFixed(2)}`);
  eq(cloudy.top.factor, 'sky'); eq(cloudy.top.level, 'cloudy');
});

test('when the regime explains nothing, the plain correction stands', () => {
  // The same 2° warm lean whatever the sky: no regime to learn.
  const days = regimeDays([['cloudy', 2, 1, 8], ['clear', 2, 1, 8]]);
  const fit = Verify.regimeFit(days);
  eq(fit.wins, false);
  eq(Verify.regimeCorrection(fit, { sky: 'cloudy', wind: 'south' }), null);
});

test('no weather-aware verdict before ten days with a regime', () => {
  const fit = Verify.regimeFit(regimeDays([['cloudy', 3, 0, 5], ['clear', 0, 0, 4]]));
  eq(fit.ready, false); eq(fit.need, 10);
});

/* ── Chase-day odds ───────────────────────────────────────────────────── */

test('chase-day features: the vector the model was trained on', () => {
  const x = ChaseDay.featuresOf({ cape: 2000, cin: -50, shear6: 20, srh1: 150, srh3: 250, lcl: 1200 });
  eq(x.length, ChaseDay.FEATURES.length);
  near(x[0], Math.log(2001), 1e-9);
  eq(x[1], 50);                               // CIN by magnitude, either sign
  eq(x[2], 20); eq(x[3], 150); eq(x[4], 250);
  near(x[5], 1.2, 1e-9);                      // LCL in km
  near(x[6], Math.sqrt(4000) * 20 / 100, 1e-9); // WMAXSHEAR, scaled
  eq(ChaseDay.featuresOf({ cape: 0, cin: -900, shear6: 0 })[1], 300);   // CIN capped
});

test('chase-day odds: none without the model or the inputs', () => {
  eq(ChaseDay.odds(null), null);
  eq(ChaseDay.odds({ cape: 1000 }), null);                 // no shear
  eq(ChaseDay.odds({ shear6: 20 }), null);                 // no CAPE
  eq(ChaseDay.envFromConvective(null), null);
  const env = ChaseDay.envFromConvective({ cape: 1500, cin: -20, shear6: { magnitude: 18 }, srh1: 100, srh3: 180, lcl: 900 });
  eq(env.shear6, 18);
  const saved = sandbox.ChaseDayWeights;
  sandbox.ChaseDayWeights = Object.assign({}, saved, { ship: false });
  eq(ChaseDay.odds(env), null);                             // a model that lost never speaks
  sandbox.ChaseDayWeights = saved;
  const p = ChaseDay.odds(env);
  ok(p > 0 && p < 1, `p ${p}`);
});

test('chase-day odds rise with the environment', () => {
  const quiet = ChaseDay.odds({ cape: 50, cin: -150, shear6: 5, srh1: 10, srh3: 20, lcl: 2500 });
  const loaded = ChaseDay.odds({ cape: 3500, cin: -10, shear6: 28, srh1: 250, srh3: 350, lcl: 900 });
  ok(loaded > 2 * quiet, `loaded ${loaded.toFixed(3)} vs quiet ${quiet.toFixed(3)}`);
  ok(quiet < 0.1, `quiet ${quiet.toFixed(3)}`);
});

test('the shipped chase-day model beat its baselines on days it never saw', () => {
  const W = ChaseDayWeights, E = W.eval;
  eq(W.w.length, ChaseDay.FEATURES.length);
  eq(W.mean.length, W.w.length); eq(W.std.length, W.w.length);
  ok(W.std.every(s => s > 0), 'positive spreads');
  eq(W.ship, true);
  ok(E.bss > 0, `BSS ${E.bss}`);
  ok(E.auc > E.aucWmaxshear && E.auc > E.aucIndex, `AUC ${E.auc} vs ${E.aucWmaxshear} / ${E.aucIndex}`);
  ok(E.heldOutDays >= 30 && E.testN >= 1000, 'a real held-out set');
});

/* ── Radar: birds, bugs and wind farms are not rain ─────────────────── */

test('each mosaic frame is masked by MRMS at its own time', () => {
  const t = Date.UTC(2026, 9, 6, 2, 47, 30);
  // The 5-minute mosaic now is valid at 02:45; MRMS archives even minutes → 02:44.
  ok(Radar.maskFor(t).includes('mrms::lcref-202610060244/'), Radar.maskFor(t));
  ok(Radar.maskFor(Date.UTC(2026, 9, 6, 2, 41)).includes('lcref-202610060240/'), 'valid 02:40, an even minute');
});

test('the mask clears what MRMS does not see, widened so storm edges survive', () => {
  const w = 20, h = 20, raw = new Uint8Array(w * h * 4), mask = new Uint8Array(w * h * 4);
  const px = (a, x, y) => (y * w + x) * 4 + 3;
  // Raw: a speck at (2,2) MRMS does not see (a wind turbine), and a storm at (12,12).
  raw[px(raw, 2, 2)] = 255; raw[px(raw, 12, 12)] = 255; raw[px(raw, 15, 12)] = 255;
  mask[px(mask, 12, 12)] = 255;                      // MRMS sees the storm, not the speck
  const cleared = Radar.applyMask(raw, mask, w, h, 3);
  eq(cleared, 1);
  eq(raw[px(raw, 2, 2)], 0, 'the speck is gone');
  eq(raw[px(raw, 12, 12)], 255, 'the storm stays');
  eq(raw[px(raw, 15, 12)], 255, 'and its edge, 3 px out, within the widened mask');
});

test('the widening is about 2 km at any zoom', () => {
  eq(Radar.maskRadius(7, 41.6), 3);     // ~920 m per pixel
  eq(Radar.maskRadius(10, 41.6), 18);   // ~115 m per pixel
  eq(Radar.maskRadius(14, 41.6), 24, 'capped');
});

/* ── "It says rain Friday and my other apps don't" ──────────────────── */

test('a day shows rain only when rain is likely — real cases from the report', () => {
  const L = Derive.likelyIcon;
  // Friday 9 Oct 2026, best-match daily codes beside their chances.
  eq(L(51, 1, 0.2, 85, false), 3, 'St. Louis: drizzle code at 1%, 0.2 mm → overcast');
  eq(L(51, 6, 0.1, 50, false), 2, 'Denver: 6% → partly cloudy');
  eq(L(51, 4, 0.1, 10, false), 0, 'San Antonio: 4% under clear skies → clear');
  eq(L(51, 28, 0.4, 90, false), 3, 'Seattle: 28% but a trace → cloudy, with the 28% still shown');
  eq(L(81, 52, 10.1, 90, false), 81, 'New Orleans: 52%, 10 mm → showers');
  eq(L(55, 27, 4.5, 90, false), 55, 'Omaha: 27% with 4.5 mm behind it → drizzle kept');
});

test('thunder keeps its icon from a 20% chance; dry codes are never touched', () => {
  const L = Derive.likelyIcon;
  eq(L(95, 20, 0, 60, false), 95, 'slight chance of storms');
  eq(L(95, 10, 0, 60, false), 2);
  eq(L(3, 0, 0, 90, false), 3); eq(L(45, 0, 0, 100, false), 45, 'fog is not rain');
  eq(L(null, 50, 5, 50, false), null);
  eq(L(61, null, 3, 80, false), 61, 'no chance given: a real amount keeps rain');
  eq(L(61, null, 0.2, 80, false), 3, 'no chance given: a trace does not');
  eq(L(61, 10, 0, null, false), 2, 'no cloud cover: partly cloudy');
});

test('an hour uses hourly thresholds', () => {
  const L = Derive.likelyIcon;
  eq(L(61, 25, 0.6, 90, true), 61, '25% with 0.6 mm in the hour');
  eq(L(61, 25, 0.6, 90, false), 3, 'the same numbers are a trace for a whole day');
  eq(L(80, 35, 0, 70, true), 80);
});

/* ── Field layers: smooth, and only where a model was trained ───────── */

test('grid fields interpolate bilinearly: no plateaus, no pillars', () => {
  const pt = (temp, cape, o) => ({ lat: 0, lon: 0, u: 0, v: 0, temp, cape, odds: [o] });
  const saved = { grid: Layers.state.grid, lattice: Layers.state.lattice, idx: Layers.state.oddsIdx };
  // A 2×2 lattice, south-west first, west to east then south to north.
  Layers.state.grid = [pt(0, 0, 0.01), pt(10, 1000, 0.03), pt(20, 2000, 0.05), pt(30, 3000, null)];
  Layers.state.lattice = { s: 30, n: 31, w: -100, e: -99, nx: 2, ny: 2 };
  Layers.state.oddsIdx = 0;
  near(Layers.sample(30.5, -99.5).temp, 15, 1e-9);                 // the centre is the mean
  near(Layers.sample(30, -99.75).temp, 2.5, 1e-9);                 // linear along an edge
  near(Layers.sample(30.25, -100).cape, 500, 1e-9);
  // Odds missing at one corner: the rest re-weighted, while they carry the weight…
  near(Layers.sample(30, -100).odds, 0.01, 1e-9);
  // …and nothing drawn where most of the weight is missing.
  eq(Layers.sample(31, -99).odds, null);
  eq(Layers.sample(29.9, -99.5), null, 'outside the lattice');
  Layers.state.grid = saved.grid; Layers.state.lattice = saved.lattice; Layers.state.oddsIdx = saved.idx;
});

test('the population grid reads people near a point, and draws the US border', () => {
  const G = PopGrid.GRID, data = new Uint8Array(G.rows * G.cols * 4);
  const cell = (lat, lon) => ((G.rows - 1 - Math.floor((lat - G.lat0) / G.step)) * G.cols + Math.floor((lon - G.lon0) / G.step)) * 4;
  data[cell(35.47, -97.52)] = 170; data[cell(35.47, -97.52) + 1] = 204;   // Oklahoma City
  const v = PopGrid.at({ data }, 35.47, -97.52);
  near(v.p10, 170 / 255 * 7.5, 1e-9); near(v.p40, 204 / 255 * 7.5, 1e-9);
  ok(PopGrid.inUS({ data }, 35.47, -97.52));
  ok(!PopGrid.inUS({ data }, 20.67, -103.35), 'Guadalajara: on the grid, no US residents');
  eq(PopGrid.at({ data }, 51.5, -0.1), null, 'London: off the grid');
});

test('the shipped population grid is the US, not an empty file', () => {
  const png = fs.readFileSync(path.join(__dirname, '..', 'data', 'popgrid.png'));
  eq(png.slice(1, 4).toString(), 'PNG');
  eq(png.readUInt32BE(16), PopGrid.GRID.cols); eq(png.readUInt32BE(20), PopGrid.GRID.rows);
  ok(png.length > 50000, 'a real grid');
});

test('the Docker image ships every file the service worker caches', () => {
  const docker = fs.readFileSync(path.join(__dirname, '..', 'Dockerfile'), 'utf8');
  const copied = [];
  docker.split('\n').forEach(l => { const m = /^COPY\s+(.+?)\s+\/usr\/share\/nginx\/html/.exec(l); if (m) copied.push(...m[1].split(/\s+/)); });
  // Files only: './notify-log' and the like are cache keys, not paths.
  const shell = (fs.readFileSync(path.join(__dirname, '..', 'sw.js'), 'utf8').match(/'\.\/[^']+'/g) || [])
    .map(q => q.slice(3, -1)).filter(f => /\.\w+$/.test(f));
  const missing = shell.filter(f => !copied.some(c => c.endsWith('/') ? f.startsWith(c) : f === c));
  eq(missing.join(', '), '', 'every cached path is in the image');
});

/* ── Vane Storm Odds ─────────────────────────────────────────────────── */

const stormEnv = (o) => Object.assign({ cape: 0, cin: 0, li: 5, td: 10, pwat: 15,
  u10: 0, v10: 0, u850: 0, v850: 0, u500: 0, v500: 0 }, o);

test('storm odds features: what the model was trained on', () => {
  const x = StormOdds.featuresOf(stormEnv({ cape: 2000, cin: -80, li: -6, td: 20, pwat: 40,
    u10: 0, v10: 5, u850: 0, v850: 15, u500: 20, v500: 5 }), Date.UTC(2024, 4, 6, 22), -97.5);
  eq(x.length, StormOdds.FEATURES.length);
  near(x[0], Math.log(2001), 1e-9);
  eq(x[1], 80);                                   // CIN by magnitude, either sign
  eq(x[2], -6); eq(x[3], 20); eq(x[4], 40);
  near(x[5], 20, 1e-9);                           // |V500 − V10| = (20, 0)
  near(x[6], 15, 1e-9); near(x[7], Math.hypot(20, 5), 1e-9);
  near(x[8], Math.sqrt(4000) * 20 / 100, 1e-9);   // WMAXSHEAR, scaled
  // 22Z at 97.5°W is ~15:30 local solar time.
  const h = 22 - 97.5 / 15;
  near(x[9], Math.sin(2 * Math.PI * h / 24), 1e-9); near(x[10], Math.cos(2 * Math.PI * h / 24), 1e-9);
});

test('storm odds read Open-Meteo hours the same way the training read HRRR', () => {
  // Open-Meteo: speed + FROM-direction. A 10 m/s wind from the west at 500 hPa
  // over a calm surface is 10 m/s of shear, whatever the frame.
  const hourly = { time: ['2024-05-06T22:00'], cape: [1500], convective_inhibition: [20], lifted_index: [-4],
    dew_point_2m: [18], total_column_integrated_water_vapour: [35], wind_speed_10m: [0], wind_direction_10m: [0],
    wind_speed_850hPa: [12], wind_direction_850hPa: [180], wind_speed_500hPa: [10], wind_direction_500hPa: [270] };
  const env = StormOdds.envFromHourly(hourly, 0);
  near(env.u500, 10, 1e-9); near(env.v500, 0, 1e-9);           // from the west → toward the east
  near(env.v850, 12, 1e-9);                                     // from the south → toward the north
  const x = StormOdds.featuresOf(env, Date.UTC(2024, 4, 6, 22), -97.5);
  near(x[5], 10, 1e-9);
  const ser = StormOdds.series(hourly, -97.5);
  eq(ser.length, 1); eq(ser[0].at, Date.UTC(2024, 4, 6, 22));
  ok(ser[0].p > 0 && ser[0].p < 1);
  eq(StormOdds.at(ser, Date.UTC(2024, 4, 6, 23)).at, ser[0].at);
  eq(StormOdds.at(ser, Date.UTC(2024, 4, 7, 2)), null, 'not an hour 4 hours away');
});

test('storm odds: none without a model or the inputs', () => {
  eq(StormOdds.odds(null, 0, 0), null);
  eq(StormOdds.odds(stormEnv({ cape: null }), 0, 0), null);
  eq(StormOdds.odds(stormEnv({ u500: null }), 0, 0), null);
  eq(StormOdds.envFromHourly({ time: ['x'], wind_speed_500hPa: [null] }, 0), null);
  const saved = sandbox.StormOddsWeights;
  sandbox.StormOddsWeights = Object.assign({}, saved, { ship: false });
  eq(StormOdds.odds(stormEnv({ cape: 3000 }), 0, -97), null, 'a model that lost never speaks');
  sandbox.StormOddsWeights = saved;
});

test('storm odds rise with a loaded afternoon and fall on a stable night', () => {
  const afternoon = Date.UTC(2024, 4, 6, 22), night = Date.UTC(2024, 4, 6, 11);
  const loaded = StormOdds.odds(stormEnv({ cape: 3500, cin: -10, li: -9, td: 22, pwat: 45,
    v10: 6, v850: 18, u500: 25, v500: 5 }), afternoon, -97.5);
  const stable = StormOdds.odds(stormEnv({ cape: 0, cin: -200, li: 8, td: 5, pwat: 10,
    u500: 10 }), night, -97.5);
  ok(loaded > 0.05, `loaded ${loaded.toFixed(4)}`);
  ok(stable < 0.002, `stable ${stable.toFixed(5)}`);
  ok(loaded > 30 * stable, 'orders of magnitude apart');
});

test('the shipped storm odds model beat CAPE and CAPE × shear on days it never saw', () => {
  const W = StormOddsWeights, E = W.eval;
  eq(W.ship, true);
  eq(W.mean.length, StormOdds.FEATURES.length); eq(W.std.length, StormOdds.FEATURES.length);
  ok(W.std.every(s => s > 0), 'positive spreads');
  if (W.kind === 'mlp') { eq(W.W1[0].length, StormOdds.FEATURES.length); eq(W.w2.length, W.b1.length); }
  else eq(W.w.length, StormOdds.FEATURES.length);
  ok(E.bss > 0, `BSS ${E.bss}`);
  ok(E.auc > E.aucCape && E.auc > E.aucWmaxshear, `AUC ${E.auc} vs ${E.aucCape} / ${E.aucWmaxshear}`);
  ok(E.unstable.auc > E.unstable.aucWmaxshear && E.unstable.auc > E.unstable.aucCape,
    `where CAPE ≥ 500: ${E.unstable.auc} vs ${E.unstable.aucWmaxshear} / ${E.unstable.aucCape}`);
  ok(E.heldOutDays >= 10 && E.testPositives >= 500, 'a real held-out set');
});

/* ── Storm reports, every kind ──────────────────────────────────────────── */

test('every NWS report type lands in a sensible kind', () => {
  const cases = {
    'TORNADO': 'tornado', 'LANDSPOUT': 'tornado', 'FUNNEL CLOUD': 'funnel', 'WATERSPOUT': 'funnel',
    'HAIL': 'hail', 'MARINE HAIL': 'hail', 'TSTM WND GST': 'wind', 'TSTM WND DMG': 'wind',
    'NON-TSTM WND GST': 'wind', 'HIGH SUST WINDS': 'wind', 'MARINE TSTM WIND': 'wind', 'DOWNBURST': 'wind',
    'FLASH FLOOD': 'flood', 'FLOOD': 'flood', 'COASTAL FLOOD': 'flood', 'HEAVY RAIN': 'flood', 'RAIN': 'flood',
    'SNOW': 'winter', 'HEAVY SNOW': 'winter', 'BLIZZARD': 'winter', 'SLEET': 'winter',
    'FREEZING RAIN': 'winter', 'ICE STORM': 'winter',
    'LIGHTNING': 'other', 'LANDSLIDE': 'other', 'DUST STORM': 'other', 'WILDFIRE': 'other',
    'EXTR WIND CHILL': 'other', 'DENSE FOG': 'other'
  };
  Object.keys(cases).forEach(t => eq(API.reportCategory(t), cases[t], t));
});

test('a report\'s size reads with its unit and how it was known', () => {
  eq(API.reportMagnitude({ magf: 1.75, unit: 'Inch', qualifier: 'E' }), '1.75″ (est.)');
  eq(API.reportMagnitude({ magf: 2, unit: 'Inch', qualifier: 'M' }), '2.0″ (measured)');
  eq(API.reportMagnitude({ magf: 70, unit: 'MPH', qualifier: 'M' }), '70 mph (measured)');
  eq(API.reportMagnitude({ magf: null, magnitude: '', unit: null }), '', 'no size, no text');
});

test('the real busy day parses into every kind, nothing dropped', () => {
  const r = API.lsrReports(JSON.parse(fs.readFileSync(path.join(__dirname, 'fixtures', 'lsr.geojson'), 'utf8')));
  eq(r.length, 197);
  const kinds = new Set(r.map(x => x.category));
  eq([...kinds].sort().join(), 'flood,funnel,hail,other,tornado,wind,winter');
  ok(r.every(x => x.at && isFinite(x.lat) && x.kind), 'time, place and kind on every report');
  ok(r.some(x => x.kind === 'Thunderstorm Wind Damage'), 'abbreviations expanded');
});

test('a report keeps its number, unit, office and product for the popup', () => {
  const r = API.lsrReports(JSON.parse(fs.readFileSync(path.join(__dirname, 'fixtures', 'lsr.geojson'), 'utf8')));
  const gust = r.find(x => x.location === '3 WSW Nemaha');
  eq(gust.magValue, 64); eq(gust.magUnit, 'mph'); eq(gust.wfo, 'OAX');
  eq(gust.productId, '202405071229-KOAX-NWUS53-LSROAX');
  ok(r.filter(x => x.category === 'hail').every(x => x.magUnit === 'in'), 'hail in inches');
});

test('hail reads against the spotter yardsticks', () => {
  eq(SPC.hailSize(1), 'quarter size'); eq(SPC.hailSize(1.75), 'golf ball size');
  eq(SPC.hailSize(0.88), 'nickel size'); eq(SPC.hailSize(2.75), 'baseball size');
  eq(SPC.hailSize(1.1), 'larger than quarter size'); eq(SPC.hailSize(0.1), 'smaller than a pea');
  eq(SPC.hailSize(null), null);
});

test('severe and significant by SPC criteria, and only for storms', () => {
  const sev = (category, kind, v, u) => (SPC.severity({ category, kind, magValue: v, magUnit: u }) || {}).level || null;
  eq(sev('hail', 'Hail', 0.75, 'in'), null);
  eq(sev('hail', 'Hail', 1, 'in'), 'severe');
  eq(sev('hail', 'Hail', 2, 'in'), 'sig');
  eq(sev('wind', 'Thunderstorm Wind Gust', 57, 'mph'), null);
  eq(sev('wind', 'Thunderstorm Wind Gust', 58, 'mph'), 'severe');
  eq(sev('wind', 'Thunderstorm Wind Gust', 50, 'kt'), 'severe');
  eq(sev('wind', 'Thunderstorm Wind Gust', 75, 'mph'), 'sig');
  eq(sev('wind', 'Non-Thunderstorm Wind Gust', 70, 'mph'), null, 'a gradient wind is not a severe storm report');
  eq(sev('tornado', 'Tornado', null, null), 'tornado');
  eq(sev('flood', 'Flash Flood', null, null), null);
});

test('the report popup: size, criteria, distance, time, remarks and both actions', () => {
  const at = Date.UTC(2024, 4, 7, 1, 52);
  const html = SPC.reportDetail({ category: 'hail', kind: 'Hail', magnitude: '1.75″ (est.)', magValue: 1.75, magUnit: 'in',
    location: '3 WSW Nemaha', county: 'Nemaha', state: 'NE', lat: 40.32, lon: -95.73, at,
    comments: 'Golf ball hail <b>covering</b> the road.', source: 'Trained Spotter', wfo: 'OAX',
    productId: '202405071229-KOAX-NWUS53-LSROAX' },
    { now: at + 2 * 3600000, from: { lat: 41.26, lon: -95.94, name: 'Omaha' }, imperial: true, hour12: true, offset: -18000 });
  ok(html.includes('1.75″ (est.) — golf ball size'), 'size against a yardstick');
  ok(html.includes('Severe hail (1″+)'), 'criteria');
  ok(html.includes('3 WSW Nemaha, Nemaha County, NE'), 'county');
  ok(/\d+ mi S of Omaha/.test(html), 'distance and direction from the user: ' + html);
  ok(html.includes('8:52 PM (2h ago)') || html.includes('8:52 PM ('), 'location clock');
  ok(html.includes('Reported by Trained Spotter · NWS OAX'), 'who');
  ok(html.includes('&lt;b&gt;covering'), 'remarks escaped');
  ok(html.includes('data-radar-at="' + at + '"'), 'radar button carries the time');
  ok(html.includes('https://mesonet.agron.iastate.edu/p.php?pid=202405071229-KOAX-NWUS53-LSROAX'), 'NWS text link');
  const bare = SPC.reportDetail({ category: 'other', kind: 'Other', lat: 1, lon: 1, time: '0930' }, { now: 0, from: null, imperial: true });
  ok(!bare.includes('lsr-actions'), 'no buttons without a time or product');
});

/* ── The CAPE layer ─────────────────────────────────────────────────────── */

test('CAPE under 100 J/kg is left clear rather than painted pale', () => {
  eq(Layers.capeColor(0), null); eq(Layers.capeColor(99), null); eq(Layers.capeColor(null), null);
  ok(Array.isArray(Layers.capeColor(100)));
});

test('the CAPE field fades in from 50 to 150 J/kg instead of a blocky hard edge', () => {
  eq(Layers.capeAlpha(null), 0); eq(Layers.capeAlpha(0), 0); eq(Layers.capeAlpha(50), 0);
  near(Layers.capeAlpha(100), 0.5, 1e-9); eq(Layers.capeAlpha(150), 1); eq(Layers.capeAlpha(3000), 1);
});

test('HRRR CAPE: runs named by their start, the parcel by its layer', () => {
  const H = Layers.hrrr;
  eq(H.runName(Date.UTC(2026, 9, 4, 2, 15)), '20261004_0200');
  eq(H.validHour(Date.UTC(2026, 9, 4, 2, 29)), Date.UTC(2026, 9, 4, 2));
  eq(H.validHour(Date.UTC(2026, 9, 4, 2, 31)), Date.UTC(2026, 9, 4, 3));
  const at = Date.UTC(2026, 9, 4, 2);
  const ml = H.params('ml', at), mu = H.params('mu', at), sb = H.params('sb', at);
  eq(ml.elevation, 4500); eq(mu.elevation, 12750); eq(sb.elevation, undefined);
  eq(sb.layers, 'Convective_available_potential_energy_surface');
  eq(ml.layers, mu.layers);
  eq(ml.time, '2026-10-04T02:00:00.000Z'); eq(ml.styles, 'raster/div-Spectral-inv');
  eq(ml.colorscalerange, '100,4000'); eq(ml.belowmincolor, 'transparent');
  ok(H.url('20261004_0000').endsWith('/HRRR_CONUS_2p5km_20261004_0000.grib2'), 'one dataset per run');
  ok(/width=8&height=8/.test(H.probeUrl('20261004_0000', 'ml', at)), 'the probe is a tiny map');
  ok(H.inCoverage(35.2, -97.4) && H.inCoverage(47.6, -122.3) && H.inCoverage(25.8, -80.2));
  ok(!H.inCoverage(51.5, -0.1) && !H.inCoverage(61.2, -149.9) && !H.inCoverage(19.7, -155.1), 'not London, Anchorage or Hilo');
  eq(Layers.CAPE_ORDER.join(), 'sb,ml,mu');
});

test('a wide view samples 80 points, a local one 42', () => {
  const box = (s, w, n, e) => ({ getSouthWest: () => ({ lat: s, lng: w }), getNorthEast: () => ({ lat: n, lng: e }) });
  eq(JSON.stringify(Layers.gridDims(box(34, -99, 37, -95))), '{"nx":7,"ny":6}');      // around a metro
  eq(JSON.stringify(Layers.gridDims(box(24, -110, 50, -80))), '{"nx":10,"ny":8}');    // the Plains and beyond
  eq(JSON.stringify(Layers.gridDims(box(31, -106, 39, -88))), '{"nx":7,"ny":6}');     // a desktop map at zoom 7
  eq(JSON.stringify(Layers.gridDims(box(33, -110, 39, -84))), '{"nx":10,"ny":8}');    // wide but short
});

test('the CAPE ramp hits its stops exactly and saturates past the top', () => {
  Layers.CAPE_STOPS.forEach(([v, c]) => eq(Layers.capeColor(v).join(','), c.join(','), v + ' J/kg'));
  eq(Layers.capeColor(9000).join(','), Layers.CAPE_STOPS[Layers.CAPE_STOPS.length - 1][1].join(','));
});

/* ── The scorecard's ground truth, worldwide ────────────────────────────── */

test('an Iowa State network extent decodes from its hex EWKB polygon', () => {
  // GB__ASOS exactly as /api/1/networks.json serves it.
  const b = API.ewkbBox('0103000020E61000000100000005000000B5F81400E3D91DC043A852B3078E4840B5F81400E3D91DC040FB912232444E4099D87C5C1B2AFD3F40FB912232444E4099D87C5C1B2AFD3F43A852B3078E4840B5F81400E3D91DC043A852B3078E4840');
  near(b[0], -7.46, 0.01, 'west'); near(b[1], 49.11, 0.01, 'south');
  near(b[2], 1.82, 0.01, 'east');  near(b[3], 60.53, 0.01, 'north');
  eq(API.ewkbBox(''), null);
});

test('station choice: online, within 50 km, nearest first', () => {
  const st = (id, lat, lon, online) => ({ id, name: id, network: 'GB__ASOS', latitude: lat, longitude: lon, online });
  const got = API.pickStation([
    st('FAR', 52.5, -0.12, true),      // ~111 km: not "your" station
    st('OFF', 51.51, -0.12, false),    // nearest, but offline
    st('MID', 51.7, -0.12, true),
    st('NEAR', 51.55, -0.12, true)
  ], 51.5, -0.12);
  eq(got.map(s => s.station).join(','), 'NEAR,MID');
  eq(got[0].archive, 'iem', 'flagged so the scorecard reads the METAR archive');
  near(got[0].distanceKm, 6, 1);
  eq(API.pickStation([st('FAR', 52.5, -0.12, true)], 51.5, -0.12).length, 0);
});

test('the METAR archive CSV reduces to the day\'s true extremes, missing reports skipped', () => {
  const csv = 'station,valid,tmpc\nEGLL,2026-10-01 23:20,13.00\nEGLL,2026-10-02 00:20,M\n' +
    'EGLL,2026-10-02 14:50,21.00\nEGLL,2026-10-02 05:50,12.50\n';
  const d = API.parseAsosTemps(csv);
  eq(d.hi, 21); eq(d.lo, 12.5); eq(d.n, 3, 'the M report is not an observation');
  eq(API.parseAsosTemps('station,valid,tmpc\n'), null, 'no reports is no day, not a zero');
});

/* ── VaneMotion grades its own calls ────────────────────────────────────── */

const T0 = Date.parse('2026-10-03T12:00:00Z');
const inbound = (minutes, extra) => Object.assign({
  stationary: false, overheadNow: false,
  vector: { toward: 'NE', speed: 32 },
  eta: { minutes, dbz: 34, distanceKm: 18, dir: 'SW' }
}, extra || {});

/* Graded calls with a chosen raw-fit error (minutes; null = never came). */
const timedCalls = (errs, calMin) => errs.map((e, i) => {
  const issuedAt = T0 + i * 3600000, raw = issuedAt + 25 * 60000, cm = calMin || 0;
  return { issuedAt, rawPredictedAt: raw, predictedAt: raw + cm * 60000, calMin: cm,
    result: e === null ? { outcome: 'miss', arrivedAt: null, errorMin: null }
                       : { outcome: 'x', arrivedAt: raw + e * 60000, errorMin: e - cm } };
});

test('VaneMotion does not correct itself before it has five timed calls', () => {
  const c = MotionSkill.calibration(timedCalls([8, 8, 8, 8, null, null]));
  eq(c.ready, false, 'misses carry no arrival time and teach nothing');
  eq(c.n, 4);
});

test('a consistent lag becomes a shrunk, rounded correction', () => {
  const c = MotionSkill.calibration(timedCalls([8, 6, 9, 7, 8, 10, 6, 8, 7, 8]));
  eq(c.ready, true);
  eq(c.medianErrMin, 8);
  eq(c.biasMin, 5, 'median 8 shrunk by 10/(10+5)');
  ok(c.spreadMin <= 1, 'tight agreement');
});

test('a correction inside the noise floor is no correction, and a huge one is clamped', () => {
  eq(MotionSkill.calibration(timedCalls([2, -1, 1, 2, 1])).biasMin, 0);
  eq(MotionSkill.calibration(timedCalls(Array(40).fill(60))).biasMin, 20);
  eq(MotionSkill.calibration(timedCalls(Array(40).fill(-60))).biasMin, -20);
});

test('the correction is applied to a copy, labelled, and the raw call is kept', () => {
  const cal = { ready: true, biasMin: 6, n: 9, spreadMin: 2 };
  const m = inbound(25);
  const out = MotionSkill.applyCalibration(m, cal);
  eq(m.eta.minutes, 25, 'the cached verdict is untouched');
  eq(out.eta.minutes, 31); eq(out.eta.rawMinutes, 25);
  eq(out.eta.calibration.biasMin, 6);
  eq(MotionSkill.applyCalibration(m, { ready: true, biasMin: 0 }), m, 'nothing to apply');
  eq(MotionSkill.applyCalibration(m, { ready: true, biasMin: 6, disabled: true }), m, 'switched off');
  eq(MotionSkill.applyCalibration(inbound(3), { ready: true, biasMin: -9, n: 9 }).eta.minutes, 1,
    'never corrected into the past');
});

test('a corrected call records what the raw fit said, so learning stays on raw errors', () => {
  const cal = MotionSkill.applyCalibration(inbound(25), { ready: true, biasMin: 6, n: 9, spreadMin: 2 });
  const c = MotionSkill.recordInto(MotionSkill.empty('k'), 'k', cal, T0).calls[0];
  eq(c.predictedAt - T0, 31 * 60000, 'graded on what the user was told');
  eq(c.rawPredictedAt - T0, 25 * 60000, 'learned from what the fit said');
  eq(c.calMin, 6);
  const st = MotionSkill.stampsFor(c);
  ok(st[st.length - 1] > c.predictedAt + (MotionSkill.GRACE_MIN - 6) * 60000, 'window covers both');
});

test('a correction that made calls worse switches itself off and says so', () => {
  // Raw fit was right on (0 error); the applied +6 made every call 6 min late.
  const calls = timedCalls([0, 1, -1, 0, 0, 1, -1], 6);
  const c = MotionSkill.calibration(calls);
  ok(c.audit && c.audit.calMaeMin > c.audit.rawMaeMin, JSON.stringify(c.audit));
  eq(c.disabled, true);
  const text = Insight.skillText(Object.assign(MotionSkill.skill(calls), { calibration: c }));
  ok(/made calls here worse/.test(text) && /switched it off/.test(text), text);
});

test('a correction that helped reports its own gain', () => {
  // Raw fit ran 8 min early on every call; the applied +6 left 2 min.
  const calls = timedCalls([8, 8, 9, 7, 8, 8], 6);
  const c = MotionSkill.calibration(calls);
  eq(c.disabled, false);
  const text = Insight.skillText(Object.assign(MotionSkill.skill(calls), { calibration: c }));
  ok(/cut the typical error from 8 to 2 min over 6 calls/.test(text), text);
});

/* Graded calls by one source: errors in minutes, null = never came. */
const graded = (who, errs) => errs.map((e, i) => {
  const predictedAt = T0 + i * 3600000;
  return { by: who, issuedAt: predictedAt - 30 * 60000, predictedAt, rawPredictedAt: predictedAt, calMin: 0,
    result: e === null ? { outcome: 'miss', arrivedAt: null, errorMin: null }
                       : { outcome: Math.abs(e) <= 10 ? 'hit' : 'late', arrivedAt: predictedAt + e * 60000, errorMin: e } };
});

test('the model and the blend make their own calls, deduped like VaneMotion\'s', () => {
  let s = MotionSkill.otherCallInto(MotionSkill.empty('k'), 'k', 'model', 40, T0, 'nexrad');
  s = MotionSkill.otherCallInto(s, 'k', 'model', 35, T0 + 5 * 60000, 'nexrad');   // same rain
  s = MotionSkill.otherCallInto(s, 'k', 'blend', 38, T0, 'nexrad');
  eq(s.calls.filter(c => c.by === 'model').length, 1);
  eq(s.calls.filter(c => c.by === 'blend').length, 1);
  eq(MotionSkill.otherCallInto(MotionSkill.empty('k'), 'k', 'model', 0, T0).calls.length, 0, 'rain already here is not a call');
});

test('VaneMotion\'s own record and correction ignore the model\'s calls', () => {
  const calls = graded('model', [30, 30, 30, 30, 30, 30]).concat(graded('motion', [1, 2]));
  eq(MotionSkill.skill(calls).n, 2, 'only VaneMotion\'s calls');
  eq(MotionSkill.skill(calls, 'model').n, 6);
  eq(MotionSkill.calibration(calls).ready, false, 'the model\'s errors do not move VaneMotion\'s clock');
});

test('the blend weighs each clock by its record, equal until both have one', () => {
  eq(MotionSkill.blendWeights(graded('motion', [2, 3])).ready, false);
  eq(MotionSkill.blendWeights([]).wMotion, 0.5);
  // Radar fit off by ~3 min, model by ~12: the fit should carry most weight.
  const w = MotionSkill.blendWeights(graded('motion', [3, -3, 3, -3, 3]).concat(graded('model', [12, -12, 12, -12, 12])));
  eq(w.ready, true);
  near(w.wMotion, (1 / 9) / (1 / 9 + 1 / 144), 1e-9);
  // Rain that never came costs as much as being thirty minutes out.
  const m = MotionSkill.blendWeights(graded('motion', [0, 0, 0, 0, null]).concat(graded('model', [0, 0, 0, 0, 0])));
  ok(m.wModel > 0.9, 'a clock that called phantom rain loses weight');
  near(MotionSkill.blendMinutes(20, 40, w), 20 * w.wMotion + 40 * w.wModel, 1e-9);
  eq(MotionSkill.blendMinutes(null, 40, w), 40); eq(MotionSkill.blendMinutes(25, null, w), 25);
  eq(MotionSkill.blendMinutes(null, null, w), null);
});

test('Insight names both clocks and how they were weighed', () => {
  const at = Date.parse('2026-10-03T20:00:00Z');
  const base = { at, motionMin: 20, modelMin: 40, blendMin: 26 };
  const eqw = Insight.compose({ rainTiming: Object.assign({ w: { ready: false, wMotion: 0.5, wModel: 0.5 } }, base) }, FMT);
  const l = eqw.find(x => x.tag === 'Rain timing');
  ok(l && /Rain around 20:26: the radar fit says 20:20, the forecast model 20:40 — equal weights until both have a record here\./.test(l.text), l && l.text);
  const ready = Insight.compose({ rainTiming: Object.assign({ w: { ready: true, wMotion: 0.7, wModel: 0.3 } }, base),
    blendSkill: { ready: true, hits: 7, n: 9, hitMin: 10 }, motionSkill: { ready: true, hits: 5, n: 9 } }, FMT);
  ok(/weighted 70\/30 by their records here\. Blended calls here: 7 of 9 within ±10 min \(radar fit alone 5 of 9\)\./
    .test(ready.find(x => x.tag === 'Rain timing').text));
});

test('a global call remembers its source and is graded on ten-minute frames', () => {
  const s = MotionSkill.recordInto(MotionSkill.empty('k'), 'k', inbound(25, { source: 'rainviewer' }), T0 + 60000);
  const call = s.calls[0];
  eq(call.source, 'rainviewer');
  const st = MotionSkill.stampsFor(call);
  ok(st.every(t => t % 600000 === 0), 'on RainViewer\'s frame times');
  ok(st.every((t, i) => !i || t - st[i - 1] === 600000), 'ten minutes apart');
  eq(st[0], T0 + 600000, 'the first frame after the call');
  eq(MotionSkill.recordInto(MotionSkill.empty('k'), 'k', inbound(25), T0).calls[0].source, 'nexrad');
});

test('a RainViewer frame that has aged out is gone, one not yet published is a retry', () => {
  const call = { source: 'rainviewer' };
  const frames = [{ t: T0, url: 'x' }, { t: T0 + 600000, url: 'y' }];
  return Promise.all([
    MotionSkill.sampleAt({ lat: 50, lon: 0 }, T0 - 600000, call, frames),
    MotionSkill.sampleAt({ lat: 50, lon: 0 }, T0 + 1200000, call, frames),
    MotionSkill.sampleAt({ lat: 50, lon: 0 }, T0 - 600000, call, null)
  ]).then(([old, future, noIndex]) => {
    eq(old, 'gone', 'older than the archive: never gradeable, dropped not guessed');
    eq(future, null, 'not published yet: retried');
    eq(noIndex, null, 'index unavailable: retried, never declared gone');
  });
});

test('an arrival call is recorded once per approaching echo', () => {
  let s = MotionSkill.recordInto(MotionSkill.empty('k'), 'k', inbound(25), T0);
  eq(s.calls.length, 1);
  eq(s.calls[0].predictedAt, T0 + 25 * 60000);
  // Re-fits of the same rain five and ten minutes later: same event.
  s = MotionSkill.recordInto(s, 'k', inbound(20), T0 + 5 * 60000);
  s = MotionSkill.recordInto(s, 'k', inbound(16), T0 + 10 * 60000);
  eq(s.calls.length, 1, 'a countdown is one call, not three');
  eq(s.calls[0].leadMin, 25, 'and the graded call is the longest-lead one');
  // A different echo arriving an hour later is a new call.
  s = MotionSkill.recordInto(s, 'k', inbound(70), T0 + 10 * 60000);
  eq(s.calls.length, 2);
});

test('no call is recorded without rain still on its way', () => {
  const e = () => MotionSkill.empty('k');
  eq(MotionSkill.recordInto(e(), 'k', inbound(25, { overheadNow: true }), T0).calls.length, 0,
    'rain already overhead has no arrival to time');
  eq(MotionSkill.recordInto(e(), 'k', inbound(25, { stationary: true }), T0).calls.length, 0);
  eq(MotionSkill.recordInto(e(), 'k', { stationary: false, eta: null }, T0).calls.length, 0);
  eq(MotionSkill.recordInto(e(), 'k', null, T0).calls.length, 0);
  const moved = MotionSkill.recordInto(MotionSkill.recordInto(e(), 'k', inbound(25), T0), 'other', inbound(25), T0);
  eq(moved.loc, 'other');
  eq(moved.calls.length, 1, 'a new pin starts a fresh record');
});

test('the graded window runs from the call through the grace period, on archive stamps', () => {
  const call = { issuedAt: T0 + 60000, predictedAt: T0 + 26 * 60000 };
  const st = MotionSkill.stampsFor(call);
  eq(st[0], T0 + 5 * 60000, 'first five-minute stamp after the call');
  ok(st.every(t => t % 300000 === 0), 'every one a real archive stamp');
  ok(st[st.length - 1] <= call.predictedAt + MotionSkill.GRACE_MIN * 60000);
  ok(st[st.length - 1] > call.predictedAt + (MotionSkill.GRACE_MIN - 5) * 60000);
});

test('grading: a hit, a late call, an early call and rain that never came', () => {
  const call = { issuedAt: T0, predictedAt: T0 + 25 * 60000 };
  const after = T0 + 60 * 60000;
  const wetAt = min => MotionSkill.stampsFor(call).map(t => ({ t, dbz: t >= T0 + min * 60000 ? 38 : -Infinity }));
  const hit = MotionSkill.grade(call, wetAt(30), after);
  eq(hit.outcome, 'hit'); eq(hit.errorMin, 5);
  const late = MotionSkill.grade(call, wetAt(45), after);
  eq(late.outcome, 'late'); eq(late.errorMin, 20);
  const early = MotionSkill.grade(call, wetAt(10), after);
  eq(early.outcome, 'early'); eq(early.errorMin, -15);
  const miss = MotionSkill.grade(call, wetAt(999), after);
  eq(miss.outcome, 'miss'); eq(miss.arrivedAt, null);
});

test('grading refuses an open window and an unreadable frame', () => {
  const call = { issuedAt: T0, predictedAt: T0 + 25 * 60000 };
  const dry = MotionSkill.stampsFor(call).map(t => ({ t, dbz: -Infinity }));
  eq(MotionSkill.grade(call, dry, T0 + 30 * 60000), null, 'still inside the grace period');
  const hole = dry.slice(); hole[3] = { t: hole[3].t, dbz: null };
  eq(MotionSkill.grade(call, hole, T0 + 90 * 60000), null,
    'a frame that failed to load is never scored as dry');
});

test('the record summarises honestly, and stays silent until it has three calls', () => {
  const r = o => ({ result: { outcome: o, errorMin: o === 'miss' ? null : (o === 'hit' ? 3 : 20) } });
  const two = MotionSkill.skill([r('hit'), r('hit')]);
  eq(two.ready, false);
  eq(Insight.skillText(two), null, 'two calls is an anecdote');
  const sk = MotionSkill.skill([r('hit'), r('hit'), r('hit'), r('late'), r('miss'), { result: null }]);
  eq(sk.n, 5); eq(sk.hits, 3); eq(sk.late, 1); eq(sk.misses, 1); eq(sk.open, 1);
  const text = Insight.skillText(sk);
  ok(/3 of 5 arrival calls landed within ±10 min/.test(text), text);
  ok(/1 late, 1 never came/.test(text), 'and the misses are named, not hidden');
});

test('a forecast that moved under you becomes an Insight line', () => {
  const at = Date.parse('2026-09-20T15:00:00Z');
  const earlier = Insight.compose({
    change: { kind: 'timing', before: at, after: at - 2 * 3600000, delta: -120 }
  }, FMT);
  eq(earlier[0].tag, 'Forecast change');
  ok(/moved from 15:00 to 13:00/.test(earlier[0].text));
  ok(/2\.0 h earlier/.test(earlier[0].text));
  const added = Insight.compose({ change: { kind: 'rain-signal', added: true, at } }, FMT);
  ok(/added rain around 15:00/.test(added[0].text));
  const dropped = Insight.compose({ change: { kind: 'rain-signal', added: false, at } }, FMT);
  ok(/has dropped out/.test(dropped[0].text));
  eq(Insight.compose({ change: { kind: 'temp', at, before: 20, after: 24, delta: 4 } }, FMT).length, 0,
    'temperature wobbles stay on the decision card, not the headline');
});

test('the leaderboard carries each agency\'s signed lean', () => {
  const results = [];
  for (let i = 0; i < 4; i++) {
    results.push({ date: 'd' + i, err: { gfs_seamless: { hi: 2, lo: -1 }, ecmwf_ifs025: { hi: -0.5, lo: 0.5 } } });
  }
  const rows = Verify.board(results).rows;
  const gfs = rows.find(r => r.short === 'GFS');
  near(gfs.biasHi, 2, 1e-9, 'GFS runs warm on highs');
  near(gfs.biasLo, -1, 1e-9, 'and cool on lows');
  near(rows.find(r => r.short === 'ECMWF').biasHi, -0.5, 1e-9);
});

test('fitTrend is one algorithm for every history: auto-trends and followed storms agree', () => {
  Cells.resetTrends();
  const t0 = Date.parse('2026-09-20T12:00:00Z');
  const samples = [[0, 38, 41], [5, 42, 44], [10, 47, 48], [15, 51, 52]]
    .map(([m, dbz, top]) => ({ t: t0 + m * 60000, dbz, top }));
  samples.forEach(s => Cells.ingest([{ id: 'KTLX-F1', maxDbz: s.dbz, top: s.top,
    valid: new Date(s.t).toISOString() }], s.t));
  const auto = Cells.trendOf('KTLX-F1');
  const direct = Cells.fitTrend(samples);
  eq(direct.dir, auto.dir);
  near(direct.dbzRate, auto.dbzRate, 1e-12, 'byte-for-byte the same fit');
  eq(Cells.fitTrend(samples.slice(0, 2)), null, 'and the same refusal on thin histories');
  Cells.resetTrends();
});

test('the consensus weights agencies by their measured local record', () => {
  // ECMWF has been twice as accurate here as GFS; its forecast pulls harder.
  const md = fakeModelDaily(['2026-09-20'], {
    ecmwf_ifs025: [[30, 20]],
    gfs_seamless: [[36, 26]]
  });
  const rows = [
    { id: 'ecmwf_ifs025', mae: 0.5 },   // weight 1/(0.5+0.5) = 1
    { id: 'gfs_seamless', mae: 2.5 }    // weight 1/(2.5+0.5) = 1/3
  ];
  const c = Insight.consensus(md, 0, rows, null);
  eq(c.weighted, true);
  eq(c.scored, 2);
  near(c.hi, 31.5, 1e-9, 'three quarters of the pull goes to the accurate agency');
  near(c.lo, 21.5, 1e-9);
  near(c.spreadHi, 6, 1e-9, 'and the disagreement is reported, not hidden');
});

test('without an earned record the consensus refuses to play favourites', () => {
  const md = fakeModelDaily(['2026-09-20'], {
    ecmwf_ifs025: [[30, 20]], gfs_seamless: [[34, 24]]
  });
  const one = Insight.consensus(md, 0, [{ id: 'ecmwf_ifs025', mae: 0.5 }], null);
  eq(one.weighted, false, 'one scored agency against unscored peers is a thumb on the scale');
  near(one.hi, 32, 1e-9, 'equal weights until at least two have a record');
  const none = Insight.consensus(md, 0, [], null);
  eq(none.weighted, false);
  eq(none.agencies, 2);
});

test('the microclimate correction lands on the consensus, when it is meaningful', () => {
  const md = fakeModelDaily(['2026-09-20'], { ecmwf_ifs025: [[30, 20]] });
  const hot = Insight.consensus(md, 0, [], { meaningful: true, corrHi: -1.5, corrLo: 0.5 });
  near(hot.hi, 28.5, 1e-9);
  near(hot.lo, 20.5, 1e-9);
  eq(hot.corrected, true);
  const meh = Insight.consensus(md, 0, [], { meaningful: false, corrHi: -1.5, corrLo: 0.5 });
  near(meh.hi, 30, 1e-9, 'a lean the fit itself called noise never moves the number');
});

test('the read leads with the official word and never buries an alert', () => {
  const lines = Insight.compose({
    alert: { event: 'Tornado Warning', until: null },
    motion: { eta: { minutes: 20, dbz: 45, distanceKm: 15, dir: 'SW' },
              vector: { toward: 'NE', speed: 40 } },
    nowcast: { state: 'dry' }
  }, FMT);
  eq(lines[0].tag, 'NWS');
  ok(/Tornado Warning/.test(lines[0].text));
  ok(/official guidance first/.test(lines[0].text), 'Vane defers, in words');
  eq(lines[1].tag, 'VaneMotion');
});

test('the motion fit outranks the model nowcast, which speaks only when the fit is silent', () => {
  const withFit = Insight.compose({
    motion: { eta: { minutes: 25, dbz: 34, distanceKm: 18, dir: 'SW' },
              vector: { toward: 'NE', speed: 32 } },
    nowcast: { state: 'dry' }
  }, FMT);
  eq(withFit.length, 1);
  eq(withFit[0].tag, 'VaneMotion');
  ok(/about 25 min/.test(withFit[0].text));

  const without = Insight.compose({ motion: null, nowcast: { state: 'dry' } }, FMT);
  eq(without[0].tag, 'Nowcast');
  ok(/No rain expected/.test(without[0].text), 'a quiet day reads as a quiet day');
});

test('a threatening cell brings its fitted trend into the sentence', () => {
  const lines = Insight.compose({
    threat: {
      stormId: 'A12',
      approach: { etaMin: 42, closest: 8 },
      trend: { dir: 'strengthening', firstDbz: 38, lastDbz: 51, scans: 4 }
    }
  }, FMT);
  eq(lines[0].tag, 'Radar · Trend');
  ok(/A12/.test(lines[0].text) && /42 min/.test(lines[0].text));
  ok(/strengthening \(38→51 dBZ over 4 scans\)/.test(lines[0].text));
});

test('Vane\'s number appears beside the official one, and says how it was earned', () => {
  const lines = Insight.compose({
    consensus: { hi: 33, lo: 21, agencies: 7, scored: 4, weighted: true,
                 corrected: true, spreadHi: 3, spreadLo: 2 },
    consensusLabel: 'today',
    official: { hi: 35, lo: 22 }
  }, FMT);
  eq(lines[0].tag, 'Consensus');
  ok(/33° \/ 21°/.test(lines[0].text), 'Vane\'s number');
  ok(/official 35° \/ 22°/.test(lines[0].text), 'never replaces the official one');
  ok(/4 agencies weighted by their record here/.test(lines[0].text));
  ok(/adjusted for your microclimate/.test(lines[0].text));
});

test('agreement is reported as agreement, not dressed up as insight', () => {
  const lines = Insight.compose({
    consensus: { hi: 34.8, lo: 21.9, agencies: 7, scored: 0, weighted: false,
                 corrected: false, spreadHi: 1.2, spreadLo: 0.8 },
    official: { hi: 35, lo: 22 }
  }, FMT);
  ok(/All 7 agencies agree/.test(lines[0].text));
  ok(/within 1°/.test(lines[0].text));
});

test('the best-model line waits for a scorecard and then names its evidence', () => {
  const lines = Insight.compose({
    bestModel: { short: 'ECMWF', mae: 1.2, n: 9 }
  }, FMT);
  eq(lines[0].tag, 'Scorecard');
  ok(/ECMWF/.test(lines[0].text) && /9 verified days/.test(lines[0].text));
  eq(Insight.compose({ bestModel: null }, FMT).length, 0, 'and says nothing before one exists');
});

test('stale unverifiable predictions expire instead of accumulating', () => {
  const store = Verify.emptyStore('x');
  store.pending['2026-09-01'] = { off: 0, models: {} };
  store.pending['2026-09-18'] = { off: 0, models: {} };
  Verify.prunePending(store, '2026-09-19');
  eq(store.pending['2026-09-01'], undefined, 'eighteen days is beyond verifying');
  ok(store.pending['2026-09-18'], 'yesterday still gets its chance');
});

/* ── Alert filtering ────────────────────────────────────────────────────── */

test('familyOf classifies core severe events', () => {
  eq(Settings.familyOf({ event: 'Tornado Warning' }), 'tornado');
  eq(Settings.familyOf({ event: 'Severe Thunderstorm Warning' }), 'severe');
  eq(Settings.familyOf({ event: 'Flash Flood Warning' }), 'flood');
  eq(Settings.familyOf({ event: 'Winter Storm Warning' }), 'winter');
  eq(Settings.familyOf({ event: 'Heat Advisory' }), 'heat');
  eq(Settings.familyOf({ event: 'Red Flag Warning' }), 'fire');
});

test('familyOf falls back to "other" for unrecognised events', () => {
  eq(Settings.familyOf({ event: 'Special Weather Statement' }), 'other');
});

test('filterAlerts passes everything when all families are enabled', () => {
  const alerts = [{ event: 'Tornado Warning' }, { event: 'Heat Advisory' }];
  eq(Settings.filterAlerts(alerts).length, 2);
});

test('filterAlerts drops a disabled family and keeps the rest', () => {
  const s = Settings.load();
  s.filters.heat = false;
  Settings.save({ filters: s.filters });
  const out = Settings.filterAlerts([
    { event: 'Tornado Warning' }, { event: 'Heat Advisory' }
  ]);
  eq(out.length, 1);
  eq(out[0].event, 'Tornado Warning');
  s.filters.heat = true;
  Settings.save({ filters: s.filters });
});

test('settings defaults enable every alert family', () => {
  VaneConfig.ALERT_FILTERS.forEach(f => {
    eq(Settings.DEFAULTS.filters[f.key], true, `${f.key} should default on`);
  });
});

/* ── Config sanity ──────────────────────────────────────────────────────── */

test('every WMO code maps to a label and a glyph', () => {
  Object.keys(VaneConfig.WMO).forEach(code => {
    const entry = VaneConfig.WMO[code];
    eq(entry.length, 2, `code ${code}`);
    ok(entry[0].length > 0, `code ${code} needs a label`);
  });
});

test('precip thresholds ascend', () => {
  const p = VaneConfig.PRECIP;
  ok(p.trace < p.light && p.light < p.moderate && p.moderate < p.heavy);
});

test('SPC risk ranks are unique and ascending by severity', () => {
  const ranks = Object.keys(VaneConfig.SPC_RISK).map(k => VaneConfig.SPC_RISK[k].rank);
  eq(new Set(ranks).size, ranks.length, 'ranks must be unique');
});

test('every API endpoint is HTTPS', () => {
  ['OM_FORECAST', 'OM_GEOCODE', 'OM_AIR', 'NWS_BASE', 'SPC_BASE', 'RAINVIEWER_INDEX']
    .forEach(k => ok(/^https:\/\//.test(VaneConfig[k]), `${k} must be https`));
});

test('chase mode refreshes more often than simple mode', () => {
  ok(VaneConfig.REFRESH_MS.chase < VaneConfig.REFRESH_MS.simple);
});

/* ── Sky palettes: the contrast promise ─────────────────────────────────── */

// Every sky gradient must keep white text at WCAG AA (4.5:1). The design leans
// on white-on-colour everywhere, so a single pastel palette slipping in would
// make the app unreadable in exactly the conditions it matters most.
function relLuminance(hex) {
  const m = /^#?([0-9a-f]{2})([0-9a-f]{2})([0-9a-f]{2})$/i.exec(hex);
  if (!m) throw new Error('bad hex: ' + hex);
  const lin = v => { v /= 255; return v <= 0.03928 ? v / 12.92 : Math.pow((v + 0.055) / 1.055, 2.4); };
  return 0.2126 * lin(parseInt(m[1], 16)) +
         0.7152 * lin(parseInt(m[2], 16)) +
         0.0722 * lin(parseInt(m[3], 16));
}

function contrastWithWhite(hex) {
  return 1.05 / (relLuminance(hex) + 0.05);
}

// Pull every hex triple out of the SKIES table in theme.js.
const skyPalettes = [];
{
  const block = THEME_SRC.slice(THEME_SRC.indexOf('var SKIES'), THEME_SRC.indexOf('var current'));
  const re = /(\w+):\s*\[([^\]]+)\]/g;
  let m;
  while ((m = re.exec(block))) {
    const band = m[1];
    const hexes = m[2].match(/#[0-9a-f]{6}/gi);
    if (hexes && hexes.length >= 3) skyPalettes.push({ band, hexes });
  }
}

test('theme.js exposes sky palettes to test', () => {
  ok(skyPalettes.length >= 28, `expected 7 groups x 4 bands, got ${skyPalettes.length}`);
});

test('every sky gradient keeps white text at WCAG AA', () => {
  skyPalettes.forEach(p => {
    // Stops 0-2 form the background gradient; stop 3 is the accent, which is
    // never used behind body text.
    p.hexes.slice(0, 3).forEach(hex => {
      const c = contrastWithWhite(hex);
      ok(c >= 4.5, `${p.band} stop ${hex} gives only ${c.toFixed(2)}:1 against white`);
    });
  });
});

test('night palettes are darker than their day counterparts', () => {
  // Sanity on the ordering: a night sky must never be lighter than day.
  const byBand = {};
  skyPalettes.forEach(p => {
    (byBand[p.band] = byBand[p.band] || []).push(relLuminance(p.hexes[1]));
  });
  const avg = b => byBand[b].reduce((a, x) => a + x, 0) / byBand[b].length;
  ok(avg('night') < avg('day'), 'night should be darker than day');
  ok(avg('twilight') < avg('day'), 'twilight should be darker than day');
});

/* ── Model ensemble ─────────────────────────────────────────────────────── */

function fakeEnsemble(perModelTemps, perModelPrecip) {
  const hourly = { time: [] };
  const n = perModelTemps[0].length;
  const base = new Date();
  base.setMinutes(0, 0, 0);
  for (let i = 0; i < n; i++) {
    const t = new Date(base.getTime() + i * 3600000);
    const p = v => String(v).padStart(2, '0');
    hourly.time.push(`${t.getFullYear()}-${p(t.getMonth() + 1)}-${p(t.getDate())}T${p(t.getHours())}:00`);
  }
  VaneConfig.MODELS.forEach((m, mi) => {
    if (perModelTemps[mi]) hourly['temperature_2m_' + m.id] = perModelTemps[mi];
    if (perModelPrecip && perModelPrecip[mi]) hourly['precipitation_' + m.id] = perModelPrecip[mi];
  });
  return { hourly, utc_offset_seconds: 0 };
}

test('stats computes min, max, mean and spread', () => {
  const s = Models.stats([10, 12, 14, null, 16]);
  eq(s.min, 10); eq(s.max, 16); eq(s.n, 4);
  eq(s.mean, 13);
  eq(s.spread, 6);
});

test('stats ignores an all-null hour', () => eq(Models.stats([null, null]), null));

test('analyse builds a per-hour envelope across models', () => {
  const ens = fakeEnsemble([
    [20, 21, 22], [21, 22, 23], [19, 20, 21], [22, 23, 24], [20.5, 21.5, 22.5]
  ]);
  const a = Models.analyse(ens, 'temperature_2m');
  ok(a, 'analysis should build');
  eq(a.series.length, 5);
  eq(a.hours.length, 3);
  eq(a.hours[0].min, 19);
  eq(a.hours[0].max, 22);
  eq(a.hours[0].spread, 3);
});

test('analyse needs at least two models to be an ensemble', () => {
  const ens = fakeEnsemble([[20, 21, 22]]);
  eq(Models.analyse(ens, 'temperature_2m'), null);
});

test('confidence tightens as spread narrows', () => {
  eq(Models.confidence(0.5, 'temperature_2m').level, 'high');
  eq(Models.confidence(2.0, 'temperature_2m').level, 'good');
  eq(Models.confidence(4.0, 'temperature_2m').level, 'fair');
  eq(Models.confidence(9.0, 'temperature_2m').level, 'low');
});

test('precipAgreement counts how many models produce rain', () => {
  const ens = fakeEnsemble(
    [[20, 20], [20, 20], [20, 20], [20, 20], [20, 20]],
    [[1.0, 0], [1.0, 0], [0, 0], [0, 0], [1.0, 0]]
  );
  const a = Models.precipAgreement(ens);
  eq(a.hours[0].wetCount, 3, 'three models produce rain in hour 0');
  near(a.hours[0].agreement, 0.6, 1e-9);
  eq(a.hours[1].wetCount, 0);
  eq(a.hours[1].agreement, 0);
});

test('precipAgreement ignores sub-threshold drizzle', () => {
  const ens = fakeEnsemble(
    [[20], [20], [20], [20], [20]],
    [[0.01], [0.02], [0.0], [0.01], [0.0]]
  );
  eq(Models.precipAgreement(ens).hours[0].wetCount, 0);
});

test('outlier identifies the model furthest from the pack', () => {
  const ens = fakeEnsemble([
    [20, 20], [20, 20], [20, 20], [20, 20], [30, 30]   // ARPEGE is the outlier
  ]);
  const a = Models.analyse(ens, 'temperature_2m');
  const o = Models.outlier(a);
  eq(o.model.short, 'ARPEGE');
  ok(o.meanDeviation > 5, `expected a large deviation, got ${o.meanDeviation}`);
});

test('summary reads as plain English', () => {
  const temps = [], precips = [];
  for (let m = 0; m < 5; m++) {
    temps.push(new Array(24).fill(20 + m * 0.2));
    precips.push(new Array(24).fill(0));
  }
  const ens = fakeEnsemble(temps, precips);
  const s = Models.summary(Models.analyse(ens, 'temperature_2m'), Models.precipAgreement(ens));
  ok(s, 'summary should build');
  ok(/confidence|agreement/i.test(s.text), s.text);
  ok(/no model produces rain/.test(s.text), s.text);
  ok(/°C/.test(s.text), 'metric by default: ' + s.text);
});

test('summary reports spread in the displayed unit', () => {
  const temps = [];
  // A 5 degC spread between the coolest and warmest model.
  [0, 1.25, 2.5, 3.75, 5].forEach(off => temps.push(new Array(24).fill(20 + off)));
  const ens = fakeEnsemble(temps);
  const an = Models.analyse(ens, 'temperature_2m');
  const metric = Models.summary(an, null, { imperial: false });
  const imperial = Models.summary(an, null, { imperial: true });
  ok(/5\.0°C/.test(metric.text), metric.text);
  ok(/9\.0°F/.test(imperial.text), imperial.text);   // a 5 degC delta is 9 degF
});

test('summary flags unanimous rain', () => {
  const temps = [], precips = [];
  for (let m = 0; m < 5; m++) {
    temps.push(new Array(24).fill(20));
    const p = new Array(24).fill(0);
    p[3] = 2.0; p[4] = 2.0;
    precips.push(p);
  }
  const ens = fakeEnsemble(temps, precips);
  const s = Models.summary(Models.analyse(ens, 'temperature_2m'), Models.precipAgreement(ens));
  ok(/all models produce rain/.test(s.text), s.text);
});

test('every configured model has an id, label and colour', () => {
  VaneConfig.MODELS.forEach(m => {
    ok(m.id && m.short && m.name, 'model needs id/short/name');
    ok(/^#[0-9a-f]{6}$/i.test(m.color), `model ${m.short} needs a hex colour`);
  });
  eq(new Set(VaneConfig.MODELS.map(m => m.id)).size, VaneConfig.MODELS.length,
    'model ids must be unique');
});

/* ── Storm cells: rotation, scoring, closest approach ───────────────────── */

function feature(props, lon, lat) {
  return {
    type: 'Feature',
    geometry: { type: 'Point', coordinates: [lon, lat] },
    properties: Object.assign({
      nexrad: 'KOUN', storm_id: 'A1', tvs: 'NONE', meso: 'NONE',
      posh: 0, poh: 0, max_size: 0, vil: 5, max_dbz: 40,
      max_dbz_height: 10, top: 20, drct: 225, sknt: 20,
      valid: '2026-08-13T18:00:00Z'
    }, props)
  };
}

test('mesoRank reads the MDA strength rank', () => {
  eq(Cells.mesoRank('NONE'), 0);
  eq(Cells.mesoRank(''), 0);
  eq(Cells.mesoRank(null), 0);
  eq(Cells.mesoRank('5'), 5);
  eq(Cells.mesoRank(12), 12);
});

test('hasTvs only fires on a real signature', () => {
  eq(Cells.hasTvs('NONE'), false);
  eq(Cells.hasTvs(''), false);
  eq(Cells.hasTvs(undefined), false);
  eq(Cells.hasTvs('TVS'), true);
});

test('VIL density divides VIL by echo top depth', () => {
  // 51 kg/m^2 over a 44.3 kft top = 13.5 km -> ~3.8 g/m^3
  near(Cells.vilDensity(51, 44.3), 3.78, 0.05);
  eq(Cells.vilDensity(0, 40), null);
  eq(Cells.vilDensity(30, 0), null);
});

test('a TVS outranks everything else', () => {
  const [tvs] = Cells.parse([feature({ tvs: 'TVS', storm_id: 'T1' }, -97.5, 35.5)]);
  const [hail] = Cells.parse([feature({ posh: 100, max_size: 2.5, vil: 60, max_dbz: 68, top: 55 }, -97.5, 35.5)]);
  ok(tvs.score > 40, `TVS should score high, got ${tvs.score}`);
  ok(tvs.reasons.some(r => /Tornado vortex/.test(r.label)), 'TVS must be an explicit reason');
  eq(tvs.band.key, 'high');
  ok(hail.score > 0, 'a hail monster should still score');
});

test('a well-defined mesocyclone scores above a weak one', () => {
  const [weak] = Cells.parse([feature({ meso: '1' }, -97.5, 35.5)]);
  const [strong] = Cells.parse([feature({ meso: '9' }, -97.5, 35.5)]);
  ok(strong.score > weak.score, `${strong.score} should beat ${weak.score}`);
  ok(strong.reasons.some(r => /well-defined/.test(r.label)), 'rank 9 reads as well-defined');
  ok(weak.reasons.some(r => /weak/.test(r.label)), 'rank 1 reads as weak');
});

test('the mesocyclone contribution is capped so hail still matters', () => {
  const [huge] = Cells.parse([feature({ meso: '25' }, -97.5, 35.5)]);
  const contribution = huge.reasons.find(r => /Mesocyclone/.test(r.label));
  ok(contribution.points <= 35, `capped at 35, got ${contribution.points}`);
});

test('an ordinary shower scores low and is filtered out', () => {
  const [plain] = Cells.parse([feature({ max_dbz: 35, top: 18, vil: 3 }, -97.5, 35.5)]);
  ok(plain.score < 10, `got ${plain.score}`);
  eq(plain.band.key, 'low');
});

test('every score contribution carries its reason', () => {
  const [c] = Cells.parse([feature({ meso: '6', posh: 70, max_size: 1.5, max_dbz: 62, top: 52, vil: 55 }, -97.5, 35.5)]);
  ok(c.reasons.length >= 5, `expected several reasons, got ${c.reasons.length}`);
  c.reasons.forEach(r => {
    ok(r.points > 0, 'a reason with no points should not be listed');
    ok(r.label && r.label.length > 3, 'every reason needs a human label');
  });
  // Reasons are sorted strongest-first so the UI can truncate safely.
  for (let i = 1; i < c.reasons.length; i++) {
    ok(c.reasons[i - 1].points >= c.reasons[i].points, 'reasons must be sorted');
  }
});

test('score is capped at 100', () => {
  const [c] = Cells.parse([feature({
    tvs: 'TVS', meso: '20', posh: 100, max_size: 3, vil: 70, max_dbz: 70, top: 60
  }, -97.5, 35.5)]);
  eq(c.score, 100);
  eq(c.band.key, 'extreme');
});

test('parse drops features without geometry', () => {
  const broken = { type: 'Feature', geometry: null, properties: {} };
  eq(Cells.parse([broken]).length, 0);
});

/* Storm motion follows the meteorological from-convention, matching the wind
 * helpers. A cell reported at 225 deg is moving toward the north-east. */
test('a cell due west moving east closes on the viewer', () => {
  const [c] = Cells.parse([feature({ drct: 270, sknt: 30 }, -98.5, 35.0)]);
  const a = Cells.approach(c, 35.0, -97.0);
  ok(a.approaching, 'should be approaching');
  ok(a.closest < 5, `should pass nearly overhead, closest ${a.closest}`);
  near(a.bearing, 270, 2, 'cell lies to the west');
  near(a.towardDeg, 90, 0.01, 'moving due east');

  // The ETA must be the physics, not a plausible-looking number: 30 kt is
  // 55.56 km/h, so the arrival time is distance / speed.
  const expected = (a.distance / (30 * 1.852)) * 60;
  near(a.etaMin, expected, 0.5, `eta should equal distance/speed (${expected} min)`);
});

test('a cell moving away is not flagged as approaching', () => {
  // East of the viewer, still moving east.
  const [c] = Cells.parse([feature({ drct: 270, sknt: 30 }, -95.5, 35.0)]);
  const a = Cells.approach(c, 35.0, -97.0);
  eq(a.approaching, false);
  eq(a.etaMin, null);
});

test('a stationary cell reports no ETA', () => {
  const [c] = Cells.parse([feature({ sknt: 0 }, -98.0, 35.0)]);
  const a = Cells.approach(c, 35.0, -97.0);
  eq(a.stationary, true);
  eq(a.etaMin, null);
  eq(a.closest, a.distance);
});

test('a glancing cell reports a closest approach greater than zero', () => {
  // Due west but tracking north-east, so it passes to the north.
  const [c] = Cells.parse([feature({ drct: 225, sknt: 40 }, -99.0, 35.0)]);
  const a = Cells.approach(c, 35.0, -97.0);
  ok(a.approaching, 'still closing');
  ok(a.closest > 10, `should miss by a margin, got ${a.closest}`);
  ok(a.closest < a.distance, 'but it does get closer than it is now');
});

test('project moves the cell along its track', () => {
  const [c] = Cells.parse([feature({ drct: 270, sknt: 30 }, -98.0, 35.0)]);
  const p = Cells.project(c, 60);   // one hour at 30 kt = 55.6 km east
  ok(p.lon > c.lon, 'should move east');
  near(p.lat, c.lat, 0.01, 'and not north or south');
  const km = U.haversine(c.lat, c.lon, p.lat, p.lon);
  near(km, 55.6, 2, `one hour at 30 kt is ~55.6 km, got ${km}`);
});

test('near() ranks by score then proximity, and filters the long tail', () => {
  Cells.state.cells = Cells.parse([
    feature({ storm_id: 'FAR', meso: '8' }, -99.0, 35.0),
    feature({ storm_id: 'NEAR', meso: '8' }, -97.2, 35.0),
    feature({ storm_id: 'JUNK', max_dbz: 34, top: 12, vil: 2 }, -97.1, 35.0)
  ]);
  const list = Cells.near(35.0, -97.0, 400, 10);
  eq(list.length, 2, 'the ordinary shower is filtered out');
  eq(list[0].stormId, 'NEAR', 'equal scores break toward the closer cell');
  Cells.state.cells = [];
});

test('near() honours the radius', () => {
  Cells.state.cells = Cells.parse([feature({ meso: '8' }, -110.0, 35.0)]);
  eq(Cells.near(35.0, -97.0, 300, 10).length, 0);
  ok(Cells.near(35.0, -97.0, 2000, 10).length === 1);
  Cells.state.cells = [];
});

test('threatToPoint picks an inbound cell, not merely a nearby one', () => {
  Cells.state.cells = Cells.parse([
    // Strong but receding.
    feature({ storm_id: 'GONE', meso: '9', drct: 90, sknt: 35 }, -97.4, 35.0),
    // Weaker but heading straight in, and close enough to arrive inside the
    // 90-minute default horizon.
    feature({ storm_id: 'INBOUND', meso: '5', drct: 270, sknt: 35 }, -97.8, 35.0)
  ]);
  const t = Cells.threatToPoint(35.0, -97.0);
  ok(t, 'should find a threat');
  eq(t.stormId, 'INBOUND');
  ok(t.approach.etaMin > 0, 'and give an ETA');
  Cells.state.cells = [];
});

test('threatToPoint stays quiet when nothing is inbound', () => {
  Cells.state.cells = Cells.parse([
    feature({ storm_id: 'GONE', meso: '9', drct: 90, sknt: 35 }, -97.4, 35.0)
  ]);
  eq(Cells.threatToPoint(35.0, -97.0), null);
  Cells.state.cells = [];
});

test('threatToPoint ignores a cell that misses by a wide margin', () => {
  Cells.state.cells = Cells.parse([
    feature({ storm_id: 'WIDE', meso: '9', drct: 270, sknt: 35 }, -98.5, 37.5)
  ]);
  eq(Cells.threatToPoint(35.0, -97.0, { withinKm: 25 }), null);
  Cells.state.cells = [];
});

test('threatToPoint ignores an arrival beyond the horizon', () => {
  Cells.state.cells = Cells.parse([
    feature({ storm_id: 'SLOW', meso: '9', drct: 270, sknt: 3 }, -99.5, 35.0)
  ]);
  eq(Cells.threatToPoint(35.0, -97.0, { horizonMin: 90 }), null);
  Cells.state.cells = [];
});

/* ── Per-cell trend learning ────────────────────────────────────────────── */

function scanSeries(id, samples) {
  // samples: [[minutesAgoOffset, dbz, top]] — fed oldest first through ingest.
  const t0 = Date.now() - 60 * 60000;
  samples.forEach(([min, dbz, top]) => {
    Cells.ingest([{ id, maxDbz: dbz, top: top,
      valid: new Date(t0 + min * 60000).toISOString() }], t0 + min * 60000);
  });
}

test('a core climbing across scans is learned as strengthening, with its slope', () => {
  Cells.resetTrends();
  scanSeries('KTLX-A12', [[0, 38, 41], [5, 42, 44], [10, 47, 48], [15, 51, 52]]);
  const t = Cells.trendOf('KTLX-A12');
  ok(t, 'four scans over fifteen minutes is a fit');
  eq(t.dir, 'strengthening');
  near(t.dbzRate, 8.7, 0.3, 'about +8.7 dBZ per 10 minutes');
  eq(t.firstDbz, 38); eq(t.lastDbz, 51);
  eq(t.scans, 4);
  ok(t.topNote, 'the climbing echo top corroborates');
  near(t.topRate, 7.3, 0.4);
  Cells.resetTrends();
});

test('a collapsing core is weakening; a wobbling one is steady, not news', () => {
  Cells.resetTrends();
  scanSeries('KTLX-DWN', [[0, 55, 50], [5, 50, 46], [10, 44, 42]]);
  eq(Cells.trendOf('KTLX-DWN').dir, 'weakening');
  scanSeries('KTLX-STDY', [[0, 50, 45], [5, 51, 45], [10, 49, 44], [15, 50, 45]]);
  const s = Cells.trendOf('KTLX-STDY');
  eq(s.dir, 'steady', 'a ±1 dBZ wobble is noise, not a tendency');
  Cells.resetTrends();
});

test('two scans is a line through anything: no verdict yet', () => {
  Cells.resetTrends();
  scanSeries('KTLX-NEW', [[0, 40, 40], [5, 55, 50]]);
  eq(Cells.trendOf('KTLX-NEW'), null, 'a 15 dBZ jump on two points stays unspoken');
  // Three scans crammed inside the minimum span are also refused.
  scanSeries('KTLX-FAST', [[0, 40, 40], [2, 45, 42], [4, 50, 44]]);
  eq(Cells.trendOf('KTLX-FAST'), null, 'three scans in four minutes is not a base');
  Cells.resetTrends();
});

test('a re-served scan is not a new observation, and dead cells are forgotten', () => {
  Cells.resetTrends();
  const now = Date.now();
  const cell = { id: 'KTLX-DUP', maxDbz: 50, top: 45,
    valid: new Date(now).toISOString() };
  Cells.ingest([cell], now);
  Cells.ingest([cell], now + 60000);       // same valid time re-fetched
  Cells.ingest([cell], now + 120000);
  eq(Cells.trendOf('KTLX-DUP'), null, 'one scan, however often fetched, is one point');
  // An hour of silence and the history is dropped rather than resumed.
  Cells.ingest([], now + 55 * 60000);
  scanSeries('KTLX-DUP', [[60, 30, 30], [65, 31, 31], [70, 30, 30]]);
  const t = Cells.trendOf('KTLX-DUP');
  ok(!t || t.firstDbz === 30, 'the old storm\'s history never bleeds into a new one');
  Cells.resetTrends();
});

test('near() carries each cell\'s fitted trend to the list it ranks', () => {
  Cells.resetTrends();
  // parse() builds ids as nexrad-storm_id; the helper's radar is KOUN.
  scanSeries('KOUN-T1', [[0, 38, 40], [5, 44, 44], [10, 50, 48]]);
  Cells.state.cells = Cells.parse([
    feature({ storm_id: 'T1', meso: '6', drct: 240, sknt: 25, max_dbz: 50, top: 48 }, -97.4, 35.2)
  ]);
  const list = Cells.near(35.0, -97.0, 400, 0);
  eq(list[0].trend.dir, 'strengthening', 'the ranked row knows its own tendency');
  Cells.state.cells = [];
  Cells.resetTrends();
});

test('environment adds context without overriding the detection', () => {
  const [c] = Cells.parse([feature({ meso: '7' }, -97.5, 35.0)]);
  const supportive = Cells.environment(c, { srh1: 320, shear6: { magnitude: 24 }, cape: 3000 });
  ok(/very large low-level helicity/.test(supportive), supportive);
  ok(/strong deep-layer shear/.test(supportive), supportive);

  const hostile = Cells.environment(c, { srh1: 40, shear6: { magnitude: 6 }, cape: 300 });
  ok(/helicity is weak/.test(hostile), hostile);
  ok(/weak deep-layer shear/.test(hostile), hostile);
});

test('environment returns null without a sounding', () => {
  const [c] = Cells.parse([feature({ meso: '7' }, -97.5, 35.0)]);
  eq(Cells.environment(c, null), null);
});

test('threat bands ascend without gaps', () => {
  const seen = Cells.BANDS.map(b => b.min);
  for (let i = 1; i < seen.length; i++) ok(seen[i - 1] > seen[i], 'bands descend by threshold');
  eq(Cells.band(100).key, 'extreme');
  eq(Cells.band(0).key, 'low');
  eq(Cells.band(45).key, 'high');
});

/* ── Radar sites ────────────────────────────────────────────────────────── */

function station(props, lon, lat) {
  return {
    type: 'Feature',
    geometry: { type: 'Point', coordinates: [lon, lat] },
    properties: Object.assign({
      id: 'KTLX', name: 'Oklahoma City', stationType: 'WSR-88D',
      elevation: { value: 370 },
      latency: { levelTwoLastReceivedTime: new Date().toISOString() },
      rda: { properties: { volumeCoveragePattern: 'R212', mode: 'Operational',
                           operabilityStatus: 'RDA - On-line', alarmSummary: 'No Alarms' } }
    }, props)
  };
}

test('vcpMode separates precipitation from clear-air scanning', () => {
  eq(Sites.vcpMode('R212'), 'precip');
  eq(Sites.vcpMode('R215'), 'precip');
  eq(Sites.vcpMode('R12'), 'precip');
  eq(Sites.vcpMode('R35'), 'clear');
  eq(Sites.vcpMode('R31'), 'clear');
  eq(Sites.vcpMode(null), 'unknown');
  eq(Sites.vcpMode('nonsense'), 'unknown');
});

test('vcpNumber pulls the digits out of the pattern code', () => {
  eq(Sites.vcpNumber('R212'), 212);
  eq(Sites.vcpNumber('L90'), 90);
  eq(Sites.vcpNumber(null), null);
});

test('parse extracts position, mode and operational state', () => {
  const [s] = Sites.parse([station({}, -97.28, 35.33)]);
  eq(s.id, 'KTLX');
  eq(s.lat, 35.33);
  eq(s.lon, -97.28);
  eq(s.scanMode, 'precip');
  eq(s.online, true);
  eq(s.usable, true);
});

// Plenty of radars report a maintenance flag while scanning perfectly well;
// treating those as down would hide most of the network.
test('a maintenance flag does not mark a scanning radar offline', () => {
  const [s] = Sites.parse([station({
    rda: { properties: { volumeCoveragePattern: 'R212',
                         operabilityStatus: 'RDA - Maintenance Action Required' } }
  }, -97.28, 35.33)]);
  eq(s.online, true, 'still receiving Level II data');
  eq(s.scanMode, 'precip');
});

test('a radar with stale data is offline', () => {
  const old = new Date(Date.now() - 3 * 3600 * 1000).toISOString();
  const [s] = Sites.parse([station({ latency: { levelTwoLastReceivedTime: old } }, -97.28, 35.33)]);
  eq(s.online, false);
});

test('a radar with no latency record is offline', () => {
  const [s] = Sites.parse([station({ latency: {} }, -97.28, 35.33)]);
  eq(s.online, false);
});

test('TDWR and profilers are listed but not usable for these products', () => {
  const parsed = Sites.parse([
    station({ id: 'TJFK', stationType: 'TDWR' }, -73.88, 40.58),
    station({ id: 'PROF', stationType: 'Profiler' }, -97.0, 35.0)
  ]);
  eq(parsed[0].usable, false);
  eq(parsed[1].usable, false);
});

test('parse drops stations without geometry', () => {
  eq(Sites.parse([{ type: 'Feature', geometry: null, properties: { id: 'X' } }]).length, 0);
});

test('near() sorts by distance and attaches bearing', () => {
  Sites.state.sites = Sites.parse([
    station({ id: 'FAR', name: 'Far' }, -100.0, 35.0),
    station({ id: 'NEAR', name: 'Near' }, -97.5, 35.0)
  ]);
  const list = Sites.near(35.0, -97.0);
  eq(list[0].id, 'NEAR');
  ok(list[0].distance < list[1].distance);
  near(list[0].bearing, 270, 2, 'the near site lies to the west');
  Sites.state.sites = [];
});

test('near() can filter to radars actively scanning storms', () => {
  Sites.state.sites = Sites.parse([
    station({ id: 'KCLR', rda: { properties: { volumeCoveragePattern: 'R35' } } }, -97.5, 35.0),
    station({ id: 'KWET', rda: { properties: { volumeCoveragePattern: 'R212' } } }, -98.5, 35.0)
  ]);
  const active = Sites.near(35.0, -97.0, { activeOnly: true });
  eq(active.length, 1);
  eq(active[0].id, 'KWET');
  Sites.state.sites = [];
});

test('near() excludes non-WSR-88D stations by default', () => {
  Sites.state.sites = Sites.parse([station({ id: 'TJFK', stationType: 'TDWR' }, -97.5, 35.0)]);
  eq(Sites.near(35.0, -97.0).length, 0);
  eq(Sites.near(35.0, -97.0, { usableOnly: false }).length, 1);
  Sites.state.sites = [];
});

test('search matches identifier or city, case-insensitively', () => {
  Sites.state.sites = Sites.parse([
    station({ id: 'KTLX', name: 'Oklahoma City' }, -97.28, 35.33),
    station({ id: 'KFWS', name: 'Dallas/Ft Worth' }, -97.30, 32.57)
  ]);
  eq(Sites.search('ktlx', 35, -97).length, 1);
  eq(Sites.search('tlx', 35, -97).length, 1);
  eq(Sites.search('dallas', 35, -97).length, 1);
  eq(Sites.search('OKLAHOMA', 35, -97).length, 1);
  eq(Sites.search('', 35, -97).length, 2, 'empty query returns everything');
  eq(Sites.search('zzz', 35, -97).length, 0);
  Sites.state.sites = [];
});

test('bestFor prefers a precipitation-mode radar over a nearer idle one', () => {
  Sites.state.sites = Sites.parse([
    station({ id: 'KIDLE', rda: { properties: { volumeCoveragePattern: 'R35' } } }, -97.1, 35.0),
    station({ id: 'KSTORM', rda: { properties: { volumeCoveragePattern: 'R212' } } }, -98.5, 35.0)
  ]);
  eq(Sites.bestFor(35.0, -97.0).id, 'KSTORM');
  Sites.state.sites = [];
});

test('bestFor falls back to the closest online radar when none are scanning storms', () => {
  Sites.state.sites = Sites.parse([
    station({ id: 'KNEAR', rda: { properties: { volumeCoveragePattern: 'R35' } } }, -97.1, 35.0),
    station({ id: 'KFAR', rda: { properties: { volumeCoveragePattern: 'R35' } } }, -99.0, 35.0)
  ]);
  eq(Sites.bestFor(35.0, -97.0).id, 'KNEAR');
  Sites.state.sites = [];
});

test('summary counts total, online and storm-scanning radars', () => {
  const stale = new Date(Date.now() - 3 * 3600 * 1000).toISOString();
  Sites.state.sites = Sites.parse([
    station({ id: 'A', rda: { properties: { volumeCoveragePattern: 'R212' } } }, -97.5, 35.0),
    station({ id: 'B', rda: { properties: { volumeCoveragePattern: 'R35' } } }, -98.5, 35.0),
    station({ id: 'C', latency: { levelTwoLastReceivedTime: stale } }, -99.5, 35.0),
    station({ id: 'T', stationType: 'TDWR' }, -97.6, 35.0)
  ]);
  const sum = Sites.summary();
  eq(sum.total, 3, 'TDWR is excluded');
  eq(sum.online, 2);
  eq(sum.precip, 1);
  Sites.state.sites = [];
});

test('coverage ring matches the product range of the radar type', () => {
  const [wsr] = Sites.parse([station({}, -97, 35)]);
  const [tdwr] = Sites.parse([station({ stationType: 'TDWR' }, -97, 35)]);
  eq(Sites.rangeKm(wsr), 230);
  eq(Sites.rangeKm(tdwr), 90);
});

test('every configured radar product declares its kind and a note', () => {
  const kinds = {};
  VaneConfig.RADAR_PRODUCTS.forEach(p => {
    ok(/^[A-Z0-9]+$/.test(p.id), `product id ${p.id}`);
    ok(p.label && p.note, `product ${p.id} needs a label and note`);
    ok(p.kind === 'reflectivity' || p.kind === 'velocity', `product ${p.id} kind`);
    kinds[p.kind] = true;
  });
  ok(kinds.velocity, 'velocity products must be offered — rotation is a velocity signature');
  ok(kinds.reflectivity, 'reflectivity products must be offered');
});

/* ── Forecaster's discussion: parsing ───────────────────────────────────── */

/* A real product from WFO Norman. Fixed-format teletype is unforgiving, so
 * the parser is tested against the actual bytes rather than a hand-written
 * approximation of them. */
const AFD = JSON.parse(
  fs.readFileSync(path.join(__dirname, 'fixtures/afd.json'), 'utf8')
).productText;

test('AFD parser finds the office and issuance from the preamble', () => {
  const p = Brief.parse(AFD);
  eq(p.office, 'Norman OK');
  eq(p.issued, '529 AM CDT Thu Aug 13 2026');
  eq(p.wmo, 'FXUS64 KOUN 131029');
});

test('AFD parser splits the product into its sections in order', () => {
  const names = Brief.parse(AFD).sections.map(s => s.name);
  eq(names[0], 'KEY MESSAGES');
  eq(names[1], 'NEAR TERM');
  eq(names[2], 'SHORT TERM');
  eq(names[3], 'LONG TERM');
  ok(names.indexOf('AVIATION') > 0, 'AVIATION section');
  // Slashes appear inside real section names and must survive.
  ok(names.indexOf('PRELIMINARY POINT TEMPS/POPS') > 0, 'slashes in a section name');
});

test('the `...New AVIATION...` update marker is not read as a section', () => {
  const names = Brief.parse(AFD).sections.map(s => s.name);
  eq(names.filter(n => n === 'AVIATION').length, 1, 'AVIATION appears once');
  ok(!names.some(n => /^New/.test(n)), 'no section named from the update marker');
});

test('section separators and the end marker are stripped from body text', () => {
  Brief.parse(AFD).sections.forEach(s => {
    ok(s.text.indexOf('\n&&') === -1, `&& leaked into ${s.name}`);
    ok(s.text.indexOf('$$') === -1, `$$ leaked into ${s.name}`);
  });
});

test('each section carries its own issuance time, which differs from the header', () => {
  const p = Brief.parse(AFD);
  const near = p.sections.find(s => s.name === 'NEAR TERM');
  const avn = p.sections.find(s => s.name === 'AVIATION');
  eq(near.issued, '131 AM CDT Thu Aug 13 2026');
  eq(avn.issued, '524 AM CDT Thu Aug 13 2026');
  // The point of showing it: NEAR TERM is four hours older than the product.
  ok(near.issued !== p.issued, 'section time differs from the product time');
  ok(near.text.indexOf('Issued at') === -1, 'the lifted line is removed from the body');
});

test('key messages come back as bullets, without the administrative line', () => {
  const km = Brief.keyMessages(Brief.parse(AFD));
  eq(km.length, 3);
  ok(!km.some(b => /^Updated at/.test(b)), 'the "Updated at" line is not a key message');
  // Bullets wrap across lines in the source and must be rejoined.
  ok(km[1].indexOf('this afternoon and evening') > 0, 'wrapped bullet rejoined');
});

test('a product with no key messages section yields no bullets', () => {
  eq(Brief.keyMessages(Brief.parse('.NEAR TERM...\nQuiet.\n\n$$')).length, 0);
});

test('section order follows the reader: chase puts fire weather before long term', () => {
  const parsed = Brief.parse(
    '.LONG TERM...\nNext week.\n\n&&\n\n.FIRE WEATHER...\nRed flag.\n\n&&\n\n' +
    '.NEAR TERM...\nToday.\n\n$$');
  eq(Brief.ordered(parsed, 'chase').map(s => s.name).join(','),
    'NEAR TERM,FIRE WEATHER,LONG TERM');
  eq(Brief.ordered(parsed, 'simple').map(s => s.name).join(','),
    'NEAR TERM,LONG TERM,FIRE WEATHER');
});

/* ── Extended outlook ───────────────────────────────────────────────────── */

test('percentiles interpolate between members rather than snapping to one', () => {
  const v = [1, 2, 3, 4];
  eq(Outlook.percentile(v, 0), 1);
  eq(Outlook.percentile(v, 1), 4);
  eq(Outlook.percentile(v, 0.5), 2.5);
  eq(Outlook.percentile(v, 0.25), 1.75);
  eq(Outlook.percentile([7], 0.9), 7, 'a single member is its own percentile');
  eq(Outlook.percentile([], 0.5), null);
});

test('member statistics ignore the ragged tail rather than counting it as zero', () => {
  const s = Outlook.stats([10, null, 12, undefined, 14, NaN, 16]);
  eq(s.n, 4, 'only real values are counted');
  eq(s.min, 10); eq(s.max, 16); eq(s.median, 13);
  near(s.mean, 13, 1e-9);
  eq(s.spread, s.p90 - s.p10);
});

test('day of year, and a window that wraps the new year', () => {
  eq(Outlook.dayOfYear('2026-01-01'), 1);
  eq(Outlook.dayOfYear('2026-12-31'), 365);
  eq(Outlook.dayOfYear('2024-12-31'), 366, 'leap year');
  // A window around 2 January must reach back into the previous December.
  eq(Outlook.doyDistance(2, 364), 4);
  eq(Outlook.doyDistance(200, 100), 100);
});

test('climatology pools a window across every year in the archive', () => {
  // Three years of a synthetic January, warming by a degree each year.
  const time = [], tmax = [], tmin = [], precip = [];
  [2022, 2023, 2024].forEach((y, k) => {
    for (let d = 1; d <= 28; d++) {
      time.push(`${y}-01-${String(d).padStart(2, '0')}`);
      tmax.push(10 + k);
      tmin.push(0 + k);
      precip.push(d % 4 === 0 ? 5 : 0);      // one wet day in four
    }
  });
  const c = Outlook.climatology({ time, tmax, tmin, precip }, '2026-01-14', { window: 7 });
  eq(c.samples, 45, '15 days × 3 years');
  near(c.tmax.mean, 11, 1e-9);
  near(c.wetFrequency, 0.2, 0.09);
});

test('skill is the ensemble spread measured against the climate spread', () => {
  const ens = { spread: 2 }, clim = { spread: 10 };
  near(Outlook.skillRatio(ens, clim), 0.2, 1e-9);
  eq(Outlook.skillRatio(ens, { spread: 0 }), null, 'a zero climate spread is not a ratio');
  eq(Outlook.skillRatio(null, clim), null);
  eq(Outlook.bandFor(0.2).key, 'firm');
  eq(Outlook.bandFor(0.5).key, 'soft');
  eq(Outlook.bandFor(0.8).key, 'trend');
  eq(Outlook.bandFor(1.4).key, 'none');
  eq(Outlook.bandFor(null), null);
});

test('the horizon needs two consecutive low-skill days, not one noisy one', () => {
  const band = k => ({ key: k });
  // A single 'trend' day in the middle of firm days is noise, not the horizon.
  eq(Outlook.horizonIndex([
    { band: band('firm') }, { band: band('trend') }, { band: band('firm') },
    { band: band('firm') }, { band: band('trend') }, { band: band('none') }
  ]), 4);
  eq(Outlook.horizonIndex([
    { band: band('firm') }, { band: band('soft') }, { band: band('firm') }
  ]), -1, 'no sustained loss of skill means no horizon');
});

test('a temperature anomaly converts as a difference, not as a temperature', () => {
  // 5 °C above normal is 9 °F above normal. Adding 32 here is the classic bug.
  eq(Outlook.describeAnomaly(5, true), '9 °F above normal');
  eq(Outlook.describeAnomaly(5, false), '5 °C above normal');
  eq(Outlook.describeAnomaly(-3, false), '3 °C below normal');
  eq(Outlook.describeAnomaly(0.4, false), 'near normal');
  eq(Outlook.describeAnomaly(null, false), null);
});

/* Built from the real captured ECMWF ensemble and twenty years of ERA5, so
 * the assertions below are about the actual atmosphere, not a mock of it. */
const ENS = JSON.parse(fs.readFileSync(path.join(__dirname, 'fixtures/ensemble-daily.json'), 'utf8'));
const NORM = JSON.parse(fs.readFileSync(path.join(__dirname, 'fixtures/normals.json'), 'utf8'));

function reshape(j) {
  const d = j.daily;
  const members = base => {
    const keys = Object.keys(d).filter(k => k === base || k.indexOf(base + '_member') === 0);
    return d.time.map((_, i) => keys.map(k => d[k][i]).filter(v => v !== null && !isNaN(v)));
  };
  return {
    model: 'ecmwf_ifs025', time: d.time, utcOffsetSeconds: j.utc_offset_seconds || 0,
    tmax: members('temperature_2m_max'), tmin: members('temperature_2m_min'),
    precip: members('precipitation_sum')
  };
}

const ARCHIVE = {
  years: 20, from: 2006, to: 2025,
  time: NORM.daily.time, tmax: NORM.daily.temperature_2m_max,
  tmin: NORM.daily.temperature_2m_min, precip: NORM.daily.precipitation_sum
};

test('the real ensemble carries the full ECMWF membership', () => {
  const e = reshape(ENS);
  ok(e.tmax[0].length >= 50, `day 1 has ${e.tmax[0].length} members`);
});

test('ensemble spread grows with lead time — the whole point of the panel', () => {
  const o = Outlook.build(reshape(ENS), ARCHIVE, null);
  const early = o.days[0].tmax.spread;
  const late = o.days[o.days.length - 1].tmax.spread;
  ok(early < 3, `day 1 spread ${early.toFixed(1)} °C is tight`);
  ok(late > early * 2.5, `day ${o.days.length} spread ${late.toFixed(1)} °C is much wider`);
});

test('trailing days with no members are dropped, not drawn empty', () => {
  const o = Outlook.build(reshape(ENS), ARCHIVE, null);
  ok(o.days.length >= 10 && o.days.length <= 16, `${o.days.length} usable days`);
  ok(o.days.every(d => d.members > 0), 'every remaining day has members');
});

test('the skill horizon lands inside the range and inside known limits', () => {
  const o = Outlook.build(reshape(ENS), ARCHIVE, null);
  ok(o.horizon > 0, 'a horizon was found');
  ok(o.horizon < o.days.length, 'and it is inside the range');
  // If this ever resolved past two weeks, the ratio would be measuring
  // something other than predictability.
  ok(o.horizon <= 14, `horizon at index ${o.horizon}`);
  ok(o.days[0].band.key === 'firm', 'tomorrow is a forecast');
});

test('every day carries a normal to be compared against', () => {
  const o = Outlook.build(reshape(ENS), ARCHIVE, null);
  ok(o.hasNormals);
  o.days.forEach(d => {
    ok(d.normal && d.normal.tmax, `normal for ${d.date}`);
    ok(d.normal.samples > 200, `${d.normal.samples} samples for ${d.date}`);
    ok(d.anomaly !== null, `anomaly for ${d.date}`);
    ok(d.precipProbability >= 0 && d.precipProbability <= 1, 'probability is a probability');
  });
});

test('without the archive the outlook still builds, but claims no horizon', () => {
  const o = Outlook.build(reshape(ENS), null, null);
  ok(o, 'it still builds');
  eq(o.hasNormals, false);
  eq(o.horizon, -1, 'no climate reference means no measured horizon');
  ok(o.days.every(d => d.skill === null), 'and no skill ratio is invented');
  ok(/could not be loaded/.test(Outlook.caveat(o)), 'and it says so');
});

test('the summary names a date rather than an ambiguous day number', () => {
  const o = Outlook.build(reshape(ENS), ARCHIVE, null);
  const s = Outlook.summary(o, true);
  // \b matters: "Wednesday 19 August" must not read as "day 19".
  ok(!/\bday \d/.test(s), `"day N" is ambiguous about whether today is 0 or 1: ${s}`);
  ok(/January|February|March|April|May|June|July|August|September|October|November|December/.test(s),
    `summary names the date: ${s}`);
});

test('the caveat states what an ensemble does and does not buy you', () => {
  const o = Outlook.build(reshape(ENS), ARCHIVE, null);
  const c = Outlook.caveat(o);
  ok(/do not extend how far ahead/.test(c), 'no claim of extended range');
  ok(/measure it/.test(c), 'what it does instead');
  ok(/not at a fixed day/.test(c), 'the horizon is measured, not asserted');
});

/* ── Shot planning ──────────────────────────────────────────────────────── */

// A cell moving toward the north-east: `fromDeg` is the direction it comes
// FROM, matching the meteorological convention used throughout the app.
function shotCell(over) {
  return Object.assign({
    id: 'KTLX-A1', site: 'KTLX', stormId: 'A1',
    lat: 35.5, lon: -97.5,
    tvs: false, mesoRank: 0, posh: 0, poh: 0, maxSize: 0,
    vil: 40, maxDbz: 58, maxDbzHeight: 30, top: 50,
    vilDensity: Cells.vilDensity(40, 50),
    fromDeg: 225, speedKt: 30
  }, over || {});
}

test('relative sun azimuth wraps the compass correctly', () => {
  eq(Shot.relativeAzimuth(10, 350), 20, 'across north');
  eq(Shot.relativeAzimuth(350, 10), 20, 'and back the other way');
  eq(Shot.relativeAzimuth(0, 180), 180, 'directly opposed');
  eq(Shot.relativeAzimuth(90, 90), 0, 'sun directly behind the storm');
});

test('light direction is read from the sun, not from the clock', () => {
  // Sun directly behind the storm from the viewer: a silhouette.
  eq(Shot.LIGHT[0].key, 'backlit');
  const back = Shot.relativeAzimuth(180, 180);
  ok(back <= 45, 'sun behind the storm reads as backlit');
  // Sun directly behind the viewer: front-lit.
  const front = Shot.relativeAzimuth(180, 0);
  ok(front > 110, 'sun behind the viewer reads as front-lit');
});

test('light quality is a solar altitude, not a time of day', () => {
  eq(Shot.lightQuality(-20).key, 'night');
  eq(Shot.lightQuality(-2).key, 'twilight');
  eq(Shot.lightQuality(5).key, 'golden');
  eq(Shot.lightQuality(18).key, 'low');
  eq(Shot.lightQuality(60).key, 'high');
});

test('a precipitation-loaded storm is called unphotographable', () => {
  // High VIL for a modest depth: an HP storm with its updraft wrapped.
  const hp = shotCell({ vil: 60, top: 30, vilDensity: Cells.vilDensity(60, 30) });
  const s = Shot.structure(hp);
  eq(s.visibility.key, 'wrapped');
  ok(s.reasons.some(r => /precipitation-loaded/.test(r)));
});

test('a tall storm holding a modest core is called visible', () => {
  const classic = shotCell({ vil: 30, top: 55, maxDbzHeight: 33,
    vilDensity: Cells.vilDensity(30, 55) });
  const s = Shot.structure(classic);
  eq(s.visibility.key, 'clear');
  ok(s.reasons.some(r => /still lofting/.test(r)), 'core held high is noted');
  ok(s.reasons.some(r => /tall tower/.test(r)));
});

test('a collapsed core is penalised even when the density looks fine', () => {
  const collapsing = shotCell({ vil: 25, top: 50, maxDbzHeight: 10,
    vilDensity: Cells.vilDensity(25, 50) });
  const s = Shot.structure(collapsing);
  ok(s.reasons.some(r => /outflow-dominant/.test(r)));
  ok(s.visibility.score < Shot.structure(shotCell({ vil: 25, top: 50, maxDbzHeight: 33,
    vilDensity: Cells.vilDensity(25, 50) })).visibility.score,
    'a collapsed core scores lower than a lofted one at the same density');
});

test('framing gives a real angular size and a usable focal length', () => {
  const cell = shotCell({ top: 50 });          // 50 kft ≈ 15.2 km
  const near = Shot.framing(cell, 20);
  const far = Shot.framing(cell, 120);
  ok(near.angularWidthDeg > far.angularWidthDeg, 'closer subtends more');
  ok(near.focalMm < far.focalMm, 'and needs a wider lens');
  ok(near.elevationDeg > 30, `top is high in the frame at 20 km (${near.elevationDeg.toFixed(0)}°)`);
  ok(far.elevationDeg < 10, 'and low at 120 km');
  eq(Shot.framing(cell, 0), null);
});

test('earth curvature eventually puts the storm below the horizon', () => {
  const small = shotCell({ top: 20 });          // ~6 km
  ok(!Shot.framing(small, 100).baseBelowHorizon, 'still visible at 100 km');
  ok(Shot.framing(small, 400).baseBelowHorizon, 'gone at 400 km');
});

test('the suggested vantage lands on the inflow flank, never in the path', () => {
  const cell = shotCell();
  const t = Shot.target(cell, 35.0, -97.0, { date: new Date('2026-05-20T23:00:00Z') });
  ok(t, 'a moving cell yields a target');
  eq(t.inCorePath, false, 'and it is never in front of the core');
  // Storm travelling toward 045°; the observer must sit 90–150° clockwise.
  const off = ((t.bearingFromStorm - t.stormTowardDeg) % 360 + 360) % 360;
  ok(off >= 90 && off <= 150, `offset ${off.toFixed(0)}° is in the inflow arc`);
  // Standing at that bearing means looking back the other way.
  eq(Math.round(Shot.angularGap(t.lookBearing, (t.bearingFromStorm + 180) % 360)), 0);
});

test('a stationary cell has no flank, so no vantage is invented', () => {
  eq(Shot.target(shotCell({ speedKt: 0 }), 35, -97), null);
});

test('the vantage prefers the side with the sun behind you', () => {
  // Sun due west and low: an observer west of the storm looks east with the
  // sun at their back.
  ok(Shot.sunAtBack(270, 270, 15) > Shot.sunAtBack(90, 270, 15),
    'matching the sun azimuth scores higher');
  eq(Shot.sunAtBack(0, 180, -5), 0.5, 'below the horizon the sun stops deciding');
});

test('standoff scales with the storm and stays inside sane bounds', () => {
  ok(Shot.standoffKm(shotCell({ top: 20 })) >= 12);
  ok(Shot.standoffKm(shotCell({ top: 60 })) <= 40);
  ok(Shot.standoffKm(shotCell({ top: 60 })) > Shot.standoffKm(shotCell({ top: 25 })),
    'a bigger storm needs more room to fit in frame');
});

test('the verdict leads with whatever is actually ruling the shot out', () => {
  const wrapped = { visibility: { key: 'wrapped' } };
  eq(Shot.verdict(wrapped, {}, null, { distance: 30 }).key, 'no-shot');

  const clear = { visibility: { key: 'clear' } };
  const noon = { quality: { key: 'high' }, direction: { key: 'frontlit', label: 'Front-lit' }, sunAltitude: 60 };
  eq(Shot.verdict(clear, noon, { baseBelowHorizon: false }, { distance: 3 }).key, 'too-close');
  eq(Shot.verdict(clear, noon, { baseBelowHorizon: true }, { distance: 300 }).key, 'too-far');

  const golden = { quality: { key: 'golden' }, direction: { key: 'side', label: 'Side-lit' }, sunAltitude: 5 };
  eq(Shot.verdict(clear, golden, { baseBelowHorizon: false }, { distance: 25 }).key, 'go');

  const back = { quality: { key: 'low' }, direction: { key: 'backlit', label: 'Backlit' }, sunAltitude: 15 };
  eq(Shot.verdict(clear, back, { baseBelowHorizon: false }, { distance: 25 }).key, 'silhouette');
});

/* ── The 3D model ───────────────────────────────────────────────────────── */

test('the 3D model is built from measured heights, in kilometres', () => {
  const m = Storm3D.model(shotCell({ top: 50, maxDbzHeight: 30 }), { lclKm: 1.2, shearMs: 25 });
  near(m.topKm, 50 * 0.3048, 0.01, '50 kft echo top');
  near(m.coreKm, 30 * 0.3048, 0.01, '30 kft core');
  eq(m.baseKm, 1.2, 'cloud base is the supplied LCL');
  eq(m.hasLcl, true);
  near(m.coreFraction, 0.6, 0.001);
});

test('without a sounding the model falls back and says so', () => {
  const m = Storm3D.model(shotCell({ top: 50 }), {});
  eq(m.hasLcl, false, 'the fallback base is flagged rather than passed off as an LCL');
  ok(m.baseKm > 0 && m.baseKm < m.topKm);
});

test('a base above the echo top is corrected rather than drawn inverted', () => {
  const m = Storm3D.model(shotCell({ top: 10 }), { lclKm: 9 });
  ok(m.baseKm < m.topKm, `base ${m.baseKm.toFixed(2)} km under top ${m.topKm.toFixed(2)} km`);
});

test('shear tilts the storm downshear, and no shear stands it up', () => {
  const sheared = Storm3D.model(shotCell(), { lclKm: 1, shearMs: 30, shearEast: 30, shearNorth: 0 });
  const still = Storm3D.model(shotCell(), { lclKm: 1, shearMs: 0 });
  ok(sheared.tiltPerKm > 0, 'sheared storms lean');
  eq(still.tiltPerKm, 0, 'unsheared storms do not');
  near(sheared.shearEast, 1, 1e-9, 'the shear direction is normalised');
  near(sheared.shearNorth, 0, 1e-9);
});

test('slabs run from base to top and lean further the higher they are', () => {
  const m = Storm3D.model(shotCell({ top: 50 }), { lclKm: 1, shearMs: 30, shearEast: 30, shearNorth: 0 });
  const s = Storm3D.slabs(m, 12);
  eq(s.length, 13);
  near(s[0].z, m.baseKm, 1e-9);
  near(s[s.length - 1].z, m.topKm, 1e-9);
  ok(s[s.length - 1].e > s[0].e, 'the top is displaced downshear of the base');
  eq(s[0].e, 0, 'and the base is not');
  ok(s[s.length - 1].r > s[0].r, 'the anvil is wider than the base');
});

test('a storm with no depth produces no geometry rather than dividing by zero', () => {
  eq(Storm3D.slabs(Storm3D.model(shotCell({ top: 0 }), {}), 8).length, 0);
});

test('the camera looks at what it was pointed at', () => {
  const cam = Storm3D.camera({ azimuth: 0, elevation: 0, range: 10,
    targetE: 0, targetN: 0, targetU: 0 });
  // Placed due north at azimuth 0, so it must look back south.
  near(cam.pos[1], 10, 1e-6);
  near(cam.fwd[1], -1, 1e-6);
  const p = Storm3D.project(cam, [0, 0, 0], 400, 300);
  ok(p, 'the target projects');
  near(p.x, 200, 0.5, 'to the centre of frame');
  near(p.y, 150, 0.5);
  eq(Storm3D.project(cam, [0, 20, 0], 400, 300), null, 'and anything behind the camera does not');
});

/* ── Reading dBZ back out of the radar image ────────────────────────────── */

test('the packed colour ramp is IEM\'s published table, in uniform steps', () => {
  const r = Reflectivity.ramp();
  eq(r.length, 255, '255 half-decibel steps');
  eq(r[0].dbz, -32);
  eq(r[r.length - 1].dbz, 95);
  r.forEach((e, i) => {
    near(e.dbz, -32 + i * 0.5, 1e-9, `step ${i}`);
    ok(e.r >= 0 && e.r <= 255 && e.g >= 0 && e.g <= 255 && e.b >= 0 && e.b <= 255);
  });
});

test('colours sampled from real tiles invert exactly, not approximately', () => {
  // Every one of these was read out of a live KDMX/KMXX N0Q tile.
  eq(Reflectivity.toDbz(148, 155, 181, 255), -0.5);
  eq(Reflectivity.toDbz(15, 183, 20, 255), 24.5);
  eq(Reflectivity.toDbz(16, 205, 23, 255), 22.5);
  eq(Reflectivity.toDbz(89, 214, 179, 255), 18.5);
  eq(Reflectivity.toDbz(77, 125, 178, 255), 11.5);
});

test('transparent and off-ramp pixels are rejected rather than forced onto the scale', () => {
  eq(Reflectivity.toDbz(0, 0, 0, 0), null, 'fully transparent is no data');
  eq(Reflectivity.toDbz(38, 38, 38, 255), null, 'a base-map grey is not reflectivity');
  eq(Reflectivity.toDbz(255, 0, 255, 255), null, 'nor is an arbitrary colour');
});

test('the ramp round-trips: a dBZ picks a colour that inverts back to it', () => {
  [-30, -5, 0, 12.5, 30, 47.5, 60, 75].forEach(d => {
    const c = Reflectivity.colourFor(d);
    eq(Reflectivity.toDbz(c.r, c.g, c.b, 255), d, `${d} dBZ round-trip`);
  });
});

test('RainViewer tiles invert through its published Universal Blue table', () => {
  // Rows straight from rainviewer_api_colors_table.csv, rain block.
  eq(Reflectivity.toDbzRainViewer(0x88, 0xdd, 0xee, 255), 15);
  eq(Reflectivity.toDbzRainViewer(0x00, 0xa3, 0xe0, 255), 20);
  eq(Reflectivity.toDbzRainViewer(0xff, 0xee, 0x00, 255), 35);
  eq(Reflectivity.toDbzRainViewer(0xc1, 0x00, 0x00, 255), 50);
  eq(Reflectivity.toDbzRainViewer(0xff, 0x4e, 0xff, 255), 64);
});

test('RainViewer plateaus decode to their lower edge — never stronger than seen', () => {
  eq(Reflectivity.toDbzRainViewer(255, 255, 255, 255), 65, 'white spans 65-74');
  eq(Reflectivity.toDbzRainViewer(0, 255, 0, 255), 75, 'green spans 75-95');
});

test('translucent RainViewer pixels are identified by alpha, whatever canvas did to the RGB', () => {
  eq(Reflectivity.toDbzRainViewer(0x63, 0x61, 0x59, 0x14), -10);
  eq(Reflectivity.toDbzRainViewer(0xde, 0xd0, 0x97, 0xbe), 14);
  // Premultiplied readback mangles the colour of a translucent pixel; the
  // alpha survives, and the alpha alone is unique per decibel.
  eq(Reflectivity.toDbzRainViewer(12, 200, 3, 150), 10);
  eq(Reflectivity.toDbzRainViewer(0, 0, 0, 0), null, 'transparent is nothing');
  eq(Reflectivity.toDbzRainViewer(200, 190, 140, 201), null, 'an alpha not in the table is not guessed');
  eq(Reflectivity.toDbzRainViewer(38, 38, 38, 255), null, 'a base-map grey is not reflectivity');
});

test('the RainViewer table round-trips across the whole rain range', () => {
  for (let d = -10; d <= 64; d++) {
    const c = Reflectivity.colourForRainViewer(d);
    const back = c.alpha !== undefined
      ? Reflectivity.toDbzRainViewer(0, 0, 0, c.alpha)
      : Reflectivity.toDbzRainViewer(c.r, c.g, c.b, 255);
    eq(back, d, `${d} dBZ round-trip`);
  }
});

test('web mercator round-trips at the zooms the sampler uses', () => {
  [8, 9, 10].forEach(z => {
    [[35.4, -97.5], [41.7, -93.7], [-33.9, 151.2]].forEach(([lat, lon]) => {
      near(Reflectivity.tileXToLon(Reflectivity.lonToTileX(lon, z), z), lon, 1e-9);
      near(Reflectivity.tileYToLat(Reflectivity.latToTileY(lat, z), z), lat, 1e-7);
    });
  });
});

/* ── VaneMotion: the on-device motion fit ───────────────────────────────── */

// A compact echo with an intensity falloff — the shape a correlation peak
// can actually lock onto, unlike a flat disc.
function blobGrid(n, cx, cy, r, dbz) {
  const g = [];
  for (let j = 0; j < n; j++) {
    const row = [];
    for (let i = 0; i < n; i++) {
      const d = Math.sqrt((i - cx) ** 2 + (j - cy) ** 2);
      row.push(d <= r ? dbz - d : null);
    }
    g.push(row);
  }
  return g;
}

function flatGrid(n, dbz) {
  return Array.from({ length: n }, () => Array.from({ length: n }, () => dbz));
}

test('block match recovers a known echo displacement exactly', () => {
  const n = 32;
  const a = Motion.weights(blobGrid(n, 12, 16, 5, 45), n);
  const b = Motion.weights(blobGrid(n, 16, 14, 5, 45), n);
  const s = Motion.bestShift(a.w, b.w, n, 8);
  ok(s, 'a peak was found');
  eq(s.dx, 4, '4 cells east');
  eq(s.dy, -2, '2 cells north');
});

test('a uniform field is no verdict, never "stationary"', () => {
  // Uniform rain has no trackable structure. The correlation surface is
  // nearly flat — its small zero-shift bias is pure window overlap — and
  // reporting that as stationary would be learning from nothing.
  const n = 32;
  const w = Motion.weights(flatGrid(n, 30), n);
  eq(Motion.bestShift(w.w, w.w, n, 8), null);
});

test('an empty field carries no weight to learn from', () => {
  const n = 16;
  const w = Motion.weights(Array.from({ length: n }, () => Array(n).fill(null)), n);
  eq(w.cells, 0);
});

test('the least-squares fit turns consistent displacements into one velocity', () => {
  const v = Motion.fitVelocity([
    { eastKm: 5, northKm: -2.5, dtMin: 10 },
    { eastKm: 5, northKm: -2.5, dtMin: 10 },
    { eastKm: 5, northKm: -2.5, dtMin: 10 }
  ]);
  near(v.east, 30, 1e-9, '5 km per 10 min is 30 km/h');
  near(v.north, -15, 1e-9);
  near(v.residualKmh, 0, 1e-9, 'perfect agreement, zero residual');
});

test('pairs that disagree show up in the residual, not in false confidence', () => {
  const v = Motion.fitVelocity([
    { eastKm: 5, northKm: 0, dtMin: 10 },
    { eastKm: -5, northKm: 0, dtMin: 10 }
  ]);
  near(v.east, 0, 1e-9, 'the contradiction cancels');
  near(v.residualKmh, 30, 1e-9, 'and the residual says how badly they fought');
});

test('arrival time is the upstream projection along the fitted motion', () => {
  const n = 25, g = Array.from({ length: n }, () => Array(n).fill(null));
  g[12][2] = 40;                          // 20 km due west of the pin
  const field = { grid: g, size: n, kmPerCell: 2 };
  const e = Motion.eta(field, { east: 40, north: 0, speed: 40 });
  ok(e, 'the upstream echo is found');
  near(e.minutes, 30, 1, '20 km at 40 km/h');
  eq(e.dir, 'W');
  eq(e.dbz, 40);
  near(e.distanceKm, 20, 0.6);
});

test('an echo moving away never gets an arrival time', () => {
  const n = 25, g = Array.from({ length: n }, () => Array(n).fill(null));
  g[12][2] = 40;                          // west of the pin…
  const field = { grid: g, size: n, kmPerCell: 2 };
  eq(Motion.eta(field, { east: -40, north: 0, speed: 40 }), null, '…and headed further west');
});

test('an echo whose track misses the pin gets no arrival time either', () => {
  const n = 25, g = Array.from({ length: n }, () => Array(n).fill(null));
  g[2][2] = 40;                           // 20 km west, 20 km north
  const field = { grid: g, size: n, kmPerCell: 2 };
  eq(Motion.eta(field, { east: 40, north: 0, speed: 40 }), null, 'it passes 20 km to the north');
});

test('the whole fit: a translating echo learns its own velocity and arrival', () => {
  const n = Motion.GRID, cell = (Motion.HALF_KM * 2) / (n - 1);
  // Two cells east per 10-minute frame, ending just west of the pin.
  const fields = [0, 1, 2, 3, 4, 5].map(k => ({
    grid: blobGrid(n, 6 + 2 * k, 24, 5, 45), size: n, kmPerCell: cell
  }));
  const m = Motion.fromFields(fields);
  ok(m, 'a verdict was learned');
  eq(m.stationary, false);
  eq(m.vector.toward, 'E');
  near(m.vector.speed, 12 * cell, 3, 'two cells per 10 minutes');
  eq(m.residualKmh, 0, 'the synthetic motion is perfectly linear');
  eq(m.overheadNow, false);
  ok(m.eta, 'the echo west of the pin is inbound');
  // The nearest in-blob cell sits half a grid cell off the axis, so the
  // 16-point compass may land one point either side of due west.
  ok(m.eta.dir.indexOf('W') !== -1, `from the western quadrant (${m.eta && m.eta.dir})`);
  ok(m.eta.minutes > 2 && m.eta.minutes < 45, `arrives in ${m.eta && m.eta.minutes} min`);
});

test('identical frames with an echo learn as stationary — never a fabricated arrival', () => {
  const n = Motion.GRID, cell = (Motion.HALF_KM * 2) / (n - 1);
  const f = { grid: blobGrid(n, 24, 20, 6, 45), size: n, kmPerCell: cell };
  const m = Motion.fromFields([f, f, f, f, f, f]);
  ok(m, 'a sharp zero-shift peak is a real verdict');
  eq(m.stationary, true);
  eq(m.eta, null);
  eq(m.vector.speed, 0);
});

test('clear sky everywhere is nothing to learn from', () => {
  const n = Motion.GRID, cell = (Motion.HALF_KM * 2) / (n - 1);
  const empty = {
    grid: Array.from({ length: n }, () => Array(n).fill(null)),
    size: n, kmPerCell: cell
  };
  eq(Motion.fromFields([empty, empty, empty, empty, empty, empty]), null);
});

test('RainViewer frames: real intervals drive the fit, and arrival counts from now', () => {
  const n = Motion.GRID, cell = (Motion.HALF_KM * 2) / (n - 1);
  const NOW = Date.parse('2026-10-03T12:00:00Z');
  // Same two-cells-per-step echo, but steps are RainViewer's ten minutes
  // with one frame missing — so one pair spans twenty minutes and four cells.
  const steps = [0, 1, 2, 4, 5, 6];
  const fields = steps.map(k => ({ grid: blobGrid(n, 2 + 2 * k, 24, 5, 45), size: n, kmPerCell: cell }));
  const latestT = NOW - 8 * 60000;      // the newest frame is eight minutes old
  const times = steps.map(k => latestT - (6 - k) * 600000);
  const m = Motion.fromFields(fields, { times, now: NOW, source: 'rainviewer' });
  ok(m, 'a verdict was learned');
  eq(m.residualKmh, 0, 'the 20-minute pair agrees with the 10-minute ones');
  near(m.vector.speed, 12 * cell, 3, 'two cells per ten minutes, gap or not');
  eq(m.source, 'rainviewer');
  eq(m.spanMin, 60);
  eq(m.observedAt, latestT);
  // The same fit, with the frame taken to be current, arrives 8 min later.
  const fresh = Motion.fromFields(fields, { times: times.map(t => t + 8 * 60000), now: NOW });
  ok(m.eta && fresh.eta, 'both see the inbound echo');
  eq(fresh.eta.minutes - m.eta.minutes, 8, 'the frame\'s age comes off the arrival time');
});

test('the IEM path is unchanged when no times are given', () => {
  const n = Motion.GRID, cell = (Motion.HALF_KM * 2) / (n - 1);
  const fields = [0, 1, 2, 3, 4, 5].map(k => ({ grid: blobGrid(n, 6 + 2 * k, 24, 5, 45), size: n, kmPerCell: cell }));
  const m = Motion.fromFields(fields);
  eq(m.source, 'nexrad');
  eq(m.spanMin, Motion.OFFSETS[0]);
});

/* ── The 3D built from that field ───────────────────────────────────────── */

function fakeField(rows, halfKm) {
  const flat = rows.flat().filter(v => v !== null);
  return {
    grid: rows, size: rows.length, halfKm: halfKm || 10,
    kmPerCell: (halfKm || 10) * 2 / (rows.length - 1),
    maxDbz: Math.max.apply(null, flat), coverage: flat.length / (rows.length * rows.length)
  };
}

test('the drawn floor follows the storm rather than a fixed cut', () => {
  eq(Storm3D.floorFor({ maxDbz: 70 }), 35, 'a violent storm shows its top 35 dB');
  eq(Storm3D.floorFor({ maxDbz: 30 }), 15, 'a weak one is not cut down to nothing');
  ok(Storm3D.floorFor({ maxDbz: 20 }) >= Storm3D.DBZ_FLOOR, 'never below the clutter floor');
});

test('the strongest return reaches the measured echo top, exactly', () => {
  const m = Storm3D.model(shotCell({ top: 50, maxDbzHeight: 30 }), { lclKm: 1, shearMs: 0 });
  const cols = Storm3D.columns(m, fakeField([[null, 20], [45, 60]]));
  const tallest = cols.reduce((a, c) => (c.z1 > a.z1 ? c : a));
  eq(tallest.dbz, 60, 'the strongest return is the tallest column');
  near(tallest.z1, 50 * 0.3048, 1e-9, 'and it reaches the measured echo top');
  cols.forEach(c => {
    ok(c.z1 <= m.topKm + 1e-9, 'nothing exceeds the measured top');
    ok(c.z0 === m.baseKm, 'every column starts at cloud base');
  });
});

test('returns below the floor are dropped, not drawn flat', () => {
  // Floor for a 60 dBZ field is 25; the 20 dBZ node must not appear.
  const m = Storm3D.model(shotCell({ top: 40 }), { lclKm: 1 });
  const cols = Storm3D.columns(m, fakeField([[20, 30], [45, 60]]));
  eq(cols.length, 3);
  ok(!cols.some(c => c.dbz === 20));
});

test('columns are placed in a north-up frame matching the grid', () => {
  const m = Storm3D.model(shotCell({ top: 40 }), { lclKm: 1 });
  // Row 0 is the north edge, column 0 the west edge.
  const cols = Storm3D.columns(m, fakeField([[60, 59], [58, 57]], 10));
  const nw = cols.find(c => c.dbz === 60);
  const se = cols.find(c => c.dbz === 57);
  ok(nw.n > 0 && nw.e < 0, `row 0 col 0 is north-west (e=${nw.e}, n=${nw.n})`);
  ok(se.n < 0 && se.e > 0, 'the last row and column is south-east');
});

test('shear displaces the tops downshear and leaves the bases alone', () => {
  const m = Storm3D.model(shotCell({ top: 50 }), { lclKm: 1, shearMs: 30, shearEast: 30, shearNorth: 0 });
  const cols = Storm3D.columns(m, fakeField([[30, 40], [50, 60]]));
  const tall = cols.reduce((a, c) => (c.z1 > a.z1 ? c : a));
  const short = cols.reduce((a, c) => (c.z1 < a.z1 ? c : a));
  ok(tall.le > short.le, 'a taller column leans further downshear');
  eq(tall.ln, 0, 'and only in the shear direction');
});

test('no field yields no columns, so the fallback silhouette takes over', () => {
  const m = Storm3D.model(shotCell({ top: 40 }), {});
  eq(Storm3D.columns(m, null).length, 0);
  eq(Storm3D.columns(m, { grid: null }).length, 0);
  eq(Storm3D.columns(m, fakeField([[null, null], [null, null]])).length, 0);
});

/* ── Installing to a home screen ────────────────────────────────────────── */

/* The shim's navigator is mutable, so each case sets the platform it means.
 * Restored afterwards so ordering never matters. */
function asPlatform(ua, touchPoints, standalone) {
  sandbox.navigator.userAgent = ua;
  sandbox.navigator.maxTouchPoints = touchPoints || 0;
  sandbox.navigator.standalone = standalone;
}

test('iOS is detected, including an iPad that claims to be a Mac', () => {
  asPlatform('Mozilla/5.0 (iPhone; CPU iPhone OS 17_0 like Mac OS X)');
  ok(Install.isIos(), 'iPhone');
  asPlatform('Mozilla/5.0 (iPad; CPU OS 16_0 like Mac OS X)');
  ok(Install.isIos(), 'older iPad');
  // iPadOS 13+ reports a desktop Safari UA; the touch points are the tell.
  asPlatform('Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7)', 5);
  ok(Install.isIos(), 'iPad reporting itself as a Mac');
  asPlatform('Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7)', 0);
  ok(!Install.isIos(), 'an actual Mac is not iOS');
  asPlatform('Mozilla/5.0 (Linux; Android 14)');
  ok(!Install.isIos());
});

test('an installed app knows it is installed and stops offering', () => {
  asPlatform('Mozilla/5.0 (iPhone)', 1, true);        // Safari's own flag
  eq(Install.status().state, 'installed');
  eq(Install.status().can, false);
  eq(Install.shouldOfferBanner(), false, 'no banner once it is on the home screen');
  asPlatform('Mozilla/5.0 (Linux; Android 14)', 1, undefined);
});

test('iOS is told how to install rather than shown a button that cannot work', () => {
  asPlatform('Mozilla/5.0 (iPhone; CPU iPhone OS 17_0 like Mac OS X)', 1);
  const s = Install.status();
  eq(s.state, 'ios');
  eq(s.can, false, 'no prompt API exists on iOS, so no Install button');
  ok(/Add to Home Screen/.test(s.note), 'the actual instructions instead');
  ok(Install.shouldOfferBanner(), 'but it is still offered');
});

test('a browser that has not offered an install says so, without pretending', () => {
  asPlatform('Mozilla/5.0 (Linux; Android 14)', 1);
  const s = Install.status();
  eq(s.state, 'unavailable');
  eq(s.can, false);
  ok(/Install app/.test(s.note), 'points at where the browser keeps it');
});

test('an insecure page cannot install, and explains why rather than failing quietly', () => {
  sandbox.isSecureContext = false;
  sandbox.location = { protocol: 'http:', hostname: 'example.com', search: '' };
  eq(Install.secure(), false);
  const s = Install.status();
  eq(s.state, 'insecure');
  ok(/https/.test(s.note));
  // localhost is a secure context by definition, which is what makes local
  // development possible at all.
  sandbox.location = { protocol: 'http:', hostname: 'localhost', search: '' };
  eq(Install.secure(), true);
  sandbox.isSecureContext = true;
  sandbox.location = { protocol: 'https:', hostname: 'example.com', search: '' };
});

test('dismissing is remembered, so the offer is made once', () => {
  asPlatform('Mozilla/5.0 (iPhone; CPU iPhone OS 17_0 like Mac OS X)', 1);
  eq(Install.dismissed(), false);
  ok(Install.shouldOfferBanner());
  Install.dismiss();
  eq(Install.dismissed(), true);
  eq(Install.shouldOfferBanner(), false, 'and not again');
  eq(store[Install.DISMISS_KEY], '1', 'persisted on the device');
  delete store[Install.DISMISS_KEY];
});

test('install() resolves rather than throwing when there is nothing to prompt', () => {
  asPlatform('Mozilla/5.0 (Linux; Android 14)', 1);
  return Install.install().then(state => {
    eq(state, 'unavailable', 'it reports why, instead of rejecting');
  });
});

/* ── The manifest ───────────────────────────────────────────────────────── */

const MANIFEST = JSON.parse(
  fs.readFileSync(path.join(__dirname, '..', 'manifest.webmanifest'), 'utf8'));

test('the manifest carries the PNG icons installers actually require', () => {
  const png = MANIFEST.icons.filter(i => i.type === 'image/png');
  const sizes = png.map(i => i.sizes);
  // Chrome will not offer an install without a 192 and a 512.
  ok(sizes.indexOf('192x192') !== -1, 'a 192px icon');
  ok(sizes.indexOf('512x512') !== -1, 'a 512px icon');
  png.forEach(i => {
    ok(fs.existsSync(path.join(__dirname, '..', i.src)), `${i.src} exists`);
    ok(fs.statSync(path.join(__dirname, '..', i.src)).size > 500, `${i.src} is a real file`);
  });
});

test('maskable icons are declared separately from ordinary ones', () => {
  const maskable = MANIFEST.icons.filter(i => (i.purpose || '').indexOf('maskable') !== -1);
  ok(maskable.length >= 1, 'at least one maskable icon');
  // "any maskable" on one asset means Android crops the same art it also shows
  // uncropped — one of the two always looks wrong. They are separate files.
  MANIFEST.icons.forEach(i => {
    ok(i.purpose !== 'any maskable',
      `${i.src} must not claim both purposes with one image`);
  });
  maskable.forEach(i => ok(i.src.indexOf('maskable') !== -1, 'and is its own artwork'));
});

test('the manifest is installable: display, scope, start and a name', () => {
  eq(MANIFEST.display, 'standalone');
  ok(MANIFEST.name && MANIFEST.name.length > 3);
  ok(MANIFEST.short_name && MANIFEST.short_name.length <= 12, 'short name fits a home screen');
  ok(MANIFEST.start_url, 'a start url');
  ok(MANIFEST.scope, 'a scope');
  // Relative so the app works from a subdirectory — GitHub Pages serves it
  // from /<repo>/, and an absolute "/" scope would break the service worker.
  eq(MANIFEST.start_url.charAt(0) === '/', false, 'start_url stays relative');
  eq(MANIFEST.scope.charAt(0) === '/', false, 'scope stays relative');
  // `id` resolves against the ORIGIN, not the manifest, so an absolute one
  // points at the site root and collides with anything else deployed there.
  eq(MANIFEST.id.charAt(0) === '/', false, 'id stays relative too');
});

test('every screenshot the manifest promises exists at the size it claims', () => {
  ok(MANIFEST.screenshots.length >= 2);
  MANIFEST.screenshots.forEach(sc => {
    const p = path.join(__dirname, '..', sc.src);
    ok(fs.existsSync(p), `${sc.src} exists`);
    // PNG header: width and height are big-endian uint32 at byte 16.
    const head = fs.readFileSync(p).subarray(0, 24);
    const w = head.readUInt32BE(16), h = head.readUInt32BE(20);
    eq(`${w}x${h}`, sc.sizes, `${sc.src} matches its declared size`);
    ok(sc.form_factor === 'narrow' || sc.form_factor === 'wide', 'form factor declared');
  });
  ok(MANIFEST.screenshots.some(s => s.form_factor === 'narrow'), 'a phone screenshot');
});

test('shortcuts point inside the app and at parameters it understands', () => {
  ok(MANIFEST.shortcuts.length >= 1);
  MANIFEST.shortcuts.forEach(sc => {
    ok(sc.url.indexOf('./') === 0, `${sc.url} is relative to the app`);
    const q = sc.url.split('?')[1] || '';
    q.split('&').filter(Boolean).forEach(pair => {
      const k = pair.split('=')[0];
      ok(k === 'mode' || k === 'tab', `${k} is a parameter the app reads`);
    });
  });
});

test('every file the service worker promises to cache is really there', () => {
  const sw = fs.readFileSync(path.join(__dirname, '..', 'sw.js'), 'utf8');
  const block = sw.slice(sw.indexOf('SHELL_FILES'), sw.indexOf('];', sw.indexOf('SHELL_FILES')));
  const files = (block.match(/'\.\/[^']*'/g) || []).map(s => s.slice(3, -1)).filter(Boolean);
  ok(files.length > 20, `${files.length} shell files listed`);
  files.forEach(f => {
    ok(fs.existsSync(path.join(__dirname, '..', f)), `sw.js caches ${f}, which must exist`);
  });
});

test('every script the page loads is in the offline shell', () => {
  const html = fs.readFileSync(path.join(__dirname, '..', 'index.html'), 'utf8');
  const sw = fs.readFileSync(path.join(__dirname, '..', 'sw.js'), 'utf8');
  const scripts = (html.match(/<script src="([^"]+)"/g) || [])
    .map(s => s.replace(/<script src="/, '').replace(/"$/, ''));
  ok(scripts.length > 15, `${scripts.length} scripts`);
  scripts.forEach(src => {
    ok(sw.indexOf("'./" + src + "'") !== -1,
      `${src} is loaded by index.html but missing from the offline shell`);
  });
});

/* ── The app icon badge ─────────────────────────────────────────────────── */

const alertOf = (severity, event) => ({ id: severity + event, severity, event, headline: event });

test('the badge counts only severe and above', () => {
  const alerts = [
    alertOf('Extreme', 'Tornado Warning'),
    alertOf('Severe', 'Severe Thunderstorm Warning'),
    alertOf('Moderate', 'Wind Advisory'),
    alertOf('Minor', 'Special Weather Statement'),
  ];
  // A badge that lights up for a routine advisory is a badge people stop
  // looking at, which costs them the one time it matters.
  eq(Settings.badgeCount(alerts), 2);
  eq(Settings.badgeCount([]), 0);
});

test('the badge respects the alert families the user muted', () => {
  const alerts = [alertOf('Extreme', 'Tornado Warning'), alertOf('Severe', 'Marine Warning')];
  eq(Settings.badgeCount(alerts), 2, 'both counted by default');
  const filters = Object.assign({}, Settings.get('filters'), { marine: false });
  Settings.save({ filters: filters });
  eq(Settings.badgeCount(alerts), 1, 'muting marine mutes the badge too');
  filters.marine = true;
  Settings.save({ filters: filters });
});

test('the badge follows the severity floor the user chose', () => {
  const alerts = [alertOf('Extreme', 'Tornado Warning'), alertOf('Moderate', 'Wind Advisory')];
  eq(Settings.badgeCount(alerts), 1);
  Settings.save({ notifyMinSeverity: 'Moderate' });
  eq(Settings.badgeCount(alerts), 2, 'lowering the floor counts more');
  Settings.save({ notifyMinSeverity: 'Severe' });
});

test('badging degrades silently where the API does not exist', () => {
  ok(!('setAppBadge' in sandbox.navigator), 'the shim has no Badging API');
  return Settings.updateBadge([alertOf('Extreme', 'Tornado Warning')]).then(r => {
    eq(r, 'unsupported', 'reported, not thrown');
  });
});

/* ── iOS launch screens ─────────────────────────────────────────────────── */

test('every launch image the page promises exists at the size it claims', () => {
  const html = fs.readFileSync(path.join(__dirname, '..', 'index.html'), 'utf8');
  const tags = html.match(/<link rel="apple-touch-startup-image"[^>]*>/g) || [];
  ok(tags.length >= 20, `${tags.length} launch images declared`);

  tags.forEach(tag => {
    const href = (tag.match(/href="([^"]+)"/) || [])[1];
    const media = (tag.match(/media="([^"]+)"/) || [])[1];
    ok(href && media, 'each tag has an href and a media query');

    const file = path.join(__dirname, '..', href);
    ok(fs.existsSync(file), `${href} exists`);

    // Apple matches on exact device metrics, so the file has to be exactly
    // points x ratio. A near-miss is simply never used, silently.
    const w = +(media.match(/device-width:\s*(\d+)px/) || [])[1];
    const h = +(media.match(/device-height:\s*(\d+)px/) || [])[1];
    const dpr = +(media.match(/device-pixel-ratio:\s*(\d+)/) || [])[1];
    const landscape = /orientation:\s*landscape/.test(media);
    const head = fs.readFileSync(file).subarray(0, 24);
    const px = head.readUInt32BE(16), py = head.readUInt32BE(20);
    const expect = landscape ? [h * dpr, w * dpr] : [w * dpr, h * dpr];
    eq(`${px}x${py}`, `${expect[0]}x${expect[1]}`, `${href} matches its media query`);
  });
});

test('both orientations are covered, since a dash mount is sideways', () => {
  const html = fs.readFileSync(path.join(__dirname, '..', 'index.html'), 'utf8');
  const tags = html.match(/<link rel="apple-touch-startup-image"[^>]*>/g) || [];
  const portrait = tags.filter(t => /orientation:\s*portrait/.test(t)).length;
  const landscape = tags.filter(t => /orientation:\s*landscape/.test(t)).length;
  eq(portrait, landscape, `${portrait} portrait, ${landscape} landscape`);
  ok(portrait >= 10, 'a real spread of devices');
});

/* ── The native scaffold ────────────────────────────────────────────────── */

/* It cannot be compiled here, so the only thing worth asserting is that it
 * never gets mistaken for something that was. */
test('the iOS scaffold is labelled untested wherever someone would look', () => {
  const dir = path.join(__dirname, '..', 'ios');
  if (!fs.existsSync(dir)) return;                  // optional in the repo

  const readme = fs.readFileSync(path.join(dir, 'README.md'), 'utf8');
  ok(/UNBUILT AND UNTESTED/.test(readme), 'the README leads with it');
  ok(/never been compiled/.test(readme), 'and says exactly what was not done');
  ok(/\$99/.test(readme), 'and states the cost of shipping it');

  const swift = [];
  (function walk(d) {
    fs.readdirSync(d).forEach(f => {
      const p = path.join(d, f);
      if (fs.statSync(p).isDirectory()) walk(p);
      else if (f.endsWith('.swift')) swift.push(p);
    });
  })(dir);
  ok(swift.length >= 4, `${swift.length} Swift sources`);
  swift.forEach(p => {
    ok(/UNTESTED/.test(fs.readFileSync(p, 'utf8')),
      `${path.basename(p)} carries the untested marker`);
  });
});

test('the web app does not depend on the native scaffold in any way', () => {
  const html = fs.readFileSync(path.join(__dirname, '..', 'index.html'), 'utf8');
  const sw = fs.readFileSync(path.join(__dirname, '..', 'sw.js'), 'utf8');
  ok(html.indexOf('ios/') === -1, 'index.html never references it');
  ok(sw.indexOf('ios/') === -1, 'and it is not in the offline shell');
});



/* ── Observed precipitation outranks the forecast ───────────────────────
   The bug this guards: Open-Meteo's 15-minute precipitation is model output,
   and when the model missed a shower the app told somebody standing in the
   rain that no rain was expected for two hours. A forecast that contradicts
   the window destroys trust in every other number on the page.

   Vane already fetched the nearest METAR and could already read dBZ back out
   of the radar tiles. These assert that it now uses them, and — just as
   important — that it never invents an observation it does not have. */

const OBS_NOW = Date.parse('2026-08-14T12:00:00Z');
const metarAt = (mins, extra) => Object.assign({
  station: 'KOUN',
  time: new Date(OBS_NOW - mins * 60000).toISOString()
}, extra);

test('a station reporting rain is believed', () => {
  const v = Derive.stationPrecip(metarAt(10, {
    presentWeather: [{ intensity: null, modifier: null, weather: 'rain', rawString: 'RA' }],
    raw: 'KOUN 141153Z 18008KT 5SM RA BKN012 22/21 A2990'
  }), OBS_NOW);
  eq(v.raining, true);
  eq(v.label, 'Rain');
  eq(v.ageMin, 10);
});

test('intensity comes through in words, not symbols', () => {
  const light = Derive.stationPrecip(metarAt(5, {
    presentWeather: [{ intensity: 'light', modifier: null, weather: 'rain', rawString: '-RA' }]
  }), OBS_NOW);
  eq(light.label, 'Light rain');
  const heavy = Derive.stationPrecip(metarAt(5, {
    presentWeather: [{ intensity: 'heavy', modifier: null, weather: 'snow', rawString: '+SN' }]
  }), OBS_NOW);
  eq(heavy.label, 'Heavy snow');
});

test('fog and mist are not precipitation', () => {
  // A real KORD report. Reading BR as rain would fire the override on a dry,
  // foggy morning — the false positive that would make the feature a nuisance.
  const v = Derive.stationPrecip(metarAt(8, {
    presentWeather: [{ intensity: null, modifier: null, weather: 'fog_mist', rawString: 'BR' }]
  }), OBS_NOW);
  eq(v.raining, false);
});

test('rain in the vicinity is not rain on you', () => {
  const v = Derive.stationPrecip(metarAt(8, {
    presentWeather: [{ intensity: null, modifier: null, weather: 'rain', rawString: 'VCSH' }]
  }), OBS_NOW);
  eq(v.raining, false);
});

test('a stale observation is not evidence about now', () => {
  eq(Derive.stationPrecip(metarAt(200, {
    presentWeather: [{ intensity: null, modifier: null, weather: 'rain', rawString: 'RA' }]
  }), OBS_NOW), null);
  // Nor is one stamped in the future by a skewed clock.
  eq(Derive.stationPrecip(metarAt(-90, {
    presentWeather: [{ intensity: null, modifier: null, weather: 'rain', rawString: 'RA' }]
  }), OBS_NOW), null);
});

test('the raw METAR is read when structured present weather is missing', () => {
  const v = Derive.stationPrecip(metarAt(12, {
    presentWeather: [],
    raw: 'KDSM 141154Z 09006KT 4SM -SHRA BR OVC009 19/18 A2988'
  }), OBS_NOW);
  eq(v.raining, true);
  ok(/rain/i.test(v.label), 'names the phenomenon: ' + v.label);
});

test('METAR remarks are never read as present weather', () => {
  /* RAB05 in the remarks means "rain began at :05" — past weather. Reading the
   * remarks section would report rain at a station that has since cleared. */
  const v = Derive.stationPrecip(metarAt(12, {
    presentWeather: [],
    raw: 'KOUN 141153Z 18008KT 10SM SCT040 28/19 A2990 RMK AO2 RAB05E22 SLP123'
  }), OBS_NOW);
  eq(v.raining, false);
});

test('a clear report is a dry verdict, not a missing one', () => {
  const v = Derive.stationPrecip(metarAt(9, {
    presentWeather: [],
    raw: 'KOUN 140855Z AUTO 17013G18KT 10SM CLR 29/18 A2991 RMK AO2'
  }), OBS_NOW);
  eq(v.raining, false);
  // ...but a station with nothing to read at all gives no verdict either way.
  eq(Derive.stationPrecip(metarAt(9, {}), OBS_NOW), null);
});

test('the station outranks the model — the reported bug', () => {
  const v = Derive.observedPrecip({
    now: OBS_NOW,
    observation: metarAt(6, {
      presentWeather: [{ intensity: null, modifier: null, weather: 'rain', rawString: 'RA' }]
    }),
    current: { precipitation: 0 }          // the model has missed it
  });
  eq(v.raining, true);
  eq(v.why, 'station');
});

test('radar overhead can carry the verdict when no station can', () => {
  const v = Derive.observedPrecip({
    now: OBS_NOW,
    overhead: { dbz: 38, at: OBS_NOW - 4 * 60000 },
    current: { precipitation: 0 }
  });
  eq(v.raining, true);
  eq(v.why, 'radar');
  eq(v.radar.dbz, 38);
});

test('a weak echo is reported but never asserted as rain', () => {
  /* 15-20 dBZ is the band the radar genuinely cannot resolve: drizzle, or
   * virga evaporating in the last kilometre it cannot see. */
  const v = Derive.observedPrecip({
    now: OBS_NOW,
    overhead: { dbz: 17, at: OBS_NOW },
    current: { precipitation: 0 }
  });
  eq(v.raining, false);
  eq(v.radar.trace, true);
  eq(v.radar.raining, false);
});

test('an echo over you beats a dry station twenty kilometres away', () => {
  /* The tempting rule is "the instrument on the ground always wins". It is
   * wrong here: the METAR is at an airport that can be 20 km off, and a summer
   * shower is smaller than that. A dry airport is not evidence that your own
   * street is dry, whereas the radar sample is taken directly overhead.
   *
   * The virga risk this trades against — an echo aloft that evaporates before
   * it lands — is handled by the 20 dBZ floor and the 15-20 dBZ band that is
   * reported but never asserted, not by discarding the local reading. Both
   * numbers are shown, so the disagreement is visible rather than resolved
   * silently. */
  const v = Derive.observedPrecip({
    now: OBS_NOW,
    observation: metarAt(5, { presentWeather: [], raw: 'KOUN 141153Z 10SM CLR 33/04 A2990' }),
    overhead: { dbz: 24, at: OBS_NOW }
  });
  eq(v.raining, true);
  eq(v.why, 'radar');
  eq(v.station.raining, false);       // and the dry station is still reported
});

test('a radar reading that could not be taken is not a dry reading', () => {
  // The failure that would recreate the original bug in the other direction:
  // offline, or outside NEXRAD coverage, must produce no radar verdict at all.
  const v = Derive.observedPrecip({ now: OBS_NOW, overhead: null, current: { precipitation: 0 } });
  eq(v.radar, null);
  eq(v.why, 'model');
  // And a stale radar sample is discarded the same way.
  const stale = Derive.observedPrecip({
    now: OBS_NOW,
    overhead: { dbz: 45, at: OBS_NOW - 60 * 60000 },
    current: { precipitation: 0 }
  });
  eq(stale.radar, null);
  eq(stale.raining, false);
});

test('with nothing observing anything, there is no verdict at all', () => {
  eq(Derive.observedPrecip({ now: OBS_NOW }), null);
});

test('the model still answers when it is the only source', () => {
  const v = Derive.observedPrecip({ now: OBS_NOW, current: { precipitation: 0.4 } });
  eq(v.raining, true);
  eq(v.why, 'model');
});


test('an observation carries a WMO code so the icon can follow it', () => {
  const rain = Derive.stationPrecip(metarAt(5, {
    presentWeather: [{ intensity: 'light', modifier: null, weather: 'rain', rawString: '-RA' }]
  }), OBS_NOW);
  eq(rain.code, 61);                                  // light rain
  const snow = Derive.stationPrecip(metarAt(5, {
    presentWeather: [{ intensity: 'heavy', modifier: null, weather: 'snow', rawString: '+SN' }]
  }), OBS_NOW);
  eq(snow.code, 75);                                  // heavy snow
  const showers = Derive.stationPrecip(metarAt(5, {
    presentWeather: [], raw: 'KDSM 141154Z 09006KT 4SM SHRA OVC009 19/18'
  }), OBS_NOW);
  eq(showers.code, 81);                               // rain showers
});

test('every observed code is one the app can already draw', () => {
  /* The icon set and the condition table are keyed by WMO code. A code that
   * exists in the mapping but not in the app renders as a blank square and an
   * empty caption, which is a worse contradiction than the one being fixed. */
  const kinds = ['rain', 'drizzle', 'snow', 'snow_grains', 'snow_pellets',
    'ice_pellets', 'ice_crystals', 'hail', 'small_hail', 'freezing_rain',
    'freezing_drizzle', 'unknown_precipitation'];
  const missing = [];
  kinds.forEach(k => {
    ['light', null, 'heavy'].forEach(intensity => {
      [true, false].forEach(showers => {
        const v = Derive.stationPrecip(metarAt(5, {
          presentWeather: [{ intensity, modifier: showers ? 'showers' : null,
                             weather: k, rawString: (showers ? 'SH' : '') + 'XX' }]
        }), OBS_NOW);
        if (!v || v.code === null || v.code === undefined) return;
        const label = U.wmo(v.code);
        if (!label || !label[0]) missing.push(k + '/' + intensity + ' -> ' + v.code);
      });
    });
  });
  eq(missing.join(', '), '');
});

test('a dry observation carries no code to override with', () => {
  const v = Derive.stationPrecip(metarAt(5, {
    presentWeather: [], raw: 'KOUN 140855Z AUTO 10SM CLR 29/18 A2991'
  }), OBS_NOW);
  eq(v.raining, false);
  eq(v.code, undefined);
});


/* ── Self-finishing updates ─────────────────────────────────────────────
   The worker activates new versions immediately; the page must finish the
   job by reloading itself — but only when nobody would notice. These drive
   the decision logic through a fake service-worker container, because the
   one thing that must never regress is the judgement call, not the plumbing:
   reload out from under nobody, strand no update forever. */

function updateRig(opts) {
  opts = opts || {};
  const events = {};
  const on = (bag, n, f) => { (bag[n] = bag[n] || []).push(f); };
  const container = {
    controller: opts.controlled === false ? null : {},
    addEventListener: (n, f) => on(events, 'sw:' + n, f)
  };
  const doc = {
    hidden: false,
    addEventListener: (n, f) => on(events, 'doc:' + n, f)
  };
  const timers = [];
  const rig = {
    container, doc,
    reloads: 0, offers: [], updates: 0,
    fire: n => (events[n] || []).forEach(f => f()),
    timers
  };
  rig.done = Updates.wire({
    container, doc,
    win: { setInterval: (f, ms) => timers.push({ f, ms }) },
    checkMs: 12345,
    register: () => Promise.resolve({ update: () => { rig.updates++; return Promise.resolve(); } }),
    reload: () => rig.reloads++,
    offer: accept => rig.offers.push(accept)
  });
  return rig;
}

test('an update landing before anyone touches anything reloads silently', () => {
  const r = updateRig();
  r.fire('sw:controllerchange');
  eq(r.reloads, 1);
  eq(r.offers.length, 0);
});

test('an update landing mid-session offers instead of yanking the page', () => {
  const r = updateRig();
  r.fire('doc:pointerdown');                    // the user is doing something
  r.fire('sw:controllerchange');
  eq(r.reloads, 0);
  eq(r.offers.length, 1);
  r.offers[0]();                                 // they tap the pill
  eq(r.reloads, 1);
});

test('a backgrounded app updates silently even after interaction', () => {
  const r = updateRig();
  r.fire('doc:keydown');
  r.doc.hidden = true;                           // switched away
  r.fire('sw:controllerchange');
  eq(r.reloads, 1);
  eq(r.offers.length, 0);
});

test('a first install never reloads the page it just claimed', () => {
  const r = updateRig({ controlled: false });    // no controller at load
  r.fire('sw:controllerchange');                 // claim() firing
  eq(r.reloads, 0);
  // ...but a real update arriving later in the same session still applies.
  r.fire('sw:controllerchange');
  eq(r.reloads, 1);
});

test('however many times the worker changes, the page reloads once', () => {
  const r = updateRig();
  r.fire('sw:controllerchange');
  r.fire('sw:controllerchange');
  r.fire('sw:controllerchange');
  eq(r.reloads, 1);
});

test('an ignored pill applies itself when the app leaves the screen', () => {
  const r = updateRig();
  r.fire('doc:pointerdown');
  r.fire('sw:controllerchange');                 // pill offered, not accepted
  eq(r.offers.length, 1);
  eq(r.reloads, 0);
  r.doc.hidden = true;
  r.fire('doc:visibilitychange');                // user switches away
  eq(r.reloads, 1);                              // applied where nobody sees it
  r.offers[0]();                                 // a late tap must not double-fire
  eq(r.reloads, 1);
});

test('going hidden with no update pending reloads nothing', () => {
  const r = updateRig();
  r.doc.hidden = true;
  r.fire('doc:visibilitychange');
  eq(r.reloads, 0);
});

test('returning to the app checks for a new version', () => {
  const r = updateRig();
  return r.done.then(() => {
    r.fire('doc:visibilitychange');              // visible again
    eq(r.updates, 1);
    r.doc.hidden = true;
    r.fire('doc:visibilitychange');              // being hidden is not a check
    eq(r.updates, 1);
  });
});

test('long sessions poll hourly with the configured interval', () => {
  const r = updateRig();
  return r.done.then(() => {
    eq(r.timers.length, 1);
    eq(r.timers[0].ms, 12345);
    r.timers[0].f();
    eq(r.updates, 1);
  });
});

test('version() answers null rather than hanging when nothing controls the page', () => {
  return Updates.version({ controller: null }).then(v => eq(v, null))
    .then(() => Updates.version(undefined)).then(v => eq(v, null));
});


/* ── Live radar: the watcher that decides when tiles re-fetch ───────────
   Polling a freshness signal is cheap; re-downloading a screenful of radar
   tiles is not. These pin the judgement calls: fire only on a real change,
   never on the first answer, never while hidden, and never twice for the
   same scan. */

function liveRig() {
  const events = {};
  const doc = { hidden: false, addEventListener: (n, f) => (events[n] = events[n] || []).push(f) };
  const timers = [];
  const rig = { fresh: [], probes: 0, result: null };
  rig.doc = doc;
  rig.timers = timers;
  rig.fire = n => (events[n] || []).forEach(f => f());
  rig.handle = Live.start({
    doc,
    win: { setInterval: (f, ms) => { timers.push({ f, ms }); return 1; }, clearInterval: () => {} },
    pollMs: 777,
    probe: () => { rig.probes++; return typeof rig.result === 'function' ? rig.result() : Promise.resolve(rig.result); },
    onFresh: r => rig.fresh.push(r)
  });
  return rig;
}

test('the first answer primes the watcher and fires nothing', () => {
  const r = liveRig();
  r.result = { key: 'scan-1' };
  return r.handle.probe().then(() => eq(r.fresh.length, 0));
});

test('a changed key fires exactly once, an unchanged key never', () => {
  const r = liveRig();
  r.result = { key: 'scan-1' };
  return r.handle.probe()
    .then(() => { r.result = { key: 'scan-2', index: { marker: true } }; return r.handle.probe(); })
    .then(() => r.handle.probe())
    .then(() => {
      eq(r.fresh.length, 1);
      // The payload rides along: for RainViewer the new frame list IS the data.
      eq(r.fresh[0].index.marker, true);
    });
});

test('a probe that cannot tell is not a change', () => {
  const r = liveRig();
  r.result = { key: 'scan-1' };
  return r.handle.probe()
    .then(() => { r.result = null; return r.handle.probe(); })       // offline
    .then(() => { r.result = { key: 'scan-1' }; return r.handle.probe(); })
    .then(() => eq(r.fresh.length, 0))                               // same scan resumed
    .then(() => { r.result = { key: 'scan-2' }; return r.handle.probe(); })
    .then(() => eq(r.fresh.length, 1));
});

test('a probe that throws is the next tick\'s problem', () => {
  const r = liveRig();
  r.result = () => Promise.reject(new Error('down'));
  return r.handle.probe()
    .then(() => { r.result = { key: 'scan-1' }; return r.handle.probe(); })
    .then(() => { r.result = { key: 'scan-2' }; return r.handle.probe(); })
    .then(() => eq(r.fresh.length, 1));
});

test('the interval tick stays silent while the app is hidden', () => {
  const r = liveRig();
  r.result = { key: 'scan-1' };
  eq(r.timers.length, 1);
  eq(r.timers[0].ms, 777);
  r.doc.hidden = true;
  r.timers[0].f();
  eq(r.probes, 0);                                  // no probe in a pocket
  r.doc.hidden = false;
  r.timers[0].f();
  eq(r.probes, 1);
});

test('coming back to the app probes immediately', () => {
  const r = liveRig();
  r.result = { key: 'scan-1' };
  r.fire('visibilitychange');                       // visible again
  eq(r.probes, 1);
  r.doc.hidden = true;
  r.fire('visibilitychange');                       // going hidden is not a probe
  eq(r.probes, 1);
});

test('reset() re-primes so a source switch cannot fire spuriously', () => {
  const r = liveRig();
  r.result = { key: 'mosaic:10:00' };
  return r.handle.probe()
    .then(() => {
      r.handle.reset();                             // user switched to a site
      r.result = { key: 'KDMX:10:03' };
      return r.handle.probe();                      // different quantity: primes
    })
    .then(() => eq(r.fresh.length, 0))
    .then(() => { r.result = { key: 'KDMX:10:08' }; return r.handle.probe(); })
    .then(() => eq(r.fresh.length, 1));              // a real new scan still fires
});


/* ── The mark and the icon are the same drawing ─────────────────────────
   icons/mark.svg (topbar, launch screens) and icons/icon.svg (app icon) are
   two files carrying one design. If someone edits the V in one and not the
   other, the home screen and the header quietly diverge. */
test('icons/mark.svg and icons/icon.svg carry identical geometry', () => {
  const read = f => fs.readFileSync(path.join(__dirname, '..', 'icons', f), 'utf8');
  const geometry = svg => (svg.match(/\bd="[^"]+"/g) || [])
    .map(d => d.replace(/\s+/g, ' ').trim())
    .sort();
  const icon = geometry(read('icon.svg'));
  const mark = geometry(read('mark.svg'));
  // The icon has no extra paths the mark lacks except none — every path in
  // the mark must exist verbatim in the icon, and the V must be among them.
  mark.forEach(d => ok(icon.indexOf(d) !== -1, 'icon.svg is missing: ' + d.slice(0, 48)));
  ok(mark.some(d => /M88 136/.test(d)), 'the V path is present');
});

test('the raster icons are regenerated from the current SVG', () => {
  /* Cheap staleness tripwire: every PNG the manifest names must be newer than
   * or written alongside the SVG that defines them. Catches "edited the SVG,
   * forgot make-icons.js" without hashing anything. */
  const st = f => fs.statSync(path.join(__dirname, '..', 'icons', f)).mtimeMs;
  const svg = st('icon.svg');
  ['icon-512.png', 'icon-192.png', 'favicon-32.png',
   'apple-touch-icon.png', 'maskable-512.png', 'maskable-192.png'].forEach(f => {
    ok(st(f) >= svg - 5000, f + ' is older than icon.svg — run scripts/make-icons.js');
  });
});


/* ── The wrong date ─────────────────────────────────────────────────────
   Reported: "the app has the wrong date." Open-Meteo's daily series is
   date-only ("2026-08-15"), and parseLocal's old regex required THH:MM — a
   bare date fell through to new Date(), which parses it as UTC midnight:
   the previous evening everywhere in the United States. Every weekday in
   the 7-day card ran one day behind. */

test('a date-only string is local midnight, not UTC midnight', () => {
  const d = U.parseLocal('2026-08-15');
  eq(d.getFullYear(), 2026);
  eq(d.getMonth(), 7);
  eq(d.getDate(), 15);                     // the 15th, in THIS timezone
  eq(d.getHours(), 0);
  eq(d.getDay(), 6);                       // August 15th 2026 is a Saturday
});

test('datetime strings parse exactly as before', () => {
  const d = U.parseLocal('2026-08-15T14:30');
  eq(d.getDate(), 15);
  eq(d.getHours(), 14);
  eq(d.getMinutes(), 30);
});

/* ── Model forecasts: each agency, honestly bounded ─────────────────── */

const MODEL_DAILY_FIXTURE = JSON.parse(fs.readFileSync(
  path.join(__dirname, 'fixtures', 'model-daily.json'), 'utf8'));

test('every requested agency with data appears, keyed by name', () => {
  const mc = Modelcast.parse(MODEL_DAILY_FIXTURE);
  eq(mc.days.length, 10);
  const shorts = mc.models.map(m => m.short);
  ['ECMWF', 'GFS', 'ICON', 'GEM', 'ARPEGE', 'UKMO', 'JMA'].forEach(want => {
    ok(shorts.indexOf(want) !== -1, want + ' present');
  });
});

test('each model horizon is its real publication limit, not padding', () => {
  /* From the captured payload: ECMWF/GFS/GEM/JMA run the full 10 days,
   * ICON stops at 7, UKMO at 6, ARPEGE at 4. If this fails after a
   * fixture refresh, the numbers moved with the providers — update the
   * expectations, not the code. */
  const mc = Modelcast.parse(MODEL_DAILY_FIXTURE);
  const h = {};
  mc.models.forEach(m => { h[m.short] = m.horizon; });
  eq(h.ECMWF, 10);
  eq(h.GFS, 10);
  eq(h.ICON, 7);
  eq(h.ARPEGE, 4);
  eq(h.UKMO, 6);
});

test('a model with no data at all is dropped, not shown empty', () => {
  const gutted = JSON.parse(JSON.stringify(MODEL_DAILY_FIXTURE));
  gutted.daily.temperature_2m_max_gfs_seamless =
    gutted.daily.temperature_2m_max_gfs_seamless.map(() => null);
  const mc = Modelcast.parse(gutted);
  ok(mc.models.every(m => m.short !== 'GFS'), 'GFS absent');
  eq(mc.models.length, 6);
});


/* ── Model chart maths ──────────────────────────────────────────────────
   The chart is drawn from primitives that either work or lie: a palette
   with a dry floor, marching squares that trace real level crossings, and
   an extrema finder that letters genuine highs and lows. */

test('the chart palette starts dry and climbs the classic greens', () => {
  eq(ModelChart.chartColor(null), null);
  eq(ModelChart.chartColor(0), null);
  eq(ModelChart.chartColor(0.05), null);
  const light = ModelChart.chartColor(0.2), heavy = ModelChart.chartColor(30);
  ok(Array.isArray(light) && light.length === 3, 'rgb triple');
  ok(light[1] > light[0], 'light rain is green');
  ok(heavy[0] > heavy[1], 'violent rain has left green behind');
});

test('marching squares finds a contour exactly where the field crosses it', () => {
  // A 3×3 ramp field: values equal x. The level 1.5 crossing is a vertical
  // line at x = 1.5 — every segment endpoint must sit on it.
  const f = [0, 1, 2, 0, 1, 2, 0, 1, 2];
  const segs = ModelChart.contourSegments(f, 3, 3, 1.5);
  ok(segs.length > 0, 'segments exist');
  segs.forEach(s => {
    ok(Math.abs(s[0] - 1.5) < 1e-9 && Math.abs(s[2] - 1.5) < 1e-9,
      'endpoints at x=1.5, got ' + JSON.stringify(s));
  });
  eq(ModelChart.contourSegments([5, 5, 5, 5], 2, 2, 4).length, 0, 'no crossing, no contour');
  eq(ModelChart.contourSegments([null, 5, 5, 5], 2, 2, 4).length, 0, 'null poisons the cell');
});

test('a pressure low is lettered L at its centre and only there', () => {
  const CH = VaneConfig.CHART;
  const rows = [];
  for (let iy = 0; iy < CH.NY; iy++) {
    for (let ix = 0; ix < CH.NX; ix++) {
      const d2 = (ix - 20) ** 2 + (iy - 9) ** 2;
      rows.push({ precip: [0], mslp: [1016 - 12 * Math.exp(-d2 / 18)], times: ['t'] });
    }
  }
  ModelChart.state.rows = rows;
  const found = ModelChart.extrema(0);
  const lows = found.filter(x => x.kind === 'L');
  eq(lows.length, 1, 'one low');
  ok(lows[0].ix === 20 && lows[0].iy === 9, 'at the centre');
  ok(lows[0].value < 1005, 'with the deep value');
  ModelChart.state.rows = [];
});

test('archive stamps are UTC, floored to the five-minute scan', () => {
  // 2026-08-15 18:17:44 UTC floors to ...1815 regardless of local clock.
  eq(U.iemStamp(Date.UTC(2026, 7, 15, 18, 17, 44)), '202608151815');
  eq(U.iemStamp(Date.UTC(2026, 7, 15, 18, 15, 0)), '202608151815');
  eq(U.iemStamp(Date.UTC(2026, 0, 1, 0, 2, 0)), '202601010000', 'year boundary');
  eq(U.iemStamp(Date.UTC(2024, 4, 8, 23, 4, 59)), '202405082300');
});

test('HRRR charts an inset box that stays inside its Lambert cone', () => {
  const dom = API.chartDomain('ncep_hrrr_conus');
  ok(dom.LAT0 > VaneConfig.CHART.LAT0 && dom.LAT1 < VaneConfig.CHART.LAT1,
    'inset in latitude');
  ok(dom.LON0 > VaneConfig.CHART.LON0 && dom.LON1 < VaneConfig.CHART.LON1,
    'inset in longitude');
  const pts = API.chartPoints(0, dom);
  eq(pts[0].lat, dom.LAT0, 'lattice follows the domain, not the default box');
  eq(pts[0].lon, dom.LON0);
  eq(API.chartDomain('gfs_seamless').LAT0, VaneConfig.CHART.LAT0,
    'the globals keep the full box');
  ok(VaneConfig.HRRR_PLAY_LEADS.every(m => m % 60 === 0 && m <= 1080),
    'the play loop visits hourly leads to +18h only');
});

test('the chart lattice splits into row bands, row-major from the south', () => {
  const CH = VaneConfig.CHART;
  const chunks = [];
  for (let k = 0; k * CH.CHUNK_ROWS < CH.NY; k++) chunks.push(API.chartPoints(k));
  const all = chunks.flat();
  eq(all.length, CH.NX * CH.NY);
  eq(all[0].lat, CH.LAT0, 'first point is the south-west corner');
  eq(all[0].lon, CH.LON0);
  eq(all[all.length - 1].lat, CH.LAT1, 'last point is the north edge');
  for (let i = 1; i < all.length; i++) {
    ok(all[i].lat >= all[i - 1].lat - 1e-9, 'latitude never steps south at ' + i);
  }
  chunks.forEach((c, k) => {
    const coords = c.map(p => p.lat.toFixed(2)).join(',') +
                   c.map(p => p.lon.toFixed(2)).join(',');
    ok(coords.length < 7000, 'chunk ' + k + ' inside URL limits: ' + coords.length);
  });
});

/* ── Glossary ───────────────────────────────────────────────────────────
   The app cannot get less technical without getting less useful, so the
   jargon stays and gets explained instead. These guard the two ways that
   goes wrong: a definition that leans on another undefined term, and a
   pattern that fires inside an unrelated word. */

test('every term the Chase and Outlook views actually use is defined', () => {
  // Taken from the UX audit's jargon list, restricted to what the app renders.
  ['dBZ', 'VIL', 'SRH', 'LCL', 'CAPE', 'CIN', 'kt', 'hPa', 'kft', 'AGL', 'MSL',
   'echo top', 'reflectivity', 'velocity', 'mesocyclone', 'TVS', 'hodograph',
   'ensemble', 'spread', 'anomaly', 'climatology', 'ERA5', 'skill horizon',
   'meteogram', 'NEXRAD', 'convective', 'sounding', 'derived', 'Bunkers',
   'dewpoint', 'geopotential', 'CWA', 'deterministic', 'percentile'
  ].forEach(term => {
    ok(Glossary.has(term), term + ' resolves to an entry');
  });
});

test('surface forms resolve to the same entry as their canonical term', () => {
  eq(Glossary.has('storm-relative helicity'), 'SRH');
  eq(Glossary.has('echo tops'), 'echo top');
  eq(Glossary.has('p90'), 'percentile');
  eq(Glossary.has('reanalysis'), 'ERA5');
  eq(Glossary.has('right mover'), 'Bunkers');
  eq(Glossary.has('boundary layer'), 'Mixing height');
});

test('a definition never explains one term using another undefined one', () => {
  /* The failure mode this catches: "VIL density is VIL divided by echo top"
   * is only a definition if VIL and echo top are themselves defined. Every
   * acronym a definition uses has to be reachable. */
  /* Acronyms a general reader already knows, or which are proper names of
   * organisations rather than concepts. Everything else that appears inside a
   * definition has to be defined itself. */
  const COMMON = /^(US|UK|NWS|NOAA|ECMWF|DWD|SI|AM|PM|UTC|IFS|GFS|ICON|GEM)$/;
  const offenders = [];
  Object.keys(Glossary.TERMS).forEach(key => {
    const t = Glossary.TERMS[key];
    const text = t.what + ' ' + (t.why || '');
    /* An acronym introduced parenthetically after its own expansion — "the
     * right mover (RM)" — is defined on the spot, and may then be used by
     * itself for the rest of the entry. */
    const introduced = (text.match(/\(([A-Z][A-Z0-9]{1,4})\)/g) || [])
      .map(m => m.slice(1, -1));
    (text.match(/\b[A-Z][A-Z0-9]{1,4}\b/g) || []).forEach(a => {
      if (COMMON.test(a)) return;              // needs no gloss
      if (introduced.indexOf(a) !== -1) return; // expanded in place
      if (Glossary.has(a)) return;             // defined elsewhere — fine
      offenders.push(key + ' uses ' + a);
    });
  });
  eq(offenders.join('; '), '');
});

test('every definition says what the thing is, in a sentence', () => {
  Object.keys(Glossary.TERMS).forEach(key => {
    const t = Glossary.TERMS[key];
    ok(t.title && t.title.length > 1, key + ' has a title');
    ok(t.what && t.what.length > 30, key + ' says what it is');
    ok(/[.!?]$/.test(t.what.trim()), key + ' is a sentence, not a fragment');
    if (t.why) ok(/[.!?]$/.test(t.why.trim()), key + ' why-line is a sentence');
  });
});

test('thresholds are stated as numbers, not as adjectives', () => {
  /* "High shear supports supercells" tells a newcomer nothing. Where a term
   * has an operational threshold, the definition has to name it. */
  ['CAPE', 'SRH', 'shear', 'dBZ', 'echo top', 'LCL', 'dewpoint'].forEach(key => {
    const t = Glossary.get(Glossary.has(key));
    ok(/\d/.test(t.what + ' ' + (t.why || '')), key + ' quotes a number');
  });
});

test('the shortest definition is still a definition', () => {
  const shortest = Object.keys(Glossary.TERMS)
    .map(k => ({ k, n: Glossary.TERMS[k].what.length }))
    .sort((a, b) => a.n - b.n)[0];
  ok(shortest.n > 30, 'shortest is ' + shortest.k + ' at ' + shortest.n + ' chars');
});

test('decorate is a no-op without a document', () => {
  // The module is loaded in a shim with no real DOM; it must not throw.
  eq(Glossary.decorate(null), 0);
});

/* ── Report ─────────────────────────────────────────────────────────────── */

Promise.all(pending).then(() => {
  console.log('\n');
  if (failures.length) {
    failures.forEach(f => {
      console.log(`\x1b[31m✗ ${f.name}\x1b[0m`);
      console.log(`  ${f.err.message}\n`);
    });
  }
  console.log(`\x1b[32m${passed} passed\x1b[0m${failed ? `, \x1b[31m${failed} failed\x1b[0m` : ''}`);
  process.exit(failed ? 1 : 0);
});
