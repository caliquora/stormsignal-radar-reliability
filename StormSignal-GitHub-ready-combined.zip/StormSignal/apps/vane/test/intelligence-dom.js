/* Integration checks with captured fixtures and a DOM. No external network.
 * Install jsdom as a development dependency to run: node test/intelligence-dom.js.
 * Maps/canvas rendering are stubbed; this does not replace visual browser QA. */
'use strict';
const { JSDOM } = require('jsdom');
const fs = require('fs'), path = require('path'), assert = require('assert/strict');
const root = path.join(__dirname, '..');
const html = fs.readFileSync(path.join(root, 'index.html'), 'utf8');
const dom = new JSDOM(html, { url: 'https://vane.test/', runScripts: 'outside-only', pretendToBeVisual: true });
const w = dom.window, now = Date.now(), H = 3600000;
let checks = 0, failures = [], alertUnavailable = false, severe = false;
const pendingForecasts = [];
let race = false;
const fx = name => JSON.parse(fs.readFileSync(path.join(__dirname, 'fixtures', name + '.json'), 'utf8'));
function stamp(data) {
  const off = (data.utc_offset_seconds || 0) * 1000;
  for (const [name, step, shift] of [['hourly', H, -2 * H], ['minutely_15', 15 * 60000, 0]]) {
    if (data[name]?.time) data[name].time = data[name].time.map((_, i) => new Date(Math.floor((now + off) / step) * step + shift + i * step).toISOString().slice(0, 16));
  }
  if (data.daily?.time) data.daily.time = data.daily.time.map((_, i) => new Date(now + off + i * 86400000).toISOString().slice(0,10));
  return data;
}
const forecast = stamp(fx('forecast'));
forecast.hourly.temperature_2m.fill(20); forecast.hourly.precipitation.fill(0);
forecast.hourly.precipitation_probability.fill(10); forecast.hourly.wind_gusts_10m.fill(5);
forecast.hourly.weather_code.fill(0);
w.matchMedia = q => ({ matches: false, media: q, addEventListener() {}, addListener() {}, removeEventListener() {} });
w.scrollTo = () => {}; w.HTMLElement.prototype.scrollIntoView = () => {};
// A canvas that accepts every call. Gradients must hand back something with
// addColorStop: the 3D view only draws its sun gradient when the sun is in
// frame, so a stub without one failed by time of day.
w.HTMLCanvasElement.prototype.getContext = () => new Proxy({}, { get: (_, k) =>
  k === 'measureText' ? () => ({ width: 20 })
  : /^create\w*Gradient$|^createPattern$/.test(k) ? () => ({ addColorStop() {} })
  : () => {}, set: () => true });
w.fetch = () => Promise.reject(new Error('External requests forbidden in fixture test'));
w.addEventListener('error', e => failures.push(e.message));
const scripts = [...html.matchAll(/<script src="([^"]+)"/g)].map(m => m[1]);
scripts.filter(s => s !== 'js/app.js').forEach(s => w.eval(fs.readFileSync(path.join(root, s), 'utf8')));
// In a browser the Chase and Outlook code loads on tab entry (js/lazy.js);
// jsdom fetches no scripts, so the bundles are evaluated here up front.
Object.values(w.Lazy.BUNDLES).forEach(b => b.files.forEach(s => w.eval(fs.readFileSync(path.join(root, s), 'utf8'))));
w.Lazy.need = () => Promise.resolve();
const noops = new Proxy({}, { get: () => () => {} });
w.Meteogram.render = () => {}; w.Modelcast.render = () => {};
w.Glossary.wire = () => {}; w.Glossary.decorateAll = () => {}; w.Glossary.observe = () => {};
w.Live.start = () => ({ stop() {}, probe: () => Promise.resolve(false) });
w.Radar = new Proxy({ init: () => false, inConus: () => true,
  pickSource: () => 'nexrad', getSource: () => 'nexrad', legend: () => ({ kind: 'dbz', scale: [], note: '' }) }, {
  get: (o, k) => k in o ? o[k] : () => {}
});
const status = () => ({ available: !alertUnavailable, stale: false, receivedAt: Date.now(), alerts: severe ? [{
  id:'test-warning', event:'Severe Thunderstorm Warning', severity:'Severe', expires:new Date(now + H).toISOString(), instruction:'Test instruction'
}] : [] });
Object.assign(w.API, {
  forecast: (lat,lon) => race ? new Promise(resolve => pendingForecasts.push({lat,lon,resolve})) : Promise.resolve(structuredClone(forecast)),
  alertsWithStatus: () => Promise.resolve(status()), alerts: () => Promise.resolve(status().alerts),
  observation: (lat,lon) => Promise.resolve({lat,lon,station:'KOKC', name:'Reference station',time:new Date(now).toISOString(),temperature:20,presentWeather:[]}),
  stationDayExtremes: () => Promise.resolve(null), airQuality: () => Promise.resolve(fx('air')),
  modelDaily: () => Promise.resolve(stamp(fx('model-daily'))), multiModel: () => Promise.resolve(stamp(fx('ensemble'))),
  sounding: () => Promise.resolve(stamp(fx('sounding'))), afd: () => Promise.resolve(null),
  ensembleDaily: () => Promise.reject(new Error('Fixture does not provide extended outlook')), normals: () => Promise.resolve(null),
  stormCells: () => Promise.resolve({ generatedAt:new Date(now).toISOString(), features:[{
    geometry:{type:'Point',coordinates:[-97.7,35.47]},properties:{nexrad:'KTLX',storm_id:'A1',valid:new Date(now).toISOString(),
      max_dbz:60,top:50,drct:270,sknt:20,meso:6,posh:60,max_size:1.5,vil:40}
  }]}), spcOutlook: () => Promise.resolve([]), stormReports: () => Promise.resolve([]),
  geocode: text => Promise.resolve([{lat:37.69,lon:-97.34,name:'Wichita',admin:'Kansas, US'}])
});
function flush() { return new Promise(r => setTimeout(r, 40)); }
function check(name, fn) { try { fn(); checks++; console.log('PASS ' + name); } catch (e) { failures.push(name + ': ' + e.message); } }
function click(id) { w.document.getElementById(id).click(); }
function value(id, v) { w.document.getElementById(id).value = v; }
function text(id) { return w.document.getElementById(id).textContent; }
function submit(id) { w.document.getElementById(id).dispatchEvent(new w.Event('submit', {bubbles:true,cancelable:true})); }
(async () => {
  try {
    w.eval(fs.readFileSync(path.join(root,'js/app.js'),'utf8')); await flush();
    check('application boots with all decision panels', () => {
      assert.ok(w.Vane.state.data); assert.ok(text('decision-changes').includes('First forecast saved'));
      // One verification engine: the ledger reports js/verify.js's state.
      assert.ok(text('decision-journal').includes('verified day'));
      assert.ok(text('decision-journal').includes('whether or not Vane was open'));
    });
    check('StormSignal provenance panel explains its limits', () => {
      const panel = w.document.querySelector('.stormsignal-panel');
      assert.ok(panel.textContent.includes('Local freshness is unknown'));
      assert.ok(panel.textContent.includes('not a research-derived safety threshold'));
      w.StormSignal.render({source:'fixture', observedAt:now-20*60000},now);
      assert.equal(w.document.getElementById('stormsignal-status').dataset.status,'stale');
      w.StormSignal.render({source:'fixture'},now);
      assert.equal(w.document.getElementById('stormsignal-status').dataset.status,'unknown');
      assert.ok(w.document.querySelectorAll('#stormsignal-timeline li').length >= 2);
      w.StormSignal.showFrame({forecast:true,time:now/1000});
      assert.ok(text('stormsignal-frame').includes('MODEL FORECAST'));
      w.StormSignal.showFrame({timeBasis:'request',time:now/1000});
      assert.ok(text('stormsignal-frame').includes('not verified scan time'));
      assert.equal(text('stormsignal-source-time'),'Unknown');
    });
    w.Vane.setMode('chase'); await flush();
    const follow = [...w.document.querySelectorAll('#cells button')].find(b => b.textContent === 'Follow storm');
    check('follow control is connected to live parsed cells', () => assert.ok(follow));
    follow?.click(); await flush();
    check('following renders persistent storm story and source', () => {
      assert.ok(text('decision-stories').includes('Following KTLX-A1'));
      assert.ok(text('decision-stories').includes('1 recorded scan'));
      // One scan is not a trend: the shared fitted-slope rule, not first-vs-last.
      assert.ok(text('decision-stories').includes('a trend needs three scans'));
      assert.equal(w.Intelligence.read().following.length,1);
    });
    const newer = { ...w.Cells.state.cells[0], valid:new Date(now+5*60000).toISOString() };
    w.Intelligence.ingest([],now+5*60000,true); w.DecisionUI.render(w.Vane.state);
    check('missing cell retains identity and pauses projection', () => assert.ok(text('decision-stories').includes('outcome unknown')));
    w.Vane.setMode('simple'); await flush();
    value('decision-plan-name', '<img src=x onerror=alert(1)>'); value('decision-plan-start','0'); value('decision-plan-end','24');
    w.document.getElementById('decision-plan-daylight').checked = false;
    submit('decision-plan-form'); await flush();
    check('saved activity produces a real forecast window', () => assert.ok(text('decision-plans').includes('forecast rain chance up to 10%')));
    check('activity names render as text, not HTML', () => assert.equal(w.document.querySelectorAll('#decision-plans img').length,0));
    alertUnavailable = true; click('decision-plan-refresh'); await flush();
    check('alert outage is not called no warnings', () => {
      assert.ok(text('decision-plans').includes('Official alert status unavailable'));
      w.WarningEvidence.render({available:false,alerts:[]},w.Vane.state.location,now);
      assert.ok(text('warning-evidence').includes('Do not interpret an empty screen as no warnings'));
    });
    alertUnavailable = false; severe = true; click('decision-plan-refresh'); await flush();
    check('severe official alerts pause activity suggestions', () => assert.ok(text('decision-plans').includes('Activity suggestions are paused')));
    check('warning desk exposes official instructions and safe links', () => {
      w.WarningEvidence.render({available:true,stale:false,receivedAt:now,alerts:[{id:'https://api.weather.gov/alerts/urn:oid:test',event:'Warning',severity:'Severe',sent:new Date(now).toISOString(),expires:new Date(now+H).toISOString(),instruction:'<img src=x onerror=alert(1)>'}]},w.Vane.state.location,now);
      assert.equal(w.document.querySelectorAll('#warning-evidence img').length,0);
      assert.ok(text('warning-evidence').includes('<img src=x'));
      assert.ok(w.document.querySelector('#warning-evidence a[href="https://api.weather.gov/alerts/urn:oid:test"]'));
      assert.ok(w.document.querySelector('#warning-evidence details[open]'));
    });
    severe = false;
    w.Vane.setMode('chase'); await flush(); value('decision-target-query','Wichita'); submit('decision-target-form'); await flush();
    w.document.querySelector('#decision-target-results button').click(); click('decision-target-compare'); await flush();
    check('target comparison fetches and renders environment and limitations', () => {
      assert.ok(text('decision-targets').includes('Modeled CAPE')); assert.ok(text('decision-targets').includes('Road closures'));
      assert.match(text('decision-targets'), /Chase-day odds: (\d+%|under 1%) chance of a severe report within 100 km/);
      assert.ok(w.document.querySelector('#decision-targets a[href^="https://www.google.com/maps/dir/"]'));
    });
    const savedStorm = JSON.parse(w.localStorage.getItem('vane.intelligence.v1'));
    check('storm, plan, target, and snapshot histories persist; no duplicate verification archive', () => {
      assert.equal(savedStorm.following.length,1); assert.equal(savedStorm.plans.length,1); assert.equal(savedStorm.targets.length,1);
      assert.ok(Object.values(savedStorm.locations).some(l => l.snapshots.length));
      assert.ok(Object.values(savedStorm.locations).every(l => l.predictions === undefined));
    });
    race = true;
    w.Vane.setLocation({lat:40,lon:-100,name:'Older request'}); w.Vane.setLocation({lat:42,lon:-93,name:'Latest request'});
    pendingForecasts[1].resolve({...structuredClone(forecast),latitude:42}); await flush();
    pendingForecasts[0].resolve({...structuredClone(forecast),latitude:40}); await flush();
    check('late response cannot overwrite the new location', () => assert.equal(w.Vane.state.data.latitude,42));
    const before = w.Intelligence.location(w.Vane.state.location).snapshots.length;
    w.Vane.state.stale = true; w.DecisionUI.receive(w.Vane.state,'forecast');
    check('stale forecast pauses advice without adding a snapshot', () => {
      assert.ok(text('decision-changes').includes('out of date')); assert.equal(w.Intelligence.location(w.Vane.state.location).snapshots.length,before);
    });
  } catch (e) { failures.push(e.stack); }
  dom.window.close();
  if(failures.length) { console.error(failures.join('\n')); process.exitCode=1; }
  console.log(checks + ' DOM integration checks passed; ' + failures.length + ' failures');
})();
