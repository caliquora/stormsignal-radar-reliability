# Integration verification — 2026-11-12

## Passed

`TZ=UTC npm test` with Node 24.22.1:
- 409 existing numerical/parser/unit checks.
- Ground Truth evaluation checks.
- 24 decision-engine tests.
- 14 DOM integration checks, including the new provenance panel, unavailable data, location race, alert outage, stale forecasts, and stored-state behavior.
- Service-worker warm-cache update simulation.
- 17 new StormSignal provenance/motion/timeline checks.
- 14 official-warning evidence tests for outages, stale metadata, safe source links, deduplication, changes, and location resets.

All application and test JavaScript files passed `node --check` in the final combined package.
- 17 bounded-agent checks and agent DOM workflows (including cancellation, safe rendering and hosted-origin restriction). Local-model requests were stubbed; actual inference was not tested.

The original unit fixture suite assumes `TZ=UTC`; running it in the host's other timezone caused eight time-window failures. Use the documented environment. Original unmodified source file bytes were verified against Git blob hashes and their source commit timestamp retained. Changed files are identified in `INTEGRATION-MANIFEST.json`.

## Not passed or not run

- Earlier Chromium socket restriction no longer reproduced. A new real-Chromium fixture pass (`node scripts/integration-qa.cjs`) loaded 390px and 1440px layouts, ran embedded agents, verified export readiness and zero horizontal overflow. Mobile screenshots were visually inspected. This uses captured API fixtures, not current conditions.
- The broad legacy browser suite and real service-worker lifecycle suite are not certified by this focused pass. Accessibility and real provider behavior remain release gates.
- Live NWS alert endpoint request timed out after 12 seconds without a data body. Live-feed validation remains blocked in this environment.
- Live provider timestamps and tile alignment have not been tested against current feeds. Index timestamp is not tile identity or local pixel age.
- Research CNN performance has not been tested on VANE's operational feeds.
- No deployment, GitHub push or publication occurred. Prior GitHub approval remains a separate gate.

## Browser-discovered fix

Expired warning records were excluded in the warning desk but could remain in the compact banner. Explicitly expired records are now removed from the shared current-alert list, notification candidates and badge. Unknown expiry remains visible rather than silently discarded. Raw evidence stays in the warning feed/ledger. A regression test covers exact expiry and unknown expiry. Agent controls now have consistent sizing, colors and keyboard focus.

## Release gates

Run the full browser and service-worker suites in a supported browser environment; inspect desktop/mobile interactions and official warning visibility. Validate timestamp parsing against live providers, offline behavior, source switching and multi-tab cache migration. Confirm application licensing before publishing VANE as open-source. Do not advertise operational forecast improvement from this integration.
