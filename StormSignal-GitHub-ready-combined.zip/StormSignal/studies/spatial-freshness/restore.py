from pathlib import Path
import pandas as pd,numpy as np,json,urllib.request,hashlib,time
from concurrent.futures import ThreadPoolExecutor,as_completed
ROOT=Path(__file__).resolve().parent
SRC=ROOT/'reference'
manifest=pd.read_csv(SRC/'data/processed/sample_manifest.csv'); manifest=manifest[manifest.split=='test'].copy()
manifest.to_csv(ROOT/'data/manifest.csv',index=False)
objects=json.loads((SRC/'data/processed/source_objects.json').read_text())
hashes=pd.read_csv(SRC/'data/processed/event_hashes.csv').set_index('id')
(ROOT/'data/source_objects.json').write_text(json.dumps(objects,indent=2))
def fetch(row):
 dest=ROOT/'data/events'/f'{row.id}.npz'
 dest.parent.mkdir(parents=True,exist_ok=True)
 expected=hashes.loc[row.id,'source_event_sha256']
 if dest.exists():
  with np.load(dest) as f: assert str(f['sha256'])==expected
  return {'id':row.id,'sha256':expected,'status':'cached'}
 meta=objects[row.file_name]; n=384*384*49; lo=int(meta['offset'])+int(row.file_index)*n
 for attempt in range(4):
  try:
   req=urllib.request.Request(meta['url'],headers={'Range':f'bytes={lo}-{lo+n-1}'})
   with urllib.request.urlopen(req,timeout=120) as r:
    assert r.status==206; b=r.read(); etag=r.headers.get('ETag'); cr=r.headers.get('Content-Range')
   assert len(b)==n; digest=hashlib.sha256(b).hexdigest(); assert digest==expected,(row.id,digest,expected)
   a=np.frombuffer(b,np.uint8).reshape(384,384,49);assert not np.any(a==255)
   blocks=a.reshape(96,4,96,4,49)
   mean=blocks.mean(axis=(1,3)).transpose(2,0,1).astype(np.float16)
   high=(blocks.max(axis=(1,3))>=133).transpose(2,0,1)
   np.savez_compressed(dest,mean=mean,high=high,sha256=digest,source_etag=str(etag))
   return {'id':row.id,'sha256':digest,'etag':etag,'range':cr,'bytes':len(b),'status':'restored'}
  except Exception:
   if attempt==3:raise
   time.sleep(2**attempt)
rows=[]
with ThreadPoolExecutor(max_workers=8) as pool:
 futures={pool.submit(fetch,row):row.id for row in manifest.itertuples()}
 for i,f in enumerate(as_completed(futures),1):
  rows.append(f.result())
  if i%10==0:print(i,len(manifest),flush=True)
(ROOT/'data/restoration_audit.json').write_text(json.dumps(rows,indent=2))
print('Restored and source-hash verified',len(rows),'events',flush=True)
