"""Render the saved spatial audit as a five-page landscape editorial brief.
No inference, calibration, metric calculation or source figure changes occur here.
The main report may reuse draw_pages(canvas, start_page, total_pages).
"""
from pathlib import Path
import matplotlib
from reportlab.pdfgen import canvas
from reportlab.lib import colors
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.platypus import Paragraph
from reportlab.lib.styles import ParagraphStyle

ROOT = Path(__file__).resolve().parent
OUT = ROOT / 'StormSignal-spatial-freshness-brief.pdf'
PAGE_COUNT = 5
W, H = 960, 640
INK, TEAL, ORANGE = '#122a3b', '#087f79', '#b8562b'
CREAM, MUTED, LINE = '#f4f2ec', '#526575', '#cbd2cf'
FONTDIR = Path(matplotlib.get_data_path()) / 'fonts' / 'ttf'
for name, filename in [('SpatialSans','DejaVuSans.ttf'), ('SpatialBold','DejaVuSans-Bold.ttf'), ('SpatialSerif','DejaVuSerif.ttf')]:
    pdfmetrics.registerFont(TTFont(name, str(FONTDIR / filename)))
pdfmetrics.registerFontFamily('SpatialSans', normal='SpatialSans', bold='SpatialBold')

def txt(c, text, x, top, width, size=14, leading=None, font='SpatialSans', color=INK):
    p=Paragraph(text, ParagraphStyle('spatial', fontName=font, fontSize=size,
                leading=leading or size*1.42, textColor=colors.HexColor(color)))
    _, height=p.wrap(width, H)
    assert top+height < 596, (text[:70],top,height)
    p.drawOn(c,x,H-top-height)
    return top+height

def rule(c, top, x=48, width=864):
    c.setStrokeColor(colors.HexColor(LINE)); c.setLineWidth(.7)
    c.line(x,H-top,x+width,H-top)

def base(c, page, total, title, subtitle):
    c.setPageSize((W,H)); c.setFillColor(colors.HexColor(CREAM));c.rect(0,0,W,H,fill=1,stroke=0)
    txt(c,title,48,40,870,31,38,'SpatialSerif')
    txt(c,subtitle,48,96,860,13,19,color=MUTED)
    rule(c,597)
    c.setFont('SpatialSans',9);c.setFillColor(colors.HexColor(MUTED))
    c.drawString(48,24,'StormSignal  /  Spatial freshness audit  /  Real SEVIR scenes, simulated faults')
    c.drawRightString(912,24,f'{page} / {total}')

def fig(c,name,x,top,width):
    from PIL import Image
    path=ROOT/'figures'/name
    with Image.open(path) as im: iw,ih=im.size
    height=width*ih/iw
    c.drawImage(str(path),x,H-top-height,width=width,height=height,mask='auto')
    return top+height

def draw_pages(c, start_page=1, total_pages=5):
    """Append five complete 960x640 pages, calling showPage after each."""
    base(c,start_page,total_pages,'The same freshness can hide different losses',
         'A matched experiment on 200 radar scenes asks where old observations do the most damage.')
    txt(c,'High-echo cells absent from the displayed mosaic',48,151,840,20,26,'SpatialBold')
    txt(c,'Input-information diagnostic at issue time, not a forecast miss rate',48,184,840,12,17,color=MUTED)
    for i,(label,value,color) in enumerate([('Front-targeted patch',20.6,ORANGE),('Random placement',10.2,MUTED),('Quiet-region patch',1.3,TEAL)]):
        top=222+i*57
        txt(c,label,48,top+4,200,14)
        c.setFillColor(colors.HexColor(color));c.rect(263,H-top-30,value/25*470,30,fill=1,stroke=0)
        txt(c,f'{value:.1f}%',275+value/25*470,top+1,120,20,27,'SpatialBold',color)
    rule(c,403)
    txt(c,'19.3 percentage points more omitted',48,425,510,22,29,'SpatialSerif')
    txt(c,'Front minus quiet: 95% interval 17.8 to 21.2. Each mosaic has identical age counts, stale coverage and patch geometry. A single average-age badge cannot distinguish them.',48,466,510,14,20)
    txt(c,'What counts as a high echo?',610,425,302,15,21,'SpatialBold')
    txt(c,'Any native SEVIR VIL pixel ≥133 in a pooled 4 × 4 block. Omission is measured against genuine issue-time high echoes. Placement targets a pre-issue front proxy, so this direction is partly expected.',610,458,302,12,18)
    txt(c,'Source: saved spatial audit results, horizontal patch; 200 scenes on 113 UTC days. Paired day-bootstrap intervals are descriptive and unadjusted.',48,555,864,10,14,color=MUTED)
    c.showPage()

    base(c,start_page+1,total_pages,'Change the placement, keep the ages fixed',
         'Front, quiet and random placements share the same footprint shape, stale area and temporal seams.')
    txt(c,'The matched comparison',48,156,280,20,27,'SpatialSerif')
    txt(c,'87.5% fresh<br/>6.25% 15 minutes old<br/>6.25% 30 minutes old',48,203,270,18,29,'SpatialBold',TEAL)
    txt(c,'Mean age: 2.8125 minutes.<br/>Maximum age: 30 minutes.<br/>One 24 × 48-cell patch; 168 temporal seam edges.',48,312,270,13,20)
    txt(c,'Placements use only genuine observations from 40 and 30 minutes before issue. Ten random translations are averaged within each scene.',48,397,270,13,20)
    txt(c,'The stronger control keeps the patch in place and swaps its 15- and 30-minute-old halves.',48,497,270,14,21,'SpatialBold')
    fig(c,'matched_age_maps.png',352,146,560)
    c.showPage()

    base(c,start_page+2,total_pages,'The age-swap result needs its geometry caveat',
         'Same stale cells, different age arrangement. Frozen CNNs predict high echoes 30 minutes after issue.')
    fig(c,'same_support_control.png',48,143,864)
    rule(c,460)
    txt(c,'Horizontal patch · blind CNN',48,477,408,15,21,'SpatialBold',ORANGE)
    txt(c,'Missed echoes: +2.89 pp [1.70, 4.25]<br/>MAE: -0.0065 [-0.0723, +0.0574]',48,510,408,14,23)
    txt(c,'Vertical patch · blind CNN',504,477,408,15,21,'SpatialBold',TEAL)
    txt(c,'Missed echoes: +0.51 pp [-0.45, 1.58]<br/>MAE: +0.0608 [0.0064, 0.1163]',504,510,408,14,23)
    txt(c,'A miss increase was not established across both orientations. This is not an interaction test; an MAE interval crossing zero is not equivalence.',48,569,864,10,14,color=MUTED)
    c.showPage()

    base(c,start_page+3,total_pages,'Useful evidence, with a deliberately narrow scope',
         'The design isolates age placement. It does not recreate operational radar failures or validate public warnings.')
    txt(c,'What was actually tested',48,155,400,22,28,'SpatialSerif')
    txt(c,'200 reused scenes on 113 UTC days',48,204,400,15,21,'SpatialBold')
    txt(c,'100 storm-source and 100 random-source events from July to November 2019. This is not a new untouched holdout, nor routine operational prevalence.',48,237,400,13,20)
    txt(c,'Frozen models and a fixed target',48,315,400,15,21,'SpatialBold')
    txt(c,'Two original seeds per CNN arm; frozen weights and calibration. Inputs end at frame 24; the +30-minute target is frame 30. No retraining or cutoff tuning.',48,348,400,13,20)
    txt(c,'Saved results, checked provenance',48,426,400,15,21,'SpatialBold')
    txt(c,'All source hashes verified. Clean/global-delay MAE and Brier reproduce within 0.000001. Paired bootstrap uses 2,000 UTC-day draws, averaging seeds and random placements within events.',48,459,400,13,20)
    txt(c,'What limits the interpretation',504,155,408,22,28,'SpatialSerif')
    txt(c,'Synthetic faults; distribution shift',504,204,408,15,21,'SpatialBold')
    txt(c,'Rectangular replay patches are artificial. CNNs learned whole-scene delays, not spatial mosaics. Real outages and timestamp errors need separate tests.',504,237,408,13,20)
    txt(c,'Oracle age; high baseline misses',504,315,408,15,21,'SpatialBold')
    txt(c,'True per-cell age is an oracle when provenance is untrusted. The fixed 0.5 cutoff has high baseline miss rates. High-echo miss rates are not public-warning rates.',504,348,408,13,20)
    txt(c,'Descriptive uncertainty',504,426,408,15,21,'SpatialBold')
    txt(c,'Day clusters can remain correlated. Intervals are unadjusted for multiple comparisons. Seeds, pixels and random placements are not independent weather replicates.',504,459,408,13,20)
    c.showPage()

    base(c,start_page+4,total_pages,'Is this novel? Original work, not a first-ever claim',
         'Spatial age already has a research history. The contribution here is a specific matched stress test.')
    txt(c,'The candidate contribution',48,153,406,22,29,'SpatialSerif')
    txt(c,'Hold the age histogram, coverage, geometry and seam count equal; vary placement; then swap ages on the same support and evaluate downstream frozen CNNs.',48,200,406,15,23)
    txt(c,'This is original exploratory work in this project. No verified first-ever novelty is claimed. The negative orientation sensitivity is part of the finding, not a detail to hide.',48,304,406,14,21)
    txt(c,'Why care?',48,409,406,22,29,'SpatialSerif')
    txt(c,'Preserve spatial ages and examine overlap with evolving weather. Check high-echo outcomes separately from average image error. Next: a new holdout, realistic age logs and repair baselines.',48,453,406,14,21)
    txt(c,'The closest context',504,153,408,22,29,'SpatialSerif')
    txt(c,'<b>Reeves, AMS 2017.</b> Built MRMS per-pixel age mosaics and compared latency with reflectivity change. Spatial age matters is not a new discovery. <link href="https://ams.confex.com/ams/97Annual/webprogram/Paper306788.html" color="#087f79">Read the AMS abstract ↗</link>',504,200,408,13,20)
    txt(c,'<b>RadarFill, 2026 preprint.</b> Studies structured spatial missingness and downstream nowcasting. It fills gaps rather than permuting stale ages. <link href="https://arxiv.org/html/2611.04768v1" color="#087f79">Read the preprint ↗</link>',504,311,408,13,20)
    txt(c,'<b>Data and reproduction.</b> <link href="https://registry.opendata.aws/sevir/" color="#087f79">SEVIR open data</link>; Veillette, Samsi and Mattioli (NeurIPS 2020). The companion folder retains the frozen protocol, code, weights, metrics and source figures.',504,411,408,13,20)
    txt(c,'NTSB SA-017 is motivation only. This study provides no aviation guidance and establishes no human or operational warning benefit.',504,513,408,11,17,color=MUTED)
    c.showPage()

if __name__ == '__main__':
    c=canvas.Canvas(str(OUT),pagesize=(W,H),pageCompression=1)
    c.setTitle('StormSignal: spatial freshness stress audit')
    c.setAuthor('StormSignal')
    draw_pages(c)
    c.save()
    print(OUT)
