from pathlib import Path
import numpy as np,pandas as pd,matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.colors import ListedColormap,BoundaryNorm
ROOT=Path(__file__).resolve().parent
plt.rcParams.update({'font.family':'DejaVu Sans','font.size':10,'axes.spines.top':False,'axes.spines.right':False,'axes.labelcolor':'#183145','text.color':'#183145','axes.titleweight':'bold','figure.facecolor':'#FAFBFC','axes.facecolor':'#FAFBFC','savefig.facecolor':'#FAFBFC','svg.fonttype':'none'})
S=pd.read_csv(ROOT/'results/summary.csv');D=pd.read_csv(ROOT/'results/paired_day_bootstrap.csv')
S=S.query("subgroup=='all' and orientation=='horizontal'");D=D.query("subgroup=='all' and orientation=='horizontal'")
COLORS=['#007D78','#6C8194','#C65F17'];labels=['Quiet region','Random location','Front proxy'];keys=['quiet','random','front']
def save(fig,name):
 fig.savefig(ROOT/'figures'/f'{name}.png',dpi=200,bbox_inches='tight');fig.savefig(ROOT/'figures'/f'{name}.svg',bbox_inches='tight');plt.close(fig)
fig,ax=plt.subplots(1,2,figsize=(11,4.2),gridspec_kw={'width_ratios':[1,1.25]})
a=S.query("model=='mosaic'").set_index('placement');v=[a.loc[k,'miss_fraction']*100 for k in keys]
ax[0].bar(labels,v,color=COLORS,width=.6);ax[0].set_ylim(0,25);ax[0].set_ylabel('Actual issue-time high-echo cells omitted (%)');ax[0].set_title('Same freshness summary, different missing echoes',loc='left',fontsize=11)
for i,n in enumerate(v):ax[0].text(i,n+.6,f'{n:.1f}%',ha='center',fontweight='bold')
models=['persistence','blind_translation','replay_blind','trusted_age'];names=['Persistence','Blind translation','Blind CNN','Trusted-age CNN']
for i,(m,n) in enumerate(zip(models,names)):
 r=D.query("model==@m and contrast=='front minus quiet' and metric=='miss_fraction'").iloc[0]
 ax[1].errorbar(r.point*100,i,xerr=np.array([[r.point-r.ci_low],[r.ci_high-r.point]])*100,fmt='o',color='#C65F17' if m!='trusted_age' else '#007D78',capsize=4,ms=7)
ax[1].set_yticks(range(4),names);ax[1].invert_yaxis();ax[1].set_xlim(0,11);ax[1].axvline(0,color='#BCC5CC');ax[1].set_xlabel('Extra missed +30-minute high echoes (percentage points)');ax[1].set_title('Front-targeted versus quiet-region faults',loc='left',fontsize=11)
fig.text(.01,-.04,'200 SEVIR scenes | Identical 12.5% stale area, age counts, patch shape and seams | Simulated faults\nBars: pooled issue-time omissions. Dots: paired forecast differences, 95% UTC-day bootstrap intervals (113 days).',fontsize=9)
fig.tight_layout(w_pad=3);save(fig,'spatial_freshness_results')

fig,ax=plt.subplots(1,2,figsize=(11,3.6))
for j,metric in enumerate(['miss_fraction','mae']):
 for i,(m,o) in enumerate([('replay_blind','horizontal'),('replay_blind','vertical'),('trusted_age','horizontal'),('trusted_age','vertical')]):
  all_d=pd.read_csv(ROOT/'results/paired_day_bootstrap.csv')
  r=all_d.query("subgroup=='all' and orientation==@o and model==@m and contrast=='front minus front_age_swap' and metric==@metric").iloc[0];scale=100 if j==0 else 1
  ax[j].errorbar(r.point*scale,i,xerr=np.array([[r.point-r.ci_low],[r.ci_high-r.point]])*scale,fmt='o',color=['#C65F17','#9BA7B0','#007D78','#6C8194'][i],capsize=5,ms=8)
 ax[j].axvline(0,color='#8D9CA8',ls='--');ax[j].set_yticks([0,1,2,3],['Blind / horizontal','Blind / vertical','Trusted / horizontal','Trusted / vertical']);ax[j].set_ylim(3.6,-.6)
 ax[j].set_xlabel(['Extra missed high echoes (percentage points)','Difference in all-domain MAE (encoded VIL units)'][j]);ax[j].set_title(['High-echo misses by patch orientation','Average image error tells a different story'][j],loc='left',fontsize=11)
fig.text(.01,-.06,'Same stale footprint; only swap its 15- and 30-minute-old halves. Horizontal is primary; vertical is sensitivity.\nDots are two-seed averages, with paired 95% UTC-day bootstrap intervals. These are exploratory, unadjusted intervals.',fontsize=9)
fig.tight_layout(w_pad=3);save(fig,'same_support_control')

with np.load(ROOT/'results/predetermined_example.npz') as z:data={k:z[k] for k in z.files}
fig,ax=plt.subplots(2,3,figsize=(10.2,7.4),layout='constrained')
cm=ListedColormap(['#ECF1F4','#E6B368','#C65F17']);norm=BoundaryNorm([-.1,7.5,22.5,40],3)
for i,(k,name) in enumerate([('front','Front-targeted'),('quiet','Quiet-region'),('random','One random placement')]):
 im=ax[0,i].imshow(data[f'age_{k}'],cmap=cm,norm=norm);ax[0,i].contour(data['front_proxy'],levels=[float(data['front_proxy'].max()*.35)],colors='#007D78',linewidths=.7);ax[0,i].set_title(name+' age map',fontsize=11)
 ax[1,i].imshow(data[f'mosaic_{k}'],vmin=0,vmax=180,cmap='viridis'); # Plot pooled mean only; high-echo metric uses separate native-max labels.
 age=data[f'age_{k}'];ax[1,i].contour(age>0,levels=[.5],colors='white',linewidths=.8);ax[1,i].set_title('Simulated issue-time mosaic',fontsize=10)
 for j in [0,1]:ax[j,i].set_xticks([]);ax[j,i].set_yticks([])
c=fig.colorbar(im,ax=ax[0,:],location='bottom',fraction=.055,pad=.02,ticks=[0,15,30]);c.set_label('True source age at issue (minutes). Teal outline: pre-issue front proxy.')
from matplotlib.cm import ScalarMappable
c=fig.colorbar(ScalarMappable(norm=plt.Normalize(0,180),cmap='viridis'),ax=ax[1,:],location='bottom',fraction=.055,pad=.02);c.set_label('Mean encoded VIL, not rainfall rate (display clipped at 180)')
fig.suptitle('Equal ages and area. Only their location changes.',x=.02,ha='left',fontweight='bold',fontsize=15)
fig.text(.02,-.035,f"Predetermined example: {data['id']}. First chronological storm scene with a moving-core proxy; not chosen for outcome.\nAll age maps: 87.5% fresh, 6.25% 15 minutes old, 6.25% 30 minutes old. Placement uses only issue-40/-30 minutes.",fontsize=9)
save(fig,'matched_age_maps')
