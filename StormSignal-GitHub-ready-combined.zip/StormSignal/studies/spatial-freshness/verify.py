from pathlib import Path
import pandas as pd,numpy as np,json,hashlib
from spatial_audit import audit_protocol
ROOT=Path(__file__).resolve().parent
audit_protocol()
a=pd.read_csv(ROOT/'results/event_statistics.csv');old=pd.read_csv(ROOT/'reference/original_metrics.csv')
assert a.id.nunique()==200
assert a.shape[0]==42000,(a.shape,'Expected200events*2orientations*15conditions*7model/seed records')
assert len(json.loads((ROOT/'data/restoration_audit.json').read_text()))==200
assert (ROOT/'PROTOCOL_FROZEN.sha256').read_text().split()[0]==hashlib.sha256((ROOT/'PROTOCOL_FROZEN.md').read_bytes()).hexdigest()
checks=[]
for model in ['replay_blind','trusted_age']:
 for seed in [17,29]:
  for placement,delay in [('clean',0),('global_30',30)]:
   r=a.query('orientation=="horizontal" and model==@model and seed==@seed and placement==@placement');o=old.query('model==@model and seed==@seed and delay_minutes==@delay').iloc[0]
   for metric in ['mae','brier']:
    diff=r[metric].mean()-o[metric];assert abs(diff)<2e-5
    checks.append(dict(model=model,seed=seed,placement=placement,metric=metric,new=r[metric].mean(),original=o[metric],absolute_difference=abs(diff)))
pd.DataFrame(checks).to_csv(ROOT/'results/original_replication_check.csv',index=False)
print('PASS: causal protocol, 200 events, 42,000 statistics rows, 200 source verifications, frozen protocol hash, 16 original-score restoration checks.')
