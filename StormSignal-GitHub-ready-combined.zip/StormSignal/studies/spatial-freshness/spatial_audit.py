"""Reproducible causal matched age-mosaic stress audit. No fitting or test tuning."""
from pathlib import Path
import sys,json,hashlib,time,platform
import numpy as np,pandas as pd
from scipy.ndimage import shift,gaussian_filter
from scipy.special import expit
ROOT=Path(__file__).resolve().parent;SRC=ROOT/'reference'
sys.path.insert(0,str(SRC/'src'))
SEED=20261112;RANDOM_REPEATS=10

def motion(a,b):
 cross=np.fft.fft2(b)*np.conj(np.fft.fft2(a)); cross/=np.maximum(abs(cross),1e-8)
 y,x=np.unravel_index(np.argmax(np.fft.ifft2(cross).real),a.shape)
 if y>a.shape[0]//2:y-=a.shape[0]
 if x>a.shape[1]//2:x-=a.shape[1]
 return np.clip([y,x],-8,8).astype(float)/2

def translate(a,v,steps):return shift(a.astype(float),np.array(v)*steps,order=1,mode='constant',cval=0,prefilter=False)

def placement_scores(mean,high):
 # The API deliberately only accepts common observed frames16 and18.
 assert mean.shape==(2,96,96) and high.shape==(2,96,96)
 v=motion(mean[0],mean[1]); h=gaussian_filter(high[1].astype(float),1)
 projected=translate(h,v,6); previous=translate(h,v,4)
 front=np.maximum(projected-previous,0)+.1*projected
 activity=gaussian_filter(mean.mean(axis=0)/254+high[1].astype(float),1)+translate(mean[1]/254,v,6)+projected
 return front,activity,v

def candidates(orientation):
 sy,sx=(4,8) if orientation=='horizontal' else (8,4)
 maps=[]
 for ty in range(1,16-sy):
  for tx in range(1,16-sx):
   a=np.zeros((96,96),np.int8);a[ty*6:(ty+sy)*6,tx*6:(tx+sx)*6]=3
   if orientation=='horizontal':a[ty*6:(ty+sy)*6,(tx+sx//2)*6:(tx+sx)*6]=6
   else:a[(ty+sy//2)*6:(ty+sy)*6,tx*6:(tx+sx)*6]=6
   maps.append(a)
 return np.stack(maps)

CANDIDATES={o:candidates(o) for o in ['horizontal','vertical']}
def placements(mean,high,event_id,orientation):
 front,activity,v=placement_scores(mean,high); a=CANDIDATES[orientation]
 front_i=int(np.argmax((a*front).sum(axis=(1,2))));quiet_i=int(np.argmin((a*activity).sum(axis=(1,2))))
 seed=int.from_bytes(hashlib.sha256((event_id+orientation+str(SEED)).encode()).digest()[:8],'little')
 rng=np.random.default_rng(seed);rand=rng.integers(0,len(a),RANDOM_REPEATS)
 swap=a[front_i].copy(); swap[a[front_i]==3]=6;swap[a[front_i]==6]=3
 result={'front':a[front_i],'quiet':a[quiet_i],'front_age_swap':swap}
 result.update({f'random_{i}':a[int(j)] for i,j in enumerate(rand)})
 return result,dict(motion_y=v[0],motion_x=v[1],moving_core=bool(np.any(high[1]) and np.any(v)),
   preissue_high_count=int(high[1].sum()),front_candidate=front_i,quiet_candidate=quiet_i),front,activity

def corrupt(mean,high,age,arm):
 # mean/high contain ONLY frames13..24, never target30.
 last=11-age; t=np.arange(12)[:,None,None];indices=np.minimum(t,last[None]); yy,xx=np.indices(age.shape)
 m=mean[indices,yy[None],xx[None]]/254; h=high[indices,yy[None],xx[None]].astype(np.float32)
 mask=(t<=last[None]).astype(np.float32); ages=np.maximum(t-last[None],0).astype(np.float32)/6
 if arm=='replay_blind':mask=np.ones_like(mask);ages=np.zeros_like(ages)
 return np.concatenate([m,h,mask,ages],axis=0).astype(np.float32)

def stat(y,h,p,q,rawq=None):
 h=h.astype(bool);yes=q>=.5; err=np.abs(p-y)
 return dict(mae=float(err.mean()),brier=float(((q-h)**2).mean()),
  raw_brier=float((((q if rawq is None else rawq)-h)**2).mean()),
  tp=float(np.sum(yes&h)),fp=float(np.sum(yes&~h)),fn=float(np.sum(~yes&h)),
  high_abs_error=float(err[h].sum()),positives=float(h.sum()),cells=float(h.size))

def audit_protocol():
 checks={}
 for o,a in CANDIDATES.items():
  hist=np.array([[(m==d).sum() for d in [0,3,6]] for m in a]);assert np.all(hist==[8064,576,576])
  boundaries=[int(np.sum(m[1:]!=m[:-1])+np.sum(m[:,1:]!=m[:,:-1])) for m in a]
  assert len(set(boundaries))==1
  # Count external and internal temporal seams, excluding image border.
  checks[o]={'candidates':len(a),'histogram_cells':hist[0].tolist(),'seam_edges':boundaries[0]}
 rng=np.random.default_rng(7);m=rng.uniform(0,254,(49,96,96)).astype(np.float32);h=m>133
 p0,_,_,_=placements(m[[16,18]],h[[16,18]],'test','horizontal')
 changed=m.copy();changed[19:]=rng.uniform(0,254,changed[19:].shape)
 p1,_,_,_=placements(changed[[16,18]],(changed>133)[[16,18]],'test','horizontal')
 assert all(np.array_equal(p0[k],p1[k]) for k in p0)
 assert np.array_equal(p0['front']>0,p0['front_age_swap']>0)
 a=p0['front'];x=corrupt(m[13:25],h[13:25],a,'trusted_age');last=24-a;yy,xx=np.indices(a.shape)
 assert np.allclose(x[11]*254,m[last,yy,xx],atol=1e-4)
 assert np.array_equal(x[23].astype(bool),h[last,yy,xx])
 clean=corrupt(m[13:25],h[13:25],np.zeros((96,96),np.int8),'trusted_age')
 assert np.allclose(clean[:12]*254,m[13:25],atol=1e-4)
 assert np.all(clean[24:36]==1) and np.all(clean[36:]==0)
 # Changed postissue target cannot affect any encoded input.
 future=m.copy();future[25:]=0
 assert np.array_equal(x,corrupt(future[13:25],h[13:25],a,'trusted_age'))
 checks.update(placement_uses_only_frames_16_18=True,postissue_input_invariance=True,clean_equivalence=True,
 source_index_correct=True,same_support_swap=True,status='passed')
 (ROOT/'results/protocol_tests.json').write_text(json.dumps(checks,indent=2));return checks

def run():
 import torch
 from weather_resilience.models import TinyNowcaster
 torch.set_num_threads(4);torch.set_num_interop_threads(2)
 audit_protocol();rows=pd.read_csv(ROOT/'data/manifest.csv');models={};cal={}
 for arm in ['replay_blind','trusted_age']:
  for seed in [17,29]:
   k=(arm,seed);model=TinyNowcaster();saved=torch.load(SRC/'models'/f'{arm}_{seed}.pt',map_location='cpu',weights_only=False)
   model.load_state_dict(saved['state_dict']);model.eval();models[k]=model
   cal[k]=json.loads((SRC/'models'/f'{arm}_{seed}_calibration.json').read_text())
 records=[];design=[];start=time.time();example_saved=False
 for num,row in enumerate(rows.itertuples(),1):
  with np.load(ROOT/'data/events'/f'{row.id}.npz') as f: m=f['mean'].astype(np.float32);h=f['high']
  common=dict(id=row.id,day=row.issue_time_utc[:10],source=row.source)
  for orientation in ['horizontal','vertical']:
   maps,characteristics,front,activity=placements(m[[16,18]],h[[16,18]],row.id,orientation)
   design.append(dict(**common,orientation=orientation,**characteristics))
   v=[characteristics['motion_y'],characteristics['motion_x']]
   maps.update(clean=np.zeros((96,96),np.int8),global_30=np.full((96,96),6,np.int8))
   keys=list(maps)
   trusted=np.stack([corrupt(m[13:25],h[13:25],maps[k],'trusted_age') for k in keys])
   for i,k in enumerate(keys):
    p=trusted[i,11]*254;q=trusted[i,23]
    base=dict(**common,orientation=orientation,placement=k,seed=0)
    records.append(dict(**base,model='mosaic',stage='input',**stat(m[24],h[24],p,q)))
    records.append(dict(**base,model='persistence',stage='forecast',**stat(m[30],h[30],p,q)))
    records.append(dict(**base,model='blind_translation',stage='forecast',**stat(m[30],h[30],translate(p,v,6),translate(q,v,6))))
   for (arm,seed),model in models.items():
    xx=trusted.copy()
    if arm=='replay_blind':xx[:,24:36]=1;xx[:,36:]=0
    with torch.inference_mode():yp,logit=model(torch.from_numpy(xx));yp=yp.numpy()*254;logit=logit.numpy()
    raw=expit(logit);q=expit(logit*cal[(arm,seed)]['slope']+cal[(arm,seed)]['intercept'])
    for i,k in enumerate(keys):
     records.append(dict(**common,orientation=orientation,placement=k,model=arm,seed=seed,stage='forecast',**stat(m[30],h[30],yp[i],q[i],raw[i])))
   if not example_saved and row.source=='storm' and characteristics['moving_core'] and orientation=='horizontal':
    np.savez_compressed(ROOT/'results/predetermined_example.npz',id=row.id,mean_common=m[18],mean_issue=m[24],mean_target=m[30],high_issue=h[24],high_target=h[30],front_proxy=front,activity=activity,age_front=maps['front']*5,age_quiet=maps['quiet']*5,age_random=maps['random_0']*5,mosaic_front=trusted[keys.index('front'),11]*254,mosaic_quiet=trusted[keys.index('quiet'),11]*254,mosaic_random=trusted[keys.index('random_0'),11]*254)
    example_saved=True
  if num%10==0:
   pd.DataFrame(records).to_csv(ROOT/'results/event_statistics.csv',index=False)
   pd.DataFrame(design).to_csv(ROOT/'results/placement_manifest.csv',index=False)
   print(f'{num}/{len(rows)} events elapsed {time.time()-start:.1f}s',flush=True)
 pd.DataFrame(records).to_csv(ROOT/'results/event_statistics.csv',index=False)
 pd.DataFrame(design).to_csv(ROOT/'results/placement_manifest.csv',index=False)
 config=dict(events=len(rows),days=rows.issue_time_utc.str[:10].nunique(),runtime_seconds=time.time()-start,random_repeats=RANDOM_REPEATS,seed=SEED,python=platform.python_version(),numpy=np.__version__,torch=torch.__version__,protocol_sha256=hashlib.sha256((ROOT/'PROTOCOL_FROZEN.md').read_bytes()).hexdigest(),source='SEVIR public byte-range restoration with original SHA256 verification',test_reuse='Exploratory stress audit on previously inspected test cohort',models='Frozen original global-delay-trained CNNs; spatial distribution shift; original calibration frozen')
 (ROOT/'results/run_manifest.json').write_text(json.dumps(config,indent=2));print(json.dumps(config,indent=2),flush=True)

if __name__=='__main__':
 if '--test-only' in sys.argv: print(json.dumps(audit_protocol(),indent=2))
 else:run()
