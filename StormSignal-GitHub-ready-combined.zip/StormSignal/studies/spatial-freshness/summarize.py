from pathlib import Path
import numpy as np,pandas as pd,json
ROOT=Path(__file__).resolve().parent
COLS=['mae','brier','raw_brier','tp','fp','fn','high_abs_error','positives','cells']

def measure(a):
 # a rows event statistics, or aggregate shape(bootstrap,event-statistic).
 mae,brier,raw,tp,fp,fn,he,pos,n=np.moveaxis(a,-1,0)
 return dict(mae=mae,brier=brier,raw_brier=raw,csi=tp/np.maximum(tp+fp+fn,1e-15),miss_fraction=fn/np.maximum(pos,1e-15),false_alarm_ratio=fp/np.maximum(tp+fp,1e-15),high_echo_mae=he/np.maximum(pos,1e-15))

def run():
 df=pd.read_csv(ROOT/'results/event_statistics.csv');design=pd.read_csv(ROOT/'results/placement_manifest.csv')
 df['placement']=df.placement.str.replace(r'random_\d+','random',regex=True)
 # Average random replicates and the two CNN seeds WITHIN each scene, keeping one weather-event observation.
 df=df.groupby(['id','day','source','orientation','model','stage','placement'],as_index=False)[COLS].mean()
 df=df.merge(design[['id','orientation','moving_core']],on=['id','orientation'],validate='many_to_one')
 df.to_csv(ROOT/'results/event_statistics_collapsed.csv',index=False)
 summaries=[];comparisons=[]
 for subgroup in ['all','moving_core','storm','random_source']:
  ss=df if subgroup=='all' else df[df.moving_core] if subgroup=='moving_core' else df[df.source==('storm' if subgroup=='storm' else 'random')]
  for (orientation,model,stage),rows in ss.groupby(['orientation','model','stage']):
   for placement,group in rows.groupby('placement'):
    v=measure(group[COLS].mean(axis=0).values)
    summaries.append(dict(subgroup=subgroup,orientation=orientation,model=model,stage=stage,placement=placement,n_events=len(group),n_days=group.day.nunique(),**{k:float(a) for k,a in v.items()}))
   for left,right in [('front','quiet'),('front','random'),('front','front_age_swap'),('front','clean'),('quiet','clean'),('random','clean'),('global_30','front')]:
    a=rows[rows.placement==left].set_index('id').sort_index();b=rows[rows.placement==right].set_index('id').sort_index();assert a.index.equals(b.index)
    # Day-cluster bootstrap with same resampled days for both matched placements.
    days=sorted(a.day.unique());day_counts=a.groupby('day').size().reindex(days).values
    aa=a.groupby('day')[COLS].sum().reindex(days).values;bb=b.groupby('day')[COLS].sum().reindex(days).values
    rng=np.random.default_rng(20261112);idx=rng.integers(0,len(days),(2000,len(days)));den=day_counts[idx].sum(axis=1)
    av=measure(aa[idx].sum(axis=1)/den[:,None]);bv=measure(bb[idx].sum(axis=1)/den[:,None])
    pointa=measure(a[COLS].mean().values);pointb=measure(b[COLS].mean().values)
    for metric in pointa:
     delta=av[metric]-bv[metric]
     comparisons.append(dict(subgroup=subgroup,orientation=orientation,model=model,stage=stage,contrast=f'{left} minus {right}',metric=metric,point=float(pointa[metric]-pointb[metric]),ci_low=float(np.quantile(delta,.025)),ci_high=float(np.quantile(delta,.975)),n_events=len(a),n_days=len(days)))
 pd.DataFrame(summaries).to_csv(ROOT/'results/summary.csv',index=False)
 pd.DataFrame(comparisons).to_csv(ROOT/'results/paired_day_bootstrap.csv',index=False)
 print(pd.DataFrame(summaries).query("subgroup=='all' and orientation=='horizontal'")[['model','placement','mae','brier','csi','miss_fraction']].to_string(index=False))
 print('\nPRIMARY CONTRASTS\n',pd.DataFrame(comparisons).query("subgroup=='all' and orientation=='horizontal' and contrast=='front minus quiet' and metric in ['mae','brier','csi','miss_fraction']").to_string(index=False))
if __name__=='__main__':run()
