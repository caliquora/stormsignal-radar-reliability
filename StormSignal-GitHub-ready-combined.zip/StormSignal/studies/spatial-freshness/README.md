# StormSignal: spatial freshness stress audit

**Executed 2026-11-11. Real SEVIR radar observations; simulated input faults. Exploratory follow-on, not operational warning validation.**

## The finding in plain English

Two radar feeds can report the same stale coverage, average observation age and maximum age yet lose very different weather information. On 200 scenes, putting a fixed stale patch near a causally inferred moving-front proxy omitted 20.6% of actual issue-time high-echo cells, compared with 1.3% when the identical patch was placed in a quiet region. Random placement was intermediate at 10.2%. The paired front-minus-quiet difference was 19.3 percentage points (95% day-bootstrap interval 17.8 to 21.2).

The more subtle control keeps the stale footprint in the **same location** and swaps its 15- and 30-minute-old halves. For the primary horizontal patch, the blind CNN missed 2.89 percentage points more future high echoes (interval 1.70 to 4.25), while its average image error changed by -0.0065 encoded VIL units (interval -0.0723 to +0.0574). Average image error did not resolve a change in the high-echo target. An interval crossing zero does not prove equivalence.

**Important sensitivity:** the blind CNN age-swap miss effect shrinks to +0.51 points for a vertical patch (interval -0.45 to +1.58). Its vertical MAE increases by 0.0608 (0.0064 to 0.1163). The forecast-miss increase was not established across both tested orientations. These intervals are not an orientation interaction test; the result is not universal or uniformly robust. The broader front-versus-quiet damage does persist in both orientations.

## Why it is useful

A single freshness number cannot distinguish these constructed cases. The practical direction is to retain spatial observation ages and inspect their overlap with evolving weather, while evaluating high-echo outcomes separately from all-domain image error. The work does **not** establish the best repair strategy, a hidden-freeze detector, a validated alert threshold, or better outcomes for people. True per-cell age is an oracle if it is unavailable or unreliable operationally.

## What is new here

This follow-on executed a causal, matched spatial age-placement stress test that was absent from the original whole-scene-delay study. It fixes age counts, stale coverage, patch geometry and seam length; includes random placements, same-support age swaps, two CNN seeds and an orientation sensitivity check; and publishes the resulting evidence, including negative sensitivity results. It does not claim that stale radar is a newly discovered problem, that spatial age maps are unprecedented, or that this is the first such experiment anywhere.

## Results at fixed +30-minute target

Primary horizontal patch. The miss-rate differences use pooled positive high-echo cells; percentage points, not relative percent. Intervals are paired UTC-day bootstrap intervals.

| Forecaster | Extra missed high echoes, front vs quiet | All-domain MAE increase, front vs quiet |
|---|---:|---:|
| Persistence | 5.27 pp [4.46, 6.12] | 0.867 [0.742, 0.983] |
| Blind global translation | 7.09 pp [6.11, 8.12] | 1.075 [0.921, 1.219] |
| Frozen blind CNN | 6.68 pp [5.22, 8.15] | 0.357 [0.279, 0.431] |
| Frozen trusted-age CNN | 8.63 pp [7.14, 10.05] | 0.382 [0.304, 0.451] |

These within-model differences do not mean one architecture is globally better. The trusted-age model has a different clean baseline; spatial faults are out of distribution for both models. Full MAE, raw/calibrated Brier, pooled CSI, miss rate, false-alarm ratio and high-echo conditional MAE are in results/summary.csv. All prespecified paired contrasts and source/moving-core subgroups are in results/paired_day_bootstrap.csv. Baseline continuous scores are heuristic scores, not calibrated probabilities. Their Brier columns are raw score diagnostics only.

## Protocol and provenance

- Original cohort: 200 events, 100 storm-source and 100 random-source, spanning 113 UTC days from July 8 to November 30, 2019. No scene was dropped. The pre-issue moving-core subgroup has 137 events; the other 63 remain in the main result.
- SEVIR VIL: 49 frames every 5 minutes, 384 x 384 native pixels. Mean-pool 4 x 4 blocks to 96 x 96 cells for encoded VIL. Separately label a block high-echo when any native pixel is >=133. Missing sentinel 255 is rejected, not converted to weather or clear sky.
- Inputs are frames 13 through 24, issue frame 24, target frame 30 (+30 min). Placements use ONLY common genuine frames 16 and 18, at issue-40/-30 min. Motion is a clipped global phase-correlation shift; the projected front score is a deliberately simple proxy, not an observed future front or an estimated growth law.
- Each matched mosaic is 87.5% fresh, 6.25% 15 min-old and 6.25% 30 min-old: exactly 8064/576/576 cells, all-domain mean age 2.8125 min, maximum age 30 min. It has one interior 24 x 48 rectangle, or 48 x 24 in the sensitivity run, with equal-age halves and 168 temporal seam edges.
- Front and quiet placements optimize different pre-issue scores over 77 translations of the same geometry. Ten deterministic random translations are averaged within each event. Identical placements/ties are retained. Same-support control swaps ages at the same stale cells.
- Per-cell terminal replay holds each stale cell fixed after its last genuine source time. Both image and historical high-echo channels are transformed consistently. No corruptor receives the future target; no placement scorer receives frames after 18.
- Two CNN arms, two original seeds 17/29, frozen weights and frozen original calibration. No retraining, calibration fit, cutoff tuning or test-based model selection. The 0.5 cutoff is fixed and has high baseline miss rates; miss rates are not public-warning rates.
- Persistence and blind global translation are simple references. Translation uses the same causal frame 16/18 motion for every placement and treats the mosaic as current. It is not dense optical flow and does not correct per-cell ages. A global 30 min-old reference is unmatched, not an equal-age control.
- Bootstrap 2000 draws, seed 20261112, paired by 113 UTCdays. Average both CNN seeds and random placements WITHIN event before resampling. Pixels, seeds and random placements are not independent weather replicates. Day clusters can remain correlated; intervals are descriptive and unadjusted for multiple comparisons.

### Verification actually completed

- Restored all 200 native event ranges from public SEVIR objects, 1,445,068,800 native bytes (1.45 GB decimal); every source SHA-256 matches the original provenance record. Source URLs, byte ranges and ETags are retained. This excludes headers/retries and is not measured total network traffic.
- Tests passed for exact age histograms, equal seam counts, common-history placement, no post-issue dependence, correct source indexing, same-support swap and clean equivalence.
- Clean/global 30 CNN MAE and Brier reproduce the original run in 16 comparisons with maximum absolute difference 0.000000700. This is a numerical restoration/inference check, not independent replication on new weather.
- Actual inference run:200 events, both orientations,15 conditions per orientation including 10 random placements and 2 unmatched references,4 CNN checkpoints; about 98 seconds CPU compute excluding restoration and summary rendering. Reproduction time varies.
- Figures/PDF were rendered and visually inspected. Tests and original replication records are in results/.

## Limitations and next scientific step

This cohort was already inspected in the original study. The protocol was written before this new run restored the arrays, but that does not make the cohort a new untouched holdout. All models were trained with global delays, not spatial mosaics. SEVIR's curated storm/random mixture is not routine operational prevalence. Synthetic rectangular patches omit real radar coverage geometry, outages, partial scans and timestamp errors. A crude early-motion proxy can be wrong. We controlled seam count and geometry, not every interaction between artificial seams, weather and a model's receptive field. Do not infer that real outages preferentially happen at fronts.

A stronger next study would freeze this protocol on a genuinely new period or dataset, use realistic observation coverage and age logs, test several patch sizes/ages and motion regimes, and compare a spatially trained model against synchronization and repair baselines. Real warning or human benefit requires separate prospective evaluation. None of these extensions is claimed executed here.

## Reproduce

Python 3.12 was used. Scientific dependencies: NumPy, pandas, SciPy and CPU PyTorch; plotting also requires Matplotlib, Pillow and ReportLab. See requirements-executed.txt. A CPU PyTorch wheel is available from https://download.pytorch.org/whl/cpu . The brief builder expects DejaVu Sans under /usr/share/fonts/truetype/dejavu; change those font paths on another OS.

1. Install dependencies in an isolated environment. Install CPU PyTorch from its official wheel index.
2. Run `python restore.py`. It fetches ONLY the selected event byte ranges, checks every original source hash and writes compact event tensors under data/events/. It needs public internet access and roughly 80 MB for derived data; nominal native transfers total 1.45 GB. Metadata are included.
3. Run `python spatial_audit.py --test-only`.
4. Run `python spatial_audit.py` to regenerate event sufficient statistics with frozen weights.
5. Run `python summarize.py` and `python make_figures.py`.
6. Run `python verify.py`; optionally run `python build_brief.py`.

The included results can be inspected and figures regenerated without restoring raw events. The package omits data/events/ and the PyTorch installation. Source code and weights are under reference/. PROTOCOL_FROZEN.md and its original SHA-256 preserve the pre-run specification; This README notes the findings rather than rewriting that protocol. Rounded display numbers are not authoritative over CSV precision.

## Files

- StormSignal-spatial-freshness-brief.pdf: five-page designed result, methods, sensitivity, limitations, and novelty brief.
- figures/: PNG and editable SVG charts, including both age-swap orientations and a predetermined example.
- results/event_statistics.csv: all 42,000 event/model/condition records before collapsing seeds/random placements.
- results/event_statistics_collapsed.csv: paired per-event records after collapsing.
- results/summary.csv and paired_day_bootstrap.csv: all results and intervals.
- results/placement_manifest.csv: causal motion, subgroup flags and chosen placements.
- results/predetermined_example.npz: first chronological storm scene with a moving-core proxy, selected without outcomes.
- data/manifest.csv, data/source_objects.json, data/restoration_audit.json: original scene identity and verified restoration.
- reference/: original frozen code, four CNN checkpoints, calibrators, data provenance and original aggregate metrics.

## Sources and licenses

SEVIR, accessed 2026-11-11: https://registry.opendata.aws/sevir/ . Dataset paper: Veillette, Samsi and Mattioli, NeurIPS 2020, https://papers.nips.cc/paper_files/paper/2020/hash/fa78a16157fed00d7a80515818432169-Abstract.html . Public VIL storage is https://sevir.s3.us-west-2.amazonaws.com/ . The registry reports no restrictions on use. Original project code license is retained in reference/LICENSE; this follow-on uses the same license. Dataset rights are separate from code rights. Third-party visualization notices are under licenses/.

## Related work and presentation update

Reeves et al. (AMS 2017) already studied per-pixel MRMS age mosaics and latency versus reflectivity change: https://ams.confex.com/ams/97Annual/webprogram/Paper306788.html. RadarFill (November 2026 preprint) studies structured spatial missingness and downstream nowcasting, using gap filling rather than stale-age permutation: https://arxiv.org/html/2611.04768v1. The specific controlled intervention is original work here; independently established first-ever novelty is not claimed. SEVIR random-source events are intensity-stratified, not an unbiased deployment background population.

The November 11 design revision changes presentation only. Saved scientific evidence, protocol, inference code, and weights are unchanged. Derived figure labels were clarified and the PDF expanded. Current artifact checksums cover the revised presentation.
